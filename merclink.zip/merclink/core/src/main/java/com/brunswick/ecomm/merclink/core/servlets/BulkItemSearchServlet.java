package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractQuickOrderRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@Component(service = Servlet.class, property = { "sling.servlet.methods=POST",
		"sling.servlet.paths=/bin/bulkItemSearchServlet" })

public class BulkItemSearchServlet extends SlingAllMethodsServlet {

	private static final Logger LOG = LoggerFactory.getLogger(BulkItemSearchServlet.class);
	private static final long serialVersionUID = 1L;
	private transient AbstractQuickOrderRetriever retriever;
	String currentPagePath;
	private String sku;
	private String companyNumber;

	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.debug("Entering into doPost() Method.");
		JSONObject requestObj;
		try {
			requestObj = new JSONObject(request.getParameter("data"));
             LOG.info("requestObj=====================" + requestObj );
			currentPagePath = requestObj.get("componentPath").toString();

			sku = requestObj.get("sku").toString();
            LOG.info("sku=====================" + sku );

			companyNumber = requestObj.get("companyNumber").toString();
            LOG.info("companyNumber=====================" + companyNumber );

  
			MagentoGraphqlClient magentoGraphqlClient = CommonUtil.getMagentoGraphqlClient(request, currentPagePath);
			retriever = new AbstractQuickOrderRetriever(magentoGraphqlClient);
			JsonObject resp = null;
			if (retriever != null) {
				resp = retriever.bulkItemSearch(sku,companyNumber);
			}
			if (resp != null) {
				LOG.info("Response=====================" + new Gson().toJson(resp) );
				response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
				response.setContentType("application/json");
				response.getWriter().print(new Gson().toJson(resp));
			}
			
		} catch (JSONException e) {
			LOG.error("Json Exception " + e.getMessage(),e);
		} catch (RuntimeException e) {
			LOG.error("RunTime Exception {}", e.getMessage(),e);
		}
		LOG.debug("Exit from doPost() Method.");
	}

}

