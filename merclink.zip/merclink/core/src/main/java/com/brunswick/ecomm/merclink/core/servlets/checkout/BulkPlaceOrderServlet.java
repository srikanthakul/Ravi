package com.brunswick.ecomm.merclink.core.servlets.checkout;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractBulkOrderRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@Component(service = Servlet.class, property = { "sling.servlet.methods=POST",
		"sling.servlet.paths=/bin/bulkPlaceOrderServlet" })

public class BulkPlaceOrderServlet extends SlingAllMethodsServlet {

	private static final Logger LOG = LoggerFactory.getLogger(BulkPlaceOrderServlet.class);
	private static final long serialVersionUID = 1L;
	private transient AbstractBulkOrderRetriever retriever;
	String currentPagePath;
	private String cart_id;
	private String po_number;
	private String order_comment;
	private String requested_ship_date;
	private String payment_method;
	private String shipping_method;
	private String shipping_cost;
	private String attribute19;
	private String is_dropship;
	private String items_data;

	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.debug("Entering into doPost() Method.");
		JSONObject requestObj;
		try {
			requestObj = new JSONObject(request.getParameter("data"));
			LOG.info("requestObj=====================" + requestObj);
			currentPagePath = requestObj.get("componentPath").toString();

			cart_id = requestObj.get("cart_id").toString();
			po_number = requestObj.get("po_number").toString();
			order_comment = requestObj.get("order_comment").toString();
			requested_ship_date = requestObj.get("requested_ship_date").toString();
			payment_method = requestObj.get("payment_method").toString();
			shipping_method = requestObj.get("shipping_method").toString();
			shipping_cost = requestObj.get("shipping_cost").toString();
			attribute19 = requestObj.get("attribute19").toString();
			is_dropship = requestObj.get("is_dropship").toString();
			items_data = requestObj.get("items_data").toString();

			LOG.info("cart_id=====================" + cart_id);
			LOG.info("po_number=====================" + po_number);
			LOG.info("order_comment=====================" + order_comment);
			LOG.info("requested_ship_date=====================" + requested_ship_date);
			LOG.info("payment_method=====================" + payment_method);
			LOG.info("shipping_method=====================" + shipping_method);
			LOG.info("shipping_cost=====================" + shipping_cost);
			LOG.info("attribute19=====================" + attribute19);
			LOG.info("is_dropship=====================" + is_dropship);
			LOG.info("items_data=====================" + items_data);

			MagentoGraphqlClient magentoGraphqlClient = CommonUtil.getMagentoGraphqlClient(request, currentPagePath);
			retriever = new AbstractBulkOrderRetriever(magentoGraphqlClient);
			JsonObject resp = null;
			if (retriever != null) {
				resp = retriever.placeBulkOrderSingleItem(cart_id, po_number, order_comment, requested_ship_date,
						payment_method, shipping_method, shipping_cost, attribute19, is_dropship, items_data);
			}
			if (resp != null) {
				LOG.info("Response=====================" + new Gson().toJson(resp));
				response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
				response.setContentType("application/json");
				response.getWriter().print(new Gson().toJson(resp));
			}

		} catch (JSONException e) {
			LOG.error("Json Exception " + e.getMessage(), e);
		} catch (RuntimeException e) {
			LOG.error("RunTime Exception {}", e.getMessage(), e);
		}
		LOG.debug("Exit from doPost() Method.");
	}

}
