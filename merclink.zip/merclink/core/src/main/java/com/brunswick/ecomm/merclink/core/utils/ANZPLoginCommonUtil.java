package com.brunswick.ecomm.merclink.core.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.UUID;
import java.util.zip.CRC32;

import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;
import javax.servlet.http.Cookie;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.constants.CommonConstants;
import com.brunswick.ecomm.core.util.CommonUtil;
import com.brunswick.ecomm.core.util.PropertyUtil;
import com.day.cq.dam.api.Asset;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.webservicesupport.Configuration;
import com.day.cq.wcm.webservicesupport.ConfigurationManagerFactory;

public class ANZPLoginCommonUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtil.class);

	public static int daysBetween(Date d1, Date d2) {
		return (int) ((d1.getTime() - d2.getTime()) / (1000 * 60 * 60 * 24));
	}

	public static Resource getSiteConfigPageContentRes(ConfigurationManagerFactory configManagerFctry,
			ResourceResolver adminResourceResolver, Page currentPage) {
		Resource siteConfigRes = null;
		Resource currentPageRes = adminResourceResolver.resolve(currentPage.getPath());
		Configuration configObj = PropertyUtil.getCloudConfigObj(configManagerFctry, adminResourceResolver,
				currentPageRes, "siteconfig");
		if (null != configObj) {
			siteConfigRes = adminResourceResolver.resolve(
					configObj.getPath().concat(CommonConstants.SLASH_STRING).concat(CommonConstants.JCR_CONTENT));
		}

		return siteConfigRes;
	}

	public static String getTokenFromCookie(String cookieName,SlingHttpServletRequest request ) {
		Cookie[] cookies = request.getCookies();
		String defaultValue = "";
		if(cookies !=null) {
		for (int i = 0; i < cookies.length; i++) {
			Cookie cookie = cookies[i];
			if (cookieName.equals(cookie.getName())) {
				LOGGER.error("Cookie value {}", cookie.getValue());
				return (cookie.getValue());
			}
		}
		}
		return (defaultValue);
	}
	
	public static String encode(final String value, final String encType) {
		LOGGER.debug("Entering into encode");
		String encoded = null;
		StringBuilder buf = new StringBuilder();
		try {
			encoded = URLEncoder.encode(value, encType);
			if (encoded == null) {
				LOGGER.error("Unable to get encoded value. encoded var is null. Hence returning empty buf");
				return buf.toString();
			}
			final int length = encoded.length();
			buf = new StringBuilder(length);
			for (int i = 0; i < length; i++) {
				char focus = encoded.charAt(i);
				if (focus == CommonConstants.STAR_CHAR) {
					buf.append(CommonConstants.STAR_ESCAPE_CHAR);
				} else if (focus == CommonConstants.PLUS_CHAR) {
					buf.append(CommonConstants.SPACE_ESCAPE_CHAR1);
				} else if (focus == CommonConstants.PERCENTAGE_CHAR && (i + 1) < length
						&& encoded.charAt(i + 1) == CommonConstants.SEVEN_CHAR
						&& encoded.charAt(i + 2) == CommonConstants.E_CHAR) {
					buf.append(CommonConstants.TILD_CHAR);
					i += 2;
				} else {
					buf.append(focus);
				}
			}
		} catch (UnsupportedEncodingException e) {
			LOGGER.error("UnsupportedEncodingException -{}", e);
		}
		LOGGER.debug("Exit from encode");
		return buf.toString();
	}

	public static String escapeHTML(final String htmlString) {
		LOGGER.debug("Entering into escapeHTML");
		String output = htmlString;
		if (output != null) {
			output = output.replaceAll(CommonConstants.REG_EXPR, CommonConstants.SPACE_STRING)
					.replaceAll(CommonConstants.BACKSLASH_SINGLE_QUOTE, CommonConstants.SINGLE_QUOTE)
					.replaceAll(".html", "").trim();
		}
		LOGGER.debug("Exit from escapeHTML");
		return output;
	}

	public static String decode(String urlParam) {
		LOGGER.debug("Entering into decode");
		try {
			if (StringUtils.isNotBlank(urlParam)) {
				urlParam = URLDecoder.decode(urlParam, "UTF-8");
			}

		} catch (UnsupportedEncodingException e) {
			LOGGER.error("UnsupportedEncodingException - " + e);
		}
		LOGGER.debug("Exit from decode");
		return urlParam;
	}

	public static String format(Calendar date, SimpleDateFormat simpleDateFormat) {
		LOGGER.debug("Entering into format");
		simpleDateFormat.setCalendar(date);
		String dateFormatted = simpleDateFormat.format(date.getTime());
		LOGGER.debug("Exit from format");
		return dateFormatted;
	}

	public static String generateHashValue(final String pagePath) {
		LOGGER.debug("Entering into generateHashValue");
		CRC32 crc32Obj = new CRC32();
		crc32Obj.update(pagePath.getBytes());
		String retVal = Long.toHexString(crc32Obj.getValue());
		if (StringUtils.isBlank(retVal)) {
			retVal = StringUtils.EMPTY;
		}
		LOGGER.debug("Exit from generateHashValue");
		return retVal;
	}

	public static Map<String, String> getListFromStringMap(String[] inputStringArray) {
		LOGGER.debug("Entering into getListFromStringMap");
		Map<String, String> outputStringMap = new HashMap<>();
		if (inputStringArray != null && inputStringArray.length > 0) {
			for (String outputString : inputStringArray) {
				String[] outputStringArray = StringUtils.split(outputString, "~");
				if (outputStringArray != null && outputStringArray.length > 0) {
					outputStringMap.put(outputStringArray[0], outputStringArray[1]);
				}
			}
		}
		LOGGER.debug("Exit from getListFromStringMap");
		return outputStringMap;
	}

	public static String getType(Asset asset) {
		LOGGER.debug("Entering into getType");
		String assetType = StringUtils.EMPTY;
		if (null != asset) {
			String assetName = asset.getName();
			if (StringUtils.isNotBlank(assetName)) {
				assetType = StringUtils.upperCase(StringUtils.substringAfterLast(assetName, CommonConstants.PERIOD));
			}
		}
		LOGGER.debug("Exit from getType");
		return assetType;
	}

	
	public static String formatedDateProperty(Calendar calendar) throws ValueFormatException, RepositoryException {
		LOGGER.debug("Entering into formatedDateProperty");
		String output = "";
		if (calendar != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(CommonConstants.DATE_FORMAT_WITH_OUT_TIME);
			sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
			output = sdf.format(calendar.getTime());
		}
		LOGGER.debug("Exit from formatedDateProperty");
		return output;
	}

	public static Date getDatefromString(String dateInString, String dateFormat) {
		LOGGER.debug("Entering into getDatefromString");
		SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
		Date date = null;
		try {
			date = formatter.parse(dateInString);

		} catch (ParseException e) {
			LOGGER.error("ParseException occoured", e);

		}
		LOGGER.debug("Exit from getDatefromString");
		return date;
	}

	public static boolean writeToDam(ResourceResolver adminResourceResolver, InputStream is, String dirPath,
			String fileName) {
		LOGGER.debug("Entering into writeToDam");
		boolean result = false;

		// Use AssetManager to place the file into the AEM DAM
		com.day.cq.dam.api.AssetManager assetMgr = adminResourceResolver.adaptTo(com.day.cq.dam.api.AssetManager.class);
		String newFile = dirPath.concat(CommonConstants.SLASH_STRING).concat(fileName);
		assetMgr.createAsset(newFile, is, "text/plain", true);
		result = true;

		LOGGER.debug("Exit from writeToDam");
		return result;
	}

	public static String getResponseStringFromFile(ResourceResolver resourceResolver, Resource res) throws IOException {
		LOGGER.debug("Entering into getResponseStringFromFile res");
		// LOGGER.debug("filePath util>>>"+res);
		// LOGGER.debug("resourceResolver util>>>>"+resourceResolver);
		StringWriter writer = new StringWriter();
		InputStream stream = null;

		if (res != null) {
			ValueMap resvm = res.getValueMap();
			if (resvm.containsKey(CommonConstants.JCR_DATA)) {
				stream = (InputStream) resvm.get(CommonConstants.JCR_DATA);
				IOUtils.copy(stream, writer, "UTF-8");
			}
		}
		if (stream != null) {
			stream.close();
		}
		LOGGER.debug("Exit from getResponseStringFromFile res");
		return writer.toString();
	}

	public static String getResponseStringFromFile(ResourceResolver adminResourceResolver, String filePath)
			throws IOException, RepositoryException {
		LOGGER.debug("Entering into getResponseStringFromFile");
		StringWriter writer = new StringWriter();
		InputStream stream = null;

		Resource res = adminResourceResolver
				.getResource(filePath.concat("/jcr:content/renditions/original/jcr:content"));
		if (res != null) {
			ValueMap resvm = res.getValueMap();
			if (resvm.containsKey(CommonConstants.JCR_DATA)) {
				stream = (InputStream) resvm.get(CommonConstants.JCR_DATA);
				IOUtils.copy(stream, writer, "UTF-8");
			}
		}
		if (stream != null) {
			stream.close();
		}
		LOGGER.debug("Exit from getResponseStringFromFile");
		return writer.toString();
	}

	
	public static void closeResourceResolver(ResourceResolver resourceResolver) {
		LOGGER.debug("Entered into closeResourceResolver method");
		if (resourceResolver != null && resourceResolver.isLive()) {
			resourceResolver.close();
		}
		LOGGER.debug("Exited from closeResourceResolver method");
	}

	public static String getUniqueID() {
		return UUID.randomUUID().toString();
	}

	public ANZPLoginCommonUtil() {
		LOGGER.debug("Inside CommonUtil constructor");
	}

}
