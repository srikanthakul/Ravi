package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.Servlet;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.brunswick.ecomm.merclink.core.models.internal.contactus.ContactUsVerifyUserRetriever;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonObject;

@Component(service = Servlet.class,property = {
        Constants.SERVICE_DESCRIPTION + "=Contact Us Verify User Servlet",
        "sling.servlet.methods="+HttpConstants.METHOD_GET, "sling.servlet.paths="
        + "/bin/merclinkcontactUsVerifyUserServlet"
})
public class ContactUsVerifyUserServlet extends SlingAllMethodsServlet{
    private static final Logger LOG=LoggerFactory.getLogger(ContactUsVerifyUserServlet.class);
    protected String RESOURCE_PATH;
    protected transient ContactUsVerifyUserRetriever retriever; 

	private static final long serialVersionUID = 1L;
	@Override
	public void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) {
		PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
		try {
			RESOURCE_PATH = request.getParameter("resourcePath");
			LOG.info("currentPagePath="+RESOURCE_PATH);
			Resource res =  request.getResourceResolver().resolve(RESOURCE_PATH);
			
			//String token = CommonUtil.getTokenFromCookie("customerToken",request);
	        String token = request.getParameter("customerToken");
			List<Header> headers = new ArrayList<>();
			headers.add(new BasicHeader("Authorization",
					"Bearer " + token));
			MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(res,
					pageManager.getPage(res.getPath()), request, headers);
			
			if (magentoGraphqlClient != null) 
			{ 
				retriever = new ContactUsVerifyUserRetriever(magentoGraphqlClient);
			JsonObject magentoresponse=retriever.getResponse();
			  response.setContentType("application/json");
		        response.getWriter().print(magentoresponse);
		        response.setStatus(response.getStatus()); 
		        
			}
		} catch (IOException e) {
			LOG.error(e.getMessage());
		}
		
	}
	

}
