package com.brunswick.ecomm.merclink.core.models.cart;

import com.adobe.cq.commerce.magento.graphql.CartItemInterfaceQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.CartItemPricesQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.CartQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.ProductPriceQueryDefinition;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.cart.retriever.AbstractCartRetriever;
import com.shopify.graphql.support.CustomFieldQueryDefinition;

public class CartRetriever extends AbstractCartRetriever {
    public CartRetriever(MagentoGraphqlClient client) {
        super(client);
    }

    @Override
    protected CartQueryDefinition generateCartQuery() {
    	//
        return q-> q.id().totalQuantity().items(items -> items.id().addCustomObjectField("item_attributes", itemAttributes()).quantity().addCustomObjectField("warehouses", warehouseAttributes())
        		.product(p -> p.name().sku().urlKey().addCustomSimpleField("bupartstatus").priceRange(r -> r.maximumPrice(generatePriceRangeQuery())).addCustomSimpleField("masterpartlowestsellinguomqty").addCustomObjectField("image_data", imageData()).addCustomSimpleField("masterpartprop65code").stockStatus().onConfigurableProduct(cp -> cp.variants(v -> v.attributes(a -> a.code())))
                .image(i -> i.url().label()).thumbnail(t -> t.url()))
                .onConfigurableCartItem(cc -> cc.configurableOptions(co -> co.valueLabel().optionLabel()))
                .quantity()
                .prices(generatePriceQuery()))
        		.appliedCoupons(a -> a.code())
        		.prices(p -> p.subtotalIncludingTax(s->s.value()).subtotalExcludingTax(s->s.value()).grandTotal(g ->g.value().currency()).discounts(d -> d.label().amount(a -> a.value())));    	
    }
    
    private CustomFieldQueryDefinition warehouseAttributes() {
    	return c -> c.addCustomObjectField("warehouse",warehouseItemAttributes()).addCustomSimpleField("quantity");
	}
    
    private CustomFieldQueryDefinition warehouseItemAttributes() {
    	return d -> d.addCustomSimpleField("name");
	}

	private ProductPriceQueryDefinition generatePriceRangeQuery() {
    	return q -> q
                .regularPrice(r -> r
                    .value()
                    .currency())
                .finalPrice(f -> f
                    .value()
                    .currency())
                .discount(d -> d
                    .amountOff()
                    .percentOff());
	}

	protected CartItemInterfaceQueryDefinition generateItemQuery() {
    	return q -> q.quantity().product(i ->i.name().sku());
    }

    protected CustomFieldQueryDefinition itemAttributes() {
    	return c -> c.addCustomSimpleField("backorder_qty").addCustomSimpleField("availability_date").addCustomSimpleField("sale_price").addCustomSimpleField("customer_adjustments").addCustomSimpleField("customer_price").addCustomSimpleField("tier_price");
    }
    
    protected CustomFieldQueryDefinition imageData() {
    	return i -> i.addCustomSimpleField("product_thumbnail");
    }
    

    protected CartItemPricesQueryDefinition generatePriceQuery() {
        return q -> q.price(p -> p.value().currency()).rowTotal(rt -> rt.currency().value())
        		.discounts(d -> d.label().amount(a -> a.value()));
    } 

}
