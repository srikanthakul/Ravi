package com.brunswick.ecomm.merclink.core.models;

import java.util.List;
import java.util.Map;

import org.apache.sling.api.resource.Resource;

import com.brunswick.ecomm.merclink.core.helper.MultifieldHelper;

public interface LoginDetails {
	
	String getAuthorName();
	
	List<Map<String,String>> getMyProfile();

	public List<MultifieldHelper> getLoginDetailsWithNestedMultifield();
}
