package com.brunswick.ecomm.merclink.core.models.retriever;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractCustomRetriever;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractCategoryTreeRetriever;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public class AbstractCategoryTreeRetriever extends AbstractCustomRetriever{
private String queryString;
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractCategoryTreeRetriever.class);

	public AbstractCategoryTreeRetriever(MagentoGraphqlClient client) {
		super(client);
	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return client.execute(queryString);
	}
	protected GraphqlResponse<JsonObject, Error> executeJsonQuery() {
		return client.executeQuery(query);
	}

	protected GraphqlResponse<Mutation, Error> executeMutation() {
		return client.executeMutation(query);
	}
	
	protected GraphqlResponse<JsonObject, Error> executeJsonMutation() {
		return client.executeJsonMutation(query);
	}
	
	@Override
	protected void populate(){
		//Nothing to do
	}

	// Getter
	public JsonObject getCategoryTree(String companyNumber) {
  		LOGGER.info("\n getCategoryTree23" );
  		query = getCategoryTreeDefinition(companyNumber);
		/*
		 * if(LOGGER.isDebugEnabled()) {
		 * LOGGER.debug(String.format("Mercury Marine category query %s",queryString));
		 * }
		 */
  		LOGGER.info("\n getCategoryTree23" );
  		LOGGER.info(" getCategoryTree QUERY=="+query);	
		GraphqlResponse<JsonObject, Error> response = executeJsonQuery();
		LOGGER.info("Shop By category response===="+response);
		List<Error> errors=response.getErrors();
		if(errors!= null) {
			JsonObject  errorjsonobject= new JsonObject();
			for(Error error:errors) {
				errorjsonobject.addProperty("categoryListMM", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info("Shop By category response1111===="+response.getData());
		  
		 
		 // JsonObject queryResponse = response.getData().getAsJsonObject("categoryListMM");
		JsonObject queryResponse = response.getData();
		//Getting languages JSON array from the JSON object  
	        JsonArray jsonArray = queryResponse.getAsJsonArray("categoryListMM");
	        LOGGER.info("Shop By category response2222===="+jsonArray);
	        ArrayList<Object> listdata = new ArrayList<Object>(); 
	      //Checking whether the JSON array has some value or not  
	        if (jsonArray != null) {   
	              
	            //Iterating JSON array  
	            for (int i=0;i<jsonArray.size();i++){   
	                  
	                //Adding each element of JSON array into ArrayList  
	                listdata.add(jsonArray.get(i));  
	            }   
	        }  
	      //Iterating ArrayList to print each element  
	        
	        LOGGER.info("Each element of ArrayList");  
	        for(int i=0; i<listdata.size(); i++) {  
	            //Printing each element of ArrayList  
	         //   System.out.println("hellooo:" +listdata.get(i));  
	        }  
		//JsonArray queryResponse1 = response.getData().getAsJsonArray("categoryListMM");
		//LOGGER.info("Shop By category response333===="+queryResponse1);
		return queryResponse;
  	}

	// Definition
	private String getCategoryTreeDefinition(String companyNumber) {
  		LOGGER.info("\n getCategoryTreeDefinition2" );
  		
  		/* CategoryTreeQueryDefinition ggrandChild = ct ->ct.level().name().path().urlKey().urlPath(); 
  			
  			 * CategoryTreeQueryDefinition grandChild = ct
  			 * ->ct.level().name().path().urlPath().urlKey().productCount().children(
  			 * ggrandChild); CategoryTreeQueryDefinition child = ct
  			 * ->ct.level().name().path().urlPath().urlKey().productCount().children(
  			 * grandChild);
  			 */
		/*
		 * CategoryTreeQueryDefinition grandChild = ct
		 * ->ct.level().id().uid().name().image().path().urlPath().urlKey().productCount
		 * ().childrenCount(); CategoryTreeQueryDefinition child = ct
		 * ->ct.level().id().name().image().path().urlPath().urlKey().productCount().
		 * childrenCount().children(grandChild);
		 * 
		 * return Operations.query(query -> query.categoryList(child)).toString();
		 */
  		StringBuilder _queryBuilder = new StringBuilder(); 
  	  _queryBuilder.append("{");
  	  _queryBuilder.append("categoryList(companyCustomerNumber:\"" + companyNumber + "\") {"); 
  	  _queryBuilder.append("level ");
  	  _queryBuilder.append("id "); 
  	  _queryBuilder.append("name ");
  	  _queryBuilder.append("image "); 
  	  _queryBuilder.append("path ");
  	  _queryBuilder.append("url_path "); 
  	  _queryBuilder.append("url_key ");
  	  _queryBuilder.append("product_count ");
  	  _queryBuilder.append("children_count "); 
  	  _queryBuilder.append("children{ ");
  	  _queryBuilder.append("level "); 
  	  _queryBuilder.append("id ");
  	  _queryBuilder.append("uid "); 
  	  _queryBuilder.append("name ");
  	  _queryBuilder.append("image "); 
  	  _queryBuilder.append("path ");
  	  _queryBuilder.append("url_path "); 
  	  _queryBuilder.append("url_key ");
  	  _queryBuilder.append("product_count ");
  	  _queryBuilder.append("children_count ");
  	  
  	  _queryBuilder.append("}}} ");
  	  
  	  return _queryBuilder.toString();
  	}
}


