package com.brunswick.ecomm.merclink.core.models.retriever;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.google.gson.JsonObject;

public class AbstractProductsAvailabilityRetriever extends AbstractCustomRetriever {
	private String queryString;
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractProductsAvailabilityRetriever.class);

	public AbstractProductsAvailabilityRetriever(MagentoGraphqlClient client) {
		super(client);
	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return client.execute(queryString);
	}

	protected GraphqlResponse<JsonObject, Error> executeJsonQuery() {
		return client.executeQuery(query);
	}

	protected GraphqlResponse<Mutation, Error> executeMutation() {
		return client.executeMutation(query);
	}

	protected GraphqlResponse<JsonObject, Error> executeJsonMutation() {
		return client.executeJsonMutation(query);
	}

	@Override
	protected void populate() {

	}

	public JsonObject getProductsAvaliability(String itemNumber) {
		query = getproductAvailabilityQuery(itemNumber);
		LOGGER.info(" magento product availability QUERY=={}", query);
		GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
		LOGGER.info("magento product availability response===={}", response);
		LOGGER.info("product availability response===={}", response.getData());
		return response.getData();

	}

	private String getproductAvailabilityQuery(String itemNumber) {
		StringBuilder sb = new StringBuilder();
		sb.append("{ ");
		sb.append("products(filter: { sku: { eq : \"" + itemNumber + "\" } }) { ");
		sb.append("items { ");
		sb.append("__typename ");
		sb.append("sku ");
		sb.append("name ");
		sb.append("bu_ss_to_part ");
		sb.append("} ");
		sb.append("} ");
		sb.append("} ");
		return sb.toString();
	}

}
