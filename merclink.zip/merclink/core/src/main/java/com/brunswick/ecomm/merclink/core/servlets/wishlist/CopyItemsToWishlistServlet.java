package com.brunswick.ecomm.merclink.core.servlets.wishlist;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.http.Cookie;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.magento.graphql.WishlistItemCopyInput;
import com.adobe.cq.commerce.magento.graphql.WishlistItemInput;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.constants.MagentoAttributes;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractWishlistDetailsRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;
import com.shopify.graphql.support.ID;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=Merclink Configuration Servlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_POST, "sling.servlet.paths=" + "/bin/copyMercItemToWishlist" })

public class CopyItemsToWishlistServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 8058516407707007720L;
	private static final Logger LOG = LoggerFactory.getLogger(CopyItemsToWishlistServlet.class);
	private transient AbstractWishlistDetailsRetriever wishlistRetriever;

	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
		try {
			String wishquantity;
			String wishlistItemId;
			JSONObject jsondata = new JSONObject(request.getParameter("data"));
			PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
			List<WishlistItemCopyInput> wishlistItems = new ArrayList<WishlistItemCopyInput>();
			String resourcepath = jsondata.get("resourcePath").toString();
			String sourceWishlistUid = jsondata.get("sourceWishlistUid").toString();
			String destinationWishlistUid = jsondata.get("destinationWishlistUid").toString();
			String wishlisttype = jsondata.get("wishlisttype").toString();
			LOG.info("wishlist type {}", wishlisttype);
			Resource res = request.getResourceResolver().resolve(resourcepath);
			String token = CommonUtil.getTokenFromCookie("customerToken", request);
			List<Header> headers = new ArrayList<>();
			headers.add(new BasicHeader("Authorization", "Bearer " + token));
			MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(res,
					pageManager.getPage(res.getPath()), request, headers);
			wishlistRetriever = new AbstractWishlistDetailsRetriever(magentoGraphqlClient);
			if (wishlisttype.equalsIgnoreCase("existing")) {
				LOG.info("existing type ");
				if (jsondata.has("items") == true) {
					JSONArray cartArray = jsondata.getJSONArray("items");
					for (int i = 0; i < cartArray.length(); i++) {
						if (cartArray != null) {
							wishlistItemId = cartArray.getJSONObject(i).getString("wishlistItemId");
							wishquantity = cartArray.getJSONObject(i).getString("quantity");
							ID wishlistItemId1 = new ID(wishlistItemId);
							WishlistItemCopyInput wishlistItemInput = new WishlistItemCopyInput(wishlistItemId1);
							wishlistItemInput.setQuantity(Double.parseDouble(wishquantity));
							wishlistItems.add(wishlistItemInput);
						}
					}
				}
				
				ID sourceWishlistUid1 = new ID(sourceWishlistUid);
				ID destinationWishlistUid1 = new ID(destinationWishlistUid);
				wishlistRetriever.copyItemsfromWishlist(sourceWishlistUid1, destinationWishlistUid1, wishlistItems);
				response.setStatus(200);
				response.setContentType("application/json");
				response.getWriter().print(jsondata);
			} else if (wishlisttype.equalsIgnoreCase("new")) {
				LOG.info("new type ");
				String newwishlistname = jsondata.get("wishlistname").toString();
				String listtype = jsondata.get("listtype").toString();
				if (wishlistRetriever != null) {
					Cookie[] cookies = request.getCookies();
					String companyNumber = null;
					if (cookies != null) {
						for (Cookie cookie : cookies) {
							if (cookie.getName().equals(MagentoAttributes.CUSTOMER_NUMBER)) {
								companyNumber = cookie.getValue();
							}
						}
					}
					String id = wishlistRetriever.createWishlist(newwishlistname, listtype, companyNumber);
					LOG.info("wishlist ID {}", id);
					if (id.contains("already exists")) {
						JSONObject errorData = new JSONObject();
						errorData.put("alreadyExists", id);
						response.setStatus(200);
						response.setContentType("application/json");
						response.getWriter().print(errorData);
					} else {
						JSONArray cartArray = jsondata.getJSONArray("items");
						for (int i = 0; i < cartArray.length(); i++) {
							if (cartArray != null) {
								wishlistItemId = cartArray.getJSONObject(i).getString("wishlistItemId");
								wishquantity = cartArray.getJSONObject(i).getString("quantity");
								ID wishlistItemId1 = new ID(wishlistItemId);
								WishlistItemCopyInput wishlistItemInput = new WishlistItemCopyInput(wishlistItemId1);
								wishlistItemInput.setQuantity(Double.parseDouble(wishquantity));
								wishlistItems.add(wishlistItemInput);
								response.setStatus(200);
								response.setContentType("application/json");
								response.getWriter().print(jsondata);
							}
						}
						ID sourceWishlistUid1 = new ID(sourceWishlistUid);
						LOG.info("source ID {}", sourceWishlistUid1);
						ID destinationWishlistUid1 = new ID(id.replace("\"", ""));
						LOG.info("destination ID {}", destinationWishlistUid1);
						wishlistRetriever.copyItemsfromWishlist(sourceWishlistUid1, destinationWishlistUid1,
								wishlistItems);
						response.setStatus(200);
						response.setContentType("application/json");
						response.getWriter().print(jsondata);
					}

				}

			}

		} catch (JSONException e) {
			LOG.error("Json Exception " + e.getMessage());
		} catch (RuntimeException e) {
			LOG.error("RunTime Exception {}", e.getMessage());
		}
	}

}
