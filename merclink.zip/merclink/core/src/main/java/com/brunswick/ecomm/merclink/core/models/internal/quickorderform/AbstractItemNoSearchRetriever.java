package com.brunswick.ecomm.merclink.core.models.internal.quickorderform;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Operations;
import com.adobe.cq.commerce.magento.graphql.ProductInterface;
import com.adobe.cq.commerce.magento.graphql.ProductInterfaceQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.ProductsQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.QueryQuery;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.product.retriever.AbstractRetriever;

public abstract class AbstractItemNoSearchRetriever extends AbstractRetriever {
	protected ProductInterface product;
	protected List<ProductInterface> products;
	protected String input;
    //protected ProductIdentifierType productIdentifierType;
    private static final Logger LOG = LoggerFactory.getLogger(AbstractItemNoSearchRetriever.class);
    
	public AbstractItemNoSearchRetriever(MagentoGraphqlClient client) {
		super(client);
	}

	public List<ProductInterface> fetchProduct() {
		if (this.products == null) {
            populate();
        }
        return this.products; 
	}
	
	 public void setInput(String input) {
	        product = null;
	        query = null;
	        this.input = input;
	    } 
	
	 protected GraphqlResponse<Query, Error> executeQuery() {
	        if (query == null) {
	            query = generateQuery(input);
	        }
	        return client.execute(query);
	    }
	 
	 @Override
	    protected void populate() {
	        // Get product list from response
	        GraphqlResponse<Query, Error> response = executeQuery();
	        Query rootQuery = response.getData();
	        products = rootQuery.getProducts().getItems();
	        LOG.info("products.."+products);
	        // Return first product in list
	        if (products.size() > 0) {
	            product = products.get(0);
	           
	        }
	    }
	 
	 public String generateQuery(String input) {
	        
	        
	        QueryQuery.ProductsArgumentsDefinition searchArgs = s -> s.search(input);

	        ProductsQueryDefinition queryArgs = q -> q.items(generateProductQuery());
	        LOG.info("\n\nthe query : "+Operations.query(query -> query.products(searchArgs, queryArgs)).toString());
	        return Operations.query(query -> query.products(searchArgs, queryArgs)).toString();
	    }

	 abstract protected ProductInterfaceQueryDefinition generateProductQuery();


	protected GraphqlResponse<Mutation, Error> executeMutation() {
		return null;
	}
}
