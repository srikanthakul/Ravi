package com.brunswick.ecomm.merclink.core.models;

import java.util.List;

public class FacetObj {
 String attrCode;
 String facetLabel;
 List<FacetOption> facetList;
public String getAttrCode() {
	return attrCode;
}
public void setAttrCode(String attrCode) {
	this.attrCode = attrCode;
}
public String getFacetLabel() {
	return facetLabel;
}
public void setFacetLabel(String facetLabel) {
	this.facetLabel = facetLabel;
}
public List<FacetOption> getFacetList() {
	return facetList;
}
public void setFacetList(List<FacetOption> facetList) {
	this.facetList = facetList;
}
}
