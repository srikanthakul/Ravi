package com.brunswick.ecomm.merclink.core.beans.personalinformation;

import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Optional;

import com.drew.lang.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerInformationDetailsBean {

	@Optional
	@JsonProperty("firstname")
	private String firstname;
	@Optional
	@JsonProperty("lastname")                            
	private String lastname;
	@Optional
	@JsonProperty("email")
	private String email;
	@Optional
	@JsonProperty("company_email")
	private String company_email;
	@Optional
	@JsonProperty("company_name")
	private String company_name;
	@Optional
	@Default(values = "null")
	@JsonIgnore
	@JsonProperty("telephone")
	private String telephone;
	@Optional
	@Default(values = "null")
	@JsonProperty("billing_address")
	@JsonIgnore
	private CustomerBillingAddressBean billing_address;
	@NotNull
	@JsonIgnore
	@Default(values = "null")
	@JsonProperty("shipping_addresses")
	private List<CustomerShippingAddressBean> shipping_addresses;
	
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCompany_email() {
		return company_email;
	}
	public void setCompany_email(String company_email) {
		this.company_email = company_email;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getTelephone() {
		if(telephone != null) {
			return telephone;
		}else {
			
			return StringUtils.EMPTY;
		}
		
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public CustomerBillingAddressBean getBilling_address() {
		if(billing_address != null) {
			return billing_address;
		}else {
			
			return null;
		}
	}
	public void setBilling_address(CustomerBillingAddressBean billing_address) {
		this.billing_address = billing_address;
	}
	public List<CustomerShippingAddressBean> getShipping_addresses() {
		return new ArrayList<>(shipping_addresses);
	}
	public void setShipping_addresses(List<CustomerShippingAddressBean> shipping_addresses) {
		this.shipping_addresses = new ArrayList<>(shipping_addresses);
	}
	
}
