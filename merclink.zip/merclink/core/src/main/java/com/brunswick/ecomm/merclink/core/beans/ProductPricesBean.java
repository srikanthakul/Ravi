package com.brunswick.ecomm.merclink.core.beans;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.models.annotations.Optional;

import com.brunswick.ecomm.merclink.core.models.internal.product.ProductImpl;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductPricesBean {

	@JsonProperty("tier_prices")
	private List<TierPriceBean> tierPrices;
	
	@JsonProperty("sale_price")
	private Float salePrice;
	
//	@Optional
	@JsonProperty("customer_quoted_price")
	private CustomerQuotedPriceBean customerQuotedPrice;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ProductPricesBean.class);
	
	/**
	 * @return the tierPrices
	 */	
	public final List<TierPriceBean> getTierPrices() {
		return new ArrayList<>(tierPrices);
	}

	/**
	 * @param tierPrices the tierPrices to set
	 */
	public final void setTierPrices(List<TierPriceBean> tierPrices) {
		this.tierPrices = new ArrayList<>(tierPrices);
	}

	/**
	 * @return the salePrice
	 */
	public final Float getSalePrice() {
		return salePrice;
	}

	/**
	 * @param salePrice the salePrice to set
	 */
	public final void setSalePrice(Float salePrice) {		
		this.salePrice = salePrice;
	}

	public CustomerQuotedPriceBean getCustomerQuotedPrice() {
		return customerQuotedPrice;
	}

	public void setCustomerQuotedPrice(CustomerQuotedPriceBean customerQuotedPrice) {
		this.customerQuotedPrice = customerQuotedPrice;
	}

	/**
	 * @return the customerQuotedPrice
	 */
	/*public final String getCustomerQuotedPrice() {
		return customerQuotedPrice;
	}*/

	/**
	 * @param customerQuotedPrice the customerQuotedPrice to set
	 */
	/*public final void setCustomerQuotedPrice(String customerQuotedPrice) {
		this.customerQuotedPrice = customerQuotedPrice;
	}*/

}
