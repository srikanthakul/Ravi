package com.brunswick.ecomm.merclink.core.beans.productdetailsrecommendations;

public class FinalPriceBean {
	private String currency;
	private Integer value;
	
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public Integer getValue() {
		return value;
	}
	public void setValue(Integer value) {
		this.value = value;
	}
	
}
