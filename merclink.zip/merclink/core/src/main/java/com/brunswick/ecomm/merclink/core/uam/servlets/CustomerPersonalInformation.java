package com.brunswick.ecomm.merclink.core.uam.servlets;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.http.Cookie;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.resource.Resource;

import com.brunswick.ecomm.merclink.core.models.retriever.AbstractPersonalInformationRetriever;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractUamRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonElement;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
@Component(service = Servlet.class, property = { "sling.servlet.methods=POST",
"sling.servlet.paths=/bin/uammerclinkCustomerPersonalInfo" })
public class CustomerPersonalInformation extends SlingAllMethodsServlet{
	private static final Logger LOG = LoggerFactory.getLogger(CustomerPersonalInformation.class);
	private static final long serialVersionUID = 1L;
	String currentPagePath;
	String customerNumber = StringUtils.EMPTY;
	
	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.debug("Entering into doPost() Method.");
		JSONObject requestObj;
		try {
			requestObj = new JSONObject(request.getParameter("data"));
			currentPagePath = requestObj.get("componentPath").toString();
			
			MagentoGraphqlClient magentoGraphqlClient = CommonUtil.getMagentoGraphqlClient(request, currentPagePath);
			AbstractPersonalInformationRetriever personalInformationRetriever;
			personalInformationRetriever = new AbstractPersonalInformationRetriever(magentoGraphqlClient);
			JsonObject resp = null;
			if (personalInformationRetriever != null) {
				resp = personalInformationRetriever.getCustomerPersonalInformation();
				JsonObject temp = resp.getAsJsonObject("roles_permission");
				String permissionCodes = temp.get("customer_permission").toString();
				
				LOG.info("roles_permission=====================" + permissionCodes );
				setCookie(response, "privileges", permissionCodes, 14400);
			}
			if (resp != null) {
				LOG.info("Response=====================" + new Gson().toJson(resp) );
				response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
				response.setContentType("application/json");
				response.getWriter().print(new Gson().toJson(resp));
			}
		} catch (JSONException e) {
		LOG.error("Json Exception " + e.getMessage(),e);
	} catch (RuntimeException e) {
		LOG.error("RunTime Exception {}", e.getMessage(),e);
	}
	LOG.debug("Exit from doPost() Method.");
	}
	
	private void setCookie(SlingHttpServletResponse response, String name, String value, int maxAge) {

		Cookie cookie = new Cookie(name, value);
		cookie.setMaxAge(maxAge);
		cookie.setPath("/");
		response.addCookie(cookie);
	}
	 
}
