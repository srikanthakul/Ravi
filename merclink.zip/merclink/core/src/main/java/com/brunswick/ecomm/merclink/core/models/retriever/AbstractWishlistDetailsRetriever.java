package com.brunswick.ecomm.merclink.core.models.retriever;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.AddProductsToWishlistOutput;
import com.adobe.cq.commerce.magento.graphql.AddProductsToWishlistOutputQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.ComplexTextValueQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.CopyProductsBetweenWishlistsOutputQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.CreateWishlistInput;
import com.adobe.cq.commerce.magento.graphql.CreateWishlistOutput;
import com.adobe.cq.commerce.magento.graphql.CreateWishlistOutputQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.CustomerQuery.WishlistsArgumentsDefinition;
import com.adobe.cq.commerce.magento.graphql.CustomerQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.CustomerToken;
import com.adobe.cq.commerce.magento.graphql.CustomerTokenQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.DeleteWishlistOutput;
import com.adobe.cq.commerce.magento.graphql.DeleteWishlistOutputQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.MoneyQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.MutationQuery.UpdateWishlistArgumentsDefinition;
import com.adobe.cq.commerce.magento.graphql.Operations;
import com.adobe.cq.commerce.magento.graphql.PriceRangeQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.ProductImageQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.ProductInterface;
import com.adobe.cq.commerce.magento.graphql.ProductInterfaceQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.ProductPriceQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.RemoveProductsFromWishlistOutput;
import com.adobe.cq.commerce.magento.graphql.RemoveProductsFromWishlistOutputQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.UpdateProductsInWishlistOutput;
import com.adobe.cq.commerce.magento.graphql.UpdateProductsInWishlistOutputQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.UpdateWishlistOutput;
import com.adobe.cq.commerce.magento.graphql.UpdateWishlistOutputQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.WishListUserInputError;
import com.adobe.cq.commerce.magento.graphql.WishListUserInputErrorQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Wishlist;
import com.adobe.cq.commerce.magento.graphql.WishlistItemCopyInput;
import com.adobe.cq.commerce.magento.graphql.WishlistItemInput;
import com.adobe.cq.commerce.magento.graphql.WishlistItemInterface;
import com.adobe.cq.commerce.magento.graphql.WishlistItemInterfaceQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.WishlistItemUpdateInput;
import com.adobe.cq.commerce.magento.graphql.WishlistItemsQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.WishlistQuery.ItemsV2ArgumentsDefinition;
import com.adobe.cq.commerce.magento.graphql.WishlistQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.WishlistVisibilityEnum;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.google.gson.JsonObject;
import com.shopify.graphql.support.CustomFieldQueryDefinition;
import com.shopify.graphql.support.ID;

public class AbstractWishlistDetailsRetriever extends AbstractCustomRetriever {
	Customer customer;
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractWishlistDetailsRetriever.class);
	private String query;

	public AbstractWishlistDetailsRetriever(MagentoGraphqlClient client) {
		super(client);

	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return client.execute(query);
	}

	protected GraphqlResponse<JsonObject, Error> excecuteQueryGraphql() {
		return client.executeQuery(query);
	}

	protected GraphqlResponse<Mutation, Error> executeMutation() {
		return client.executeMutation(query);
	}
	protected GraphqlResponse<JsonObject, Error> executeCustomMutation() {
		return client.executeJsonMutation(query);
	}

	@Override
	protected void populate() {
		// Nothing to do

	}

	public Customer getPaginationOfWishlist(ID wishlistId, String pageSize, String page) {
		query = getWishlistsPaginationDefinition(wishlistId, pageSize, page);
		LOGGER.info("QUERY==" + query);
		GraphqlResponse<Query, Error> response = executeQuery();
		if (response != null) {
			Query queryResponse = response.getData();
			LOGGER.info("queryResponse=={}", queryResponse);
			if (queryResponse != null) {
				customer = queryResponse.getCustomer();
			}
		}
		return customer;

	}

	public JsonObject getQueryPaginationOfWishlist(ID wishlistId, String pageSize, String page) {
		LOGGER.info("getQueryPaginationOfWishlist=={}", wishlistId, pageSize, page);
		query = getWishlistsPaginationDefinition(wishlistId, pageSize, page);
		JsonObject queryResponse=new JsonObject();
		LOGGER.info("QUERY==" + query);
		try {
			GraphqlResponse<JsonObject, Error> response = excecuteQueryGraphql();
			queryResponse = response.getData();
			LOGGER.info("queryResponse=={}", queryResponse);
		}catch(RuntimeException e) {
			LOGGER.error("Exception thrown {}",e.getMessage());
		}
		return queryResponse;

	}
	
	public String copyItemsfromWishlist(ID sourceWishlistUid, ID destinationWishlistUid, List<WishlistItemCopyInput> wishlistItems) {
		query = getCopyItemsFromWishlistDefinition(sourceWishlistUid, destinationWishlistUid, wishlistItems);
		LOGGER.info("QUERY==" + query);
		try {
			GraphqlResponse<Mutation, Error> response = executeMutation();
			LOGGER.info("queryResponse=={}", response);	
			 if (response !=null && response.getData() != null) {
				 if(response.getData().getCopyProductsBetweenWishlists() !=null && response.getData().getCopyProductsBetweenWishlists().getUserErrors()!=null) {
						List<WishListUserInputError> errors = response.getData().getCopyProductsBetweenWishlists().getUserErrors();
						for (WishListUserInputError error : errors) {
							return error.getMessage();
						}
					}else {
				
				return "success";
					}
			}			
			
		}catch(RuntimeException e) {
			LOGGER.error("Exception thrown {}",e.getMessage());
		}
		return "1";
	}
	
	private String getCopyItemsFromWishlistDefinition(ID sourceWishlistUid, ID destinationWishlistUid, List<WishlistItemCopyInput> wishlistItems) {
			ProductInterfaceQueryDefinition pdef = p -> p.name().sku().id();
			WishlistItemInterfaceQueryDefinition wiiqdef = wer -> wer.id().quantity().product(pdef);
			WishlistItemsQueryDefinition wisqdef = wef -> wef.items(wiiqdef);
			WishlistQueryDefinition wqdef = weg -> weg.id().name().itemsCount().itemsV2(wisqdef);
			WishListUserInputErrorQueryDefinition errdef = errdef1 -> errdef1.message().code();
			AddProductsToWishlistOutputQueryDefinition obj1 = o -> o.wishlist(wqdef).userErrors(errdef);
			CopyProductsBetweenWishlistsOutputQueryDefinition queryDef = q -> q.destinationWishlist(wqdef).userErrors(errdef); 
			return Operations.mutation(mutation -> mutation.copyProductsBetweenWishlists(sourceWishlistUid, destinationWishlistUid, wishlistItems, queryDef))
					.toString();

		}
	


	public String getWishlistsPaginationDefinition(ID wishlistId, String pageSize, String page) {
		ComplexTextValueQueryDefinition ctvdef = shtml -> shtml.html();
		CustomFieldQueryDefinition cfqd = pd -> pd.addCustomSimpleField("warning_message");
		ProductInterfaceQueryDefinition productDef = p -> p.uid().name().sku()
				.addCustomSimpleField("masterpartprop65code").addCustomSimpleField("bupartpartclass").addCustomSimpleField("masterpartlowestsellinguomqty").addCustomObjectField("product_data", cfqd)
				.shortDescription(ctvdef);
		WishlistItemInterfaceQueryDefinition wislistItemInterfaceDef = wiidef -> wiidef.id().description().quantity()
				.addedAt().product(productDef);
		WishlistItemsQueryDefinition wishlistItemsdef = witems -> witems.items(wislistItemInterfaceDef);
		ItemsV2ArgumentsDefinition v2augdef = vdef -> vdef.currentPage(Integer.parseInt(page))
				.pageSize(Integer.parseInt(pageSize));
		WishlistQueryDefinition wishlistDef = w -> w.id().name().visibility().updatedAt().addCustomSimpleField("is_auto")
				.addCustomSimpleField("isDefault").addCustomSimpleField("added_at").itemsCount()
				.itemsV2(v2augdef,wishlistItemsdef);
		
		CustomerQueryDefinition cust = c -> c.firstname().lastname().wishlistV2(wishlistId, wishlistDef);
		return Operations.query(query -> query.customer(cust)).toString();
	}

	// Getters
	public JsonObject getCustomerWishlist(String pageSize, String page, String companyNumber) {
		query = getWishlistsDefinition(pageSize, page, companyNumber);
		LOGGER.info("QUERY== {}", query);
		JsonObject customerObj = null;
        GraphqlResponse<JsonObject, Error> response = executeCustomMutation();
        if (response != null) {
             JsonObject queryResponse = response.getData();
            if (queryResponse != null) {
                 customerObj = queryResponse.getAsJsonObject("customer");
            }
        }
        LOGGER.info("magento wishlist  response===={}", response);
		LOGGER.info(" wishlist response===={}", response.getData());
        return response.getData();
	}

	public String generateCustomerToken(String emailId, String password) {
		query = generateCustomerTokenDefinition(emailId, password);
		GraphqlResponse<Mutation, Error> response = executeMutation();
		if (response != null) {
			Mutation queryResponse = response.getData();
			if (queryResponse != null) {
				CustomerToken token = queryResponse.getGenerateCustomerToken();
				if (token != null) {
					return token.getToken();

				}
			}
		}
		return null;

	}

	public Boolean deleteWishlist(ID wishlistId) {
		query = deleteWishlistDefinition(wishlistId);
		GraphqlResponse<Mutation, Error> response = executeMutation();
		if (response != null) {
			Mutation queryResponse = response.getData();
			if (queryResponse != null) {
				DeleteWishlistOutput deleteOutput = queryResponse.getDeleteWishlist();
				if (deleteOutput != null) {
					return deleteOutput.getStatus();

				}
			}
		}
		return false;

	}

	public String removeWishlistItem(ID wishlistId, List<ID> wishlistItemIds) {
		String responseString = "";
		query = removeWishlistItemDefinition(wishlistId, wishlistItemIds);
		LOGGER.info("remove query" + query);
		GraphqlResponse<Mutation, Error> response = executeMutation();
		if (response != null) {
			Mutation queryResponse = response.getData();
			LOGGER.info("remove queryResponse" + queryResponse);
			if (queryResponse != null) {
				RemoveProductsFromWishlistOutput removeOutput = queryResponse.getRemoveProductsFromWishlist();
				List<WishListUserInputError> usererrors = removeOutput.getUserErrors();
				Wishlist wishlist = removeOutput.getWishlist();
				if (wishlist != null) {
					if (wishlist.getId() != null) {
						responseString = wishlist.getId().toString();
					}

				}
				if (usererrors != null) {
					for (WishListUserInputError error : usererrors) {
						responseString += error.getMessage();
					}
				}
			}
		}
		return responseString;

	}

	public String createWishlist(String wishlistName, String visibility, String companyNumber) {
		String errorString = "";
		query = createWishlistDefinition(wishlistName, visibility, companyNumber);
		LOGGER.info("create query {}",query);
		GraphqlResponse<JsonObject, Error> response = executeCustomMutation();
		LOGGER.info("create query response {}",response);
		LOGGER.info("create query response get data {}",response.getData());
		LOGGER.info("create query response get errors {}",response.getErrors());
        if (response != null) {
            JsonObject queryResponse = response.getData();
            if (queryResponse != null) {
                if (!queryResponse.get("createWishlist").isJsonNull()) {
                    JsonObject createWLObj = queryResponse.getAsJsonObject("createWishlist");
                    if (!createWLObj.get("wishlist").isJsonNull()) {
                        JsonObject wishlistObj = createWLObj.getAsJsonObject("wishlist");
                        return wishlistObj.get("id").isJsonNull() ? "" : wishlistObj.get("id").toString();
                    }
                }
            }



           List<Error> errors = response.getErrors();
            if (errors != null) {
                for (Error error : errors) {
                    errorString += error.getMessage();
                }
            }
        }
        return errorString;
	}

	public void addWishlistItems(ID wishlistId, List<WishlistItemInput> wishlistItems) {
		query = addWishlistItemsDefinition(wishlistId, wishlistItems);
		LOGGER.info("add wishlist items query" + query);
		GraphqlResponse<Mutation, Error> response = executeMutation();
		if (response != null) {
			Mutation queryResponse = response.getData();
			if (queryResponse != null) {
				AddProductsToWishlistOutput output = queryResponse.getAddProductsToWishlist();
				if (output != null) {
					List<WishListUserInputError> usererrors = output.getUserErrors();
					Wishlist wishlist = output.getWishlist();
					LOGGER.info("wishlistname" + wishlist);
					if (wishlist != null) {
						List<WishlistItemInterface> wishlistiteminterface = wishlist.getItemsV2().getItems();
						for (WishlistItemInterface wint : wishlistiteminterface) {
							ProductInterface product = wint.getProduct();
							LOGGER.info("Name: " + product.getName() + "\n" + "Sku: " + product.getSku());
						}
					}
					if (usererrors != null) {
						for (WishListUserInputError error : usererrors) {
							error.getMessage();
						}
					}
				}
			}
		}
	}

	public String updateCommentQty(ID wishlistId, JSONArray commentArray) {
		String res = "";
		query = addCommentQtyDefinition(wishlistId, commentArray);
		LOGGER.info("comment query " + query);
		GraphqlResponse<Mutation, Error> response = executeMutation();
		if (response != null) {
			Mutation queryResponse = response.getData();
			if (queryResponse != null) {
				UpdateProductsInWishlistOutput updateOutput = queryResponse.getUpdateProductsInWishlist();
				List<WishListUserInputError> usererrors = updateOutput.getUserErrors();
				if (usererrors != null) {
					for (WishListUserInputError error : usererrors) {
						res += error.getMessage();
					}
				}
			}
		}
		return res;

	}

	public String updateQuantity(ID wishlistId, ID wishlistItemId, String quantity) {
		String res = null;
		query = updateQuantityDefinition(wishlistId, wishlistItemId, quantity);
		LOGGER.info("comment query " + query);
		GraphqlResponse<Mutation, Error> response = executeMutation();
		if (response != null) {
			Mutation queryResponse = response.getData();
			if (queryResponse != null) {
				UpdateProductsInWishlistOutput updateOutput = queryResponse.getUpdateProductsInWishlist();
				List<WishListUserInputError> usererrors = updateOutput.getUserErrors();
				Wishlist wishlist = updateOutput.getWishlist();

				List<WishlistItemInterface> wishlistiteminterface = wishlist.getItemsV2().getItems();
				for (WishlistItemInterface wint : wishlistiteminterface) {
					if (wishlistItemId.equals(wint.getId())) {
						res = wint.getQuantity().toString();
					}
				}
				if (usererrors != null) {
					for (WishListUserInputError error : usererrors) {
						res += error.getMessage();
					}
				}
			}
		}
		return res;

	}

	public JSONObject updateWishlist(ID wishlistId, String wishlistName, String visibility) {
		query = updateWishlistDefinition(wishlistId, wishlistName, visibility);
		GraphqlResponse<Mutation, Error> response = executeMutation();
		JSONObject jsonResponse = new JSONObject();
		if (response != null) {					
			List<Error> errors = response.getErrors();
			if (null != errors) {
				JSONObject errorjsonobject = new JSONObject();
				for (Error error : errors) {
					try {
						errorjsonobject.put("alreadyExistError", error.getMessage());
					} catch (JSONException e) {
						LOGGER.error(String.format("jsonexception occurred in updatewishlist query method {}", e));
					}
				}
				return errorjsonobject;
			}
			Mutation queryResponse = response.getData();			
			if (queryResponse != null) {
				try {					
					UpdateWishlistOutput updateOutput = queryResponse.getUpdateWishlist();
					jsonResponse.put("wishlistName", updateOutput.getName());
					jsonResponse.put("visibility", updateOutput.getVisibility());
				} catch (JSONException e) {
					LOGGER.error(String.format("jsonexception occurred in updatewishlist query method {}", e));
				}
			}
		}
		return jsonResponse;
	}

	public JsonObject deleteMultipleWishlists(List<ID> wishlistIds) {
		query = deleteMultipleWishlistsDefinition(wishlistIds);
		LOGGER.info("Query :"+query);
		GraphqlResponse<JsonObject, Error> response = executeCustomMutation();
		return response.getData();
	}

	// Query Definitions
	public String getWishlistsDefinition(String pageSize, String page, String companyNumber) {
		StringBuilder wishlistQB = new StringBuilder();
		wishlistQB.append("{ ");
		wishlistQB.append("customer { ");
		wishlistQB.append("firstname ");
		wishlistQB.append("lastname ");
		wishlistQB.append("wishlists(pageSize:" + pageSize + " currentPage:" + page + " companyNumber:\"" + companyNumber + "\") { ");
		wishlistQB.append("isDefault ");
		wishlistQB.append("is_auto ");
		wishlistQB.append("added_at ");
		wishlistQB.append("updated_at ");
		wishlistQB.append("id ");
		wishlistQB.append("name ");
		wishlistQB.append("items_count ");
		wishlistQB.append("creator_name ");
		wishlistQB.append("visibility ");
		wishlistQB.append("items_v2(currentPage:" + page + ", pageSize:" + pageSize + ") { ");
		wishlistQB.append("items { ");
		wishlistQB.append("quantity ");
		wishlistQB.append("description ");
		wishlistQB.append("product { ");
		wishlistQB.append("uid ");
		wishlistQB.append("id ");
		wishlistQB.append("name ");
		wishlistQB.append("sku ");
		wishlistQB.append("bupartpartclass_custom_: bupartpartclass ");
		wishlistQB.append("short_description { ");
		wishlistQB.append("html ");
		wishlistQB.append("} ");
		wishlistQB.append("} ");
		wishlistQB.append("} ");
		wishlistQB.append("} ");
		wishlistQB.append("} ");
		wishlistQB.append("} ");
		wishlistQB.append("} ");

		return wishlistQB.toString();
	}

	private CustomFieldQueryDefinition generateImageQuery(){
		 return customquery -> customquery.addCustomSimpleField("image_set").addCustomSimpleField("product_thumbnail").addCustomObjectField("productattachment", generateImageInnerQuery());
		
	}
	
	private CustomFieldQueryDefinition generateImageInnerQuery(){
		 return custominnerquery ->custominnerquery.addCustomSimpleField("attach_identifer").addCustomSimpleField("label_name").addCustomSimpleField("description").addCustomSimpleField("attachment").addCustomSimpleField("visible");
		
	}
	private String removeWishlistItemDefinition(ID wishlistId, List<ID> wishlistItemIds) {
		MoneyQueryDefinition mqd = m -> m.currency().value();
		ProductPriceQueryDefinition pppdef = pdef1 -> pdef1.regularPrice(mqd);
		PriceRangeQueryDefinition prqdef = prdef1 -> prdef1.maximumPrice(pppdef).minimumPrice(pppdef);
		ProductInterfaceQueryDefinition pdef = p -> p.name().sku().id().priceRange(prqdef);
		WishlistItemInterfaceQueryDefinition wiiqdef = wer -> wer.id().quantity().product(pdef);
		WishlistItemsQueryDefinition wisqdef = wef -> wef.items(wiiqdef);
		WishlistQueryDefinition wqdef = weg -> weg.id().itemsCount().itemsV2(wisqdef);
		WishListUserInputErrorQueryDefinition errdef = errdef1 -> errdef1.message().code();
		RemoveProductsFromWishlistOutputQueryDefinition obj1 = o -> o.wishlist(wqdef).userErrors(errdef);
		return Operations.mutation(mutation -> mutation.removeProductsFromWishlist(wishlistId, wishlistItemIds, obj1))
				.toString();
	}

	private String deleteWishlistDefinition(ID wishlistId) {
		WishlistQueryDefinition wqdef = weg -> weg.id().name().itemsCount();
		DeleteWishlistOutputQueryDefinition dwoqdef = op -> op.status().wishlists(wqdef);
		return Operations.mutation(mutation -> mutation.deleteWishlist(wishlistId, dwoqdef)).toString();
	}

	private String createWishlistDefinition(String wishlistName, String visibility, String companyNumber) {
		StringBuilder wishlistCreateQB = new StringBuilder();
		wishlistCreateQB.append("mutation { ");
		wishlistCreateQB.append("createWishlist(input: { ");
		wishlistCreateQB.append("name: \"" + wishlistName + "\" ");
		wishlistCreateQB.append("visibility: "  + visibility + " ");
		wishlistCreateQB.append("creator_name: \"" + companyNumber + "\" ");
		wishlistCreateQB.append("} ");
		wishlistCreateQB.append("){ ");
		wishlistCreateQB.append("wishlist { ");
		wishlistCreateQB.append("id ");
		wishlistCreateQB.append("name ");
		wishlistCreateQB.append("visibility ");
		wishlistCreateQB.append("} ");
		wishlistCreateQB.append("} ");
		wishlistCreateQB.append("} ");

		return wishlistCreateQB.toString();
	}

	private String addWishlistItemsDefinition(ID wishlistId, List<WishlistItemInput> wishlistItems) {
		MoneyQueryDefinition mqd = m -> m.currency().value();
		ProductPriceQueryDefinition pppdef = pdef1 -> pdef1.regularPrice(mqd);
		PriceRangeQueryDefinition prqdef = prdef1 -> prdef1.maximumPrice(pppdef).minimumPrice(pppdef);
		ProductInterfaceQueryDefinition pdef = p -> p.name().sku().id().priceRange(prqdef);
		WishlistItemInterfaceQueryDefinition wiiqdef = wer -> wer.id().quantity().product(pdef);
		WishlistItemsQueryDefinition wisqdef = wef -> wef.items(wiiqdef);
		WishlistQueryDefinition wqdef = weg -> weg.id().itemsCount().itemsV2(wisqdef);
		WishListUserInputErrorQueryDefinition errdef = errdef1 -> errdef1.message().code();
		AddProductsToWishlistOutputQueryDefinition obj1 = o -> o.wishlist(wqdef).userErrors(errdef);
		return Operations.mutation(mutation -> mutation.addProductsToWishlist(wishlistId, wishlistItems, obj1))
				.toString();

	}

	private String generateCustomerTokenDefinition(String emailId, String password) {
		CustomerTokenQueryDefinition customerToken = c -> c.token();
		return Operations.mutation(mutation -> mutation.generateCustomerToken(emailId, password, customerToken))
				.toString();
	}

	private String addCommentQtyDefinition(ID wishlistId, JSONArray commentArray) {
		MoneyQueryDefinition mqd = m -> m.currency().value();
		ProductPriceQueryDefinition pppdef = pdef1 -> pdef1.regularPrice(mqd);
		PriceRangeQueryDefinition prqdef = prdef1 -> prdef1.maximumPrice(pppdef).minimumPrice(pppdef);
		ProductInterfaceQueryDefinition pdef = p -> p.name().sku().id().priceRange(prqdef);
		WishlistItemInterfaceQueryDefinition wiiqdef = wer -> wer.id().description().quantity().product(pdef);
		WishlistItemsQueryDefinition wisqdef = wef -> wef.items(wiiqdef);
		WishlistQueryDefinition wqdef = weg -> weg.id().itemsCount().itemsV2(wisqdef);
		WishListUserInputErrorQueryDefinition errdef = errdef1 -> errdef1.message().code();
		List<WishlistItemUpdateInput> list = new ArrayList<>();
		WishlistItemUpdateInput input = null;
		for (int i = 0; i < commentArray.length(); i++) {
			try {
				JSONObject cmntQtyObj = commentArray.getJSONObject(i);
				ID wlItemId = new ID(cmntQtyObj.optString("wishlistItemId"));
				input = new WishlistItemUpdateInput(wlItemId);
				if (StringUtils.isNotBlank(cmntQtyObj.optString("comment"))) {
					input.setDescription(cmntQtyObj.optString("comment"));
				}
				if (StringUtils.isNotBlank(cmntQtyObj.optString("quantity"))) {
					input.setQuantity(Double.parseDouble(cmntQtyObj.optString("quantity")));
				}
				input.setWishlistItemId(wlItemId);
			} catch (JSONException e) {
				LOGGER.error(String.format("jsonexception occurred in WL comment query method {}", e));
			}
			list.add(input);
		}
		
		UpdateProductsInWishlistOutputQueryDefinition updef = up -> up.wishlist(wqdef).userErrors(errdef);
		return Operations.mutation(mutation -> mutation.updateProductsInWishlist(wishlistId, list, updef)).toString();
	}

	private String updateQuantityDefinition(ID wishlistId, ID wishlistItemId, String quantity) {
		MoneyQueryDefinition mqd = m -> m.currency().value();
		ProductPriceQueryDefinition pppdef = pdef1 -> pdef1.regularPrice(mqd);
		PriceRangeQueryDefinition prqdef = prdef1 -> prdef1.maximumPrice(pppdef).minimumPrice(pppdef);
		ProductInterfaceQueryDefinition pdef = p -> p.name().sku().id().priceRange(prqdef);
		WishlistItemInterfaceQueryDefinition wiiqdef = wer -> wer.id().description().quantity().product(pdef);
		WishlistItemsQueryDefinition wisqdef = wef -> wef.items(wiiqdef);
		WishlistQueryDefinition wqdef = weg -> weg.id().itemsCount().itemsV2(wisqdef);
		WishListUserInputErrorQueryDefinition errdef = errdef1 -> errdef1.message().code();
		List<WishlistItemUpdateInput> list = new ArrayList<>();
		WishlistItemUpdateInput input = new WishlistItemUpdateInput(wishlistId);
		input.setQuantity(Double.parseDouble(quantity));
		input.setWishlistItemId(wishlistItemId);
		list.add(input);
		UpdateProductsInWishlistOutputQueryDefinition updef = up -> up.wishlist(wqdef).userErrors(errdef);
		return Operations.mutation(mutation -> mutation.updateProductsInWishlist(wishlistId, list, updef)).toString();
	}

	private String updateWishlistDefinition(ID wishlistId, String wishlistName, String visibility) {
		UpdateWishlistArgumentsDefinition uped = ped -> ped.name(wishlistName)
				.visibility(WishlistVisibilityEnum.valueOf(visibility));
		UpdateWishlistOutputQueryDefinition oped = op -> op.name().visibility().uid();
		return Operations.mutation(mutation -> mutation.updateWishlist(wishlistId, uped, oped)).toString();
	}

	private String deleteMultipleWishlistsDefinition(List<ID> wishlistIds) {
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation{");
		_queryBuilder.append("deleteWishlist");
		_queryBuilder.append("(wishlistId: [");
		for (ID id : wishlistIds) {
			_queryBuilder.append(id.toString() + ",");
		}
		_queryBuilder.append("]) {");
		_queryBuilder.append("status ");
		_queryBuilder.append(" wishlists {");
		_queryBuilder.append("id ");
		_queryBuilder.append("name ");
		_queryBuilder.append("items_count }");
		_queryBuilder.append(" user_errors { ");
		_queryBuilder.append("	message ");
		_queryBuilder.append(" }}}");

		return _queryBuilder.toString();
	}

}
