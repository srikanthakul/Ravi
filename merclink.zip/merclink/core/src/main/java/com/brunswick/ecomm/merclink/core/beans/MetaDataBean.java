package com.brunswick.ecomm.merclink.core.beans;

import java.io.Serializable;

public class MetaDataBean implements Serializable{
	
	private static final long serialVersionUID = 8390846639945438593L;

	/** The canonical URL. */
	private String canonicalURL;

	/** The keywords. */
	private String keywords;

	/** The description. */
	private String description;

	/** The tags. */
	private String tags;

	/** The content type. */
	private String contentType;

	/** The last modified date. */
	private String lastModifiedDate;

	/** The thumbnail. */
	private String thumbnail;

	/** The robots. */
	private String robots;

	/** The og locale. */
	private String ogLocale;
	
	/** The og title. */
	private String ogTitle;

	/** The og type. */
	private String ogType;

	/** The og URL. */
	private String ogURL;

	/** The og desc. */
	private String ogDesc;

	/** The og image. */
	private String ogImage;

	/** The og sitename. */
	private String ogSitename;

	/** The twitter site. */
	private String twitterSite;

	/** The twitter description. */
	private String twitterDesc;

	/** The twitter title. */
	private String twitterTitle;

	/** The twitter image. */
	private String twitterImage;
	
	/** The youtube title. */
	private String youtubeTitle;
	
	/** The youtube description. */
	private String youtubeDesc;
	
	/** The youtube image. */
	private String youtubeImage;
	
	/** The linkedin title. */
	private String linkedinTitle;
	
	/** The linkedin description. */
	private String linkedinDesc;
	
	/** The linkedin image. */
	private String linkedinImage;

	public String getCanonicalURL() {
		return canonicalURL;
	}

	public void setCanonicalURL(String canonicalURL) {
		this.canonicalURL = canonicalURL;
	}

	public String getKeywords() {
		return keywords;
	}

	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTags() {
		return tags;
	}

	public void setTags(String tags) {
		this.tags = tags;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public String getRobots() {
		return robots;
	}

	public void setRobots(String robots) {
		this.robots = robots;
	}

	public String getOgLocale() {
		return ogLocale;
	}

	public void setOgLocale(String ogLocale) {
		this.ogLocale = ogLocale;
	}

	public String getOgTitle() {
		return ogTitle;
	}

	public void setOgTitle(String ogTitle) {
		this.ogTitle = ogTitle;
	}

	public String getOgType() {
		return ogType;
	}

	public void setOgType(String ogType) {
		this.ogType = ogType;
	}

	public String getOgURL() {
		return ogURL;
	}

	public void setOgURL(String ogURL) {
		this.ogURL = ogURL;
	}

	public String getOgDesc() {
		return ogDesc;
	}

	public void setOgDesc(String ogDesc) {
		this.ogDesc = ogDesc;
	}

	public String getOgImage() {
		return ogImage;
	}

	public void setOgImage(String ogImage) {
		this.ogImage = ogImage;
	}

	public String getOgSitename() {
		return ogSitename;
	}

	public void setOgSitename(String ogSitename) {
		this.ogSitename = ogSitename;
	}

	public String getTwitterSite() {
		return twitterSite;
	}

	public void setTwitterSite(String twitterSite) {
		this.twitterSite = twitterSite;
	}

	public String getTwitterDesc() {
		return twitterDesc;
	}

	public void setTwitterDesc(String twitterDesc) {
		this.twitterDesc = twitterDesc;
	}

	public String getTwitterTitle() {
		return twitterTitle;
	}

	public void setTwitterTitle(String twitterTitle) {
		this.twitterTitle = twitterTitle;
	}

	public String getTwitterImage() {
		return twitterImage;
	}

	public void setTwitterImage(String twitterImage) {
		this.twitterImage = twitterImage;
	}

	public String getYoutubeTitle() {
		return youtubeTitle;
	}

	public void setYoutubeTitle(String youtubeTitle) {
		this.youtubeTitle = youtubeTitle;
	}

	public String getYoutubeDesc() {
		return youtubeDesc;
	}

	public void setYoutubeDesc(String youtubeDesc) {
		this.youtubeDesc = youtubeDesc;
	}

	public String getYoutubeImage() {
		return youtubeImage;
	}

	public void setYoutubeImage(String youtubeImage) {
		this.youtubeImage = youtubeImage;
	}

	public String getLinkedinTitle() {
		return linkedinTitle;
	}

	public void setLinkedinTitle(String linkedinTitle) {
		this.linkedinTitle = linkedinTitle;
	}

	public String getLinkedinDesc() {
		return linkedinDesc;
	}

	public void setLinkedinDesc(String linkedinDesc) {
		this.linkedinDesc = linkedinDesc;
	}

	public String getLinkedinImage() {
		return linkedinImage;
	}

	public void setLinkedinImage(String linkedinImage) {
		this.linkedinImage = linkedinImage;
	}
	
	
	



}
