package com.brunswick.ecomm.merclink.core.models;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.beans.PrivilegeMultiFieldBean;

@Model(
        adaptables = SlingHttpServletRequest.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class TouchMultiFieldComponentModel {
	private static final Logger LOG = LoggerFactory.getLogger(TouchMultiFieldComponentModel.class);

    @SlingObject
    Resource componentResource;
    
    @Self
    SlingHttpServletRequest response;

    private List<PrivilegeMultiFieldBean> privilegesBean;
    
    public List<PrivilegeMultiFieldBean> getPrivilegeDetailsWithBean(){
        privilegesBean=new ArrayList<PrivilegeMultiFieldBean>();
        String privileges = response.getCookie("privileges").getValue().toString();
        ArrayList<String> privilegeList = new ArrayList<>(Arrays.asList(privileges.split(",")));
        LOG.debug(" Cookie from response for Privileges : ",response.getCookie("privileges").getValue().toString());
        try {
            Resource privilegeDetailBean=componentResource.getChild("privilegedetailswithbean");
            if(privilegeDetailBean!=null){
                for (Resource privilegeBean : privilegeDetailBean.getChildren()) {
                	ValueMap vm = privilegeBean.getValueMap();
                	String code = getPropertyValue(vm, "privilegecode");
                	if(privilegeList.contains(code)) {
                		PrivilegeMultiFieldBean menuItem = new PrivilegeMultiFieldBean();
                		String name = getPropertyValue(vm, "privilegename");
                		String tooltip = getPropertyValue(vm, "privilegetooltip");
                		menuItem.setName(name);
                		menuItem.setPrivilegeCode(code);
                		menuItem.setTooltip(tooltip);
                		privilegesBean.add(menuItem);
                	}

                }
            }
        }catch (Exception e){
            LOG.error("ERROR in getPrivilegeDetailsWithBean {} ",e.getMessage());
        }
        return new ArrayList<>(privilegesBean);
    }
    
    private String getPropertyValue(final ValueMap properties, final String propertyName) {
        return properties.containsKey(propertyName) ? properties.get(propertyName, String.class) : StringUtils.EMPTY;
    }

}
