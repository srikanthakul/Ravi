package com.brunswick.ecomm.merclink.core.models;

import java.net.MalformedURLException;
import java.net.URL;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.servlet.http.Cookie;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.constants.CommonConstants;
import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.util.PathLinkUtil;
import com.brunswick.ecomm.core.util.PropertyUtil;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.webservicesupport.Configuration;
import com.day.cq.wcm.webservicesupport.ConfigurationManagerFactory;

@Model(adaptables = SlingHttpServletRequest.class, adapters=DatalayerModel.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class DatalayerModel {

	private final Logger logger = LoggerFactory.getLogger(DatalayerModel.class);

	@SlingObject
	protected Resource resource;

	@Default(values = StringUtils.EMPTY)
	private String primaryCategory;

	@Default(values = StringUtils.EMPTY)
	private String pageName;

	@Default(values = "US")
	private String countryCode;

	@Default(values = "en")
	private String languageCode;
	
	@Default(values = StringUtils.EMPTY)
	private String customerNumber;
	
	@Default(values = StringUtils.EMPTY)
	private String brandName;
	
	@Default(values = StringUtils.EMPTY)
	private String queryString;
	
	@Inject
	@Via("resource")
	private String newsTitle;

	@Inject
	EcommSessionService adminService;

	@Inject
	ConfigurationManagerFactory configManagerFctry;
	
	@Inject
	private SlingHttpServletRequest request;

	private String currentPagePath;
	
	private String userLoginStatus;
	
	public static String getCustomerFromCookie(String cookieName, SlingHttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		String defaultValue = "";
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				Cookie cookie = cookies[i];
				if (cookieName.equals(cookie.getName())) {
					return (cookie.getValue());
				}
			}
		}
		return (defaultValue);
	}

	@PostConstruct
	protected void init() throws MalformedURLException {

		ResourceResolver adminResourceResolver = null;
		try {
			
			userLoginStatus = StringUtils.EMPTY;
			
			adminResourceResolver = adminService.getReadServiceResourceResolver();
			
			String token = CommonUtil.getTokenFromCookie("customerToken", request);
			
			String customerNumberVal = getCustomerFromCookie("customerNumber", request);
			
			logger.info(" customerNumber in DataLayerModel :", customerNumberVal);	
			
			logger.info(" token in DataLayerModel :", token);		
			
			setUserLoginStatus("loggedOut");
			if(null != token && !StringUtils.isEmpty(token)) {
				setUserLoginStatus("loggedIn");
				customerNumber = customerNumberVal;
			}
			
			
			
			logger.info("UserLoggedIn Status--->{}",userLoginStatus);
			PageManager pageManager = resource.getResourceResolver().adaptTo(PageManager.class);
			
			if (pageManager != null) {
				Page currentPage = pageManager.getContainingPage(resource);
				logger.info("Current Page--->{}",currentPage);
				if (currentPage != null) {				
					
					currentPagePath = currentPage.getPath();
					logger.info("Current Page path-->{}",currentPagePath);
					if(currentPagePath.contains(CommonConstants.CONTENT_ROOT_PATH)){
						Page homePage = PathLinkUtil.getHomePage(currentPage);
						logger.info("Home page-->{}",homePage.getPath());						
						String countryLanguage = homePage.getProperties().get(JcrConstants.JCR_LANGUAGE, String.class);				
					
						countryCode = homePage.getPath().substring(nthLastIndexOf(homePage.getPath(),'/',2)+1,nthLastIndexOf(homePage.getPath(),'/',1)).toUpperCase();
					
					
						if (StringUtils.isNotBlank(countryLanguage)) {
							String[] countryLang = countryLanguage.split("_");
							logger.info("Making the country code");
							if (countryLang.length == 2) {
								languageCode = countryLang[0];
								countryCode = countryLang[1];
							} else if (countryLang.length == 1) {
								languageCode = countryLang[0];
							}
					}
					
					logger.info("Country Code--->{}",countryCode);

					logger.info("Language Code--->{}",languageCode);
					  
					String CurrentURI = request.getScheme() + "://" +  
				             request.getServerName() +      
				             ":" +                           
				             request.getServerPort() +       
				             request.getRequestURI() +       
				             "?" +                           
				             request.getQueryString();       
					
					logger.info("current query  string --->{}", CurrentURI);
					
					queryString = CurrentURI;
					
					int pageDepth = currentPage.getDepth();
					int homePageDepth = homePage.getDepth();
					int diff= pageDepth-homePageDepth;
					String brandCode = StringUtils.EMPTY;
					Configuration configObj = PropertyUtil.getCloudConfigObj(configManagerFctry, adminResourceResolver,
							adminResourceResolver.resolve(currentPage.getPath()), "siteconfig");
					if (configObj != null) {
						Resource siteConfigRes = adminResourceResolver.resolve(configObj.getPath()
								.concat(CommonConstants.SLASH_STRING).concat(CommonConstants.JCR_CONTENT));
						brandCode = PropertyUtil.getStringProperty(siteConfigRes.getValueMap(), "brand");
					}
					logger.info("Page Depth --->{}",pageDepth);
					String pageTitle=currentPage.getName();
					logger.info("Page name ---->{}",pageTitle);
					pageName = brandCode.concat(CommonConstants.COLON).concat(languageCode).concat(CommonConstants.HYPHEN).concat(countryCode);
					brandName = brandCode;
					if(diff==0)
					{
						pageName= pageName.concat(CommonConstants.COLON).concat("home");
					}
					else
					{
						String reqPath = currentPage.getPath().replace(homePage.getPath(),"");						
						String[] reqPathAttr  = reqPath.split(CommonConstants.SLASH_STRING);
						for(int i=1;i<=diff;i++)
						{
							pageName=pageName.concat(CommonConstants.COLON).concat(reqPathAttr[i].replace("-", " ").toLowerCase());
						}
					}					
					
					primaryCategory = brandCode.concat(CommonConstants.COLON).concat(languageCode).concat(CommonConstants.HYPHEN).concat(countryCode);
					logger.info("Page Name--->{}",pageName);
					if(diff==0)
					{
						primaryCategory = primaryCategory.concat(CommonConstants.COLON).concat("home");
					}
					else if(diff == 1)
					{
						primaryCategory = primaryCategory.concat(CommonConstants.COLON).concat(pageTitle.replace("-", " ").toLowerCase());
					}
					else
					{
						String reqPath = currentPage.getPath().replace(homePage.getPath(),"");						
						String[] reqPathAttr  =reqPath.split(CommonConstants.SLASH_STRING);
						for(int i=1;i<diff;i++)
						{
							primaryCategory = primaryCategory.concat(CommonConstants.COLON).concat(reqPathAttr[i].replace("-", " ").toLowerCase());
						}
					}
					 
					logger.info("Primary Category--->{}",primaryCategory);
					languageCode= languageCode.concat(CommonConstants.HYPHEN).concat(countryCode);
				}
				}
			}
		} catch (LoginException e) {
			logger.error("[checkAction] ->  Error while getting the resource resolver", e);
		} finally {
			if (adminResourceResolver != null && adminResourceResolver.isLive()) {
				adminResourceResolver.close();
			}
		}

	}
	
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}
	public void setUserLoginStatus(String userLoginStatus) {
		this.userLoginStatus = userLoginStatus;
	}
	public String getUserLoginStatus() {
		return userLoginStatus;
	}
	public String getPageName() {
		return pageName;
	}
	public String getPrimaryCategory() {
		return primaryCategory;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public String getLanguageCode() {
		return languageCode;
	}
	public String getCurrentPagePath() {
		return currentPagePath;
	}
	public String getCustomerNumber() {
		return customerNumber;
	}
	public String getBrandName() {
		return brandName;
	}
	public String getQueryString() {
		return queryString;
	}
	public String getNewsTitle() {
		return newsTitle;
	}

	private int nthLastIndexOf(String str, char c, int n) {
        if (str == null || n < 1)
            return -1;
        int pos = str.length();
        while (n-- > 0 && pos != -1)
            pos = str.lastIndexOf(c, pos - 1);
        return pos;
	}

	
}
 