package com.brunswick.ecomm.merclink.core.utils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.joda.time.DateTime;
import org.opensaml.Configuration;
import org.opensaml.DefaultBootstrap;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.Response;
import org.opensaml.saml2.core.Subject;
import org.opensaml.xml.ConfigurationException;
import org.opensaml.xml.io.Unmarshaller;
import org.opensaml.xml.io.UnmarshallerFactory;
import org.opensaml.xml.io.UnmarshallingException;
import org.opensaml.xml.validation.ValidationException;
import org.opensaml.xml.validation.ValidatorSuite;
import org.owasp.esapi.codecs.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.brunswick.ecomm.core.constants.CommonConstants;

public class SAMLResponseDataUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(SAMLResponseDataUtil.class);

	public static String validateAssertion(SlingHttpServletRequest request, SlingHttpServletResponse response) {

		String username = null;
		String sessionIndex = null;

		try {
			final String responseString = new String(Base64.decode(request.getParameter(CommonConstants.SAML_RESPONSE)),
					StandardCharsets.UTF_8.name());
			LOGGER.info("SAML Response :" + responseString);
			final Response decodedResponse = getAssertionsFromFederation(responseString);
			// validate SAML response XML
			validateSchema(decodedResponse);

			List<Assertion> assertions = decodedResponse.getAssertions();

			if (null != assertions && assertions.size() > 0) {
				// Fetching username from SAML response from federation
				final Subject subject = assertions.get(0).getSubject();
				username = subject.getNameID().getValue();

				// Fetching session Id from SAML response from federation
				sessionIndex = assertions.get(0).getAuthnStatements().get(0).getSessionIndex();

				final DateTime onOrAfterTime = assertions.get(0).getConditions().getNotOnOrAfter();

				final Calendar calEndDate = getDateInGMT(onOrAfterTime.toString(), "0");
				final Date todate = new Date();
				SimpleDateFormat format = new SimpleDateFormat("yy-MM-dd'T'HH:mm:ss");
				format.setTimeZone(TimeZone.getTimeZone("GMT"));
				final String currentDateGMTString = format.format(todate);
				Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
				final DateFormat format2 = new SimpleDateFormat("yy-MM-dd'T'HH:mm:ss");
				final Date formattedExpirationDate = format2.parse(currentDateGMTString);
				cal.setTime(formattedExpirationDate);

				final String oldAssertionId = (String) request.getSession().getAttribute("assertionID");

				if ((oldAssertionId == null
						|| !oldAssertionId.equalsIgnoreCase(assertions.get(0).getID().toString()))
						&& calEndDate.getTime().after(cal.getTime())) {
					username = username.concat("#:#").concat(sessionIndex);
					request.getSession().setAttribute("assertionID", assertions.get(0).getID());
					LOGGER.info("Valid saml response");
				} else {
					LOGGER.info("Invalid Saml response");
				}
			}

		} catch (UnsupportedEncodingException e) {
			LOGGER.error("UnsupportedEncodingException in validate assertion.", e);
		} catch (ConfigurationException e) {
			LOGGER.error("ConfigurationException in validate assertion.", e);
		} catch (SAXException e) {
			LOGGER.error("SAXException in validate assertion.", e);
		} catch (IOException e) {
			LOGGER.error("IOException in validate assertion.", e);
		} catch (UnmarshallingException e) {
			LOGGER.error("UnmarshallingException in validate assertion.", e);
		} catch (ParserConfigurationException e) {
			LOGGER.error("ParserConfigurationException in validate assertion.", e);
		} catch (ValidationException e) {
			LOGGER.error("ValidationException in validate assertion.", e);
		} catch (ParseException e) {
			LOGGER.error("ParseException in validate assertion.", e);
		}
		return username;
	}

	private static Calendar getDateInGMT(final String date, final String timeDiff) throws ParseException {
		Calendar calDate = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		final DateFormat formatStartDate = new SimpleDateFormat("yy-MM-dd'T'HH:mm:ss");
		final Date formattedStartDate = formatStartDate.parse(date);
		calDate.setTime(formattedStartDate);
		calDate.add(Calendar.MINUTE, Integer.parseInt(timeDiff));
		return calDate;
	}

	private static void validateSchema(Response decodedResponse) throws ValidationException {
		// we have the xml unmarshalled to a response object
		LOGGER.debug("Response object created");
		LOGGER.debug("Issue Instant: {}", decodedResponse.getIssueInstant().toString());
		LOGGER.debug("Signature Reference ID: {}", decodedResponse.getSignatureReferenceID().toString());

		// Validate SAML Response against schemas
		final ValidatorSuite schemaValidators = Configuration.getValidatorSuite("saml2-core-schema-validator");

		schemaValidators.validate(decodedResponse);
		LOGGER.debug("Schemas validation was successful.");
	}

	private static Response getAssertionsFromFederation(final String responseString) throws ConfigurationException,
			SAXException, IOException, UnmarshallingException, ParserConfigurationException {
		DefaultBootstrap.bootstrap();
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		documentBuilderFactory.setNamespaceAware(true);
		DocumentBuilder docBuilder = documentBuilderFactory.newDocumentBuilder();

		final ByteArrayInputStream byArInputStream = new ByteArrayInputStream(
				responseString.getBytes(StandardCharsets.UTF_8.name()));
		// Sonar Note: already DTD disabled in NewtpUtil.getDocumentBuilder() method
		// where DocumentBuilderFactory object created
		final Document document = docBuilder.parse(byArInputStream);
		final Element element = document.getDocumentElement();
		final QName qName = new QName(element.getNamespaceURI(), element.getLocalName(), element.getPrefix());

		final UnmarshallerFactory unmarshallerFactory = Configuration.getUnmarshallerFactory();

		final Unmarshaller unmarshaller = unmarshallerFactory.getUnmarshaller(qName);

		return (Response) unmarshaller.unmarshall(element);
	}

}
