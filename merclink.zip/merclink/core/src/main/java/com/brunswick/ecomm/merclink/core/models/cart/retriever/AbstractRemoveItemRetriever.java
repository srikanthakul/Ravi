package com.brunswick.ecomm.merclink.core.models.cart.retriever;

import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.*;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public abstract class AbstractRemoveItemRetriever {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractRemoveItemRetriever.class);
    //protected ProductIdentifierType productIdentifierType;
    protected String cartId;
    protected Integer itemId;
    private List<Error> error =new ArrayList<>();
    protected List<CartItemInterface> cartItems;
    protected Consumer<CartItemInterface> cartQueryHook;
    /**
     * Generated or fully customized query.
     */
    protected String query;

    /**
     * Instance of the Magento GraphQL client.
     */
    protected MagentoGraphqlClient client;


    protected AbstractRemoveItemRetriever(MagentoGraphqlClient client) {
        if (client == null) {
            throw new java.lang.Error("No GraphQL client provided");
        }
        this.client = client;
    }

    public void setIdentifier(String cartId, Integer itemId) {
        this.cartId = cartId;
        this.itemId = itemId;
    }


    protected GraphqlResponse<Mutation, Error> executeMutation() {
        LOGGER.info("In executemutation() method");
        if (query == null) {
            int itemIdTemp;
            try {
                itemIdTemp = itemId.intValue();
            } catch (NumberFormatException e) {
                itemIdTemp = 0;
            }
            query = generateQuery(cartId, itemIdTemp);
            LOGGER.info("In executemutation() method query generated:-"+query);
        }
        return client.executeMutation(query);
    }

    protected String generateQuery(String cartId, int itemId) {
        RemoveItemFromCartOutputQueryDefinition queryDef = generateRemoveItemQuery();
        MutationQuery.RemoveItemFromCartArgumentsDefinition queryArgs = generateRemoveItemInputQuery(cartId, itemId);
        return Operations.mutation(mutationQuery -> mutationQuery.removeItemFromCart(queryArgs, queryDef)).toString();

    }


    protected void populate() {
        // Get product list from response
        GraphqlResponse<Mutation, Error> response = executeMutation();
        LOGGER.info("In populate() method query executed:response--"+response);
        LOGGER.info("In populate() method query executed:response.data-"+response.getData());
        LOGGER.info("In populate() method query executed:error-"+response.getErrors());
        Mutation rootQuery = response.getData();
        if (rootQuery !=null && rootQuery.getRemoveItemFromCart()!=null) {
        cartItems = rootQuery.getRemoveItemFromCart().getCart().getItems();
        }
        else{
        	error = response.getErrors();
        }
    }

    public List<Error> getError() {
		return new ArrayList<>(error);
	}

	public List<CartItemInterface> fetchCart() {
        if (this.cartItems == null) {
            populate();
        }
        return this.cartItems;
    }

    protected abstract RemoveItemFromCartOutputQueryDefinition generateRemoveItemQuery();

    protected abstract MutationQuery.RemoveItemFromCartArgumentsDefinition generateRemoveItemInputQuery(String cartId, int itemId);


}
