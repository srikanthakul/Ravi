package com.brunswick.ecomm.merclink.core.helper;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParentfieldHelper {
	private static final Logger LOG = LoggerFactory.getLogger(ParentfieldHelper.class);
	private String orderTitle;
	private String permissionCode;
	private List<subNastedHelper> subMenu;
	public ParentfieldHelper(Resource resource) {
		try {
			if(StringUtils.isNotBlank(resource.getValueMap().get("orderTitle",String.class))) {
				this.orderTitle = resource.getValueMap().get("orderTitle", String.class);
			}
			if(StringUtils.isNotBlank(resource.getValueMap().get("pPrmsnCode",String.class))) {
				this.permissionCode = resource.getValueMap().get("pPrmsnCode", String.class);
			}
			
		}catch(Exception e) {
			LOG.info("\n BEAN ERROR : {}",e.getMessage());
			
		}
		
	}
	public String getOrderTitle() {
		return orderTitle;
	}
	
	public String getPermissionCode() {
		return permissionCode;
	}
	
	public List<subNastedHelper> getSubMenu() {
		return new ArrayList<>(subMenu);
	}
	public void setSubMenu(List<subNastedHelper> subMenu){
		this.subMenu = new ArrayList<>(subMenu);
	}
}
