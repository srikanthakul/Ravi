package com.brunswick.ecomm.merclink.core.servlets.wishlist;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.http.Cookie;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.magento.graphql.WishlistItemInput;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.constants.MagentoAttributes;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractWishlistDetailsRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;
import com.shopify.graphql.support.ID;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=Merclink Configuration Servlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_POST, "sling.servlet.paths=" + "/bin/addToMercWishlist" })
public class AddtoWishListServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 8058516407707007720L;
	private static final Logger LOG = LoggerFactory.getLogger(AddtoWishListServlet.class);
	private transient AbstractWishlistDetailsRetriever wishlistRetriever;

	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
		try {
			String skuid, wishquantity, wishlisttype = null;
			JSONObject jsondata = new JSONObject(request.getParameter("data"));
			String type = request.getParameter("type").toString();
			PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
			List<WishlistItemInput> wishlistItems = new ArrayList<WishlistItemInput>();
			String resourcepath = jsondata.get("resourcePath").toString();
			LOG.info("jsondata : " + jsondata);
			wishlisttype = jsondata.get("wishlisttype").toString();
			if (type.equals("addfromcart")) {
				if (jsondata.has("cartobj") == true) {
					JSONArray cartArray = jsondata.getJSONArray("cartobj");
					for (int i = 0; i < cartArray.length(); i++) {
						LOG.info("cartArray " + cartArray.getJSONObject(i));
						skuid = cartArray.getJSONObject(i).getString("skuid");
						wishquantity = cartArray.getJSONObject(i).getString("quantity");
						LOG.info("wishquantity=== " + wishquantity);
						WishlistItemInput wishlistItemInput = new WishlistItemInput(Double.parseDouble(wishquantity),
								skuid);
						wishlistItems.add(wishlistItemInput);

					}
				}

			} else {
				LOG.info("quantity : " + jsondata.get("quantity"));
				LOG.info("skuid : " + jsondata.get("skuid"));

				LOG.info("resourcepath : " + resourcepath);

				LOG.info("wishlisttype : " + wishlisttype);
				String quantity = jsondata.get("quantity").toString();
				// WIshlist CODE

				WishlistItemInput wishlistItemInput = new WishlistItemInput(Double.parseDouble(quantity),
						(String) jsondata.get("skuid"));
				wishlistItems.add(wishlistItemInput);
			}
			Resource res = request.getResourceResolver().resolve(resourcepath);
			String token = CommonUtil.getTokenFromCookie("customerToken", request);
			Cookie[] cookies = request.getCookies();
			String companyNumber = null;
			if (cookies != null) {
				for (Cookie cookie : cookies) {
					if (cookie.getName().equals(MagentoAttributes.CUSTOMER_NUMBER)) {
						companyNumber = cookie.getValue();
					}
				}
			}
			List<Header> headers = new ArrayList<>();
			headers.add(new BasicHeader("Authorization", "Bearer " + token));
			MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(res,
					pageManager.getPage(res.getPath()), request, headers);
			wishlistRetriever = new AbstractWishlistDetailsRetriever(magentoGraphqlClient);

			LOG.info("in servlet before calling retriever");
			if (wishlisttype.equalsIgnoreCase("newwish")) {
				String wishlistname = jsondata.get("wishlistname").toString();
				String listtype = jsondata.get("listtype").toString();
				if (wishlistRetriever != null) {
					String id = wishlistRetriever.createWishlist(wishlistname, listtype, companyNumber);
					if(id.contains("already exists")) {
						JSONObject errorData = new JSONObject();
						errorData.put("alreadyExists", id);
						response.setStatus(200);
						response.setContentType("application/json");
						response.getWriter().print(errorData);
					} else {
						wishlistRetriever.addWishlistItems(new ID(id.replace("\"", "")), wishlistItems);
						response.setStatus(200);
						response.setContentType("application/json");
						response.getWriter().print(jsondata);
					}
					
				}

			} else {
				String wishListid = jsondata.get("id").toString();
				ID wishlistId = new ID(wishListid);
				if (wishlistRetriever != null) {
					wishlistRetriever.addWishlistItems(wishlistId, wishlistItems);
				}
				response.setStatus(200);
				response.setContentType("application/json");
				response.getWriter().print(jsondata);
			}
			
		} catch (JSONException e) {
			LOG.error("Json Exception " + e.getMessage());
		} catch (RuntimeException e) {
			LOG.error("RunTime Exception {}", e.getMessage());
		}
	}
}
