package com.brunswick.ecomm.merclink.core.constants;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.DamConstants;
import com.day.cq.wcm.api.NameConstants;
import com.day.cq.wcm.webservicesupport.ConfigurationConstants;

public class CommonConstants {


	/** The Constant SLASH_STRING. */
	/* **************** Symbol Constants - Starts Here **************** */
	public static final String RESOURCE_PATH = "/jcr:content/root";
	
	public static final String SLASH_STRING = "/";

	/** The Constant DOUBLE_QUOTE. */
	public static final String DOUBLE_QUOTE = "\"";

	/** The Constant FORWARD_SLASH. */
	public static final String FORWARD_SLASH = "\\/";

	/** The Constant SEMI_COLON. */
	public static final String SEMI_COLON = ";";

	/** The Constant HASH_STRING. */
	public static final String HASH_STRING = "#";

	/** The Constant DOLLAR. */
	public static final String DOLLAR = "$";

	/** The Constant PIPE. */
	public static final String PIPE = "\\|";

	/** The Constant DOUBLE_SLASH. */
	public static final String DOUBLE_SLASH = "//";

	/** The Constant DOUBLE_QUOTE_WITH_SPACE. */
	public static final String DOUBLE_QUOTE_WITH_SPACE = "\" ";

	/** The Constant UNDERSCORE. */
	public static final String UNDERSCORE = "_";

	/** The Constant HYPHEN. */
	public static final String HYPHEN = "-";

	/** The Constant COMMA. */
	public static final String COMMA = ",";

	/** The Constant COMMA_SPACE. */
	public static final String COMMA_SPACE = ", ";

	/** The Constant PERIOD. */
	public static final String PERIOD = ".";

	/** The Constant AMPERSAND_DELIMITER. */
	public static final String AMPERSAND_DELIMITER = "&";

	/** The Constant SPACE_STRING. */
	public static final String SPACE_STRING = " ";

	/** The Constant BACKSLASH_SINGLE_QUOTE. */
	public static final String BACKSLASH_SINGLE_QUOTE = "\\'";

	/** The Constant BACKSLASH_PERIOD. */
	public static final String BACKSLASH_PERIOD = "\\.";

	/** The Constant SPACE_HYPEHN_SPACE. */
	public static final String SPACE_HYPEHN_SPACE = " - ";

	/** The Constant COLON. */
	public static final String COLON = ":";

	/** The Constant SINGLE_QUOTE. */
	public static final String SINGLE_QUOTE = "'";

	/** The Constant COLON_SLASH. */
	public static final String COLON_SLASH = ":/";

	/** The Constant QUESTION_MARK_CHAR. */
	public static final char QUESTION_MARK_CHAR = '?';

	/** The Constant QUESTION_MARK_STR. */
	public static final String QUESTION_MARK_STR = "?";

	/** The Constant COLON_DOUBLE_SLASH. */
	public static final String COLON_DOUBLE_SLASH = "://";

	/** The Constant STRING_NEXT_LINE. */
	public static final String STRING_NEXT_LINE = "\n";

	/** The Constant STAR_CHAR. */
	public static final char STAR_CHAR = '*';

	/** The Constant STAR_ESCAPE_CHAR. */
	public static final String STAR_ESCAPE_CHAR = "%2A";

	/** The Constant SPACE_ESCAPE_CHAR1. */
	public static final String SPACE_ESCAPE_CHAR1 = "%20";

	/** The Constant PLUS_CHAR. */
	public static final char PLUS_CHAR = '+';

	/** The Constant PERCENTAGE_CHAR. */
	public static final char PERCENTAGE_CHAR = '%';

	/** The Constant E_CHAR. */
	public static final char E_CHAR = 'E';

	/** The Constant TILD_CHAR. */
	public static final char TILD_CHAR = '~';

	/** The Constant REG_EXPR. */
	public static final String REG_EXPR = "(?s)<[^>]*>(\\s*<[^>]*>)*";

	/** The Constant SEVEN_CHAR. */
	public static final char SEVEN_CHAR = '7';
	/* **************** Symbol Constants - Ends Here **************** */

	/* **************** Page Depths - Ends Here **************** */
	/** The Constant CONTENT_PAGE_DEPTH. */
	public static final int CONTENT_PAGE_DEPTH = 1;

	/** The Constant BRAND_PAGE_DEPTH. */
	public static final int BRAND_PAGE_DEPTH = 3;

	/** The Constant REGION_PAGE_DEPTH. */
	public static final int REGION_PAGE_DEPTH = 4;

	/** The Constant COUNTRY_PAGE_DEPTH. */
	public static final int COUNTRY_PAGE_DEPTH = 5;

	/** The Constant LANGUAGE_PAGE_DEPTH. */
	public static final int LANGUAGE_PAGE_DEPTH = 6;
	/* **************** Page Depths - Ends Here **************** */

	/*
	 * **************** Resource Property Constants - Starts Here
	 * ****************
	 */
	/** The Constant CLIENT_LIB_VERSION. */
	public static final String CLIENT_LIB_VERSION = "client.lib.version";

	/** The Constant FALLBACK_LOCALE. */
	public static final String FALLBACK_LOCALE = "en_US";

	/** The Constant TEMPLATE_PROP_KEY. */
	public static final String TEMPLATE_PROP_KEY = NameConstants.NN_TEMPLATE;

	/** The Constant REDIRECT_URL. */
	public static final String REDIRECT_URL = "redirectTarget";

	/** The Constant JCR_TITLE. */
	public static final String JCR_TITLE = JcrConstants.JCR_TITLE;

	/** The Constant JCR_DESC. */
	public static final String JCR_DESC = JcrConstants.JCR_DESCRIPTION;

	/** The Constant META_ROBOTS_NOINDEX. */
	public static final String META_ROBOTS_NOINDEX = "meta-robots-noindex";

	/** The Constant DEFAULT_BRAND_ALT_TEXT. */
	public static final String BRAND = "brand";

	/** The Constant HOMEPAGE. */
	public static final String HOMEPAGE = "homepage";

	/** The Constant HOME. */
	public static final String HOME = "home";

	/** The Constant JCR_MODIFIED. */
	public static final String JCR_MODIFIED = JcrConstants.JCR_LASTMODIFIED;

	/** The Constant HASH_VALUE. */
	public static final String HASH_VALUE = "hashValue";

	/** The Constant JCR_CREATED. */
	public static final String JCR_CREATED = JcrConstants.JCR_CREATED;

	/** The Constant JCR_CONTENT. */
	public static final String JCR_CONTENT = JcrConstants.JCR_CONTENT;

	/** The Constant PAGE_NODE_TYPE. */
	public static final String PAGE_NODE_TYPE = NameConstants.NT_PAGE;

	/** The Constant PAGE_CONTENT_NODE_TYPE. */
	public static final String PAGE_CONTENT_NODE_TYPE = "cq:PageContent";

	/** The Constant DAM_NODE_TYPE. */
	public static final String DAM_NODE_TYPE =DamConstants.NT_DAM_ASSET;

	/** The Constant UNSTRUCTURED_NODE_TYPE. */
	public static final String UNSTRUCTURED_NODE_TYPE =JcrConstants.NT_UNSTRUCTURED;

	/** The Constant JCR_PRIMARY_TYPE. */
	public static final String JCR_PRIMARY_TYPE = JcrConstants.JCR_PRIMARYTYPE;

	/** The Constant CQ_PAGE_CONTENT. */
	public static final String CQ_PAGE_CONTENT = "cq:PageContent";

	/** The Constant CQ_LAST_REPLICATED. */
	public static final String CQ_LAST_REPLICATED = NameConstants.PN_PAGE_LAST_REPLICATED;

	/** The Constant CQ_LAST_MODIFIED. */
	public static final String CQ_LAST_MODIFIED =NameConstants.PN_PAGE_LAST_MOD;

	/** The Constant SLING_VANITY. */
	public static final String SLING_VANITY =NameConstants.PN_SLING_VANITY_PATH;

	/** The Constant BASE_PAGE_PATH. */
	public static final String BASE_PAGE_PATH = "base.page.path";

	/** The Constant CLOUD_SERVICES. */
	public static final String CLOUD_SERVICES = ConfigurationConstants.PN_CONFIGURATIONS;

	/** The Constant REFERER_URL. */
	public static final String REFERER_URL = "referer";

	/** The Constant TARGET_BLANK. */
	public final static String TARGET_BLANK = "_blank";

	/** The Constant TARGET_SELF. */
	public final static String TARGET_SELF = "_self";
	/* **************** Property Constants - Ends Here **************** */

	/* ****** DuPont Data Integration Service Constants - Starts Here ******* */
	/** The Constant WEBSERVICE_SERVER_URL. */
	public final static String WEBSERVICE_SERVER_URL = "webservice.server.url";

	/** The Constant WEBSERVICE_STUB_ENABLED. */
	public final static String WEBSERVICE_STUB_ENABLED = "webservice.stub.enabled";

	/** The Constant WEBSERVICE_STUB_DIR. */
	public final static String WEBSERVICE_STUB_DIR = "webservice.stub.dir";

	/** The Constant JSON_DIR. */
	public final static String JSON_DIR = "json.dir";

	/** The Constant WEBSERVICE_API_KEY. */
	public final static String WEBSERVICE_API_KEY = "webservice.api.key";
	/* ****** DuPont Data Integration Service Constants - Ends Here ******* */

	/*
	 * **************** Site Configuration Constants - Starts Here
	 * ****************
	 */

	/** The Constant SITE_CONFIGURATION_NAME. */
	public static final String SITE_CONFIGURATION_NAME = "siteconfig";

	/** The Constant HOME_PAGE_PATH_PROP_NAME. */
	public static final String HOME_PAGE_PATH_PROP_NAME = "homePagePath";

	/** The Constant RECAPTCHA_SITEKEY. */
	public static final String RECAPTCHA_SITEKEY = "reCaptchaSiteKey";

	/*
	 * **************** Site Configuration Constants - Ends Here
	 * ****************
	 */

	/* **************** General Constants - Starts Here **************** */
	/** The Constant WCM_MODE. */
	public static final String WCM_MODE = "wcmmode";

	/** The Constant EDIT. */
	public static final String EDIT = "edit";

	/** The Constant DISABLED. */
	public static final String DISABLED = "disabled";

	/** The Constant PREVIEW. */
	public static final String PREVIEW = "preview";

	/** The Constant HTML_EXTN. */
	public static final String HTML_EXTN = ".html";

	/** The Constant TXT_EXTN. */
	public static final String TXT_EXTN = ".txt";

	/** The Constant PDF_EXTN. */
	public static final String PDF_EXTN = ".pdf";

	/** The Constant MP4_EXTN. */
	public static final String MP4_EXTN = ".mp4";

	/** The Constant LOCATION. */
	public static final String LOCATION = "Location";

	/** The Constant HTTP. */
	public static final String HTTP = "http";

	/** The Constant HTTPS. */
	public static final String HTTPS = "https";

	/** The Constant CACHE_CONTROL. */
	public static final String CACHE_CONTROL = "Cache-Control";

	/** The Constant NO_CACHE. */
	public static final String NO_CACHE = "no-cache";

	/** The Constant CONTENT__BASE_ROOT_FOLDER. */
	public static final String EXPERIENCE_FRAGMENT_MASTER_NODE = "master";

	/** The Constant TRUE. */
	public static final String TRUE = "true";

	/** The Constant FALSE. */
	public static final String FALSE = "false";

	/** The Constant EMPTY_ARRAY. */
	public static final String[] EMPTY_ARRAY = new String[0];

	/** The Constant WWW. */
	public static final String WWW = "www.";

	/** The Constant HTTP_SLASH. */
	public static final String HTTP_SLASH = "http://";

	/** The Constant UTF_8. */
	public static final String UTF_8 = "UTF-8";

	/** The Constant MEGA_BYTE. */
	public static final String MEGA_BYTE = "MB";

	/** The Constant KILO_BYTE. */
	public static final String KILO_BYTE = "KB";

	/** The Constant BYTE. */
	public static final String BYTE = "B";

	/** The Constant CONTENT_ROOT_PATH. */
	public static final String CONTENT_ROOT_PATH = "/content/";

	/** The Constant DAM_ROOT_PATH. */
	public static final String DAM_ROOT_PATH = "/content/dam/";

	/** The Constant FILE_NOT_FOUND_ERROR_MSG. */
	public static final String FILE_NOT_FOUND_ERROR_MSG = "File not found";

	/** The Constant NA. */
	public final static String NA = "NA";

	/** The Constant DATE_FORMAT_PUBLISH. */
	public static final String DATE_FORMAT_PUBLISH = "MMM, dd yyyy";

	/** The Constant DATE_FORMAT_NEWS_CAROUSEL. */
	public static final String DATE_FORMAT_NEWS_CAROUSEL = "MMM dd yyyy";

	/** The Constant DATE_FORMAT_WITH_OUT_TIME. */
	public static final String DATE_FORMAT_WITH_OUT_TIME = "yyyy-MM-dd";

	/** The Constant DATE_FORMAT_CARDS. */
	public static final String DATE_FORMAT_CARDS = "MMMM d, yyyy";

	/** The Constant RESOURCE_RESOLVER_READ_SERVICE. */
	public static final String RESOURCE_RESOLVER_READ_SERVICE = "readService";

	/** The Constant RESOURCE_RESOLVER_WRITE_SERVICE. */
	public static final String RESOURCE_RESOLVER_WRITE_SERVICE = "writeService";

	/** The Constant CAMPAIGN_PATH. */
	public static final String CAMPAIGN_PATH = "/content/campaigns/";

	/** The Constant ROOT_PATH_BAYLINER. */
	public static final String BL_ROOT_PATH_BOATS = "/content/brunswick/bayliner/na/us/en/boats";

	/** The Constant ROOT_PATH_BAYLINER_BUILD. */
	public static final String BL_ROOT_PATH_BOAT_CONFIGURATOR = "/content/brunswick/bayliner/na/us/en/build/boat-configurator";

	/** The Constant PAGE_TYPE. */
	public static final String PAGE_TYPE = "pageType";

	/* **************** General Constants - Ends Here **************** */

	/** The Constant LIST_FROM_MANUAL. */
	public static final String LIST_FROM_MANUAL = "manual";

	/** The Constant LIST_FROM_FIXEDLIST. */
	public static final String LIST_FROM_FIXEDLIST = "static";

	/** The Constant LIST_FROM_TAGS. */
	public static final String LIST_FROM_TAGS = "tags";

	/** The Constant LIST_FROM_DYNAMIC. */
	public static final String LIST_FROM_DYNAMIC = "dynamic";

	/** The Constant LIST_FROM_CHILDLIST. */
	public static final String LIST_FROM_CHILDLIST = "children";

	/** The Constant LIST_FROM_ARTICLES. */
	public static final String LIST_FROM_ARTICLES = "articles";

	/** The Constant PROP_NAME_BRAND. */
	public static final String PROP_NAME_BRAND = "brand";

	/** The Constant PROP_NAME_TEASER_TITLE. */
	public static final String PROP_NAME_TEASER_TITLE = "teaserTitle";

	/** The Constant PROP_NAME_TEASER_DESC. */
	public static final String PROP_NAME_TEASER_DESC = "teaserDesc";

	/** The Constant PROP_NAME_TEASER_EYEBROW. */
	public static final String PROP_NAME_TEASER_EYEBROW = "teaserEyebrow";

	/** The Constant PROP_NAME_TEASER_IMAGE. */
	public static final String PROP_NAME_TEASER_IMAGE = "teaserImage";

	/** The Constant LIST_COMP_PROP_IMAGE. */
	public static final String LIST_COMP_PROP_IMAGE = "image";

	/** The Constant LIST_COMP_PROP_IMAGE_ALT_TXT. */
	public static final String LIST_COMP_PROP_IMAGE_ALT_TXT = "altText";

	/** The Constant LIST_COMP_PROP_ICON. */
	public static final String LIST_COMP_PROP_ICON = "icon";

	/** The Constant LIST_COMP_PROP_EYEBROW_TXT. */
	public static final String LIST_COMP_PROP_EYEBROW_TXT = "eyebrowText";

	/** The Constant LIST_COMP_PROP_TITLE. */
	public static final String LIST_COMP_PROP_TITLE = "title";

	/** The Constant LIST_COMP_PROP_DATE. */
	public static final String LIST_COMP_PROP_DATE = "date";

	/** The Constant LIST_COMP_PROP_PATH. */
	public static final String LIST_COMP_PROP_PATH = "path";

	/** The Constant LIST_COMP_PROP_DESC. */
	public static final String LIST_COMP_PROP_DESC = "desc";

	/** The Constant LIST_COMP_PROP_LINK_TARGET. */
	public static final String LIST_COMP_PROP_LINK_TARGET = "newTab";

	public static final String LIST_COMP_PROP_MANUAL_IMG_CLICKABLE = "manualImagesClickable";

	public static final String LIST_COMP_PROP_MANUAL_TITLE_CLICKABLE = "manualTitlesClickable";

	public static final String LIST_COMP_PROP_CHILD_IMG_CLICKABLE = "childImagesClickable";

	public static final String LIST_COMP_PROP_CHILD_TITLE_CLICKABLE = "childTitlesClickable";

	public static final String LIST_COMP_PROP_FIXED_IMG_CLICKABLE = "fixedImagesClickable";

	public static final String LIST_COMP_PROP_FIXED_TITLE_CLICKABLE = "fixedTitlesClickable";
	public static final String LIST_COMP_PROP_IMG_BOTTOM_TAG = "imgbottomtag";

	/** The Constant PROP_OG_TITLE. */
	public static final String PROP_OG_TITLE = "ogTitle";

	/** The Constant PROP_OG_DESC. */
	public static final String PROP_OG_DESC = "ogDesc";

	/** The Constant PROP_OG_IMAGE. */
	public static final String PROP_OG_IMAGE = "ogImage";

	/** The Constant PROP_OG_URL. */
	public static final String PROP_OG_URL = "ogURL";

	/** The Constant PROP_CANONICAL_URL. */
	public static final String PROP_CANONICAL_URL = "canonicalURL";

	/** The Constant CONTENT_ROOT_PATH. */
	public static final String SITE_CONTENT = "content";

	/** The Constant CONTENT_ROOT_PATH. */
	public static final String ASSET_CONTENT = "asset";

	/** The Constant BRAND_TITLE. */
	public static final String BRAND_TITLE = "brands";
	
	/** The Constant POSTAL_TITLE. */
	public static final String POSTAL_TITLE = "postalcodes";

	/** The Constant DEALER_TITLE. */
	public static final String DEALER_TITLE = "dealers";

	/** The Constant COUNTRY_TITLE. */
	public static final String COUNTRY_TITLE = "countries";

	/** The Constant PLACEID_TITLE. */
	public static final String PLACEID_TITLE = "placeid";

	/** The Constant ASSET_METADATA_ALT_TEXT. */
	public static final String ASSET_METADATA_ALT_TEXT = "altText";
}
