package com.brunswick.ecomm.merclink.core.servlets.checkout;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.EcommTokenService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonObject;



@Component(service = Servlet.class, property = { "sling.servlet.methods=GET",
"sling.servlet.paths=/bin/merclink/getAddressesServlet" })
public class GetAddressServlet  extends SlingAllMethodsServlet{

	private static final Logger LOG = LoggerFactory.getLogger(GetAddressServlet.class);
	private static final long serialVersionUID = 1L;
	   
	String currentPagePath;

	 @Reference
		EcommTokenService tokenService;
	    @Reference
		transient APIGEEService apigeeservice;

	@Reference
		transient EcommSessionService ecommservice;

	
	
	   
	 public void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
	 
	LOG.debug("customer address");

	JSONObject requestObj;

	try{
		
	
	long startTime = System.currentTimeMillis();

	LOG.info(" GetAddressServlet Request start time :{}", startTime);
	
	PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
	requestObj = new JSONObject(request.getParameter("data"));
	currentPagePath = requestObj.get("resourcePath").toString();
	Resource resource = request.getResourceResolver().resolve(currentPagePath);
    String customerNumber = requestObj.get("customerNumber").toString();
	
	LOG.info("innnnnn res==" + resource);
     JsonObject jsonresponse = null;

	if (resource != null) {
	
		 jsonresponse = apigeeservice.getAddressDetails( customerNumber, resource.getPath(),
							ecommservice.getReadServiceResourceResolver());	
	
	long endTime = System.currentTimeMillis();
	LOG.info(" GetAddressServlet Response end time :"+endTime+" Time difference b/w request and response of GetAddressServlet : {}", (endTime-startTime));
	LOG.info(" GetAddressServlet jsonresponse=" + jsonresponse);
	
}
	response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
	response.setContentType("application/json");
	response.getWriter().print(jsonresponse);
	
	}


	catch (JSONException e) {
		LOG.error("Json Exception " + e.getMessage(),e);
	} catch (LoginException e) {
		LOG.error("Login Exception " + e.getMessage(),e);
	}
	 }
	 }