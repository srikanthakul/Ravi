package com.brunswick.ecomm.merclink.core.utils;

import java.util.HashMap;
import java.util.Map;



public class ValidateContactUsServlet {
 
	 
	 public Map<String, String> validate(Map<String,String> jsondata) {
		 
		 Map<String, String> errormessages = new HashMap<>(); 
		 		 
		
		 if(!isValidName(jsondata.get("fname"))){
			 errormessages.put("fnameError","Invalid First Name");
		}
		 else if(jsondata.get("fname").equals("")) {
			 errormessages.put("fnameError","First Name Required");
		 }
		 if(!isValidName(jsondata.get("lname"))){
			 errormessages.put("lnameError","Invalid Last Name");
		 }
		 else if(jsondata.get("lname").equals("")) {
			 errormessages.put("lnameError","Last Name Required");
		 }
//		 if(!isValidAddress(jsondata.get("address1"))){
//			 errormessages.put("addline1Error","Invalid Address");
//		 }
//		 else if(jsondata.get("address1").equals("")) {
//			 errormessages.put("addline1Error","Address Required");
//		 }
//		 if(!isValidAddress(jsondata.get("address2"))){
//			 errormessages.put("addline2Error","Invalid Address");
//		 }
//		 if(!isValidCity(jsondata.get("city"))){
//			 errormessages.put("cityError","Invalid City");
//		 }
//		 else if(jsondata.get("city").equals("")) {
//			 errormessages.put("cityError","City Required");
//		 }
//		 if(!isValidZipcode(jsondata.get("zipcode"))){
//			 errormessages.put("zcodeError","Invalid Zipcode");
//		 }
//		 else if(jsondata.get("zipcode").equals("")) {
//			 errormessages.put("zcodeError","Zipcode Required");
//		 }
		 if(!isValidPhone(jsondata.get("phone"))){
			 errormessages.put("phonenoError","Invalid Phone Number");
			 }
		 if(!isValidEmail(jsondata.get("email"))){
			 errormessages.put("emailError","Invalid Email Address");
		 }
		 return errormessages;
	 } 
	 
	 public boolean isValidEmail(String email) {
		 if(!email.equals("")) {
		 return email.matches("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$");
		 }
		 else {
			 return true;
		 }
	 }
	 
	 public boolean isValidPhone(String phone) {
		 if(!phone.equals("")) {
			 return phone.matches("[0-9]{10,}");
		 }
		 else {
			 return true;
		 }
		 
	 }
	 
	 public boolean isValidName(String name) {
	 return name.matches("[a-zA-Z\\s]+");
	 }
	 
	 public boolean isValidAddress(String addline) {
		 if(!addline.equals("")) {
		 return addline.matches("[a-zA-Z0-9\\s,.-]+");
		 }
		 else {
			 return true;
		 }
	 }
	 
	 public boolean isValidCity(String city) {
		 return city.matches("[a-zA-Z\\s]+");
	 }
	 
	 public boolean isValidZipcode(String zipcode) {
			 return zipcode.matches("[0-9]+");
	 }
	 
	 
	 
}