package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.beans.productprice.PriceAvailabilityBean;
import com.brunswick.ecomm.core.beans.productprice.PriceCodeResultBean;
import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.brunswick.ecomm.core.util.CommonUtil;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.constants.CatalogConstants;
import com.brunswick.ecomm.merclink.core.models.FacetObj;
import com.brunswick.ecomm.merclink.core.models.FacetOption;
import com.brunswick.ecomm.merclink.core.models.ProductItem;
import com.brunswick.ecomm.merclink.core.models.ProductListResponse;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractProductsListingRetriever;
import com.brunswick.ecomm.merclink.core.models.retriever.ProductsRequest;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=ProductListing Servlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_POST, "sling.servlet.paths=" + "/bin/productlistingservlet" })
public class ProductListingServlet extends SlingAllMethodsServlet {

	private static final Logger LOG = LoggerFactory.getLogger(ProductListingServlet.class);
	private static final long serialVersionUID = 1L;
	transient MagentoGraphqlClient magentoGraphqlClient;

	transient AbstractProductsListingRetriever productsRetriever;
	String currentPagePath;
	String tokenParam;
	transient ProductsRequest productRequest;
	transient List<String> itemIds = null;
	String customerNumber;
	@Reference
	transient EcommSessionService adminService;

	@Reference
	transient APIGEEService apigeeService;

	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		String data = request.getParameter(CatalogConstants.DATA);
		String genericData = request.getParameter(CatalogConstants.GENERIC_DATA);
		LOG.info("data requested:::{}", data);
		LOG.info("genericData requested:::{}", genericData);
		Type type = new TypeToken<List<FacetObj>>() {
		}.getType();
		List<FacetObj> filterMap = new Gson().fromJson(data, type);
		PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
		
		// if (null == tokenParam)
		tokenParam = CommonUtil.getTokenFromCookie("customerToken", request);
		// if (null == customerNumber)
		customerNumber = CommonUtil.getTokenFromCookie("customerNumber", request);
		prepareRequest(genericData, filterMap,customerNumber);

		LOG.info("customerToken:::{}", tokenParam);
		LOG.info("customerNumber :::{}", customerNumber);
		if (null != tokenParam && null != customerNumber) {
			List<Header> headersVal = new ArrayList<>();
			headersVal.add(new BasicHeader("Authorization", "Bearer " + tokenParam));
			Resource resource = request.getResourceResolver().resolve(currentPagePath);
			LOG.info("resource :::{}", resource.getPath());

		LOG.info("resource path:::{}", pageManager.getPage(resource.getPath()));

			if (resource != null) {
				magentoGraphqlClient = MagentoGraphqlClient.create(resource, pageManager.getPage(currentPagePath),
						request, headersVal);
				if (null != magentoGraphqlClient) {
					ProductListResponse productsResponse = getProducts(magentoGraphqlClient, productRequest);
					LOG.info("Magento plp response :::{}", new Gson().toJson(productsResponse));
//					PriceCodeResultBean apigeeResponse = null;
					// Get Apigee price details
					if (itemIds != null) {
						Long startTime = System.currentTimeMillis();
						ResourceResolver adminResolver = null;
						try {
							String salesPoolId = getSalesPoolIdByTaxGroup(request);
							adminResolver = adminService.getWriteServiceResourceResolver();
							// Commenting below line/call  as per INC1825139  
//							apigeeResponse = apigeeService.getProductsPrice(adminResolver,
//									currentPagePath, prepareApigeeRequest(itemIds, customerNumber, salesPoolId));
							
//							LOG.info("Apigee plp response :::{}", new Gson().toJson(apigeeResponse));
							Long endTime = System.currentTimeMillis();
							LOG.info("product size ... {}", itemIds.size());
							LOG.info("Apigee total exe time :::{}", (endTime - startTime) / 1000 + " seconds");
							LOG.info("==============================================");
						} catch (LoginException e) {
							LOG.error("Exception occured %f", e.getMessage());
						} finally {
							adminService.closeResourceResolver(adminResolver);
						}
					}
					if (null != productsResponse.getProdList() && productsResponse.getProdList().size() > 0
							) {
//						mergeResponse(productsResponse, apigeeResponse);
					}
					response.setContentType(CatalogConstants.CONTENT_TYPE);
					LOG.info("final plp response :::{}", new Gson().toJson(productsResponse));
					response.getWriter().print(new Gson().toJson(productsResponse));
				}

			}
		} else {
			LOG.info("Login details tokenparam/customerNumber missing to proceed on PLP... ");
		}

	}

	private String getSalesPoolIdByTaxGroup(SlingHttpServletRequest request) {
		String taxGroup = com.brunswick.ecomm.merclink.core.utils.CommonUtil.getCustomerTaxGroupFromCookie(request);
		String salesPoolId="";
		if("Export".equalsIgnoreCase(taxGroup)) {
			salesPoolId = "SPE";
		} else {
			salesPoolId = "SP";
		}
		return salesPoolId;
	}

	private ProductListResponse mergeResponse(ProductListResponse productsResponse,
			PriceCodeResultBean apigeeResponse) {

		for (ProductItem proditem : productsResponse.getProdList()) {

			for (PriceAvailabilityBean priceAvailabilityBean : apigeeResponse.getReturnCodeResults()) {
				if (priceAvailabilityBean.getItemNumber().equalsIgnoreCase(proditem.getSku())
						&& priceAvailabilityBean.getResponseStatus().getCode().equalsIgnoreCase("200")) {
					proditem.setBuyPrice(priceAvailabilityBean.getPrices().getCustomerQuotedPrice().getBuyPrice());
					proditem.setListPrice(priceAvailabilityBean.getPrices().getCustomerQuotedPrice().getListPrice());
					if (priceAvailabilityBean.getInventory().getStatus().getId().equalsIgnoreCase("1")) {
						// if ("test".equalsIgnoreCase("test")) {
						proditem.setAvailability("Available In Stock");
					} else {
						proditem.setAvailability("Currently Not In Stock");
						if (null != priceAvailabilityBean.getInventory()
								&& priceAvailabilityBean.getInventory().getDate() != null)
							proditem.setAvailableDate(
									"Estimated Availability " + priceAvailabilityBean.getInventory().getDate());
					}

				}
			}
		}
		return productsResponse;

	}

	private void prepareRequest(String genericData, List<FacetObj> filterMap, String customerNumber) {
		try {
			JSONObject requestObj = new JSONObject(genericData);
			String categoryId = requestObj.get(CatalogConstants.REQ_CATEGORYID).toString();
			String categoryPath = requestObj.get(CatalogConstants.CATEGORY_PATH).toString();
			String pageNo = null;
			if (requestObj.has(CatalogConstants.PAGE)) {
				pageNo = requestObj.get(CatalogConstants.PAGE).toString();
			} else {
				pageNo = "1";
			}
			String pageSize = requestObj.get(CatalogConstants.ITEM_SIZE).toString();
			String sort = requestObj.get(CatalogConstants.SORT).toString();
			currentPagePath = requestObj.get(CatalogConstants.RESOURCE_PATH).toString();
			//tokenParam = requestObj.get(CatalogConstants.TOKEN_PARAM).toString();
			productRequest = new ProductsRequest();
			productRequest.setCategoryId(categoryId);
			productRequest.setCategoryPath(categoryPath);
			productRequest.setCurrentPageNo(pageNo);
			productRequest.setPageSize(pageSize);
			productRequest.setFilterMap(filterMap);
			productRequest.setSort(sort);
			productRequest.setCustomerNumber(customerNumber);
			LOG.info("Token ===", tokenParam);
			LOG.info("catId::" + categoryId + " catpath :::" + categoryPath + " resourcepath :::" + currentPagePath
					+ " pageNo :::" + pageNo + " pagesize :::" + pageSize);
		} catch (Exception e) {
			LOG.error("required input error");
		}
	}

	public ProductListResponse getProducts(MagentoGraphqlClient magentoGraphqlClient, ProductsRequest prodReq) {

		Long startTimemagento = System.currentTimeMillis();
		productsRetriever = new AbstractProductsListingRetriever(magentoGraphqlClient);
		JsonObject jsonresponse = productsRetriever.getProductsList(prodReq);
		Long endTimeMagento = System.currentTimeMillis();
		LOG.info("==============================================");
		LOG.info("Magento exe time :::{}", (endTimeMagento - startTimemagento) / 1000 + " seconds");
		ProductListResponse list = new ProductListResponse();
		if (jsonresponse.getAsJsonObject(CatalogConstants.PRODUCTS) != null) {
			list = prepareProdList(jsonresponse);
		} else {
			list.setErrors(jsonresponse.getAsJsonPrimitive(CatalogConstants.PRODUCT_ERRORS));
		}
		return list;
	}

	private ProductListResponse prepareProdList(JsonObject jsonresponse) {
		JsonObject magentoProducts = jsonresponse.getAsJsonObject(CatalogConstants.PRODUCTS);
		List<ProductItem> prodList = prepareProducts(magentoProducts.getAsJsonArray(CatalogConstants.PRODUCT_ITEMS));
		List<FacetObj> facetList = prepareFacet(magentoProducts.getAsJsonArray(CatalogConstants.PRODUCT_AGGREGATIONS));
		ProductListResponse listResponse = new ProductListResponse();
		listResponse.setProdList(prodList);
		listResponse.setFacetList(facetList);
		listResponse.setProdCount(magentoProducts.get(CatalogConstants.PRODUCT_COUNT).getAsInt());
		return listResponse;
	}

	private List<FacetObj> prepareFacet(JsonArray asJsonArray) {
		List<FacetObj> facetList = new ArrayList<FacetObj>();
		asJsonArray.forEach(item -> {
			JsonObject obj = (JsonObject) item;
			JsonElement attrCode = obj.get(CatalogConstants.ATTRIBUTE_CODE);
			if (attrCode != null && magentoFiltering(attrCode.getAsString())) {
				FacetObj facetObj = new FacetObj();
				facetObj.setAttrCode(obj.get(CatalogConstants.ATTRIBUTE_CODE).getAsString());
				facetObj.setFacetLabel(obj.get(CatalogConstants.LABEL).getAsString());
				JsonArray ja = obj.getAsJsonArray(CatalogConstants.OPTIONS);
				List<FacetOption> options = new ArrayList<FacetOption>();
				ja.forEach(items -> {
					JsonObject facetobj = items.getAsJsonObject();
					FacetOption facetVal = new FacetOption();
					facetVal.setAttrCode(facetobj.get(CatalogConstants.VALUE).getAsString());
					facetVal.setAttrLabel(facetobj.get(CatalogConstants.LABEL).getAsString());
					facetVal.setAttrCount(facetobj.get(CatalogConstants.ATTR_COUNT).getAsString());
					options.add(facetVal);
					facetObj.setFacetList(options);
				});
				facetList.add(facetObj);
			}
		});
		return facetList;
	}

	private boolean magentoFiltering(String asString) {
		if (asString.equalsIgnoreCase(CatalogConstants.PRICE)) {
			return false;
		} else if (asString.equalsIgnoreCase(CatalogConstants.CATEGORY_ID)) {
			return false;
		}
		return true;
	}

	private List<ProductItem> prepareProducts(JsonArray jsonArray) {
		List<ProductItem> list = new ArrayList<ProductItem>();
		itemIds = new ArrayList<>();
		jsonArray.forEach(item -> {
			JsonObject ob = (JsonObject) item;
			ProductItem items = new ProductItem();
			itemIds.add(ob.get(CatalogConstants.SKU).getAsString());
			items.setItemId(ob.get(CatalogConstants.ID).getAsString());
			items.setSku(ob.get(CatalogConstants.SKU).getAsString());
			items.setName(ob.get(CatalogConstants.NAME).getAsString());
			JsonElement imageElement = ob.getAsJsonObject(CatalogConstants.IMAGE_DATA_CUSTOM)
					.get(CatalogConstants.PRODUCT_THUMBNAIL_CUSTOM);
					

			//  Image null check old code. 
			
			// if (null != imageElement && !imageElement.getAsString().isEmpty()) {
			// 	items.setImageUrl(imageElement.getAsString());
			// } else {
			// 	items.setImageUrl(null);
			// }

			//  Image null check new code. 
			String imgPath = null;
			try {
				 imgPath = imageElement.getAsString();
			}catch(Exception e) {
				 imgPath = null;
			}
			
			if (null != imgPath && !imgPath.isEmpty()) {
				items.setImageUrl(imageElement.getAsString());
			} else {
				items.setImageUrl(null);
			}

			JsonElement quantity = ob.get(CatalogConstants.QUANTITY);
			if (quantity.isJsonNull()) {
				items.setQuantity("1");
			} else {
				if (quantity.getAsString().equalsIgnoreCase("0")) {
					items.setQuantity("1");
				} else {
					items.setQuantity(quantity.getAsString());
				}
			}
			JsonElement hazardousCode = ob.get(CatalogConstants.HAZARDOUS_CODE);
			if (hazardousCode.isJsonNull()) {
				items.setHazardousCode("");
			} else {
				items.setHazardousCode(hazardousCode.getAsString());
			}
			
			JsonElement prop65 = ob.get(CatalogConstants.PROP65_CODE);
			if (prop65.isJsonNull()) {
				items.setProp65(null);
			} else {
				String prob65Msg = prop65.getAsString();
				if (prob65Msg.equalsIgnoreCase(CatalogConstants.PROP65_CANCER)
						|| prob65Msg.equalsIgnoreCase(CatalogConstants.PROP65_001)) {
					items.setProp65(CatalogConstants.PROP65_CANCER);
				} else if (prob65Msg.equalsIgnoreCase(CatalogConstants.PROP65_CANCER_REPRODUCTIVE)
						|| prob65Msg.equalsIgnoreCase(CatalogConstants.PROP65_003)
						|| prob65Msg.equalsIgnoreCase(CatalogConstants.PROP65_YES)) {
					items.setProp65(CatalogConstants.PROP65_CANCER_REPRODUCTIVE);
				} else if (prob65Msg.equalsIgnoreCase(CatalogConstants.PROP65_REPRODUCTIVE)
						|| prob65Msg.equalsIgnoreCase(CatalogConstants.PROP65_N)
						|| prob65Msg.equalsIgnoreCase(CatalogConstants.PROP65_002)) {
					items.setProp65(CatalogConstants.PROP65_REPRODUCTIVE);
				} else {
					items.setProp65(null);
				}
			}
			list.add(items);
		});
		return list;
	}

	private String prepareApigeeRequest(List<String> itemList, String customerNumber, String salesPoolId) {
		JsonObject parentObj = new JsonObject();
		parentObj.addProperty("customer_number", customerNumber);
		parentObj.addProperty("sales_pool_id", salesPoolId);
		JsonArray jsonArr = new JsonArray();
		for (String str : itemList) {
			JsonObject jsonObj = new JsonObject();
			jsonObj.addProperty("item_number", str);
			jsonObj.addProperty("quantity", 1);
			jsonArr.add(jsonObj);
		}
		parentObj.add("item_numbers", jsonArr);
		LOG.info("apigee request :::{}", parentObj.toString());
		return parentObj.toString();
	}
}
