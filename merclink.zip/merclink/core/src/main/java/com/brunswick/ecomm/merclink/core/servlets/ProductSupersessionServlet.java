package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;

import javax.servlet.Servlet;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "= Product Superssion Servlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_POST,
		"sling.servlet.paths=" + "/bin/merclink/productSupersession" })
public class ProductSupersessionServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	@Reference
	transient EcommSessionService adminService;
	@Reference
	transient APIGEEService apigeeService;
	private static final Logger LOG = LoggerFactory.getLogger(ProductSupersessionServlet.class);

	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.debug("inside do get Merclink Product Superssion");
		ResourceResolver resourceResolver = null;
		JSONObject supersessionData = null;
		try {
			resourceResolver = adminService.getWriteServiceResourceResolver();
			response.setContentType("application/json");
			LOG.info("inside Product Supersession of do get");
			JSONObject data = new JSONObject(request.getParameter("data"));
			String itemNumber = data.getString("itemNumber");
			String currentPage = data.getString("resourcePath");
			Resource currentPageRes = resourceResolver.getResource((resourceResolver.resolve(currentPage).getPath()));
			if (itemNumber != null && StringUtils.isNotBlank(itemNumber)) {
				supersessionData = apigeeService.getProductSupersessions(itemNumber, "true",
						currentPageRes, adminService.getWriteServiceResourceResolver());

			}
			response.getWriter().println(supersessionData);

		} catch (JSONException | LoginException e) {
			LOG.error("JSON/Login exception occurred %f", e);
		} finally {
			adminService.closeResourceResolver(resourceResolver);
		}
	}
}
