package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.Servlet;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.magento.graphql.ProductInterface;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.internal.quickorderform.QuickOrderFormRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.Gson;
import com.google.gson.JsonObject;


@Component(service = Servlet.class, property = { "sling.servlet.methods=" + HttpConstants.METHOD_POST,
		"sling.servlet.resourceTypes=" + "sling/servlet/default", "sling.servlet.selectors=" + "merclinkquickorderitems",
		"sling.servlet.extensions=" + "json" })
public class QuickOrderServlet extends SlingAllMethodsServlet{
	
	@Inject 
	private QuickOrderFormRetriever productRetriever;
	private static final long serialVersionUID = 1L;
    private static final Logger LOG = LoggerFactory.getLogger(QuickOrderServlet.class); 
    String currentPagePath;
    protected String RESOURCE_PATH;
    
	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
	

			//RESOURCE_PATH = request.getParameter("resourcePath").toString();
		JSONObject requestObj;
		try {
			requestObj = new JSONObject(request.getParameter("data"));
		
			PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
			//Resource res = request.getResourceResolver() 
					//.getResource(RESOURCE_PATH);
					currentPagePath = requestObj.get("resourcePath").toString();
			//String token=request.getParameter("token");
			//String token = (String) request.getSession().getAttribute("token");
			String token = CommonUtil.getTokenFromCookie("customerToken", request);
			Resource res = request.getResourceResolver().resolve(request, currentPagePath);
			LOG.info("Current page path=====================" + res.getPath());
			List<Header> headers = new ArrayList<>();
			headers.add(new BasicHeader("Authorization",
					"Bearer " + token));
			//MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(res,
					//pageManager.getPage(RESOURCE_PATH), request, headers);	
			MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(res,
					pageManager.getPage(res.getPath()), request, headers);
			
			if (magentoGraphqlClient != null) 
			{ 
				productRetriever = new QuickOrderFormRetriever(magentoGraphqlClient);
				setSkuQty(request, response);
				
			} 
		} catch (JSONException e) {
			LOG.error("Json Exception " + e.getMessage(),e);
		} catch (RuntimeException e) {
			LOG.error("RunTime Exception {}", e.getMessage(),e);
		}
	}
	
	

	public ProductInterface getProduct() {
			LOG.info("\ninside getProduct");
	        if (productRetriever == null) {
	            return null;
	        }
	        ProductInterface baseProduct = productRetriever.fetchProduct();
	        LOG.info("baseprod...."+baseProduct);
	        return baseProduct;
	}

	public List<ProductInterface> getProducts() {
			LOG.info("\ninside getProducts");
	        if (productRetriever == null) {
	        	LOG.info("productRetriever is null");
	            return null;
	        }
	        List<ProductInterface> baseProduct = productRetriever.fetchProducts();
	        if(baseProduct==null) {
	        	LOG.info("base prod is null");
	        }
	        return baseProduct;
	}
	 

	 
	 public String setResponseData(SlingHttpServletResponse response, JsonObject jsonObject) throws IOException {
		 response.setContentType("application/json");
			response.getWriter().println(jsonObject);
			response.getWriter().flush();
			response.getWriter().close();
		 return "success";
	 } 
		  
	
	public String setSkuQty(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		/*if(request.getParameter("sku")!=null || request.getParameter("sku") == "99" ) 
        {*/
		//productRetriever.setIdentifier(ProductIdentifierType.SKU, request.getParameter("sku"));
		productRetriever.setIdentifier(request.getParameter("sku"));
		LOG.info("request.getParameter=====================" + request.getParameter("sku"));
		Gson stringTree = new Gson(); 
		JsonObject jsonObject = new JsonObject();
		jsonObject.addProperty("quickorderItems", stringTree.toJson(getProduct()));
		setResponseData(response, jsonObject);
		/* }
        else 
        { 
        	List<String> skuidlist = new ArrayList<>();
   		 String skuid=request.getParameter("skuids");
   		LOG.info("request.getParameter=====================" + request.getParameter("skuids"));
   		String[] skuids=skuid.split(",");
   		
   		 Collections.addAll(skuidlist, skuids);
		JsonObject jsonObject = new JsonObject(); 
			productRetriever.setIdentifier(skuidlist);
			Gson stringTree = new Gson();
			List<ProductInterface> products = getProducts();
			int i=0;
			if(products!=null) {
				
				for (ProductInterface product : products) {
					jsonObject.addProperty("quickorderItems"+i, stringTree.toJson(product));
					i++;
				}
			}
			
		
		
		setResponseData(response,jsonObject);
        } */
		return "success"; 
	}
	}
