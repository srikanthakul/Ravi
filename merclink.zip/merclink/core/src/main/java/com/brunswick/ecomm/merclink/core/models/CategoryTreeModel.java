/*
 * package com.brunswick.ecomm.mmanzp.core.models;
 * 
 * import java.util.List;
 * 
 * import javax.annotation.PostConstruct; import javax.inject.Inject; import
 * org.slf4j.Logger; import org.slf4j.LoggerFactory; import
 * org.apache.sling.api.SlingHttpServletRequest; import
 * org.apache.sling.api.resource.Resource; import
 * org.apache.sling.models.annotations.Model; import
 * org.apache.sling.models.annotations.injectorspecific.Self;
 * 
 * import com.adobe.cq.commerce.magento.graphql.CategoryTree; import
 * com.brunswick.ecomm.mmanzp.core.client.MagentoGraphqlClient; import
 * com.brunswick.ecomm.mmanzp.core.models.retriever.
 * AbstractCategoryTreeRetriever; import com.day.cq.wcm.api.Page; import
 * com.google.gson.JsonObject; import
 * com.shopify.graphql.support.SchemaViolationError;
 * 
 * @Model(adaptables = SlingHttpServletRequest.class) public class
 * CategoryTreeModel { private static final Logger LOGGER =
 * LoggerFactory.getLogger(CategoryTreeModel.class); private
 * AbstractCategoryTreeRetriever abstractCategoryTree;
 * 
 * @Inject private Page currentPage; String categoryId;
 * 
 * @Self private SlingHttpServletRequest request; List<CategoryTree>
 * categoryTree; CategoryTree onecategoryTree;
 * 
 * @PostConstruct private void initModel() { Resource resource =
 * request.getResourceResolver().getResource(currentPage.getPath());
 * abstractCategoryTree = new AbstractCategoryTreeRetriever(
 * MagentoGraphqlClient.create(resource, currentPage, request, null)); }
 * 
 * public List<CategoryTree> getCategoryTree() throws SchemaViolationError {
 * categoryTree = abstractCategoryTree.getCategoryTree(); return categoryTree; }
 * 
 * 
 * public CategoryTree getTreeForCategory(){ categoryId =
 * request.getParameter("id"); LOGGER.info("categoryId=="+categoryId);
 * onecategoryTree =
 * abstractCategoryTree.getTreeForCategory(Integer.parseInt(categoryId));
 * 
 * return onecategoryTree;
 * 
 * }
 * 
 * }
 */