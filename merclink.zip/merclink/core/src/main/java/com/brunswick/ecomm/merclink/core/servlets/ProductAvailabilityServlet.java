package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractProductsAvailabilityRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonObject;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "= Product Availability Servlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_POST,
		"sling.servlet.paths=" + "/bin/merclink/productAvailability" })
public class ProductAvailabilityServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	@Reference
	transient EcommSessionService adminService;
	@Reference
	transient APIGEEService apigeeService;
	private transient AbstractProductsAvailabilityRetriever productRetriever;
	private static final Logger LOG = LoggerFactory.getLogger(ProductAvailabilityServlet.class);

	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.debug("inside do get Merclink ProductAvailability");
		ResourceResolver resourceResolver = null;
		
		try {
			PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
			resourceResolver = adminService.getWriteServiceResourceResolver();
			response.setContentType("application/json");
			LOG.info("inside Product Availability of do get");
			JSONObject data = new JSONObject(request.getParameter("data"));
			String itemNumber = data.getString("itemNumber");
			String currentPagePath = data.getString("resourcePath");
			String token = CommonUtil.getTokenFromCookie("customerToken",request);
			Resource resource = request.getResourceResolver().resolve(currentPagePath);
			if (itemNumber != null && StringUtils.isNotBlank(itemNumber)) {
				List<Header> headers1 = new ArrayList<>();
				headers1.add(new BasicHeader("Authorization", "Bearer " + token));
				JsonObject jsonresponse = new JsonObject();

				if(resource!= null) {
				MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(resource,
					pageManager.getPage(resource.getPath()), request, headers1);
				productRetriever = new AbstractProductsAvailabilityRetriever(magentoGraphqlClient);
				jsonresponse = productRetriever.getProductsAvaliability(itemNumber);

				LOG.info("Product Availability jsonresponse {}", jsonresponse);
				}
				response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
				response.setContentType("application/json");
				response.getWriter().print(jsonresponse);
				
				}

		} catch (JSONException | LoginException e) {
			LOG.error("JSON/Login exception occurred %f", e);
		} finally {
			adminService.closeResourceResolver(resourceResolver);
		}
	}

}
