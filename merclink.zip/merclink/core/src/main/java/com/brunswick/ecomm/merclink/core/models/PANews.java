package com.brunswick.ecomm.merclink.core.models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.models.impl.NewsSectionImpl;
import com.brunswick.ecomm.merclink.core.helper.MultifieldHelper;
import com.day.cq.wcm.api.Page;


@Model(
		adaptables = Resource.class,
		adapters = NewsSection.class,
		 defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
		)

public class PANews{
	
	static final Logger LOG = LoggerFactory.getLogger(PANews.class);
	
	@SlingObject
	Resource componentResource;
	
	@ValueMapValue
	private String newsSectionHeading;
	

   
    @Inject
    private ResourceResolver resolver;
	
    @ScriptVariable
    private Page currentPage;
	
	public String getNewsSectionHeading() {
		// TODO Auto-generated method stub
		return newsSectionHeading;
	}

	public List<Map<String, String>> getNewsSectionDetails() {
		LOG.info("Hello1");
		List<Map<String, String>> newsSectioDetails = new ArrayList<>();
		try {
			LOG.info("\n CNShippingUpdates PATH Current News {}");
			   
	    	componentResource = resolver.getResource("/content/ecommerce/merclink/au/en/home/news/P-ANews/jcr:content/root/container/container/allnews");
	    LOG.info("\n CNShippingUpdates PATH Current News path{}",componentResource.getPath());
	    LOG.info("\n CNShippingUpdates PATH Current News name {}",componentResource.getName());
	   
	    Resource loginDetailNasted=componentResource.getChild("currentnews");
	    LOG.info("\n Curren News  Resource ::" +loginDetailNasted.getName().toString());
		
		LOG.info("\n Entering loginDetailsNasteds");
		if(loginDetailNasted != null) {
			LOG.info("\n Inside loginDetailsNasteds");
			
			  for (Resource loginNasted : loginDetailNasted.getChildren()) {
					LOG.info("\n PATH Current News {}",loginNasted.getPath());
					LOG.info("\n PATH2 Current News {}",loginNasted);
					ValueMap property = loginNasted.adaptTo(ValueMap.class);
					String currentnewslinktext = property.get("currentnewslinktext", String.class);
					LOG.info("\n currentnewslinktext {}",currentnewslinktext);
					String currentnewsdata = property.get("currentnewsdata", String.class);
					LOG.info("\n currentnewsdata {}",currentnewsdata);
					String currentnewsicons = property.get("currentnewsicons", String.class);
					LOG.info("\n currentnewsicons {}",currentnewsicons);
					String currentnewslink = property.get("currentnewslink", String.class);
					LOG.info("\n currentnewslink {}",currentnewslink);
					String currentnewspdf = property.get("currentnewspdf", String.class);
					LOG.info("\n currentnewslink {}",currentnewspdf);
					String currentnewslctn = property.get("currentnewslctn", String.class);
					LOG.info("\n currentnewslink {}",currentnewslctn);
					String currentnewsdt = property.get("currentnewsdt", String.class);
					LOG.info("\n currentnewslink {}",currentnewsdt);
					Map<String,String> newsMap = new HashMap<>();
					newsMap.put("currentnewslinktext", property.get("currentnewslinktext", String.class));
					newsMap.put("currentnewsdata", property.get("currentnewsdata", String.class));
					newsMap.put("currentnewsicons", property.get("currentnewsicons", String.class));
					newsMap.put("currentnewslink", property.get("currentnewslink", String.class));
					newsMap.put("currentnewspdf", property.get("currentnewspdf", String.class));
					newsMap.put("currentnewslctn", property.get("currentnewslctn", String.class));
					newsMap.put("currentnewsdt", property.get("currentnewsdt", String.class));
					newsSectioDetails.add(newsMap);
				}
		}
			/*
			 * 
			 * Resource resource =
			 * getResource("/content/mmanzp/au/en/home/news/current-news"); SlingQuery
			 * collectionItr = $(resource)
			 * .closest("cq:PageContent").siblings("cq:Page").first().children();
			 * Iterator<Resource> childItr = collectionItr.iterator();
			 * 
			 * Resource childRes = childItr.next(); SlingQuery collectionItr2 = $(childRes)
			 * .closest("cq:PageContent").siblings("cq:Page").first().children();
			 * 
			 * SlingQuery collectionItr3 = collectionItr2.children();
			 * LOG.debug("collectionItr3------{}", collectionItr3.children());
			 * 
			 * SlingQuery collectionItr4 = collectionItr3.children();
			 * LOG.debug("collectionItr4------{}", collectionItr4.children());
			 * 
			 * SlingQuery collectionItr5 = collectionItr4.children();
			 * LOG.debug("collectionItr5------{}", collectionItr5.children());
			 * 
			 * SlingQuery collectionItr6 = collectionItr5.children();
			 * LOG.debug("collectionItr6------{}", collectionItr6.children());
			 * 
			 * SlingQuery collectionItr7 = collectionItr6.children();
			 * LOG.debug("collectionItr7------{}", collectionItr7.children());
			 * 
			 * Iterator<Resource> childItr1 = collectionItr6.iterator();
			 * 
			 * Resource childRes1 = childItr1.next();
			 * LOG.debug("childRes.getPath1()------{}", childRes1.getPath());
			 * LOG.debug("collectionItr21()------{}", collectionItr7.children());
			 * LOG.debug("childRes.getPath2()------{}", childRes1.getValueMap());
			 * 
			 * LOG.debug("childRes.getPath3()------{}", childRes1.listChildren().next());
			 * Resource currentNewssDetails = childRes1.listChildren().next(); for (Resource
			 * currentNewss : currentNewssDetails.getChildren()) {
			 * LOG.info("\n PATH Current News {}",currentNewss.getPath());
			 * LOG.info("\n PATH2 Current News {}",currentNewss); ValueMap property =
			 * currentNewss.adaptTo(ValueMap.class); String currentnewslinktext =
			 * property.get("currentnewslinktext", String.class);
			 * LOG.info("\n currentnewslinktext {}",currentnewslinktext); String
			 * currentnewsdata = property.get("currentnewsdata", String.class);
			 * LOG.info("\n currentnewsdata {}",currentnewsdata); Map<String,String> newsMap
			 * = new HashMap<>(); newsMap.put("currentnewslinktext",
			 * property.get("currentnewslinktext", String.class));
			 * newsMap.put("currentnewsdata", property.get("currentnewsdata",
			 * String.class)); newsSectioDetails.add(newsMap); }
			 * 
			 * 
			 * 
			 * 
			 * 
			 */
			}catch(Exception e) {
			LOG.info("\n ERROR while getting News Section Details {}", e.getMessage());
		}
		LOG.info("\n SIZE {} ",newsSectioDetails.size() );
		return newsSectioDetails;
	}
	private Resource getResource(String string) {
		// TODO Auto-generated method stub
		return componentResource ;
	}

}