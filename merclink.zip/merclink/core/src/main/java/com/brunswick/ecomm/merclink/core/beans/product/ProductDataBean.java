package com.brunswick.ecomm.merclink.core.beans.product;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductDataBean {
	@JsonProperty("inventory")
	private InventoryBean inventory;
	@JsonProperty("item_number")
	private String itemNumber;
	@JsonProperty("alternate_item_number")
	private String alternateItemNumber;
	@JsonProperty("superseeded_for_item")
	private String superseededForItem;
	@JsonProperty("description")
	private String description;
	@JsonProperty("item_type")
	private String itemType;
	@JsonProperty("item_status")
	private String itemStatus;
	@JsonProperty("total_quantity")
	private String totalQuantity;
	@JsonProperty("date")
	private String date;
	//include prices
	
	public String getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	public String getAlternateItemNumber() {
		return alternateItemNumber;
	}
	public void setAlternateItemNumber(String alternateItemNumber) {
		this.alternateItemNumber = alternateItemNumber;
	}
	public String getSuperseededForItem() {
		return superseededForItem;
	}
	public void setSuperseededForItem(String superseededForItem) {
		this.superseededForItem = superseededForItem;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public String getItemStatus() {
		return itemStatus;
	}
	public void setItemStatus(String itemStatus) {
		this.itemStatus = itemStatus;
	}
	public String getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(String totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public InventoryBean getInventory() {
		return inventory;
	}
	public void setInventory(InventoryBean inventory) {
		this.inventory = inventory;
	}

}
