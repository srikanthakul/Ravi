package com.brunswick.ecomm.merclink.core.models.internal.contactus;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractCustomRetriever;
import com.google.gson.JsonObject;

public class ContactUsVerifyUserRetriever  extends AbstractCustomRetriever{
	private static final Logger LOGGER = LoggerFactory.getLogger(ContactUsVerifyUserRetriever.class);

	public ContactUsVerifyUserRetriever(MagentoGraphqlClient client) {
		super(client); 
	}
	private String queryString;
	public JsonObject getResponse() {
		queryString = getResponseDefinition();
		GraphqlResponse<JsonObject , Error> response = executeQuerygraphql();
		LOGGER.info("response="+response.toString());
		return response.getData();
	}

	protected GraphqlResponse<JsonObject , Error> executeQuerygraphql() { 
		return client.executeQuery(queryString);
	}

	@Override
	protected void populate() {
		// NOTHING TO DO
		
	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return null;
	}
	private String getResponseDefinition() {
	
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("query{\r\n" + 
				" department_list{ \r\n" + 
				"department_name\r\n" + 
				" }");
		queryBuilder.append(" customer{firstname lastname suffix email group_id addresses");
		queryBuilder.append("{firstname lastname telephone}}");
		queryBuilder.append("company{company_admin{firstname lastname email}");
		queryBuilder.append("email id legal_address{street city region{region_id region_code}");
		queryBuilder.append("postcode country_code telephone}legal_name name customer_number}}");
		LOGGER.info("query string "+ queryBuilder.toString());
		return queryBuilder.toString();
			 
	}

}
