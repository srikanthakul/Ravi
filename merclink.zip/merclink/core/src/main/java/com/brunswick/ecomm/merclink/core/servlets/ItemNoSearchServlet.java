package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.Servlet;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.magento.graphql.ProductInterface;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.internal.quickorderform.ItemNoSearchRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.Gson;
import com.google.gson.JsonObject;



/*@Component(service = Servlet.class, property = { "sling.servlet.methods=" + HttpConstants.METHOD_POST,
		"sling.servlet.resourceTypes=" + "sling/servlet/default", "sling.servlet.selectors=" + "itemsearch",
		"sling.servlet.extensions=" + "json" })*/
@Component(service = Servlet.class,property = {
"sling.servlet.methods="+HttpConstants.METHOD_POST, "sling.servlet.paths="
+ "/bin/merclinkItemNoSearchServlet"
})
public class ItemNoSearchServlet extends SlingAllMethodsServlet {
	@Inject 
	private ItemNoSearchRetriever productRetriever;
	private static final long serialVersionUID = 1L;
    private static final Logger LOG = LoggerFactory.getLogger(ItemNoSearchServlet.class); 
    String currentPagePath;
    protected String RESOURCE_PATH; 
    
    @Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
    		//RESOURCE_PATH = request.getParameter("resourcePath");
    	JSONObject requestObj;
    	try {
			requestObj = new JSONObject(request.getParameter("data"));
			PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
			currentPagePath = requestObj.get("resourcePath").toString();
		//	Resource res = request.getResourceResolver() 
			//		.getResource(RESOURCE_PATH);
			//String token=request.getParameter("token");
			//String token = (String) request.getSession().getAttribute("token");
			//String token = CommonUtil.getTokenFromCookie("customerToken", request);
			String token = CommonUtil.getTokenFromCookie("customerToken", request);
		Resource res = request.getResourceResolver().resolve(request, currentPagePath);
			LOG.info("Current page path=====================" + res.getPath());
			LOG.info("token=="+token);
			List<Header> headers = new ArrayList<>();
			headers.add(new BasicHeader("Authorization",
					"Bearer " + token));
			LOG.info(headers+"...headers...");
			//MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(res,
					//pageManager.getPage(RESOURCE_PATH), request, headers);
			MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(res,
					pageManager.getPage(res.getPath()), request, headers);
			
			if (magentoGraphqlClient != null) 
			{ 
				productRetriever = new ItemNoSearchRetriever(magentoGraphqlClient);
				
				productRetriever.setInput(request.getParameter("input"));
				
				Gson stringTree = new Gson(); 
				JsonObject jsonObject = new JsonObject();
				jsonObject.addProperty("Items", stringTree.toJson(getProduct()));
				setResponseData(response, jsonObject);
				LOG.info("\n\nProduct sku "+getProduct());        
		      
				
			}
			
    	} catch (JSONException e) {
			LOG.error("Json Exception " + e.getMessage(),e);
		} catch (RuntimeException e) {
			LOG.error("RunTime Exception {}", e.getMessage(),e);
		}	
		
	}
	public List<ProductInterface> getProduct() {
		LOG.info("\ninside getProduct");
        if (productRetriever == null) {
            return null;
        }
        List<ProductInterface> baseProduct = productRetriever.fetchProduct();
        LOG.info("baseprod...."+baseProduct);
        return baseProduct;
	}
	
    public String setResponseData(SlingHttpServletResponse response, JsonObject jsonObject) throws IOException {
		 response.setContentType("application/json");
			response.getWriter().println(jsonObject);
			response.getWriter().flush();
			response.getWriter().close();
		 return "success";
	 } 
}
