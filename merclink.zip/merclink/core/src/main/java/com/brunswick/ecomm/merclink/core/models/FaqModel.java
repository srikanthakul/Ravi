package com.brunswick.ecomm.merclink.core.models;

import java.util.List;
import java.util.Map;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
public interface FaqModel {
	String getFaqHeader();
	List<Map<String,String>> getFaqDetails();
}
