package com.brunswick.ecomm.merclink.core.servlets.wishlist;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractWishlistDetailsRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.shopify.graphql.support.ID;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=Wishlist Details Servlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_POST, "sling.servlet.paths=" + "/bin/WishlistMercDetailsServlet" })
public class WishlistDetailsServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory.getLogger(WishlistDetailsServlet.class);
	protected String RESOURCE_PATH;

	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.info("in do Post");
		JsonObject jsonData;
		jsonData = new Gson().fromJson(request.getParameter("data"), JsonObject.class);
		ID wishlistId = new ID(jsonData.get("wishlistid").toString().replaceAll("\"", ""));
		String pageSize = jsonData.get("pageSize").toString().replaceAll("\"", "");
		String page = jsonData.get("currentPage").toString().replaceAll("\"", "");
		LOG.info("wishlistId:{}", wishlistId);
		LOG.info("pageSize:{}", pageSize);
		LOG.info("page:{}", page);
		RESOURCE_PATH = request.getParameter("resourcePath").toString();
		PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
		Resource res = request.getResourceResolver().getResource(RESOURCE_PATH);
		String token = CommonUtil.getTokenFromCookie("customerToken", request);
		List<Header> headers = new ArrayList<>();
		headers.add(new BasicHeader("Authorization", "Bearer " + token));
		if (pageManager.getPage(RESOURCE_PATH) != null) {

			MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(res,
					pageManager.getPage(RESOURCE_PATH), request, headers);

			if (magentoGraphqlClient != null) {
				LOG.info("magentoGraphqlClient:{}", magentoGraphqlClient);
				AbstractWishlistDetailsRetriever retriever = new AbstractWishlistDetailsRetriever(magentoGraphqlClient);
				JsonObject queryresponse = retriever.getQueryPaginationOfWishlist(wishlistId, pageSize, page);
				LOG.info("queryresponse in do Post{}", queryresponse);
				response.setContentType("application/json");
				response.getWriter().print(queryresponse);
			}
		} else {
			LOG.info("pagemgr is null{}", RESOURCE_PATH);
		}

	}

}
