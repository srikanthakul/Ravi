package com.brunswick.ecomm.merclink.core.utils;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.core.components.services.ComponentsConfiguration;
import com.adobe.cq.wcm.launches.utils.LaunchUtils;
import com.brunswick.ecomm.core.util.PathLinkUtil;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.constants.CommonConstants;
import com.day.cq.commons.inherit.ComponentInheritanceValueMap;
import com.day.cq.commons.inherit.HierarchyNodeInheritanceValueMap;
import com.day.cq.commons.inherit.InheritanceValueMap;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

public class CommonUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtil.class);

	private static final String ERRORS_ROOT_PAGE = "/etc/acs-commons/lists/ecommerce/delcity/";
	
	public static final String STORE_CODE_PROPERTY = "magentoStore";

	public static String getTokenFromCookie(String cookieName, SlingHttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		String defaultValue = "";
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				Cookie cookie = cookies[i];
				if (cookieName.equals(cookie.getName())) {
					LOGGER.error("Cookie value {}", cookie.getValue());
					return (cookie.getValue());
				}
			}
		}
		return (defaultValue);
	}

	public static void setCookie(String cookieName, String cookieValue, SlingHttpServletResponse response) {
		Cookie cookie = new Cookie(cookieName, cookieValue);
		cookie.setMaxAge(-1);
		cookie.setPath("/");
		response.addCookie(cookie);
	}

	public static String getUserMessage(ResourceResolver rr, Page currentPage, String error) {

		LOGGER.debug("Current Page Path in getUserMessage(): {}", currentPage.getPath());
		if (currentPage != null && currentPage.getPath().contains(CommonConstants.CONTENT_ROOT_PATH)) {

			String languageCode = getLanguageCode(currentPage);
			if(!StringUtils.isEmpty(languageCode)) {
				Resource resource = rr.resolve(ERRORS_ROOT_PAGE.concat(languageCode+"-errors/jcr:content/list"));
				Iterable<Resource> itrRes =  resource.getChildren();
				for (Resource res : itrRes) {
					ValueMap valueMap = res.getValueMap();
					if (null != valueMap && null != error) {
						String val = (String) valueMap.get("value");
						LOGGER.debug("Value in valuemap getUserMessage(): {}", val);
						if (error.startsWith(val)) {
							return (String) valueMap.get("jcr:title");
						}else if (error.equalsIgnoreCase(val)) {
							return (String) valueMap.get("jcr:title");
						}
					}
				}
			}

		}
		return error;
	}

	private static String getLanguageCode(Page currentPage) {
		Page homePage = PathLinkUtil.getHomePage(currentPage);
		LOGGER.info("Home page-->{}", homePage.getPath());
		String languageCode = StringUtils.EMPTY;
		String country_language = homePage.getProperties().get(JcrConstants.JCR_LANGUAGE, String.class);

		// Making the Country Code
		if (StringUtils.isNotBlank(country_language)) {
			String[] countryLang = country_language.split("_");
			LOGGER.info("Making the country code");
			if (countryLang.length == 2) {
				languageCode = countryLang[0];
			} else if (countryLang.length == 1) {
				languageCode = countryLang[0];
			}
		}
		LOGGER.info("languageCode-->{}", languageCode);
		return languageCode;
	}
	
	/**
	 * This method will return MagentoGraphqlClient based on request and current
	 * page path
	 */
	public static MagentoGraphqlClient getMagentoGraphqlClient(SlingHttpServletRequest request,
			String currentPagePath) {
		PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
		Resource res = request.getResourceResolver().resolve(request, currentPagePath);
		LOGGER.info("Current page path=====================" + res.getPath());
		List<Header> headers = new ArrayList<>();
		String token = CommonUtil.getTokenFromCookie("customerToken", request);
		headers.add(new BasicHeader("Authorization", "Bearer " + token));
		MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(res, pageManager.getPage(res.getPath()),
				request, headers);
		return magentoGraphqlClient;
	}

	public static String getCustomerEmailFromCookie(SlingHttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		String customerEmail = "";
		String customerPersonalInfo = "";
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				Cookie cookie = cookies[i];
				if ("merclinkCustomerPersonalInfo".equals(cookie.getName())) {
					LOGGER.error("Cookie value {}", cookie.getValue());
					customerPersonalInfo = cookie.getValue();
					break;
				}
			}
		}
		try {
			JSONObject personalObj = null;
			if (StringUtils.isNotBlank(customerPersonalInfo)) {

				personalObj = new JSONObject(customerPersonalInfo);
			}
			if (personalObj != null) {
				customerEmail = personalObj.optString("email");
			}
		} catch (JSONException e) {
			LOGGER.error("JSON exception occurred in common util %f", e);
		}
		return customerEmail;

	}
	
	public static String getMagentoStoreCode(Resource resource, Page page) {
		Resource configurationResource = page != null ? page.adaptTo(Resource.class) : resource;

		// If the page is an AEM Launch, we get the configuration from the production
		// page
		if (page != null && LaunchUtils.isLaunchBasedPath(page.getPath())) {
			configurationResource = LaunchUtils.getTargetResource(configurationResource, null);
		}

		LOGGER.debug("Try to get a graphql client from the resource at {}", configurationResource.getPath());

		ComponentsConfiguration configuration = configurationResource.adaptTo(ComponentsConfiguration.class);

		String storeCode;
		if (configuration.size() > 0) {
			storeCode = configuration.get(STORE_CODE_PROPERTY, String.class);
			LOGGER.info("CommonUtil Magento storeCode: {} ", storeCode);
			if (storeCode == null) {
				storeCode = readFallBackConfiguration(configurationResource, STORE_CODE_PROPERTY);
			}
		} else {
			storeCode = readFallBackConfiguration(configurationResource, STORE_CODE_PROPERTY);
		}
		return storeCode;
	}
	
	private static String readFallBackConfiguration(Resource resource, String propertyName) {

		InheritanceValueMap properties;
		String storeCode;

		Page page = resource.getResourceResolver().adaptTo(PageManager.class).getContainingPage(resource);
		if (page != null) {
			properties = new HierarchyNodeInheritanceValueMap(page.getContentResource());
		} else {
			properties = new ComponentInheritanceValueMap(resource);
		}
		storeCode = properties.getInherited(propertyName, String.class);
		if (storeCode == null) {
			storeCode = properties.getInherited("cq:" + propertyName, String.class);
			if (storeCode != null) {
				LOGGER.warn("Deprecated 'cq:magentoStore' still in use for {}. Please update to 'magentoStore'.",
						resource.getPath());
			}
		}
		return storeCode;
	}
	
	public static String getCustomerTaxGroupFromCookie(SlingHttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		String taxGroup = "";
		String customerAccountInfo = "";
		String sCustomer = getTokenFromCookie("selectedCustomer", request);
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				Cookie cookie = cookies[i];
				if ("completeAccountDetails".equals(cookie.getName())) {
					customerAccountInfo = cookie.getValue();
					break;
				}
			}
		}
		try {
			JSONArray custAccountArray = null;
			if (StringUtils.isNotBlank(customerAccountInfo)) {
				custAccountArray = new JSONArray(customerAccountInfo);
			}
			if (custAccountArray != null) {
				for (int i = 0; i < custAccountArray.length(); i++) {
					JSONObject accountObj = custAccountArray.getJSONObject(i);
					if (accountObj.optString("company_number").equals(sCustomer)) {
						return accountObj.optString("tax_group");
					}
				}
			}
		} catch (JSONException e) {
			LOGGER.error("JSON exception occurred in common util %f", e);
		}
		LOGGER.info("taxGroup :: {}", taxGroup);
		return taxGroup;
	}
}
