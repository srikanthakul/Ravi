package com.brunswick.ecomm.merclink.core.models.impl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.models.FaqModel;
import com.brunswick.ecomm.merclink.core.models.NewsSection;
import com.day.cq.wcm.api.Page;

@Model(
		adaptables = Resource.class,
		adapters = FaqModel.class,
		 defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
		)
public class FaqImpl implements FaqModel{

	
	private static final Logger LOG = LoggerFactory.getLogger(FaqImpl.class);
	
	@SlingObject
	Resource componentResource;
	
	@ValueMapValue
	private String faqHeading;
	
	@Inject
    private ResourceResolver resolver;
	
	@ScriptVariable
    private Page currentPage;

	@Override
	public String getFaqHeader() {
		// TODO Auto-generated method stub
		componentResource = resolver.getResource("/content/ecommerce/merclink/au/en/faq/jcr:content/root/container/container/faq");
		ValueMap property = componentResource.adaptTo(ValueMap.class);
		String title = property.get("title", String.class);
		return title;
	}
	
	
	private Resource getResource(String string) {
		// TODO Auto-generated method stub
		return componentResource ;
	}

	@Override
	public List<Map<String, String>> getFaqDetails() {
		// TODO Auto-generated method stub
		List<Map<String, String>> faqDetails = new ArrayList<>();
	
		try {
			LOG.info("\n Faq Start {}");  
			componentResource = resolver.getResource("/content/ecommerce/merclink/au/en/faq/jcr:content/root/container/container/faq");
	    	LOG.info("\n faq path{}",componentResource.getPath());
	 	    LOG.info("\n faq name {}",componentResource.getName());
	 	    
	 	   Resource nestedDetails = componentResource.getChild("multifaq");
	 	  if(nestedDetails != null) {
	 		  for (Resource nested : nestedDetails.getChildren()) {
	 			 ValueMap property = nested.adaptTo(ValueMap.class);
	 			String question = property.get("question", String.class);
	 			String answer = property.get("answer", String.class);
	 			LOG.info("\n question {}",question);
	 			LOG.info("\n answer {}",answer);
	 			Map<String,String> faqMap = new HashMap<>();
	 			faqMap.put("question", property.get("question", String.class));
	 			faqMap.put("answer", property.get("answer", String.class));
	 			faqDetails.add(faqMap);
	 		  }
	 	  }
		}catch(Exception e) {
			LOG.info("\n faq Details {}", e.getMessage());
		}
		LOG.info("\n SIZE {} ",faqDetails.size() );
		return faqDetails;
	}
	

}
