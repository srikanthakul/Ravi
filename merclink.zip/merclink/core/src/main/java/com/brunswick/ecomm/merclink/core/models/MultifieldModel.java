package com.brunswick.ecomm.merclink.core.models;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
@Model(
	    adaptables = {Resource.class},
	    defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class MultifieldModel {
	@Inject
	private Resource multiIconsBar;

	@Inject
	private Resource multifaq;
	
	@Inject
	private Resource itemsPerPageSelection;
	
	@Inject
	private Resource itemsPerPageSelectionWishlist;
	
	@Inject
    private Resource newsItems;

    @Inject
    private Resource newsItems1;
	
	@Inject
    private Resource newsItems2;
	
		@Inject
    private Resource newsItems3;

		 
		@SlingObject
		Resource componentResource;

public Resource getNewsItems() {
return newsItems;
}



public void setNewsItems(Resource newsItems) {
this.newsItems = newsItems;
}

public Resource getNewsItems1() {
return newsItems1;
}



public void setNewsItems1(Resource newsItems1) {
this.newsItems1 = newsItems1;
}

public Resource getNewsItems2() {
return newsItems2;
}



public void setNewsItems2(Resource newsItems2) {
this.newsItems2 = newsItems2;
}

public Resource getNewsItems3() {
return newsItems3;
}



public void setNewsItems3(Resource newsItems3) {
this.newsItems3 = newsItems3;
}

@Inject

    private Resource pageTitle;



    @Inject

    private Resource pageLink;



       



    public Resource getPageLink() {

        return pageLink;

    }



    public void setPageLink(Resource pageLink) {

        this.pageLink = pageLink;

    }



    public Resource getPageTitle() {

        return pageTitle;

    }



    public void setPageTitle(Resource pageTitle) {

        this.pageTitle = pageTitle;

    }

	public Resource getItemsPerPageSelectionWishlist() {
		return itemsPerPageSelectionWishlist;
	}

	public void setItemsPerPageSelectionWishlist(Resource itemsPerPageSelectionWishlist) {
		this.itemsPerPageSelectionWishlist = itemsPerPageSelectionWishlist;
	}

	public Resource getMultiIconsBar() {
		return multiIconsBar;
	}
	
	public Resource getMultifaq() {
		return multifaq;
	}

	public Resource getItemsPerPageSelection() {
		return itemsPerPageSelection;
	}
	
}
