package com.brunswick.ecomm.merclink.core.models.internal.quickorderform;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.magento.graphql.ProductInterfaceQuery;
import com.adobe.cq.commerce.magento.graphql.ProductInterfaceQueryDefinition;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;


public class QuickOrderFormRetriever extends AbstractQuickOrderFormRetriever{
	private static final Logger LOG = LoggerFactory.getLogger(AbstractQuickOrderFormRetriever.class);
	public QuickOrderFormRetriever(MagentoGraphqlClient client) {
		super(client); 
		LOG.info("QuickOrderFormRetriever client.."+client);
	}

	@Override
	protected ProductInterfaceQueryDefinition generateProductQuery() {
		return (ProductInterfaceQuery q) -> {
            q.name()
            .id()
                .metaDescription()
                .sku()
                .stockStatus()
                .addCustomSimpleField("masterpartlowestsellinguomqty")
                .addCustomSimpleField("bupartstatus");
                
            
        };
    }
	

}
