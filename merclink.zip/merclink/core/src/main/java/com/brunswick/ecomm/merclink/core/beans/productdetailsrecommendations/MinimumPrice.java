package com.brunswick.ecomm.merclink.core.beans.productdetailsrecommendations;

import org.apache.sling.models.annotations.Optional;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MinimumPrice {
	

	@Optional
	@JsonProperty("final_price")
	 private FinalPriceBean final_price;

	public FinalPriceBean getFinal_price() {
		return final_price;
	}

	public void setFinal_price(FinalPriceBean final_price) {
		this.final_price = final_price;
	}
	
	
}
