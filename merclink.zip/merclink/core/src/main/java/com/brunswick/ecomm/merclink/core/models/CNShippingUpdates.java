package com.brunswick.ecomm.merclink.core.models;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.Page;


@Model(adaptables = {Resource.class}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class CNShippingUpdates {
	private static final Logger LOG = LoggerFactory.getLogger(CNShippingUpdates.class);
	
	@SlingObject
	Resource componentResource;
	
   
    @Inject
    private ResourceResolver resolver;
	
    @ScriptVariable
    private Page currentPage;

    @ValueMapValue
    private String myComponentCustomProperty;
    
    @PostConstruct
    protected void init() {
    	LOG.info("\n CNShippingUpdates PATH Current News {}");
   
    	componentResource = resolver.getResource("/content/ecommerce/merclink/au/en/home/news/current-news/jcr:content/root/container/container/allnews/currentnews");
    LOG.info("\n CNShippingUpdates PATH Current News path{}",componentResource.getPath());
    LOG.info("\n CNShippingUpdates PATH Current News name {}",componentResource.getName());
    ValueMap map= componentResource.getValueMap();
    //get properties
    map.get(JcrConstants.JCR_TITLE,String.class);
    //your code...
    }
}
