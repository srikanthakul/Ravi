package com.brunswick.ecomm.merclink.core.constants;

public class MagentoAttributes {

	// ProductImpl class
	public static final String RESOURCE_TYPE = "merclink/components/commerce/productdetails";
	public static final String PLACEHOLDER_DATA = "product-component-placeholder-data.json";
	public static final String CUSTOMER_NUMBER = "customerNumber";
	
	public static final String DATA = "data";
	public static final String IMAGE_DATA = "image_data";
	
	public static final String PRODUCTATTACHMENT = "productattachment_custom_";
	public static final String DESCRIPTION = "description_custom_";
	public static final String ATTACHMENT = "attachment_custom_";
	public static final String LABEL_NAME = "label_name_custom_";
	
	public static final String SPECIFICATIONS = "specifications";
	public static final String LABEL = "label_custom_";
	public static final String VALUE = "value_custom_";
	
	public static final String VIDEOS = "videos_custom_";
	
	public static final String VIDEO = "video_custom_";
	public static final String PROP65 = "masterpartprop65code";
	
	public static final String BRAND = "brand_name";
	public static final String LONGDESCRIPTION = "bupartlongdescription";
	public static final String LONGDESCRIPTION1 = "bupartlongdescription1";
	public static final String LONGDESCRIPTION2 = "bupartlongdescription2";
	public static final String LONGDESCRIPTION3 = "bupartlongdescription3";
	public static final String LONGDESCRIPTION4 = "bupartlongdescription4";
	public static final String LONGDESCRIPTION5 = "bupartlongdescription5";
	public static final String BU_PART_BULLET = "bupartbullet";
	public static final String BU_PART_BULLET1 = "bupartbullet1";
	public static final String BU_PART_BULLET2 = "bupartbullet2";
	public static final String BU_PART_BULLET3 = "bupartbullet3";
	public static final String BU_PART_BULLET4 = "bupartbullet4";
	public static final String BU_PART_BULLET5 = "bupartbullet5";
	public static final String BU_PART_BULLET6 = "bupartbullet6";
	public static final String BU_PART_BULLET7 = "bupartbullet7";
	public static final String BU_PART_BULLET8 = "bupartbullet8";
	public static final String BU_PART_BULLET9 = "bupartbullet9";
	public static final String BU_PART_BULLET10 = "bupartbullet10";
	public static final String BU_PART_BULLET11 = "bupartbullet11";
	public static final String BU_PART_BULLET12 = "bupartbullet12";
	public static final String BU_PART_BULLET13 = "bupartbullet13";
	public static final String BU_PART_BULLET14 = "bupartbullet14";
	public static final String BU_PART_BULLET15 = "bupartbullet15";
	public static final String BUNDLED_QUANTITY ="masterpartlowestsellinguomqty";
	
	public static final String ITEM_STATUS = "bupartstatus";
	
	public static final String ESCAPE_INVERT_COMMA = "\"";
	public static final String EMPTY_STRING = ""; 
	public static final String COLON = ":";
	public static final String COMMA = ",";
	
	// ProductRetriever class
	public static final String IMAGE_SET = "image_set"; 
	public static final String IMAGE_SET_CUSTOM = "image_set_custom_";
	public static final String PRODUCT_THUMBNAIL = "product_thumbnail";
	public static final String VIDEOS_QUERY = "videos";
	public static final String PRODUCT_ATTACHMENT_QUERY = "productattachment" ;
	public static final String TITLE = "title";
	public static final String VIDEO_QUERY = "video";
	
	public static final String ATTACH_IDENTIFIER = "attach_identifer"; 
	public static final String LABEL_NAME_QUERY = "label_name";
	public static final String DESCRIPTION_QUERY = "description";
	public static final String ATTACHMENT_QUERY = "attachment";
	public static final String VISIBLE_QUERY = "visible";
	public static final String LABEL_QUERY = "label";
	public static final String CODE_QUERY = "code";
	public static final String VALUE_QUERY = "value";
	public static final String WEIGHT = "weight";
	
	public static final String BU_SS_TO_PART = "bu_ss_to_part";
	public static final String MP_HAZARDOUS_MATERIAL = "mp_hazardous_material";
	public static final String MP_PKG_EA_WEIGHT_METRIC = "mp_pkg_ea_weight_metric";
	public static final String MP_PKG_EA_WEIGHT_UOM_METRIC = "mp_pkg_ea_weight_uom_metric";

	
}
