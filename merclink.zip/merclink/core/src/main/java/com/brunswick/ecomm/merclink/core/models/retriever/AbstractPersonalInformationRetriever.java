package com.brunswick.ecomm.merclink.core.models.retriever;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.GenerateCustomerTokenAsAdminInput;
import com.adobe.cq.commerce.magento.graphql.GenerateCustomerTokenAsAdminOutput;
import com.adobe.cq.commerce.magento.graphql.GenerateCustomerTokenAsAdminOutputQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Operations;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.google.gson.JsonObject;


public class AbstractPersonalInformationRetriever extends AbstractCustomRetriever {
	Customer customer;
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractPersonalInformationRetriever.class);
	private String query;

	public AbstractPersonalInformationRetriever(MagentoGraphqlClient client) {
		super(client);

	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return client.execute(query);
	}
	
	protected GraphqlResponse<JsonObject, Error> executeJsonQuery() {
		return client.executeQuery(query);
	}

	protected GraphqlResponse<Mutation, Error> executeMutation() {
		return client.executeMutation(query);
	}
	
	protected GraphqlResponse<JsonObject, Error> executeJsonMutation() {
		return client.executeJsonMutation(query);
	}
	
	@Override
	protected void populate() {
		// Nothing to do

	}

	// Getters
	public JsonObject getCustomerPersonalInformation(){
		query = getCustomerPersonalInformationDefinition();
		LOGGER.info("QUERY=="+query);	
		GraphqlResponse<JsonObject, Error> response = executeJsonQuery();
		LOGGER.info("response===="+response);
		List<Error> errors=response.getErrors();
		if(errors!= null) {
			JsonObject  errorjsonobject= new JsonObject();
			for(Error error:errors) {
				errorjsonobject.addProperty("getCustomerPersonalInformation", error.getMessage());
			}
			return errorjsonobject;
		}
		
		JsonObject queryResponse = response.getData().getAsJsonObject("getCustomerPersonalInformation");
		
		return queryResponse;
	}
	
	public JsonObject updateCustomerAddress(String id,String firstname,String lastname,String emailaddress,String phonenumber) {
		query = updateCustomerAddressDefinition(id,firstname,lastname,emailaddress,phonenumber);
		LOGGER.info("remove query" + query);
		GraphqlResponse<JsonObject, Error> response =executeJsonMutation();
		List<Error> errors=response.getErrors();
	
			LOGGER.info("in errors null condition");
		JsonObject queryResponse = response.getData().getAsJsonObject("updateCompanyAddress");
		LOGGER.info("updateCustomerAddress queryResponse" + queryResponse);
		
		if(errors!= null) {
			JsonObject  errorjsonobject= new JsonObject();
			for(Error error:errors) {
				errorjsonobject.addProperty("updateCompanyAddress", error.getMessage());
			}
			return errorjsonobject;
		}
		return queryResponse;
	}
	

	public JsonObject addNewCustomerAddress(String id,String fistname,String lastname, String address1,String address2,String city,String state,String regioncode,String country,String postalcode,String addresstype,String customertype) {
		query = addNewCustomerAddressDefinition(id,fistname,lastname,address1,address2,city,state,regioncode,country,postalcode,addresstype,customertype);
		LOGGER.info("remove query" + query);
		GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
		List<Error> errors=response.getErrors();
		JsonObject queryResponse = new  JsonObject();
		
		if(errors!= null) {
			JsonObject  errorjsonobject= new JsonObject();
			for(Error error:errors) {
				errorjsonobject.addProperty("createCompanyAddress", error.getMessage());
			}
			return errorjsonobject;
		}else {
			if(response.getData()!= null) {
				if(response.getData().getAsJsonObject("createCompanyAddress") != null) {
				 queryResponse = response.getData().getAsJsonObject("createCompanyAddress");
				LOGGER.info("addNewCustomerAddress queryResponse" + queryResponse);
				}
				}
		}
		
		return queryResponse;
	}
	public JsonObject updateCustomerPersonalInformation(String id,String firstname,String lastname,String emailaddress,String phonenumber,String customertype,String companyname) {
		query = updateCustomerPersonalInformationDefinition(id,firstname,lastname,emailaddress,phonenumber,customertype,companyname);
		LOGGER.info("updateCustomerPersonalInformation query" + query);
		GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
		LOGGER.info("GraphqlResponse in updateCustomerPersonalInformation::::::::{}",response.getData());
		List<Error> errors=response.getErrors();
		JsonObject queryResponse = new JsonObject();
			LOGGER.info("in errors null condition");
			if(errors!= null) {
				JsonObject  errorjsonobject= new JsonObject();
				for(Error error:errors) {
					errorjsonobject.addProperty("updateCompany", error.getMessage());
				}
				return errorjsonobject;
			}else {
			if(response.getData()!= null) {
			if(response.getData().getAsJsonObject("updateCompany") != null) {
		 queryResponse = response.getData().getAsJsonObject("updateCompany");
		LOGGER.info("updateCustomerPersonalInformation queryResponse111 " + queryResponse);
		JsonObject queryResponse1 = response.getData().getAsJsonObject("company");
		LOGGER.info("updateCustomerPersonalInformation queryResponse " + queryResponse1);
			}
			}
			}
		return queryResponse;
	}
	
	public String deleteAddress(String addressid) {
		query = deletaddressDefinition(addressid);
		LOGGER.info("deleteAddress query::::" + query);
		GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
		List<Error> errors=response.getErrors();
		String message = null;
		
			LOGGER.info("deleteAddress response" + message);
		if(errors!= null) {
			for(Error error:errors) {
				message=error.getMessage();
			}
			message = response.getData().toString();
			LOGGER.info("deleteAddress response1" + message);
		}else {
			if(response.getData()!= null) {
				message = response.getData().toString();
				LOGGER.info("deleteAddress response2" + message);
			}
		}
		LOGGER.info("updateCustomerPersonalInformation queryResponse111 " + message);
		return message;
		
	}
	
	public JsonObject updateAddress(String customerId, String firstname, String lastname, String address1,
			String address2, String city, String state, String postalcode, String country,String addressid,String addresstype,String customertype,String regioncode,String primaryaddress) {
		query = updateAddressDefinition(customerId,firstname,lastname,address1,address2,city,state,postalcode,country,addressid,addresstype,customertype,regioncode,primaryaddress);
		LOGGER.info("updateAddress query" + query);
		GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
		List<Error> errors=response.getErrors();
		JsonObject queryResponse = new JsonObject();
		if(errors!= null) {
			JsonObject  errorjsonobject= new JsonObject();
			for(Error error:errors) {
				errorjsonobject.addProperty("updateCompanyAddress", error.getMessage());
			}
			return errorjsonobject;
		}else {
		if(response.getData()!= null) {
		if(response.getData().getAsJsonObject("updateCompanyAddress")!= null) {
		 queryResponse = response.getData().getAsJsonObject("updateCompanyAddress");
		}
		}
		LOGGER.info("updateaddress queryResponse111 " + queryResponse);
		
		}
		
		return queryResponse;
	}
	
	private String updateAddressDefinition(String customerId, String firstname, String lastname, String address1,
			String address2, String city, String state, String postalcode, String country,String addressid,String addresstype,String customertype,String regioncode,String primaryaddress) {
		
		String street= "[\""+address1+"\", \""+address2+"\"]";
		// regioncode="WI";
		String address_type = addresstype;
		LOGGER.info("addresstype===" + addresstype);
		if(addresstype.equalsIgnoreCase("Save Shipping Address")) {
			address_type="shipping";
		}else if(addresstype.equalsIgnoreCase("Save Billing Address")) {
			address_type="billing";
		}
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation {");
		_queryBuilder.append(" updateCompanyAddress(");
		_queryBuilder.append(" id: ");
		_queryBuilder.append(addressid);
		_queryBuilder.append(", ");
		_queryBuilder.append(" input: {  ");   
		_queryBuilder.append(" firstname: ");
		_queryBuilder.append("\""+firstname.toString()+"\"" );
		_queryBuilder.append(" lastname: ");
		_queryBuilder.append("\""+lastname.toString()+"\"" );
		_queryBuilder.append("postcode:" );
		_queryBuilder.append("\""+postalcode.toString()+"\"");
		_queryBuilder.append(" address_type:");
		if (null != address_type) {_queryBuilder.append("\""+address_type.toString()+"\"");}
		_queryBuilder.append(" primary_flag:");
		_queryBuilder.append("\""+primaryaddress.toString()+"\"" );
		_queryBuilder.append(" region: { region:");
		_queryBuilder.append("\""+state.toString()+"\"");
		_queryBuilder.append(",");
		_queryBuilder.append("region_code:");
		_queryBuilder.append("\""+regioncode.toString()+"\"");
		_queryBuilder.append("}");
		_queryBuilder.append("country_code: ");
		_queryBuilder.append(country.toString());
		
		_queryBuilder.append(" city:");
		_queryBuilder.append("\""+city.toString()+"\"");
		_queryBuilder.append(" street:");
		_queryBuilder.append(street.toString());
		
		_queryBuilder.append("}) {");
		_queryBuilder.append("id ");
		_queryBuilder.append("city " );
		_queryBuilder.append("postcode " );
		_queryBuilder.append("street " );
		_queryBuilder.append("firstname " );
		_queryBuilder.append("lastname " );
		_queryBuilder.append("address_type " );
		_queryBuilder.append("primary_flag " );
		_queryBuilder.append("country_code " );
		_queryBuilder.append("region { ");
		_queryBuilder.append("region ");
		_queryBuilder.append("region_code } ");
		
		_queryBuilder.append("}} ");
		return _queryBuilder.toString();
	
	}

	private String deletaddressDefinition(String addressid) {
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation {");
		_queryBuilder.append("deleteCompanyAddress(");
		_queryBuilder.append(" id: ");
		_queryBuilder.append(addressid);
		_queryBuilder.append(")");
		_queryBuilder.append("}");
		
		
		return _queryBuilder.toString();
	}

	public String generateCustomerToken(String emailId) {
		query = generateCustomerTokenDefinition(emailId);
		LOGGER.info("customer token query" + query);
		GraphqlResponse<Mutation, Error> response = executeMutation();
		LOGGER.info("customer token query response" + response);
		List<Error> errors=response.getErrors();
		if(errors!= null) {
		for(Error error:errors) {
			LOGGER.info("error message token==="+error.getMessage());
			
		}
		}
		Mutation queryResponse = response.getData();
		LOGGER.info("customer token query response1" + queryResponse);
		GenerateCustomerTokenAsAdminOutput token = queryResponse.getGenerateCustomerTokenAsAdmin();
		LOGGER.info("customer token query token" + token);
		if(token!=null) {
			LOGGER.info("customer token query token1" + token.getCustomerToken());
			return token.getCustomerToken();
			
		}
		return null;
		
	}

	
	
	
	

	private String updateCustomerPersonalInformationDefinition(String id, String firstname,String lastname,String emailaddress,String phonenumber,String customertype,String companyname) {
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation {");
		_queryBuilder.append("updateCompany(");
		_queryBuilder.append(" input: {");
		
		_queryBuilder.append("company_name :");
		_queryBuilder.append("\""+companyname.toString()+"\"");
		_queryBuilder.append("company_email:");
		_queryBuilder.append("\""+emailaddress.toString()+"\"");
		//_queryBuilder.append("email:");
		//_queryBuilder.append("\""+emailaddress.toString()+"\"");
		
		_queryBuilder.append("firstname:");
		_queryBuilder.append("\""+firstname.toString()+"\"");
		_queryBuilder.append("lastname:");
		_queryBuilder.append("\""+lastname.toString()+"\"");
		_queryBuilder.append("customer_type:");
		_queryBuilder.append("\""+customertype.toString()+"\"");
		_queryBuilder.append(" telephone: ");
		_queryBuilder.append("\""+phonenumber.toString()+"\"");
		_queryBuilder.append(" }) {");
		_queryBuilder.append("company {");
		_queryBuilder.append("id ");
		_queryBuilder.append("email ");
		_queryBuilder.append("name ");
		_queryBuilder.append("company_admin { ");
		
		
		
		_queryBuilder.append("firstname ");
		_queryBuilder.append("lastname ");
		_queryBuilder.append("email ");
		_queryBuilder.append("telephone ");
		_queryBuilder.append("customer_type ");
		_queryBuilder.append("orig_system_reference ");
		_queryBuilder.append("azure_object_id ");
		_queryBuilder.append("erp_customer_id ");
		_queryBuilder.append(" }");
		
		_queryBuilder.append("default_shipping ");
		_queryBuilder.append("default_billing ");
		_queryBuilder.append("}} }");
		
		return _queryBuilder.toString();
	}
	
	

	private String addNewCustomerAddressDefinition(String id,String fistname,String lastname, String address1,String address2,String city,String state,String regioncode,String country,String postalcode,String addresstype,String customertype) {
		String address_type = addresstype;
		LOGGER.info("addresstype===" + addresstype);
		if(addresstype.equalsIgnoreCase("Add New Shipping Address")) {
			address_type="Shipping";
		}
		String primaryflag="N";
		
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation {");
		_queryBuilder.append(" createCompanyAddress(input: { ");
		_queryBuilder.append(" city:");
		_queryBuilder.append("\""+city.toString()+"\"");
		
		_queryBuilder.append(" region: { region:");
		_queryBuilder.append("\""+state.toString()+"\"");
		_queryBuilder.append(",");
		_queryBuilder.append("region_code:");
		_queryBuilder.append("\""+regioncode.toString()+"\"");
		_queryBuilder.append(",");
		_queryBuilder.append("}");
		_queryBuilder.append("country_code: ");
		_queryBuilder.append(country.toString());
		_queryBuilder.append(" street:");
		_queryBuilder.append("[\""+address1+"\",\""+address2+"\"]");
		_queryBuilder.append("postcode:" );
		_queryBuilder.append("\""+postalcode.toString()+"\"");
		_queryBuilder.append(" company_id:"+"0 " );
		_queryBuilder.append(" address_type:");
		if (null != address_type) {_queryBuilder.append("\""+address_type.toString()+"\"");}
		
		
		_queryBuilder.append(" primary_flag:");
		_queryBuilder.append("\""+primaryflag.toString()+"\"" );
		
		_queryBuilder.append(" firstname: ");
		_queryBuilder.append("\""+fistname.toString()+"\"" );
		_queryBuilder.append(" lastname: ");
		_queryBuilder.append("\""+lastname.toString()+"\"" );
		
		_queryBuilder.append(" customer_type:");
		_queryBuilder.append("\""+customertype.toString()+"\"" );
		_queryBuilder.append(" default_shipping:true " );
		_queryBuilder.append(" default_billing:false " );
		_queryBuilder.append("}) {");
		_queryBuilder.append("id ");
	
		_queryBuilder.append("region { ");
		_queryBuilder.append("region ");
		_queryBuilder.append("region_code } ");
		_queryBuilder.append("country_code " );
		_queryBuilder.append("street " );
		_queryBuilder.append("postcode " );
		_queryBuilder.append("city " );
		_queryBuilder.append("default_shipping ");
		_queryBuilder.append("default_billing ");
		_queryBuilder.append("}} ");
		return _queryBuilder.toString();
	}

	private String updateCustomerAddressDefinition(String id,String firstname,String lastname,String emailaddress,String phonenumber) {
	
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation {");
		_queryBuilder.append(" updateCompanyAddress(id:"+id+", input: {   ");
		_queryBuilder.append("firstname:"+firstname);
		_queryBuilder.append("lastnme");
		_queryBuilder.append(" }) {");
		_queryBuilder.append("id");
		_queryBuilder.append("city");
		_queryBuilder.append("postcode");
		_queryBuilder.append("street");
		_queryBuilder.append("firstname");
		_queryBuilder.append("lastname");
		_queryBuilder.append("email");
		_queryBuilder.append("}}");
		
		return _queryBuilder.toString();  
	}

	// Query Definitions
	private String getCustomerPersonalInformationDefinition() {
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("{");
		_queryBuilder.append("getCustomerPersonalInformation {");
		_queryBuilder.append("firstname ");
		_queryBuilder.append("lastname ");
		_queryBuilder.append("email ");
		_queryBuilder.append("company_email ");
		_queryBuilder.append("company_name ");
		_queryBuilder.append("customer_number ");
		_queryBuilder.append("company_currency ");
		_queryBuilder.append("warehouse_name ");
		_queryBuilder.append("shipping_method ");
		_queryBuilder.append("dropship ");
		_queryBuilder.append("is_wells_fargo ");
		_queryBuilder.append("tax_group ");
		_queryBuilder.append("blog_news ");
		_queryBuilder.append("roles_permission{ ");		
		_queryBuilder.append("company_name ");
		_queryBuilder.append("company_number ");
		_queryBuilder.append("customer_group ");
		_queryBuilder.append("customer_roles ");
		_queryBuilder.append("customer_permission ");
		
		_queryBuilder.append("} ");
		
		_queryBuilder.append("account_list{ ");		
		_queryBuilder.append("company_number ");
		_queryBuilder.append("company_name ");
		_queryBuilder.append("is_admin ");
		_queryBuilder.append("is_default ");
		_queryBuilder.append("} ");
		
		
		_queryBuilder.append("telephone ");
	
		_queryBuilder.append("billing_address { ");
		_queryBuilder.append("id ");
		_queryBuilder.append("customer_id ");
		_queryBuilder.append("firstname ");
		_queryBuilder.append("lastname ");
		_queryBuilder.append("street ");
		_queryBuilder.append("city ");
		_queryBuilder.append("primary_flag ");
		_queryBuilder.append("country_code ");
		_queryBuilder.append("postcode ");
		_queryBuilder.append("country_id ");
		_queryBuilder.append("region_id ");
		_queryBuilder.append("default_shipping ");
		_queryBuilder.append("default_billing ");
		_queryBuilder.append("} ");
		_queryBuilder.append("shipping_addresses  { ");
		_queryBuilder.append("id ");
		_queryBuilder.append("customer_id ");
		_queryBuilder.append("firstname ");
		_queryBuilder.append("lastname ");
		_queryBuilder.append("street ");
		_queryBuilder.append("city ");
		_queryBuilder.append("country_name ");
		_queryBuilder.append("country_code ");
		_queryBuilder.append("postcode ");
		_queryBuilder.append("region_id ");
		_queryBuilder.append("primary_flag ");
		_queryBuilder.append("default_shipping ");
		_queryBuilder.append("default_billing ");
			
		
		
		_queryBuilder.append("}}} ");

		return _queryBuilder.toString();
	}

	private String generateCustomerTokenDefinition(String emailId) {
		GenerateCustomerTokenAsAdminInput input  = new GenerateCustomerTokenAsAdminInput(emailId);
		GenerateCustomerTokenAsAdminOutputQueryDefinition queryDef=i->i.customerToken();
		return Operations.mutation(mutation -> mutation.generateCustomerTokenAsAdmin(input, queryDef))
				.toString();
	}

	

}
