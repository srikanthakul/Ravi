package com.brunswick.ecomm.merclink.core.servlets;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.Servlet; 
import org.apache.http.Header;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.xss.XSSAPI;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.internal.contactus.ContactUsRetriever;
import com.brunswick.ecomm.merclink.core.utils.ValidateContactUsServlet;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonObject;

@Component(service = Servlet.class,property = {
        Constants.SERVICE_DESCRIPTION + "=Contact Us Servlet",
        "sling.servlet.methods="+HttpConstants.METHOD_POST, "sling.servlet.paths="
        + "/bin/merclinkcontactUsServlet"
})
public class ContactUsServlet extends SlingAllMethodsServlet{
	@Inject 
	private ContactUsRetriever retriever;
	private static final long serialVersionUID = 1L;
    private static final Logger LOG=LoggerFactory.getLogger(ContactUsServlet.class);
    private transient ValidateContactUsServlet validate = new ValidateContactUsServlet();
    protected String RESOURCE_PATH;
    
    @Reference
	private transient XSSAPI xssAPI;  
    

	public void setXssAPI(XSSAPI xssAPI) {
		this.xssAPI = xssAPI;
	}

	@Override
    public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
        response.setCharacterEncoding(StandardCharsets.UTF_8.displayName()); 	
        String data = request.getParameter("data").replaceAll("[\n\r|\t]", "_");      
		try {
			JSONObject requestObj= new JSONObject(data);
			Map<String, String> errormessage = new HashMap<>();
			Map<String, String> filtereddata;
			if(request.getParameter("formtype").equalsIgnoreCase("Credit Application")) {
				filtereddata = getFilteredDataforCreditApp(requestObj);
			} 
			else {
				errormessage= validate.validate(getFilteredData(requestObj));
				filtereddata = getFilteredData(requestObj);
			}
				PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
				
				if (errormessage.isEmpty()) {
					RESOURCE_PATH = requestObj.get("resourcePath").toString();
					Resource res = request.getResourceResolver().resolve(RESOURCE_PATH);

					List<Header> headers = new ArrayList<>();
					MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(res,
							pageManager.getPage(res.getPath()), request, headers);
					
					if (magentoGraphqlClient != null) 
					{ 
						retriever = new ContactUsRetriever(magentoGraphqlClient);
						
					JsonObject magentoresponse=request.getParameter("formtype").equalsIgnoreCase("Credit Application")?retriever.getResponseforCreditApp(filtereddata):retriever.getResponse(filtereddata);
					  response.setContentType("application/json");
				        response.getWriter().print(magentoresponse);
				        response.setStatus(response.getStatus()); 
				        
					}
						
				       
				
			}else {
				sendStatus(errormessage, 400, response);
			} 
			
		} catch (JSONException e) {
			  LOG.error("context", e);
		}         
        
    
    }
	
	   Map<String, String> getFilteredDataforCreditApp(JSONObject jsondata) throws JSONException {
		   HashMap<String, String> data= new HashMap<>();	
	        
	        data.put("department", getFilteredText((String) jsondata.get("department")));
	        data.put("company", getFilteredText((String) jsondata.get("company")));
	        data.put("contact_name", getFilteredText((String) jsondata.get("contact_name")));
	        data.put("title", getFilteredText((String) jsondata.get("title")));
	        data.put("address1", getFilteredText((String) jsondata.get("address1")));
	        data.put("address2", getFilteredText((String) jsondata.get("address2")));
	        data.put("phone", getFilteredText((String) jsondata.get("phone")));
	        data.put("city", getFilteredText((String) jsondata.get("city"))); 
	        data.put("state", getFilteredText((String) jsondata.get("state")));
	        data.put("zipcode", getFilteredText((String) jsondata.get("zipcode")));
	        data.put("fax", getFilteredText((String) jsondata.get("fax")));
	        data.put("email", getFilteredText((String) jsondata.get("email")));
	        data.put("type", getFilteredText((String) jsondata.get("type")));
	        data.put("db_number", getFilteredText((String) jsondata.get("db_number")));
	        data.put("employee_id", getFilteredText((String) jsondata.get("employee_id")));
	        data.put("annual_spend", getFilteredText((String) jsondata.get("annual_spend")));
	        data.put("w9_file", jsondata.get("w9_file").toString());
	        data.put("sales_file", jsondata.get("sales_file").toString());
	        data.put("add_file", jsondata.get("add_file").toString());
	        data.put("agree_name", getFilteredText((String) jsondata.get("agree_name")));
	        data.put("documents", getFilteredText((String) jsondata.get("documents")));
	        data.put("resourcePath", getFilteredText((String) jsondata.get("resourcePath")));
	        return data;
	}

	public Map<String, String> getFilteredData(JSONObject jsondata) throws JSONException {
	        HashMap<String, String> data= new HashMap<>();	
	        
	        data.put("fname", getFilteredText((String) jsondata.get("fname")));
	        data.put("lname", getFilteredText((String) jsondata.get("lname")));
	        data.put("email", getFilteredText((String) jsondata.get("email")));
	        data.put("phone", getFilteredText((String) jsondata.get("phone")));
	        data.put("companyname", getFilteredText((String) jsondata.get("companyname")));
	        data.put("customerno", getFilteredText((String) jsondata.get("customerno")));
	        data.put("dept", getFilteredText((String) jsondata.get("dept")));
	        data.put("subject", getFilteredText((String) jsondata.get("subject")));
	        data.put("message", getFilteredText((String) jsondata.get("message"))); 
	        data.put("resourcePath", getFilteredText((String) jsondata.get("resourcePath")));
	        return data;
	    }
	   
		public String getFilteredText(String userInputText) {  
			return xssAPI.filterHTML(userInputText);
		   }  	
		
    public int sendStatus(Map<String, String> errormessage, int statusCode, SlingHttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.getWriter().print(new JSONObject(errormessage));
        response.setStatus(statusCode);  
        return statusCode;
        
    }
    
    

 

}

 

