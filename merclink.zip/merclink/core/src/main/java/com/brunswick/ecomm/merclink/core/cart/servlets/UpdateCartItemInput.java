
package com.brunswick.ecomm.merclink.core.cart.servlets;

import java.io.Serializable;
import java.util.List;

import com.shopify.graphql.support.AbstractQuery;
import com.shopify.graphql.support.ID;
import com.shopify.graphql.support.Input;

public class UpdateCartItemInput implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int quantity;
    private int sku;


    private Input<String> parentSku = Input.undefined();

    private Input<List<ID>> selectedOptions = Input.undefined();

    public UpdateCartItemInput(int quantity, int sku) {
        this.quantity = quantity;
        this.sku = sku;
    }

    public int getQuantity() {
        return quantity;
    }

    public UpdateCartItemInput setQuantity(int quantity) {
        this.quantity = quantity;
        return this;
    }

    public int getSku() {
        return sku;
    }

    public UpdateCartItemInput setSku(int sku) {
        this.sku = sku;
        return this;
    }

   
    /**
     * For child products, the SKU of its parent product
     */
    public String getParentSku() {
        return parentSku.getValue();
    }

    /**
     * For child products, the SKU of its parent product
     */
    public Input<String> getParentSkuInput() {
        return parentSku;
    }

    /**
     * For child products, the SKU of its parent product
     */
    public UpdateCartItemInput setParentSku(String parentSku) {
        this.parentSku = Input.optional(parentSku);
        return this;
    }

    /**
     * For child products, the SKU of its parent product
     */
    public UpdateCartItemInput setParentSkuInput(Input<String> parentSku) {
        if (parentSku == null) {
            throw new IllegalArgumentException("Input can not be null");
        }
        this.parentSku = parentSku;
        return this;
    }

    /**
     * The selected options for the base product, such as color or size with unique ID for a
     * `CustomizableRadioOption`, `CustomizableDropDownOption`, `ConfigurableProductOptionsValues`, etc.
     * objects
     */
    public List<ID> getSelectedOptions() {
        return selectedOptions.getValue();
    }

    /**
     * The selected options for the base product, such as color or size with unique ID for a
     * `CustomizableRadioOption`, `CustomizableDropDownOption`, `ConfigurableProductOptionsValues`, etc.
     * objects
     */
    public Input<List<ID>> getSelectedOptionsInput() {
        return selectedOptions;
    }

    /**
     * The selected options for the base product, such as color or size with unique ID for a
     * `CustomizableRadioOption`, `CustomizableDropDownOption`, `ConfigurableProductOptionsValues`, etc.
     * objects
     */
    public UpdateCartItemInput setSelectedOptions(List<ID> selectedOptions) {
        this.selectedOptions = Input.optional(selectedOptions);
        return this;
    }

    /**
     * The selected options for the base product, such as color or size with unique ID for a
     * `CustomizableRadioOption`, `CustomizableDropDownOption`, `ConfigurableProductOptionsValues`, etc.
     * objects
     */
    public UpdateCartItemInput setSelectedOptionsInput(Input<List<ID>> selectedOptions) {
        if (selectedOptions == null) {
            throw new IllegalArgumentException("Input can not be null");
        }
        this.selectedOptions = selectedOptions;
        return this;
    }

    public void appendTo(StringBuilder _queryBuilder) {
        String separator = "";
        _queryBuilder.append('{');

        _queryBuilder.append(separator);
        separator = ",";
        _queryBuilder.append("quantity:");
        _queryBuilder.append(quantity);

        _queryBuilder.append(separator);
        separator = ",";
        _queryBuilder.append("cart_item_id:");
        _queryBuilder.append(sku);

    

        if (this.parentSku.isDefined()) {
            _queryBuilder.append(separator);
            separator = ",";
            _queryBuilder.append("parent_sku:");
            if (parentSku.getValue() != null) {
                AbstractQuery.appendQuotedString(_queryBuilder, parentSku.getValue().toString());
            } else {
                _queryBuilder.append("null");
            }
        }

        if (this.selectedOptions.isDefined()) {
            _queryBuilder.append(separator);
            separator = ",";
            _queryBuilder.append("selected_options:");
            if (selectedOptions.getValue() != null) {
                _queryBuilder.append('[');
                {
                    String listSeperator1 = "";
                    for (ID item1 : selectedOptions.getValue()) {
                        _queryBuilder.append(listSeperator1);
                        listSeperator1 = ",";
                        AbstractQuery.appendQuotedString(_queryBuilder, item1.toString());
                    }
                }
                _queryBuilder.append(']');
            } else {
                _queryBuilder.append("null");
            }
        }

        _queryBuilder.append('}');
    }
}
