package com.brunswick.ecomm.merclink.core.beans.productdetailsrecommendations;

import org.apache.sling.models.annotations.Optional;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PriceRange {
	
	
	@Optional
	@JsonProperty("minimum_price")
	 private MinimumPrice minimum_price;

	public MinimumPrice getMinimum_price() {
		return minimum_price;
	}

	public void setMinimum_price(MinimumPrice minimum_price) {
		this.minimum_price = minimum_price;
	}
	
	
}
