package com.brunswick.ecomm.merclink.core.beans.personalinformation;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
public class CreateCompanyAddress {
	
	
	@JsonProperty("city")
	private String city;
	@JsonProperty("region")
	private Region region;
	@JsonProperty("country_code")
	private String country_code;
	@JsonProperty("street")
	private List<String> street;
	@JsonProperty("postcode")
	private Integer postcode;
	
	@JsonProperty("company_id")
	private String company_id;
	@JsonProperty("address_type")
	private Integer address_type;
	@JsonProperty("customer_type")
	private String customer_type;
	
	@JsonProperty("primary_flag")
	private String primary_flag;
	
	@JsonProperty("firstname")
	private String firstname;
	
	@JsonProperty("lastname")
	private String lastname;
	
	@JsonProperty("default_shipping")
	private Boolean default_shipping;
	
	@JsonProperty("default_billing")
	private Boolean default_billing;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

	public String getCountry_code() {
		return country_code;
	}

	public void setCountry_code(String country_code) {
		this.country_code = country_code;
	}

	public List<String> getStreet() {
		return new ArrayList<>(street);
	}

	public void setStreet(List<String> street) {
		this.street = new ArrayList<>(street);
	}

	public Integer getPostcode() {
		return postcode;
	}

	public void setPostcode(Integer postcode) {
		this.postcode = postcode;
	}

	public String getCompany_id() {
		return company_id;
	}

	public void setCompany_id(String company_id) {
		this.company_id = company_id;
	}

	public Integer getAddress_type() {
		return address_type;
	}

	public void setAddress_type(Integer address_type) {
		this.address_type = address_type;
	}

	public String getCustomer_type() {
		return customer_type;
	}

	public void setCustomer_type(String customer_type) {
		this.customer_type = customer_type;
	}

	public String getPrimary_flag() {
		return primary_flag;
	}

	public void setPrimary_flag(String primary_flag) {
		this.primary_flag = primary_flag;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Boolean getDefault_shipping() {
		return default_shipping;
	}

	public void setDefault_shipping(Boolean default_shipping) {
		this.default_shipping = default_shipping;
	}

	public Boolean getDefault_billing() {
		return default_billing;
	}

	public void setDefault_billing(Boolean default_billing) {
		this.default_billing = default_billing;
	}
	
	
    
	
	
	
	
	


	
}
