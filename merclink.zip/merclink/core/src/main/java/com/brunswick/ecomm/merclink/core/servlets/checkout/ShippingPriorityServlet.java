package com.brunswick.ecomm.merclink.core.servlets.checkout;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.EcommTokenService;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractCheckoutRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonObject;

@Component(service = Servlet.class, property = { "sling.servlet.methods=POST",
		"sling.servlet.paths=/bin/shippingPriorityML" })

public class ShippingPriorityServlet extends SlingAllMethodsServlet {
	private static final Logger LOG = LoggerFactory.getLogger(ShippingPriorityServlet.class);
	private static final long serialVersionUID = 1L;
	@Reference
	transient EcommTokenService tokenService;

	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		long startTime = System.currentTimeMillis();
		LOG.info(" ShippingPriorityServlet Request start time :{}", startTime);
		JSONObject requestObj;
		try {

			JsonObject jsonresponse = null;
			if (request != null) {
				PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
				LOG.info(" pagemanager in shipping priority servlet====={}", pageManager);
				requestObj = new JSONObject(request.getParameter("data"));
				String currentPagePath = requestObj.get("resourcePath").toString();
				LOG.info(" currentPage in shipping priority servlet====={}", currentPagePath);
				Resource resource = request.getResourceResolver().resolve(currentPagePath);
				LOG.info(" resource in shipping priority servlet====={}", resource);
				String token = CommonUtil.getTokenFromCookie("customerToken", request);
				LOG.info(" customerToken in shippingMethod servlet====={}", token);
				String cartId = CommonUtil.getTokenFromCookie("cartId", request);
				LOG.info(" cartId in shipping priority servlet====={}", cartId);
				String shippingType = requestObj.get("shippingType").toString();
				List<Header> headers = new ArrayList<>();
				headers.add(new BasicHeader("Authorization", "Bearer " + token));
				if (resource != null) {
					MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(resource,
							pageManager.getPage(resource.getPath()), request, headers);
					AbstractCheckoutRetriever checkoutretriever = new AbstractCheckoutRetriever(magentoGraphqlClient);
					jsonresponse = checkoutretriever.getShippingPriorityInformation(cartId, shippingType);

					LOG.info("jsonresponse in shippingpriority Servlet={}", jsonresponse);
				}
				response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
				response.setContentType("application/json");
				response.getWriter().print(jsonresponse);
			}
		} catch (JSONException e) {
			LOG.error("Json Exception=={}", e.getMessage());
		}
	}

}
