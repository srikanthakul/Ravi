package com.brunswick.ecomm.merclink.core.beans;


/**
 * POJO for Multi Field items
 *
 */
public class PrivilegeMultiFieldBean {

	private String name;
	private String privilegeCode;
	private String tooltip;

	public String getTooltip() {
		return tooltip;
	}

	public void setTooltip(String tooltip) {
		this.tooltip = tooltip;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPrivilegeCode() {
		return privilegeCode;
	}

	public void setPrivilegeCode(String code) {
		this.privilegeCode = code;
	}

}
