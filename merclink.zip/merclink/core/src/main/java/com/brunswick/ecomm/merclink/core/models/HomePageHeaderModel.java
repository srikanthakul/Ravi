package com.brunswick.ecomm.merclink.core.models;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.helper.MultifieldHelper;
import com.brunswick.ecomm.merclink.core.helper.NastedHelper;
import com.brunswick.ecomm.merclink.core.helper.ParentfieldHelper;
import com.brunswick.ecomm.merclink.core.helper.subNastedHelper;
@Model(
	    adaptables = {Resource.class},
	    defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class HomePageHeaderModel {
	private static final Logger LOG = LoggerFactory.getLogger(HomePageHeaderModel.class);
	@Inject
	private Resource multilanguage;
	@Inject
	private Resource loginmultitopnav;
	@Inject
	private Resource multitopnav;
	@Inject
	private Resource languageCode;
	@SlingObject
	Resource componentResource;
	@Inject
	public List<MultifieldHelper> logindetailswithnastedmultifield;
	
	@Inject
	public List<ParentfieldHelper> parentmenudetailswithnastedmultifield;
	
	
	public Resource getMultilanguage() {
		return multilanguage;
	}

	public Resource getLoginmultitopnav() {
		return loginmultitopnav;
	}

	public Resource getMultitopnav() {
		return multitopnav;
	}
	public Resource getLanguageCode() {
		return languageCode;
	}
	public List<MultifieldHelper> getLoginDetailsWithNestedMultifield() {
		List<MultifieldHelper> loginDetailsNasted = new ArrayList<>();
		LOG.info("\n Entering into Try Block");
		try {
			LOG.info("\n Inside Try Block");
			Resource loginDetailNasted=componentResource.getChild("logindetailswithnastedmultifield");
			LOG.info("\n loginDetailNasted Resource ::" +loginDetailNasted.getName().toString());
			
			LOG.info("\n Entering loginDetailsNasteds");
			if(loginDetailNasted != null) {

				LOG.info("\n Inside loginDetailsNasteds");
				for(Resource loginNasted : loginDetailNasted.getChildren())
				{
					LOG.info("\n Inside for  loginNasted:::" );
					MultifieldHelper multifieldHelper = new MultifieldHelper(loginNasted);
					if(loginNasted.hasChildren())
					{
						List<NastedHelper>  loginNastedList = new ArrayList<>();
						
						
						Resource nastedResource=loginNasted.getChild("myprofile");
					//	 Resource resource = resolver.getResource("/content/VignetteContent/plan");
						  
						LOG.info("\n nastedResource ::" +nastedResource.getName().toString());
						
						for(Resource nasted : nastedResource.getChildren()) {
							loginNastedList.add(new NastedHelper(nasted));
							LOG.info("\n nasted child pages: ::" +nasted.getName().toString());
							
						}
						
						multifieldHelper.setMyProfile(loginNastedList);
					}
					loginDetailsNasted.add(multifieldHelper);
				}
			
				
			}
			
			
		}catch(Exception e) {
			LOG.info("\n ERROR while getting Login Details With Nasted Multifield {} ", e.getMessage());
		}
		LOG.info("\n SIZE Multifield {} ", loginDetailsNasted.size());
		return loginDetailsNasted;
	}
	
	public List<ParentfieldHelper> getParentMenuDetailsWithNastedMultifield() {
		List<ParentfieldHelper> menuDetailsNasted = new ArrayList<>();
		LOG.info("\n Entering into Try Block ParentfieldHelper");
		try {
			LOG.info("\n Inside Try Block ParentfieldHelper");
			Resource parentMenuDetailNasted=componentResource.getChild("parentmenudetailswithnastedmultifield");
			LOG.info("\n parentMenuDetailNasted Resource ::" +parentMenuDetailNasted.getName().toString());
			
			LOG.info("\n Entering loginDetailsNasteds ParentfieldHelper");
			if(parentMenuDetailNasted != null) {

				LOG.info("\n Inside loginDetailsNasteds ParentfieldHelper");
				for(Resource parentMenuNasted : parentMenuDetailNasted.getChildren())
				{
					LOG.info("\n Inside for  loginNasted ParentfieldHelper:::" );
					ParentfieldHelper parentfieldHelper = new ParentfieldHelper(parentMenuNasted);
					if(parentMenuNasted.hasChildren())
					{
						List<subNastedHelper>  parentNastedList = new ArrayList<>();
						
						
						Resource nastedResource=parentMenuNasted.getChild("submenu");
					//	 Resource resource = resolver.getResource("/content/VignetteContent/plan");
						  
						LOG.info("\n nastedResource ParentfieldHelper::" +nastedResource.getName().toString());
						
						for(Resource nasted : nastedResource.getChildren()) {
							parentNastedList.add(new subNastedHelper(nasted));
							LOG.info("\n nasted child pages ParentfieldHelper: ::" +nasted.getName().toString());
							
						}
						
						parentfieldHelper.setSubMenu(parentNastedList);
					}
					menuDetailsNasted.add(parentfieldHelper);
				}
			
				
			}
			
			
		}catch(Exception e) {
			LOG.info("\n ERROR while getting Login Details With Nasted Multifield ParentfieldHelper{} ", e.getMessage());
		}
		LOG.info("\n SIZE Multifield ParentfieldHelper{} ", menuDetailsNasted.size());
		return menuDetailsNasted;
	}
}
