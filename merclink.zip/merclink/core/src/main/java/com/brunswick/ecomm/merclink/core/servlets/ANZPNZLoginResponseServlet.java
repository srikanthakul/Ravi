package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.http.Cookie;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.core.models.retriever.LoginRetriever;
import com.brunswick.ecomm.core.services.ANZPEcommTokenService;
import com.brunswick.ecomm.core.util.CommonUtil;
import com.brunswick.ecomm.core.util.SAMLResponseDataUtil;
import com.brunswick.ecomm.merclink.core.constants.LoginCommonConstants;
import com.day.cq.wcm.api.PageManager;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=Login Servlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_POST,
		"sling.servlet.paths=" + "/bin/anzpnzloginresponseservlet" })
public class ANZPNZLoginResponseServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1047669014764627919L;

	private static final Logger LOGGER = LoggerFactory.getLogger(ANZPNZLoginResponseServlet.class);

	@Reference
	transient ANZPEcommTokenService tokenService;

	transient LoginRetriever loginRetriever;

	String currentPage;

	String customerToken = StringUtils.EMPTY;

	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {

		LOGGER.info("Entering into ANZPNZLoginResponseServlet doPost() method.");
		currentPage = request.getParameter("RelayState");
		LOGGER.info("currentPage in ANZPLoginResponse servlet : {}", currentPage);
		processRequest(request, response);
		response.sendRedirect(currentPage);
		LOGGER.info("Exit from ANZPNZLoginResponseServlet doPost() method.");

	}

	@Override
	public void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOGGER.info("Entering into ANZPNZLoginResponseServlet doGet() method.");
		currentPage = request.getParameter("RelayState");
		LOGGER.info("currentPage in ANZPLoginResponse servlet : {}", currentPage);
		processRequest(request, response);
		response.sendRedirect(currentPage);
		LOGGER.info("Exit from ANZPNZLoginResponseServlet doGet() method.");
	}

	private void setCookie(SlingHttpServletResponse response, String name, String value) {

		Cookie cookie = new Cookie(name, value);
		cookie.setMaxAge(-1);
		cookie.setPath("/");
		response.addCookie(cookie);
	}

	protected void processRequest(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws IOException {
		LOGGER.info("Starts ANZPNZLoginResponseServlet processRequest()...");
		String userName = null;
		if ((request != null && null != request.getParameter(LoginCommonConstants.SAML_RESPONSE))) {
			request.getSession().removeAttribute("randomId");
			if (null != request.getParameter(LoginCommonConstants.SAML_RESPONSE)) {
				userName = SAMLResponseDataUtil.validateAssertion(request, response);
				LOGGER.info("userName from SAML response for NZ domain:::User Name: {}", userName);
				if (null != userName && !StringUtils.isEmpty(userName)) {
					if (userName.lastIndexOf("#:#") != -1) {
						userName = userName.substring(0, userName.lastIndexOf("#:#"));
						LOGGER.info("Starts LoginResponse processRequest():::User Name: {}", userName);
					} else {
						LOGGER.error(" #:# doesnot exit:::User Name: {}", userName);
						response.sendRedirect(LoginCommonConstants.ANZP_NZ_ERROR_PAGE);
					}
					getLoginUserData(request, response, userName);
				} else {
					response.sendRedirect(currentPage);
				}
			}
		}
	}

	private void getLoginUserData(SlingHttpServletRequest request, SlingHttpServletResponse response, String userName)
			throws IOException {
		String adminToken = tokenService.getAdminToken();
		LOGGER.info("Starts Merclink ANZPNZLoginResponseServlet getLoginUserData():::adminToken: {}", adminToken);
		if (null != adminToken && StringUtils.isNotEmpty(adminToken)) {

			List<Header> headers = new ArrayList<>();
			headers.add(new BasicHeader("Authorization", "Bearer " + adminToken));
			String page = null;
			if (currentPage.endsWith(".html")) {
				page = currentPage;
				page = page.replace(".html", "");
			} else {
				page = currentPage;
			}
			if (request != null) {
				PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
				Resource resource = request.getResourceResolver().resolve(request, page);
				loginRetriever = new LoginRetriever(MagentoGraphqlClient.create(resource,
						pageManager.getPage(resource.getPath()), request, headers));
				LOGGER.info("getLoginUserData():::ANZPNZLoginResponseServlet loginRetriever: {}", loginRetriever);
				if (loginRetriever != null) {
					customerToken = loginRetriever.generateCustomerToken(userName);
					if (null != customerToken) {
						setCookie(response, "customerToken", customerToken);
						List<Header> headers1 = new ArrayList<>();
						headers1.add(new BasicHeader("Authorization", "Bearer " + customerToken));
						LOGGER.info("headers1:::loginRetriever: {}", headers1);
						long startTime = System.currentTimeMillis();
						LOGGER.info("ANZPNZLoginResponseServlet login magento call start time :{}", startTime);
						loginRetriever = new LoginRetriever(MagentoGraphqlClient.create(resource,
								pageManager.getPage(resource.getPath()), request, headers1));
						String cartId = loginRetriever.getCustomerCart();
						long endTime = System.currentTimeMillis();
						LOGGER.info(
								" login Response end time , Time difference b/w request and response of login : {} {} ",
								endTime, (endTime - startTime));
						LOGGER.info("Starts Merclink ANZPNZLoginResponseServlet getLoginUserData():::cartId: {}",
								cartId);
						String oldCartId = CommonUtil.getTokenFromCookie("cartId", request);
						if (oldCartId != null && StringUtils.isNotEmpty(oldCartId)) {
							cartId = loginRetriever.mergeCarts(oldCartId);
							LOGGER.info("Merclink ANZPNZLoginResponseServlet merge carts = {}", cartId);
						}

						if (cartId != null && StringUtils.isNotEmpty(cartId)) {
							setCookie(response, "cartId", cartId);
						}
					} else {
						LOGGER.error(" customer token doesnot exist for this user:::User Name: {}", userName);
						response.sendRedirect(LoginCommonConstants.ANZP_NZ_ERROR_PAGE);
					}

				}
			}
		} else {
			LOGGER.error(" admin token doesnot exist: {}", userName);
			response.sendRedirect(LoginCommonConstants.ANZP_NZ_ERROR_PAGE);

		}
	}
}
