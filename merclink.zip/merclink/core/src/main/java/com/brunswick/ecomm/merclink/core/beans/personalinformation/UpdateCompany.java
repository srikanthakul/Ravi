package com.brunswick.ecomm.merclink.core.beans.personalinformation;

import org.apache.sling.models.annotations.Optional;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdateCompany {
	
	
	@Optional
	@JsonProperty("company")
	 private Company company;

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}
	
	
}
