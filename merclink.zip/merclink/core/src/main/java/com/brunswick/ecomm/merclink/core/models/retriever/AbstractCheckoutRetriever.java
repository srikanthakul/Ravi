package com.brunswick.ecomm.merclink.core.models.retriever;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.beans.checkout.CustomerAddressBean;
import com.brunswick.ecomm.merclink.core.beans.checkout.PlaceOrderBean;
import com.brunswick.ecomm.merclink.core.beans.checkout.SubmitOrderBean;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.google.gson.JsonObject;

public class AbstractCheckoutRetriever extends AbstractCustomRetriever {
	Customer customer;
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractCheckoutRetriever.class);
	private String query;

	protected String errorMessage = null;

	public String getErrorMessage() {
		return errorMessage;
	}

	public AbstractCheckoutRetriever(MagentoGraphqlClient client) {
		super(client);

	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return client.execute(query);
	}

	protected GraphqlResponse<JsonObject, Error> executeJsonQuery() {
		return client.executeQuery(query);
	}

	protected GraphqlResponse<Mutation, Error> executeMutation() {
		return client.executeMutation(query);
	}

	protected GraphqlResponse<JsonObject, Error> executeJsonMutation() {
		return client.executeJsonMutation(query);
	}

	@Override
	protected void populate() {

	}

	// Getters
	public JsonObject getCheckoutInformation(String cartId, int freeCatalogChk) {
		query = getCheckoutDefinition(cartId, freeCatalogChk);
		LOGGER.info("updateCart mutation ==" + query);
		GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
		LOGGER.info("updateCart mutation response ==" + response);
		List<Error> errors = response.getErrors();
		JsonObject queryResponse = null;
		if (errors != null) {
			for (Error error : errors) {
				this.errorMessage = error.getMessage();
			}
		} else {
			queryResponse = response.getData().getAsJsonObject("updateCart");
		}

		return queryResponse;
	}

	public JsonObject setEmailOnGuestCart(String cartId, String email) {
		query = setEmailOnGuestCartDefinition(cartId, email);
		LOGGER.info("setGuestEmailOnCart mutation==" + query);
		GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
		LOGGER.info("setGuestEmailOnCart mutation response====" + response);
		List<Error> errors = response.getErrors();
		JsonObject queryResponse = null;
		if (errors != null) {
			for (Error error : errors) {
				this.errorMessage = error.getMessage();
			}
		} else {
			queryResponse = response.getData().getAsJsonObject("setEmailOnGuestCartDefinition");
		}
		return queryResponse;
	}

	private String setEmailOnGuestCartDefinition(String cartId, String email) {
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation {\r\n" + "  setGuestEmailOnCart(\r\n" + "    input: {\r\n" + "      cart_id: \""
				+ cartId + "\"\r\n" + "      email: \"" + email + "\"\r\n" + "    }\r\n" + "  ) {\r\n"
				+ "    cart {\r\n" + "      email\r\n" + "    }\r\n" + "  }\r\n" + "}");
		return _queryBuilder.toString();
	}

	// Query Definitions
	private String getCheckoutDefinition(String cartId, int freeCatalogChk) {
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation { ");
		_queryBuilder.append("updateCart( ");
		_queryBuilder.append("input:{ ");
		_queryBuilder.append("cart_id: \"" + cartId + "\"");
		_queryBuilder.append(" order_source: \"Web\"");
		_queryBuilder.append(" order_type: \"NAEUS Del Web\"");
		_queryBuilder.append(" is_catalog_checked: " + freeCatalogChk + " ");
		_queryBuilder.append("}) { ");
		_queryBuilder.append("erp_quote_info ");
		_queryBuilder.append("cart{ ");
		_queryBuilder.append("shipping_addresses { ");
		_queryBuilder.append("available_shipping_methods { ");
		_queryBuilder.append("amount { ");
		_queryBuilder.append("currency ");
		_queryBuilder.append("value ");
		_queryBuilder.append("} ");
		_queryBuilder.append("available ");
		_queryBuilder.append("carrier_code ");
		_queryBuilder.append("carrier_title ");
		_queryBuilder.append("error_message ");
		_queryBuilder.append("method_code ");
		_queryBuilder.append("method_title }");
		_queryBuilder.append("}  ");
		_queryBuilder.append("items {  ");
		_queryBuilder.append(" item_attributes{  availability_date backorder_qty ");
		_queryBuilder.append("customer_adjustments}");
		_queryBuilder.append(
				"item_attributes_custom_:item_attributes{backorder_qty_custom_:backorder_qty availability_date_custom_:availability_date}");
		_queryBuilder.append("id ");
		_queryBuilder.append("product { ");
		_queryBuilder.append(
				" weight length width masterpartprop65code_custom_: masterpartprop65code masterparteachesweight_custom_: masterparteachesweight ");
		_queryBuilder.append(" sku ");
		_queryBuilder.append("name ");
		_queryBuilder.append("image_data_custom_: image_data { ");
		_queryBuilder.append("product_thumbnail_custom_: product_thumbnail ");
		_queryBuilder.append("}} ");
		_queryBuilder.append("quantity ");
		_queryBuilder.append("} ");
		_queryBuilder.append("available_payment_methods { ");
		_queryBuilder.append("code ");
		_queryBuilder.append("title ");
		_queryBuilder.append("} ");
		_queryBuilder.append("applied_coupons { ");
		_queryBuilder.append("code ");
		_queryBuilder.append("}  ");
		_queryBuilder.append("prices { ");
		_queryBuilder.append("grand_total { ");
		_queryBuilder.append("value ");
		_queryBuilder.append("currency  ");
		_queryBuilder.append("}}}}}");
		return _queryBuilder.toString();
	}

	// Getters
	public JsonObject setShippingAddressToCart(CustomerAddressBean customerAddrBean) {
		query = setShippingAddressToCartDefinition(customerAddrBean);
		LOGGER.info("setShippingAddressesOnCart mutation=={}", query);
		GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
		LOGGER.info("setShippingAddressesOnCart mutation response===={}", response);
		List<Error> errors = response.getErrors();
		JsonObject queryResponse = null;
		if (errors != null) {
			for (Error error : errors) {
				this.errorMessage = error.getMessage();
			}
		} else {
			queryResponse = response.getData().getAsJsonObject("setShippingAddressesOnCart");
		}
		return queryResponse;
	}

	// shipping address
	private String setShippingAddressToCartDefinition(CustomerAddressBean customerAddrBean) {
		LOGGER.info("calling set ship to cart");
		StringBuilder _queryBuilder = new StringBuilder();

		_queryBuilder.append("mutation { ");
		_queryBuilder.append("setShippingAddressesOnCart( ");
		_queryBuilder.append("input:{ ");
		_queryBuilder.append("cart_id: \"" + customerAddrBean.getCartId() + "\"");
		_queryBuilder.append("shipping_addresses: [");
		_queryBuilder.append("{ ");
		_queryBuilder.append("address: { ");
		if (customerAddrBean.getCompanyAddrId() != null) {
			_queryBuilder.append("company_address_id: " + customerAddrBean.getCompanyAddrId());
		}
		_queryBuilder.append(" firstname: ");
		_queryBuilder.append("\"" + customerAddrBean.getFirstname() + "\"");
		_queryBuilder.append("lastname: ");
		_queryBuilder.append("\"" + customerAddrBean.getLastname() + "\"");
		_queryBuilder.append("company: ");
		_queryBuilder.append("\"" + customerAddrBean.getCompany() + "\"");
		_queryBuilder.append("street: ");
		_queryBuilder.append("[\"" + customerAddrBean.getAddress1() + "\"]");
		_queryBuilder.append("city: ");
		_queryBuilder.append("\"" + customerAddrBean.getCity() + "\"");
		_queryBuilder.append("region: ");
		_queryBuilder.append("\"" + customerAddrBean.getRegioncode() + "\"");
		_queryBuilder.append("postcode: ");
		_queryBuilder.append("\"" + customerAddrBean.getPostalcode() + "\"");
		_queryBuilder.append("country_code: ");
		_queryBuilder.append("\"" + customerAddrBean.getCountry() + "\"");
		_queryBuilder.append("telephone: ");
		_queryBuilder.append("\"" + customerAddrBean.getTelephone() + "\"");
		_queryBuilder.append("save_in_address_book : ");
		_queryBuilder.append(customerAddrBean.getAddressbook());
		_queryBuilder.append(" } } ] }	) { ");

		_queryBuilder.append("cart  { ");
		_queryBuilder.append("shipping_addresses { ");
		_queryBuilder.append("firstname ");
		_queryBuilder.append("lastname ");
		_queryBuilder.append("company ");
		_queryBuilder.append("street ");
		_queryBuilder.append("city  ");
		_queryBuilder.append("region { ");
		_queryBuilder.append("code ");
		_queryBuilder.append("label  ");
		_queryBuilder.append("} ");
		_queryBuilder.append(" postcode ");
		_queryBuilder.append(" telephone ");
		_queryBuilder.append(" country { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" label ");
		_queryBuilder.append("} ");
		_queryBuilder.append(" pickup_location_code  ");
		_queryBuilder.append("} ");
		_queryBuilder.append("erp_errors { ");
		_queryBuilder.append("message ");
		_queryBuilder.append("code ");
		_queryBuilder.append("} } ");

		_queryBuilder.append("shipping_methods{ ");
		_queryBuilder.append("shipping_method_name ");
		_queryBuilder.append("sub_methods{ ");
		_queryBuilder.append("free_shipping ");
		_queryBuilder.append("method_code ");
		_queryBuilder.append("method_title ");
		_queryBuilder.append("amount{ ");
		_queryBuilder.append("currency ");
		_queryBuilder.append("value ");

		_queryBuilder.append(" } } } } }");
		return _queryBuilder.toString();
	}

	// Getters
	public JsonObject setBillingAddressToCart(CustomerAddressBean customerAddrBean) {
		query = setBillingAddressToCartDefinition(customerAddrBean);
		LOGGER.info("setBillingAddressOnCart mutation==" + query);
		GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
		LOGGER.info("setBillingAddressOnCart mutation response====" + response.toString());
		List<Error> errors = response.getErrors();
		JsonObject queryResponse = null;
		if (errors != null) {
			for (Error error : errors) {
				this.errorMessage = error.getMessage();
			}
		} else {
			queryResponse = response.getData().getAsJsonObject("setBillingAddressOnCart");
		}
		return queryResponse;
	}

	private String setBillingAddressToCartDefinition(CustomerAddressBean customerAddrBean) {
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation { ");
		_queryBuilder.append("setBillingAddressOnCart( ");
		_queryBuilder.append("input:{ ");
		_queryBuilder.append("cart_id: \"" + customerAddrBean.getCartId() + "\"");
		_queryBuilder.append("billing_address: {");
		_queryBuilder.append("address: { ");
		if (customerAddrBean.getCompanyAddrId() != null) {
			_queryBuilder.append("company_address_id: " + customerAddrBean.getCompanyAddrId());
		}
		_queryBuilder.append(" firstname: ");
		_queryBuilder.append("\"" + customerAddrBean.getFirstname().toString() + "\"");
		_queryBuilder.append("lastname: ");
		_queryBuilder.append("\"" + customerAddrBean.getLastname().toString() + "\"");
		_queryBuilder.append(" street:  ");
		_queryBuilder
				.append("[\"" + customerAddrBean.getAddress1() + "\", \"" + customerAddrBean.getAddress2() + "\"]");
		_queryBuilder.append(" city: ");
		_queryBuilder.append("\"" + customerAddrBean.getCity().toString() + "\"");
		_queryBuilder.append("region: ");
		_queryBuilder.append("\"" + customerAddrBean.getRegioncode().toString() + "\"");
		_queryBuilder.append("postcode: ");
		_queryBuilder.append("\"" + customerAddrBean.getPostalcode().toString() + "\"");
		_queryBuilder.append("country_code: ");
		_queryBuilder.append("\"" + customerAddrBean.getCountry().toString() + "\"");
		_queryBuilder.append("telephone: ");
		_queryBuilder.append("\"" + customerAddrBean.getTelephone().toString() + "\"");
		_queryBuilder.append("save_in_address_book : ");
		_queryBuilder.append(customerAddrBean.getAddressbook().toString());
		_queryBuilder.append(" primary_flag:\"Y\"");
		_queryBuilder.append(" } ");

		_queryBuilder.append("same_as_shipping :   ");
		_queryBuilder.append(customerAddrBean.getSameasshipping());
		_queryBuilder.append("}}){ ");
		_queryBuilder.append("cart { ");
		_queryBuilder.append("billing_address { ");
		_queryBuilder.append("firstname ");
		_queryBuilder.append("lastname ");
		_queryBuilder.append("company ");
		_queryBuilder.append("street ");
		_queryBuilder.append("city  ");
		_queryBuilder.append("region { ");
		_queryBuilder.append("code ");
		_queryBuilder.append("label  ");
		_queryBuilder.append("} ");

		_queryBuilder.append("postcode ");
		_queryBuilder.append("telephone ");
		_queryBuilder.append("country { ");
		_queryBuilder.append("code ");
		_queryBuilder.append("label ");
		_queryBuilder.append("}}}}} ");

		return _queryBuilder.toString();
	}

	public JsonObject addShippingRates(String cartId, String shippingmethod, String shippingrates) {
		query = addShippingRatesDefinition(cartId, shippingmethod, shippingrates);
		LOGGER.info("addShippingRates mutation==" + query);
		GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
		LOGGER.info("addShippingRates mutation response====" + response);
		List<Error> errors = response.getErrors();
		JsonObject queryResponse = null;
		if (errors != null) {
			for (Error error : errors) {
				this.errorMessage = error.getMessage();
			}
		} else {
			queryResponse = response.getData().getAsJsonObject("addShippingRates");
		}

		return queryResponse;
	}

	private String addShippingRatesDefinition(String cartId, String shippingmethod, String shippingrates) {
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation { ");
		_queryBuilder.append("addShippingRates( ");
		_queryBuilder.append("input:{ ");
		_queryBuilder.append("cart_id: \"" + cartId + "\"");
		_queryBuilder.append("shipping_method: ");
		_queryBuilder.append("\"" + shippingmethod.toString() + "\"");

		_queryBuilder.append("shipping_rate: ");
		_queryBuilder.append(shippingrates.toString());
		_queryBuilder.append("}){");
		_queryBuilder.append("cart { ");
		_queryBuilder.append(" street:  ");
		_queryBuilder.append("shipping_addresses {");
		_queryBuilder.append(" shipping_cost ");
		_queryBuilder.append("}}");
		_queryBuilder.append("erp_quote_info ");
		_queryBuilder.append("}}");
		return _queryBuilder.toString();
	}

	// shippingmethod Definitions
	public JsonObject getShippingMethodInformation(String cartId, String customerNumber) {
		query = getShippingMethodInformationDefinition(cartId, customerNumber);
		LOGGER.info("QUERY==" + query);
		GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
		LOGGER.info("response====" + response);
		List<Error> errors = response.getErrors();
		if (errors != null) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				errorjsonobject.addProperty("shippingMethodAnzp", error.getMessage());
			}
			return errorjsonobject;
		}

		JsonObject queryResponse = response.getData().getAsJsonObject("shippingMethodAnzp");

		return queryResponse;
	}

	private String getShippingMethodInformationDefinition(String cartId, String customerNumber) {
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation { ");
		_queryBuilder.append("shippingMethodAnzp(");
		_queryBuilder.append("input:{ ");
		_queryBuilder.append("customer_number: " + customerNumber + ",");
		_queryBuilder.append("cart_id: \"" + cartId + "\",");
		_queryBuilder.append(" } ");
		_queryBuilder.append("){ ");
		_queryBuilder.append("shipping_method{");
		_queryBuilder.append("name");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } }");
		return _queryBuilder.toString();
	}

	public JsonObject placeOrder(PlaceOrderBean placeorder) {
		query = placeOrderDefinition(placeorder);
		LOGGER.info("placeOrder mutation==" + query);
		GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
		LOGGER.info("placeOrder mutation response====" + response);
		List<Error> errors = response.getErrors();
		JsonObject queryResponse = null;
		if (errors != null) {
			for (Error error : errors) {
				this.errorMessage = error.getMessage();
			}
		} else {
			queryResponse = response.getData().getAsJsonObject("placeOrder");
		}
		return queryResponse;
	}

	private String placeOrderDefinition(PlaceOrderBean placeorder) {
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation { ");
		_queryBuilder.append("placeOrder( ");
		_queryBuilder.append("input:{ ");
		_queryBuilder.append("cart_id: \"" + placeorder.getCartId() + "\"");
		_queryBuilder.append(" po_number: ");
		_queryBuilder.append("\"" + placeorder.getPonumber().toString() + "\"");

		_queryBuilder.append(" order_comment: ");
		_queryBuilder.append("\"" + placeorder.getOrdercomment().toString() + "\"");
		_queryBuilder.append(" requested_ship_date: ");
		_queryBuilder.append("\"" + placeorder.getRequestedshipdate().toString() + "\"");
		_queryBuilder.append("credit_card_approval_code : " + "\"" + placeorder.getCredit_card_approval_code() + "\"");
		_queryBuilder.append("credit_card_approval_date:" + "\"" + placeorder.getCredit_card_approval_date() + "\"");
		_queryBuilder.append(" credit_card_token: " + "\"" + placeorder.getCredit_card_token() + "\"");
		_queryBuilder.append(" credit_card_holder_name: " + "\"" + placeorder.getCredit_card_holder_name() + "\"");
		_queryBuilder
				.append(" credit_card_expiration_date: " + "\"" + placeorder.getCredit_card_expiration_date() + "\"");
		_queryBuilder.append(" payment_method: " + "\"" + placeorder.getPayment_method() + "\"");
		_queryBuilder.append(" shipping_method: " + "\"" + placeorder.getShipping_method() + "\"");
		_queryBuilder.append(" shipping_cost: " + "\"" + placeorder.getShipping_cost() + "\"");
		_queryBuilder.append(" shipping_discount_amount: " + "\"" + placeorder.getShipping_discount_amount() + "\"");
		_queryBuilder.append(" shipping_tax_amount: " + "\"" + placeorder.getShipping_tax_amount() + "\"");
		_queryBuilder.append(" request_id:\" \" ");
		_queryBuilder.append(" collect_account_number: " + "\"" + placeorder.getCollectAccNumber() + "\"");
		_queryBuilder.append("}){");
		_queryBuilder.append(" order  { ");
		_queryBuilder.append(" order_number  ");
		_queryBuilder.append(" order_id ");
		_queryBuilder.append("}}}");
		return _queryBuilder.toString();
	}

	// Shipping Cost Checkout

	public JsonObject getShippingCostInformation(String cartid, String shippingmode) {
		query = getShippingCostInformationDefinition(cartid, shippingmode);
		LOGGER.info("getShippingCostInformation mutation==" + query);
		GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
		LOGGER.info("getShippingCostInformation mutation response====" + response);
		List<Error> errors = response.getErrors();

		if (errors != null) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				errorjsonobject.addProperty("shippingCost", error.getMessage());
			}
			return errorjsonobject;
		}

		JsonObject queryResponse = response.getData().getAsJsonObject("shippingCost");

		return queryResponse;
	}

	private String getShippingCostInformationDefinition(String cartid, String shippingmode) {
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation { ");
		_queryBuilder.append("shippingCost( ");
		_queryBuilder.append("input:{ ");
		_queryBuilder.append("cart_id: \"" + cartid + "\"");
		_queryBuilder.append("shipping_mode: \"" + shippingmode + "\"");
		_queryBuilder.append("}){");
		_queryBuilder.append(" shipping_cost ");
		_queryBuilder.append(" shipping_mode ");
		_queryBuilder.append("} }");

		return _queryBuilder.toString();
	}
	
	// DropShip Cost Checkout
	public JsonObject getDropShipCost(String cartId, boolean isDropship) {
        query = getDropShipCostQuery(cartId, isDropship);
        LOGGER.info(" submitOrder==" + query);
        GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
        List<Error> errors = response.getErrors();
        if (null != errors) {
            JsonObject errorjsonobject = new JsonObject();
            for (Error error : errors) {
                LOGGER.info("Error in getting  submitOrder  ==" + error.getMessage());
                errorjsonobject.addProperty("submitOrder", error.getMessage());
            }
            return errorjsonobject;
        }
        LOGGER.info(" submitOrder ==" + response.getData());
        return response.getData();
    }



    private String getDropShipCostQuery(String cartId, boolean isDropship) {
        StringBuilder _queryBuilder = new StringBuilder();
        _queryBuilder.append("mutation { ");
        _queryBuilder.append("setDropShip( ");
        _queryBuilder.append("input:{ ");
        _queryBuilder.append("cart_id: \"" + cartId + "\"");
        _queryBuilder.append("is_dropship:" + isDropship);
        _queryBuilder.append("}){");
        _queryBuilder.append(" is_dropship ");        
		_queryBuilder.append(" } ");
     	_queryBuilder.append(" } ");
        return _queryBuilder.toString();
    }
	// Submit Order Checkout

	public JsonObject submitOrder(SubmitOrderBean submitorder) {
		query = submitOrderDefinition(submitorder);
		LOGGER.info(" submitOrder=={}", query);
		GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  submitOrder  =={}", error.getMessage());
				errorjsonobject.addProperty("submitOrder", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" submitOrder =={}", response.getData());
		return response.getData();
	}

	private String submitOrderDefinition(SubmitOrderBean submitorder) {
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation { ");
		_queryBuilder.append("placeOrder( ");
		_queryBuilder.append("input:{ ");
		_queryBuilder.append("cart_id: \"" + submitorder.getCartId() + "\"");
		_queryBuilder.append(" po_number: \"" + submitorder.getPonumber() + "\"");
		_queryBuilder.append(" order_comment: \"" + submitorder.getOrdercomment() + "\"");
		_queryBuilder.append(" requested_ship_date: \"" + submitorder.getRequestedshipdate() + "\"");
		_queryBuilder.append(" payment_method: " + "\"" + submitorder.getPayment_method() + "\"");
		_queryBuilder.append(" shipping_method: " + "\"" + submitorder.getShipping_method() + "\"");
		_queryBuilder.append(" shipping_cost: " + "\"" + submitorder.getShipping_cost() + "\"");
		_queryBuilder.append(" attribute19: " + "\"" + submitorder.getAttribute19() + "\"");
		_queryBuilder.append(" is_dropship : ");
		_queryBuilder.append(submitorder.isIs_dropship());
		_queryBuilder.append("}){");
		_queryBuilder.append(" order  { ");
		_queryBuilder.append(" order_number  ");
		_queryBuilder.append(" order_id ");
		_queryBuilder.append(" erp_order_number ");
		_queryBuilder.append(" order_created  ");
		_queryBuilder.append("}}}");
		return _queryBuilder.toString();
	}

// shipping priority

	public JsonObject getShippingPriorityInformation(String cartId, String shippingType) {
		query = getShippingPriorityInformationDefinition(cartId, shippingType);
		LOGGER.info("QUERY=={}", query);
		GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
		LOGGER.info("response===={}", response);
		List<Error> errors = response.getErrors();
		if (errors != null) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				errorjsonobject.addProperty("shippingPriority", error.getMessage());
			}
			return errorjsonobject;
		}

		return response.getData().getAsJsonObject("shippingPriority");
	}

	private String getShippingPriorityInformationDefinition(String cartId, String shippingType) {
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append(" mutation { ");
		_queryBuilder.append("shippingPriority( ");
		_queryBuilder.append("input: { ");
		_queryBuilder.append("cart_id: \"" + cartId + "\",");
		_queryBuilder.append("shipping_type: \"" + shippingType + "\",");
		_queryBuilder.append(" } ");
		_queryBuilder.append("){ ");
		_queryBuilder.append(" shipping_type ");
		_queryBuilder.append(" message ");
		_queryBuilder.append(" } } ");
		return _queryBuilder.toString();
	}

}
