package com.brunswick.ecomm.merclink.core.models.retriever;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.google.gson.JsonObject;

public class AbstractRecentOrderRetriever extends AbstractCustomRetriever {
	private String queryString;
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractRecentOrderRetriever.class);

	public AbstractRecentOrderRetriever(MagentoGraphqlClient client) {
		super(client);
	}

	protected GraphqlResponse<JsonObject , Error> executeQuerygraphql() {
		return client.executeQuery(queryString);
	}
	protected GraphqlResponse<JsonObject , Error> executeMutationgraphql() {
		return client.executeJsonMutation(queryString);
	}
	
	@Override
	protected void populate(){
		//Nothing to do
	}

	// Getter
	public JsonObject getCustomerRecentOrder() {
		queryString = getRecentOrderDefinition();
		if(LOGGER.isDebugEnabled()) {
		LOGGER.debug(String.format("Recent orders query %s",queryString));
		}
		GraphqlResponse<JsonObject , Error> response = executeQuerygraphql();
		LOGGER.info("response="+response.toString());
		JsonObject jsonResponse = response.getData();

//LOGGER.info("jsonResponse=="+jsonResponse.toString());
		return jsonResponse;
	}
	
	// Getter
		public JsonObject getNewsletterSubscription(String emailId) {
			queryString = getNewsletterSubscriptionDefinition(emailId);
			if(LOGGER.isDebugEnabled()) {
			LOGGER.debug(String.format("News letter Subscription query %s",queryString));
			}
			GraphqlResponse<JsonObject , Error> response = executeMutationgraphql();
			LOGGER.info("response="+response.toString());
			JsonObject jsonResponse = response.getData();
			LOGGER.info("jsonResponse=="+jsonResponse.toString());
			return jsonResponse;
		}
		
		// Getter
		public JsonObject getCustomerDetails() {
			queryString = getCustomerDetailsDefinition();
			if(LOGGER.isDebugEnabled()) {
			LOGGER.debug(String.format("Customer Details query %s",queryString));
			}
			GraphqlResponse<JsonObject , Error> response = executeQuerygraphql();
			LOGGER.info("response="+response.toString());
			JsonObject jsonResponse = response.getData();
			//LOGGER.info("jsonResponse=="+jsonResponse.toString());
			return jsonResponse;
		}
		
		// Definition
		private String getNewsletterSubscriptionDefinition(String emailId) {	
			StringBuilder queryBuilder = new StringBuilder();
			queryBuilder.append("mutation {");
			queryBuilder.append(" subscribeEmailToNewsletter(");
			queryBuilder.append("email:");
			queryBuilder.append("\""+emailId.toString()+"\"");
			queryBuilder.append("  ) {");
			queryBuilder.append(" status ");
			queryBuilder.append("}}");
			return queryBuilder.toString();
			
		}
		
		/***
		 * Generate the customer detail query.
		 * @return query.
		 */
		private String getCustomerDetailsDefinition() {	
			StringBuilder queryBuilder = new StringBuilder();
			queryBuilder.append("{");
			queryBuilder.append(" customer {");
			queryBuilder.append(" customer_type firstname");
			queryBuilder.append(" lastname");
			queryBuilder.append(" suffix");
			queryBuilder.append(" email ");
			queryBuilder.append(" account_name ");
			queryBuilder.append(" customer_number company_name");
			queryBuilder.append(" addresses {");
			queryBuilder.append(" firstname");
			queryBuilder.append(" lastname");
			queryBuilder.append(" street");
			queryBuilder.append(" city");
			queryBuilder.append(" region {");
			queryBuilder.append(" region_code");
			queryBuilder.append(" region");
			queryBuilder.append(" }");
			queryBuilder.append(" postcode");
			queryBuilder.append(" country_code");
			queryBuilder.append(" telephone");				
			queryBuilder.append("}}}");
			return queryBuilder.toString();
			
		}

	
	// Definition
	private String getRecentOrderDefinition() {	
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("{");
		_queryBuilder.append(" salesOrder{");
		_queryBuilder.append("increment_id");
		
		_queryBuilder.append(" customer_name");
		_queryBuilder.append(" items {");
		_queryBuilder.append(" title ");
		_queryBuilder.append(" sku");
		_queryBuilder.append(" price");
		_queryBuilder.append(" image");
		_queryBuilder.append("}}}");
		return _queryBuilder.toString();
		
	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		// TODO Auto-generated method stub
		return null;
	}

}
