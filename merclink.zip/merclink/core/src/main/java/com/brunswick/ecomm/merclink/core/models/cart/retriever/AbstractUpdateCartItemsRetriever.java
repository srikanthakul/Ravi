package com.brunswick.ecomm.merclink.core.models.cart.retriever;

import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.*;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public abstract class AbstractUpdateCartItemsRetriever {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractUpdateCartItemsRetriever.class);
    //protected ProductIdentifierType productIdentifierType;
    protected String cartId;
    protected List<CartItemUpdateInput> cartItemsInput;
    private List<Error> error =new ArrayList<>();
    protected List<CartItemInterface> cartItems;
    protected Consumer<CartItemInterface> cartQueryHook;
    /**
     * Generated or fully customized query.
     */
    protected String query;

    /**
     * Instance of the Magento GraphQL client.
     */
    protected MagentoGraphqlClient client;


    protected AbstractUpdateCartItemsRetriever(MagentoGraphqlClient client) {
        if (client == null) {
            throw new java.lang.Error("No GraphQL client provided");
        }
        this.client = client;
    }

    public void setIdentifier(String cartId, List<CartItemUpdateInput> cartItemsInput) {
        this.cartId = cartId;
        this.cartItemsInput = cartItemsInput;
    }


    protected GraphqlResponse<Mutation, Error> executeMutation() {
        LOGGER.info("In executemutation() method");
        if (query == null) {
//            int itemIdTemp;
//            try {
//                itemIdTemp = itemId.intValue();
//            } catch (NumberFormatException e) {
//                itemIdTemp = 0;
//            }
            query = generateQuery(cartId, cartItemsInput);
            LOGGER.info("In executemutation() method query generated:-"+query);
        }
        return client.executeMutation(query);
    }

    protected String generateQuery(String cartId, List<CartItemUpdateInput> cartItemsInput) {
        UpdateCartItemsOutputQueryDefinition  queryDef = generateUpdateItemQuery();
        MutationQuery.UpdateCartItemsArgumentsDefinition argsDef = generateUpdateItemInputQuery(cartId, cartItemsInput);
        return Operations.mutation(mutationQuery -> mutationQuery.updateCartItems(argsDef, queryDef)).toString();
    }


    protected void populate() {
        // Get product list from response
        GraphqlResponse<Mutation, Error> response = executeMutation();
        if(response != null && response.getData()!=null) {
        Mutation rootQuery = response.getData();
        if (rootQuery !=null && rootQuery.getUpdateCartItems()!=null) {
        cartItems = rootQuery.getUpdateCartItems().getCart().getItems();
        }
        else{
        	error = response.getErrors();
        }
    }
    }

    public List<Error> getError() {
		return new ArrayList<>(error);
	}

	public List<CartItemInterface> fetchCart() {
        if (this.cartItems == null) {
            populate();
        }
        return this.cartItems;
    }

    protected abstract UpdateCartItemsOutputQueryDefinition generateUpdateItemQuery();

    protected abstract MutationQuery.UpdateCartItemsArgumentsDefinition generateUpdateItemInputQuery(String cartId, List<CartItemUpdateInput> cartItemsInput);


}

