package com.brunswick.ecomm.merclink.core.uam.servlets;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractUamRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@Component(service = Servlet.class, property = { "sling.servlet.methods=POST",
		"sling.servlet.paths=/bin/uam/childSecondaryUserDetailsServlet" })
public class SecondaryUserDetailsServlet extends SlingAllMethodsServlet {

	private static final Logger LOG = LoggerFactory.getLogger(SecondaryUserDetailsServlet.class);
	private static final long serialVersionUID = 1L;
	private transient AbstractUamRetriever retriever;
	String currentPagePath;
	private Integer company_number;
	private Integer customer_Id;
	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.debug("Entering into doPost() Method.");
		JSONObject requestObj;
		try {
			requestObj = new JSONObject(request.getParameter("data"));
             LOG.info("requestObj=====================" + requestObj );
			currentPagePath = requestObj.get("componentPath").toString();
			company_number = (int) requestObj.get("company_number");
            LOG.info("company_number=====================" + company_number );
			customer_Id = (int) requestObj.get("customer_Id");
            LOG.info("customer_Id=====================" + customer_Id );
  
			MagentoGraphqlClient magentoGraphqlClient = CommonUtil.getMagentoGraphqlClient(request, currentPagePath);
			retriever = new AbstractUamRetriever(magentoGraphqlClient);
			JsonObject resp = null;
			if (retriever != null) {
				resp = retriever.childSecondaryUserDetails(customer_Id,company_number);
			}
			if (resp != null) {
				LOG.info("Response=====================" + new Gson().toJson(resp) );
				response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
				response.setContentType("application/json");
				response.getWriter().print(new Gson().toJson(resp));
			}
			
		} catch (JSONException e) {
			LOG.error("Json Exception " + e.getMessage(),e);
		} catch (RuntimeException e) {
			LOG.error("RunTime Exception {}", e.getMessage(),e);
		}
		LOG.debug("Exit from doPost() Method.");
	}

}
