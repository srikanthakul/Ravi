package com.brunswick.ecomm.merclink.core.models.internal.cart;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractCustomRetriever;
import com.brunswick.ecomm.merclink.core.cart.servlets.UpdateCartItemInput;
import com.google.gson.JsonObject;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.cq.commerce.magento.graphql.CartItemInput;

public class AbstractCartRetriever extends AbstractCustomRetriever {
	Customer customer;
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractCartRetriever.class);
	private String query;

	enum User {
		ACTIVE
	}

	public AbstractCartRetriever(MagentoGraphqlClient client) {
		super(client);
	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return client.execute(query);
	}

	protected GraphqlResponse<JsonObject, Error> excecuteQueryGraphql() {
		return client.executeQuery(query);
	}

	protected GraphqlResponse<Mutation, Error> executeMutation() {
		return client.executeMutation(query);
	}

	protected GraphqlResponse<JsonObject, Error> excecuteJsonMutation() {
		return client.executeJsonMutation(query);
	}

	@Override
	protected void populate() {
		// Nothing to do
	}

	/**
	 * creating query and return .
	 */
	public JsonObject cartPageQuery(String cartId) {
		try {
			query = generateCartPageQuery(cartId);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" cartPageQuery== {}", query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  cartPageQuery  =={}", error.getMessage());
				errorjsonobject.addProperty("cartPageQuery", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" cartPageQuery =={}", response.getData());
		return response.getData();
	}

	/**
	 * creating query to change email.
	 */
	private String generateCartPageQuery(String cartId) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();

		_queryBuilder.append("{ ");
		_queryBuilder.append(" cart(cart_id: \"" + cartId + "\") { ");
		_queryBuilder.append(" email ");
		_queryBuilder.append(" items { ");
		_queryBuilder.append(" id ");
		_queryBuilder.append(" item_attributes{ ");
		_queryBuilder.append(" availability_date ");
		_queryBuilder.append(" backorder_qty ");
		_queryBuilder.append(" customer_adjustments ");
		_queryBuilder.append(" tier_price ");
		_queryBuilder.append(" customer_price ");
		_queryBuilder.append(" availability ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" product { ");
		_queryBuilder.append(" name ");
		_queryBuilder.append(" sku ");
		_queryBuilder.append(" masterpartprop65code ");
		_queryBuilder.append(" product_data { ");
		_queryBuilder.append(" weight ");
		_queryBuilder.append(" weight_unit ");
		_queryBuilder.append(" masterpartlowestsellinguomqty ");
		_queryBuilder.append(" warning_message ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" quantity ");
		_queryBuilder.append(" cpq_session ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append("} ");

		return _queryBuilder.toString();
	}

	/**
	 * creating query and return .
	 */
	public JsonObject cartQuery(String cartId, boolean item) {
		try {
			query = generatecartQuery(cartId, item);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" cartQuery== {}", query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  cartQuery  =={}", error.getMessage());
				errorjsonobject.addProperty("cartQuery", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" cartQuery =={}", response.getData());
		return response.getData();
	}

	/**
	 * creating query to change email.
	 */
	private String generatecartQuery(String cartId, boolean item) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();

		_queryBuilder.append("{ ");
		_queryBuilder.append(" cart(cart_id: \"" + cartId + "\") { ");
		_queryBuilder.append(" email ");
		_queryBuilder.append(" is_dropship ");
		_queryBuilder.append(" billing_address { ");
		_queryBuilder.append(" city ");
		_queryBuilder.append(" country { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" label ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" firstname ");
		_queryBuilder.append(" lastname ");
		_queryBuilder.append(" company_address_id ");
		_queryBuilder.append(" postcode ");
		_queryBuilder.append(" region { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" label ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" street ");
		_queryBuilder.append(" telephone ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" shipping_addresses { ");
		_queryBuilder.append(" firstname ");
		_queryBuilder.append(" lastname ");
		_queryBuilder.append(" company_address_id ");
		_queryBuilder.append(" street ");
		_queryBuilder.append(" city ");
		_queryBuilder.append(" region { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" label ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" country { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" label ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" telephone ");
		_queryBuilder.append(" pickup_location_code ");
		_queryBuilder.append(" available_shipping_methods { ");
		_queryBuilder.append(" amount { ");
		_queryBuilder.append(" currency ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" available ");
		_queryBuilder.append(" carrier_code ");
		_queryBuilder.append(" carrier_title ");
		_queryBuilder.append(" error_message ");
		_queryBuilder.append(" method_code ");
		_queryBuilder.append(" method_title ");
		_queryBuilder.append(" price_excl_tax { ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" currency ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" price_incl_tax { ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" currency ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" selected_shipping_method { ");
		_queryBuilder.append(" amount { ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" currency ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" carrier_code ");
		_queryBuilder.append(" carrier_title ");
		_queryBuilder.append(" method_code ");
		_queryBuilder.append(" method_title ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		if (item) {
			_queryBuilder.append(" items { ");
			_queryBuilder.append(" id ");
			_queryBuilder.append(" item_attributes{ ");
			_queryBuilder.append(" availability_date ");
			_queryBuilder.append(" backorder_qty ");
			_queryBuilder.append(" customer_adjustments ");
			_queryBuilder.append(" tier_price ");
			_queryBuilder.append(" customer_price ");
			_queryBuilder.append(" availability ");
			_queryBuilder.append(" } ");
			_queryBuilder.append(" product { ");
			_queryBuilder.append(" name ");
			_queryBuilder.append(" sku ");
			_queryBuilder.append(" masterpartprop65code ");
			_queryBuilder.append(" product_data { ");
			_queryBuilder.append(" weight ");
			_queryBuilder.append(" weight_unit ");
			_queryBuilder.append(" masterpartlowestsellinguomqty ");
			_queryBuilder.append(" warning_message ");
			_queryBuilder.append(" } ");
			_queryBuilder.append(" } ");
			_queryBuilder.append(" quantity ");
			_queryBuilder.append(" } ");
		}
		_queryBuilder.append(" available_payment_methods { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" title ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" applied_coupons { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" prices { ");
		_queryBuilder.append(" minimum_charge { ");
		_queryBuilder.append(" chargecode ");
		_queryBuilder.append(" minimum ");
		_queryBuilder.append(" message ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" shipping_priority { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" title ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" grand_total { ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" currency ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" applied_taxes { ");
		_queryBuilder.append(" label ");
		_queryBuilder.append(" amount { ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append("}");

		return _queryBuilder.toString();
	}
	
	/**
	 * creating query and return .
	 */
	public JsonObject bulkcartQuery(String cartId) {
		try {
			query = generatebulkcartQuery(cartId);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" cartQuery== {}", query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  cartQuery  =={}", error.getMessage());
				errorjsonobject.addProperty("cartQuery", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" cartQuery =={}", response.getData());
		return response.getData();
	}

	/**
	 * creating query to change email.
	 */
	private String generatebulkcartQuery(String cartId) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("{ ");
		_queryBuilder.append(" cart(cart_id: \"" + cartId + "\") { ");
		_queryBuilder.append(" email ");
		_queryBuilder.append(" billing_address { ");
		_queryBuilder.append(" city ");
		_queryBuilder.append(" country { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" label ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" firstname ");
		_queryBuilder.append(" lastname ");
		_queryBuilder.append(" company_address_id ");
		_queryBuilder.append(" postcode ");
		_queryBuilder.append(" region { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" label ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" street ");
		_queryBuilder.append(" telephone ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" shipping_addresses { ");
		_queryBuilder.append(" firstname ");
		_queryBuilder.append(" lastname ");
		_queryBuilder.append(" company_address_id ");
		_queryBuilder.append(" street ");
		_queryBuilder.append(" city ");
		_queryBuilder.append(" region { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" label ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" country { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" label ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" telephone ");
		_queryBuilder.append(" pickup_location_code ");
		_queryBuilder.append(" available_shipping_methods { ");
		_queryBuilder.append(" amount { ");
		_queryBuilder.append(" currency ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" available ");
		_queryBuilder.append(" carrier_code ");
		_queryBuilder.append(" carrier_title ");
		_queryBuilder.append(" error_message ");
		_queryBuilder.append(" method_code ");
		_queryBuilder.append(" method_title ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" selected_shipping_method { ");
		_queryBuilder.append(" amount { ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" currency ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" carrier_code ");
		_queryBuilder.append(" carrier_title ");
		_queryBuilder.append(" method_code ");
		_queryBuilder.append(" method_title ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");		
		_queryBuilder.append(" available_payment_methods { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" title ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append("}");

		return _queryBuilder.toString();
	}

	public JsonObject cartPrice(String cartId) {
		try {
			query = generatecartPrice(cartId);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" cartPrice== {}", query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  cartPrice  =={}", error.getMessage());
				errorjsonobject.addProperty("cartPrice", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" cartPrice =={}", response.getData());
		return response.getData();
	}

	private String generatecartPrice(String cartId) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();

		_queryBuilder.append("{ ");
		_queryBuilder.append(" cart(cart_id: \"" + cartId + "\") { ");
		_queryBuilder.append(" items { ");
		_queryBuilder.append(" id ");
		_queryBuilder.append(" item_attributes{ ");
		_queryBuilder.append(" availability_date ");
		_queryBuilder.append(" backorder_qty ");
		_queryBuilder.append(" customer_adjustments ");
		_queryBuilder.append(" tier_price ");
		_queryBuilder.append(" customer_price ");
		_queryBuilder.append(" availability ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" product { ");
		_queryBuilder.append(" name ");
		_queryBuilder.append(" sku ");
		_queryBuilder.append(" masterpartprop65code ");
		_queryBuilder.append(" product_data { ");
		_queryBuilder.append(" weight ");
		_queryBuilder.append(" weight_unit ");
		_queryBuilder.append(" masterpartlowestsellinguomqty ");
		_queryBuilder.append(" warning_message ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" quantity ");
		_queryBuilder.append(" cpq_session ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" prices { ");
		_queryBuilder.append(" minimum_charge { ");
		_queryBuilder.append(" chargecode ");
		_queryBuilder.append(" minimum ");
		_queryBuilder.append(" message ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" shipping_priority { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" title ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" grand_total { ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" currency ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" applied_taxes { ");
		_queryBuilder.append(" label ");
		_queryBuilder.append(" amount { ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append("}");
		return _queryBuilder.toString();
	}

	public JsonObject shippingMethodCartQuery(String cartId) {
		try {
			query = generateshippingMethodCartQuery(cartId);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" shippingMethodCartQuery== {}", query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  shippingMethodCartQuery  =={}", error.getMessage());
				errorjsonobject.addProperty("shippingMethodCartQuery", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" shippingMethodCartQuery =={}", response.getData());
		return response.getData();
	}

	private String generateshippingMethodCartQuery(String cartId) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();

		_queryBuilder.append("{ ");
		_queryBuilder.append(" cart(cart_id: \"" + cartId + "\") { ");
		_queryBuilder.append(" prices { ");
		_queryBuilder.append(" minimum_charge { ");
		_queryBuilder.append(" chargecode ");
		_queryBuilder.append(" minimum ");
		_queryBuilder.append(" message ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" shipping_priority { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" title ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" grand_total { ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" currency ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" applied_taxes { ");
		_queryBuilder.append(" label ");
		_queryBuilder.append(" amount { ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" shipping_addresses { ");
		_queryBuilder.append(" firstname ");
		_queryBuilder.append(" lastname ");
		_queryBuilder.append(" company_address_id ");
		_queryBuilder.append(" street ");
		_queryBuilder.append(" city ");
		_queryBuilder.append(" region { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" label ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" country { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" label ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" telephone ");
		_queryBuilder.append(" pickup_location_code ");
		_queryBuilder.append(" selected_shipping_method { ");
		_queryBuilder.append(" amount { ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" currency ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" carrier_code ");
		_queryBuilder.append(" carrier_title ");
		_queryBuilder.append(" method_code ");
		_queryBuilder.append(" method_title ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		return _queryBuilder.toString();
	}

	public JsonObject RemoveCartItemPriceQuery(String cartId) {
		try {
			query = generateRemoveCartItemPriceQuery(cartId);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" RemoveCartItemPriceQuery== {}", query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  RemoveCartItemPriceQuery  =={}", error.getMessage());
				errorjsonobject.addProperty("RemoveCartItemPriceQuery", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" RemoveCartItemPriceQuery =={}", response.getData());
		return response.getData();
	}

	private String generateRemoveCartItemPriceQuery(String cartId) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();

		_queryBuilder.append("{ ");
		_queryBuilder.append(" cart(cart_id: \"" + cartId + "\") { ");
		_queryBuilder.append(" prices { ");
		_queryBuilder.append(" minimum_charge { ");
		_queryBuilder.append(" chargecode ");
		_queryBuilder.append(" minimum ");
		_queryBuilder.append(" message ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" shipping_priority { ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" title ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" grand_total { ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" currency ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" applied_taxes { ");
		_queryBuilder.append(" label ");
		_queryBuilder.append(" amount { ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append("}");
		return _queryBuilder.toString();
	}

	public JsonObject createCartId(String conpanyNumber) {
		try {
			query = generateCartId(conpanyNumber);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" createCartId==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  createCartId  ==" + error.getMessage());
				errorjsonobject.addProperty("createCartId", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" createCartId ==" + response.getData());
		return response.getData();
	}

	/**
	 * creating query to change email.
	 */
	private String generateCartId(String conpanyNumber) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();

		_queryBuilder.append("{ ");
		_queryBuilder.append(" customerCart(company_customer_number: \"" + conpanyNumber + "\") { ");
		_queryBuilder.append(" id ");
		_queryBuilder.append(" erp_errors { ");
		_queryBuilder.append(" message ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append("}");

		return _queryBuilder.toString();
	}

	public JsonObject addToCartQuery(String cartId, List<CartItemInput> cartItems) {
		try {
			query = generateAddToCart(cartId, cartItems);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" createCartId==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  createCartId  ==" + error.getMessage());
				errorjsonobject.addProperty("createCartId", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" createCartId ==" + response.getData());
		return response.getData();
	}

	private String generateAddToCart(String cartId, List<CartItemInput> cartItems) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();

		_queryBuilder.append("mutation { ");
		_queryBuilder.append(" addProductsToCart( ");
		_queryBuilder.append(" cartId:  \"" + cartId + "\" ");
		_queryBuilder.append(" cartItems: [ ");

		{
			String listSeperator1 = "";
			for (CartItemInput item1 : cartItems) {
				_queryBuilder.append(listSeperator1);
				listSeperator1 = ",";
				item1.appendTo(_queryBuilder);
			}
		}
		_queryBuilder.append(" ] ");
		_queryBuilder.append("  ){ ");
		_queryBuilder.append("  cart { ");
		_queryBuilder.append("  items { ");
		_queryBuilder.append("  product { ");
		_queryBuilder.append("  name ");
		_queryBuilder.append("  sku ");
		_queryBuilder.append("  } ");
		_queryBuilder.append("  quantity ");
		_queryBuilder.append("  } ");
		_queryBuilder.append("  erp_errors { ");
		_queryBuilder.append("  message ");
		_queryBuilder.append("  code ");
		_queryBuilder.append("  } ");
		_queryBuilder.append("  } ");
		_queryBuilder.append("  user_errors { ");
		_queryBuilder.append("  message ");
		_queryBuilder.append("  code ");
		_queryBuilder.append("  } ");
		_queryBuilder.append("  } ");
		_queryBuilder.append("  } ");

		return _queryBuilder.toString();
	}

	public JsonObject updateCartQuery(String cartId, List<UpdateCartItemInput> cartItems) {
		try {
			query = generatUpdateCart(cartId, cartItems);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" updateCartQuery==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  updateCartQuery  ==" + error.getMessage());
				errorjsonobject.addProperty("updateCartQuery", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" updateCartQuery ==" + response.getData());
		return response.getData();
	}

	private String generatUpdateCart(String cartId, List<UpdateCartItemInput> cartItems) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();

		_queryBuilder.append(" mutation { ");
		_queryBuilder.append(" updateCartItems( ");
		_queryBuilder.append(" input: { ");
		_queryBuilder.append(" cart_id: \"" + cartId + "\",  ");
		_queryBuilder.append(" cart_items: [ ");

		{
			String listSeperator1 = "";
			for (UpdateCartItemInput item1 : cartItems) {
				_queryBuilder.append(listSeperator1);
				listSeperator1 = ",";
				item1.appendTo(_queryBuilder);
			}
		}
		_queryBuilder.append(" ] ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" ){ ");
		_queryBuilder.append(" cart { ");
		_queryBuilder.append(" items { ");
		_queryBuilder.append(" uid ");
		_queryBuilder.append(" product { ");
		_queryBuilder.append(" name ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" quantity ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" prices { ");
		_queryBuilder.append(" grand_total{ ");
		_queryBuilder.append(" value ");
		_queryBuilder.append(" currency ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");

		return _queryBuilder.toString();
	}

	public JsonObject cartSummary(String cartId) {
		try {
			query = generateCartSummary(cartId);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" cartQuery==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  cartQuery  ==" + error.getMessage());
				errorjsonobject.addProperty("cartQuery", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" cartQuery ==" + response.getData());
		return response.getData();
	}

	/**
	 * creating query to change email.
	 */
	private String generateCartSummary(String cartId) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();

		_queryBuilder.append("mutation{ ");
		_queryBuilder.append(" cartCount(input: { ");
		_queryBuilder.append(" cart_id:  \"" + cartId + "\", ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" ){ ");
		_queryBuilder.append(" item_count ");
		_queryBuilder.append(" cart_updatedat ");
		_queryBuilder.append(" errors{ ");
		_queryBuilder.append(" message ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append("}");

		return _queryBuilder.toString();
	}

	public JsonObject validateCart(String cartId, String companyNumber) {
		try {
			query = generateValidateCart(cartId, companyNumber);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" validateCart==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  validateCart  ==" + error.getMessage());
				errorjsonobject.addProperty("validateCart", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" validateCart ==" + response.getData());
		return response.getData();
	}

	/**
	 * creating query to change email.
	 */
	private String generateValidateCart(String cartId, String companyNumber) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();

		_queryBuilder.append("{");
		_queryBuilder.append(" ValidateUserCompany(cartId:\"" + cartId + "\"");
		_queryBuilder.append(" companyCustomerNumber:\"" + companyNumber + "\") { ");
		_queryBuilder.append(" status ");
		_queryBuilder.append(" errortype ");
		_queryBuilder.append(" message ");
		_queryBuilder.append(" cartCompany ");
		_queryBuilder.append(" } ");
		_queryBuilder.append("}");

		return _queryBuilder.toString();
	}
}