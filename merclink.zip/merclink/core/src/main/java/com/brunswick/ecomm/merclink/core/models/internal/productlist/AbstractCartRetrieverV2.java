package com.brunswick.ecomm.merclink.core.models.internal.productlist;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.AddConfigurableProductsToCartOutput;
import com.adobe.cq.commerce.magento.graphql.AddConfigurableProductsToCartOutputQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.AddProductsToCartOutput;
import com.adobe.cq.commerce.magento.graphql.AddProductsToCartOutputQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Cart;
import com.adobe.cq.commerce.magento.graphql.CartItemInput;
import com.adobe.cq.commerce.magento.graphql.CartItemInterface;
import com.adobe.cq.commerce.magento.graphql.CartItemInterfaceQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.CartQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.CartUserInputError;
import com.adobe.cq.commerce.magento.graphql.CartUserInputErrorQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.ConfigurableProductCartItemInput;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.MutationQuery.AddConfigurableProductsToCartArgumentsDefinition;
import com.adobe.cq.commerce.magento.graphql.MutationQuery.AddSimpleProductsToCartArgumentsDefinition;
import com.adobe.cq.commerce.magento.graphql.MutationQuery.CreateEmptyCartArgumentsDefinition;
import com.adobe.cq.commerce.magento.graphql.Operations;
import com.adobe.cq.commerce.magento.graphql.ProductInterfaceQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.SimpleProductCartItemInput;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractCustomRetriever;

public abstract class AbstractCartRetrieverV2 extends AbstractCustomRetriever {
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractCartRetrieverV2.class);

	private String errorMessage = null;

	private String userError = null;

	public final String getUserError() {
		return userError;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public AbstractCartRetrieverV2(MagentoGraphqlClient client) {
		super(client);
	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return client.execute(query);
	}

	protected GraphqlResponse<Mutation, Error> executeMutation() {
		return client.executeMutation(query);
	}

	@Override
	protected void populate() {

	}

	// Getters
	public String createEmptyCart(String cartId) {
		query = CreateEmptyCartDefinition(cartId);
		GraphqlResponse<Mutation, Error> response = executeMutation();
		Mutation queryResponse = response.getData();
		LOGGER.info(queryResponse.getCreateEmptyCart());
		return queryResponse.getCreateEmptyCart();
	}

	public String addProductsToCart(String cartId, List<CartItemInput> cartItems) {
		String totalQuantity = "0";
		query = addProductsToCartDefinition(cartId, cartItems);
		LOGGER.debug("Add Products to Cart Query:" + query);
		GraphqlResponse<Mutation, Error> response = executeMutation();
		List<CartUserInputError> userErrors = new ArrayList<CartUserInputError>();
		List<Error> errors = response.getErrors();
		if (errors != null) {
			for (Error error : errors) {
				this.errorMessage = error.getMessage();
			}
		} else if (response.getData() != null) {
			Mutation queryResponse = response.getData();
			AddProductsToCartOutput addCartOutput = queryResponse.getAddProductsToCart();
			if (addCartOutput != null) {
				userErrors = addCartOutput.getUserErrors();
				for (CartUserInputError error : userErrors) {
					if (error != null) {
						this.userError = error.getMessage();
					}
				}
				Cart cart = addCartOutput.getCart();
				List<CartItemInterface> cartList = cart.getItems();
				totalQuantity = "" + cartList.size();
				LOGGER.info("Cart Id:{} count {} ", cart.getId(), cartList.size());
				LOGGER.debug("Cart errorMessage :{} ", errorMessage);
				LOGGER.debug("Cart userMessage :{} ", userError);
				/*
				 * for (CartItemInterface cartListItems : cartList) { LOGGER.info(
				 * "Simple Items in cart " + cartListItems.getProduct().getSku() + ":" +
				 * cartListItems.getQuantity()); }
				 */
			}

		}

		return totalQuantity;

	}

	public void addConfigurableProductsToCart(String typeName, String cartId,
			List<ConfigurableProductCartItemInput> configurablecartItems) {
		query = addConfigurableProductsToCartDefinition(typeName, cartId, configurablecartItems);
		GraphqlResponse<Mutation, Error> response = executeMutation();
		Mutation queryResponse = response.getData();
		AddConfigurableProductsToCartOutput cartOutput = queryResponse.getAddConfigurableProductsToCart();
		Cart cart = cartOutput.getCart();
		List<CartItemInterface> cartList = cart.getItems();
		for (CartItemInterface cartListItems : cartList) {
			LOGGER.info("Configurable Items in cart " + cartListItems.getProduct().getSku() + ":"
					+ cartListItems.getQuantity());
		}
	}

	// Query Definitions
	@SuppressWarnings("deprecation")
	private String addProductsToCartDefinition(String cartId, List<CartItemInput> cartItems) {
		LOGGER.info("inside addProductsToCartDefinition " + cartId);
		ProductInterfaceQueryDefinition pdef = p -> p.name().sku();
		CartItemInterfaceQueryDefinition cdef = c -> c.id().product(pdef).quantity();
		CartQueryDefinition cart = c -> c.id().totalQuantity().items(cdef);
		CartUserInputErrorQueryDefinition errordef = e -> e.message().code();
		AddProductsToCartOutputQueryDefinition queryDef = o -> o.cart(cart).userErrors(errordef);
		return Operations.mutation(mutation -> mutation.addProductsToCart(cartId, cartItems, queryDef)).toString();
	}

	@SuppressWarnings("deprecation")
	private String addConfigurableProductsToCartDefinition(String typeName, String cartId,
			List<ConfigurableProductCartItemInput> configurablecartItems) {
		ProductInterfaceQueryDefinition pdef = p -> p.name().sku();
		CartItemInterfaceQueryDefinition cdef = c -> c.id().product(pdef).quantity();
		CartQueryDefinition cart = c -> c.items(cdef);
		AddConfigurableProductsToCartOutputQueryDefinition confoutputdef = co -> co.cart(cart);
		AddConfigurableProductsToCartArgumentsDefinition confinputdef = generateconfigurableaddtoCartArgsQuery(cartId,
				configurablecartItems);
		return Operations.mutation(mutation -> mutation.addConfigurableProductsToCart(confinputdef, confoutputdef))
				.toString();
	}

	private String CreateEmptyCartDefinition(String cartId) {
		CreateEmptyCartArgumentsDefinition emptycart = generateCartArgsQuery(cartId);
		return Operations.mutation(mutation -> mutation.createEmptyCart(emptycart)).toString();
	}

	abstract protected CreateEmptyCartArgumentsDefinition generateCartArgsQuery(String cartId);

	abstract protected AddSimpleProductsToCartArgumentsDefinition generateaddtoCartArgsQuery(String cartId,
			List<SimpleProductCartItemInput> cartItems);

	abstract protected AddConfigurableProductsToCartArgumentsDefinition generateconfigurableaddtoCartArgsQuery(
			String cartId, List<ConfigurableProductCartItemInput> cartItems);

}
