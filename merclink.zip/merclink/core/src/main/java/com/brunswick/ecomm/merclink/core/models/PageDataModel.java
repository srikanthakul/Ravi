package com.brunswick.ecomm.merclink.core.models;

import java.text.SimpleDateFormat;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;

import com.brunswick.ecomm.core.beans.common.NewRelicDataBean;
import com.brunswick.ecomm.core.util.PropertyUtil;
import com.brunswick.ecomm.merclink.core.constants.CommonConstants;
import com.brunswick.ecomm.core.services.EcommNewRelic;
import com.brunswick.ecomm.merclink.core.beans.MetaDataBean;
import com.day.cq.wcm.api.Page;

@Model(adaptables = { SlingHttpServletRequest.class,
		Resource.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class PageDataModel {

	/** The current page. */
	@ScriptVariable
	protected Page currentPage;
	
	/** The resource resolver. */
	@SlingObject
	protected ResourceResolver resourceResolver;
	
	@SlingObject
	protected SlingHttpServletRequest slingRequest;

	/** The Constant DATE_FORMAT. */
	public final String DATE_FORMAT = "dd MMM yyyy HH:mm:ss z";

	/** The Constant PROP_SEO_KEYWORDS. */
	public final String PROP_SEO_KEYWORDS = "seokeywords";

	/** The Constant PROP_OG_TYPE. */
	public final String OG_TYPE = "ogtype";

	/** The meta data bean. */
	private MetaDataBean metaDataBean = new MetaDataBean();
	
	private String pageTitle;

	private String currentPagePath;

	public final String HTTPS = "https://";
	
	@Inject
	EcommNewRelic ecommNewRelicService;
	
	private NewRelicDataBean newRelic;
	
	/**
	 * Gets the meta data bean.
	 *
	 * @return the meta data bean
	 */
	public MetaDataBean getMetaDataBean() {
		return metaDataBean;
	}

	/**
	 * Inits the.
	 *
	 * @throws ValueFormatException the value format exception
	 * @throws RepositoryException  the repository exception
	 */
	@PostConstruct
	public void init() throws ValueFormatException, RepositoryException {
		populateMetaData();
	}

	/**
	 * Populate meta data.
	 */
	private void populateMetaData() {
		ValueMap currentPageProp = null;
		if (null != currentPage) {
			pageTitle = PropertyUtil.getPageTitle(currentPage.getPath(), resourceResolver);
			currentPageProp = currentPage.getProperties();
			currentPagePath = currentPage.getPath();
		

		// get SEO Keywords configured in Brunswick custom properties tab
		String seoKeywords = PropertyUtil.getStringProperty(currentPage.getProperties(), PROP_SEO_KEYWORDS);
		String ogType = PropertyUtil.getStringProperty(currentPage.getProperties(), OG_TYPE);
		metaDataBean.setOgType(ogType);
		metaDataBean.setKeywords(seoKeywords);
		metaDataBean.setDescription(currentPage.getDescription());
		metaDataBean.setOgTitle(currentPage.getTitle());
		metaDataBean.setOgSitename(currentPage.getTitle());
		metaDataBean.setOgDesc(currentPage.getDescription());
		}
		// populate thumbnail with teaser image
		String teaserImage = StringUtils.EMPTY;
		if (StringUtils.isNotBlank(teaserImage)) {
			metaDataBean.setThumbnail(teaserImage);
		}

		// populate OG Image and Twitter Image with OG Image, fallback is teaser
		// image
		String ogImage = PropertyUtil.getStringProperty(currentPageProp, CommonConstants.PROP_OG_IMAGE);
		if (StringUtils.isNotBlank(ogImage)) {
			String servername = slingRequest.getServerName();
			metaDataBean.setOgImage(HTTPS + servername + ogImage);
			metaDataBean.setTwitterImage(ogImage);
		} else {
			metaDataBean.setOgImage(teaserImage);
			metaDataBean.setTwitterImage(teaserImage);
		}
		// populate last modified time
		String pageLastModifiedDate;
		SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT);
		if (currentPage.getLastModified() != null) {
			pageLastModifiedDate = format.format(currentPage.getLastModified().getTime());
			metaDataBean.setLastModifiedDate(pageLastModifiedDate);
		}

		setNewRelic(ecommNewRelicService.getNewRelicData());
	}

	/**
	 * @return the currentPagePath
	 */
	public String getCurrentPagePath() {
		return currentPagePath;
	}

	/**
	 * @return the pageTitle
	 */
	public String getPageTitle() {
		return pageTitle;
	}

	public NewRelicDataBean getNewRelic() {
		return newRelic;
	}

	public void setNewRelic(NewRelicDataBean newRelic) {
		this.newRelic = newRelic;
	}
}
