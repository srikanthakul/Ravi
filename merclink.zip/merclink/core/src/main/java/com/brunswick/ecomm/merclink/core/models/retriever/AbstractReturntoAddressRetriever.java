package com.brunswick.ecomm.merclink.core.models.retriever;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.google.gson.JsonObject;

public class AbstractReturntoAddressRetriever extends AbstractCustomRetriever {
	Customer customer;
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractReturntoAddressRetriever.class);
	private String query;

	public AbstractReturntoAddressRetriever(MagentoGraphqlClient client) {
		super(client);

	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return client.execute(query);
	}

	protected GraphqlResponse<JsonObject, Error> excecuteQueryGraphql() {
		return client.executeQuery(query);
	}

	protected GraphqlResponse<Mutation, Error> executeMutation() {
		return client.executeMutation(query);
	}

	@Override
	protected void populate() {
		// Nothing to do

	}

	public JsonObject getReturntoAddressDetails() {
		query = getReturntoAddressDefinition();
		LOGGER.info("QUERY==" + query);
		JsonObject queryResponse = null;
		GraphqlResponse<JsonObject, Error> response = excecuteQueryGraphql();
		if (response != null) {
			if (response.getData() != null) {
				LOGGER.info("addr response===="+ response.getData().toString());
				 queryResponse = response.getData().getAsJsonObject();
			}
		}
		LOGGER.info("queryResponse==" + queryResponse);
		return queryResponse;

	}

	


	public String getReturntoAddressDefinition() {
		
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("query{");
		_queryBuilder.append("warehouse (");
		_queryBuilder.append(" name:\"DWC Del City West Coast Distribution\" ");
		_queryBuilder.append(") {");
		_queryBuilder.append(" type ");
		_queryBuilder.append(" name ");
		_queryBuilder.append(" address ");
		_queryBuilder.append("}}");

		return _queryBuilder.toString();
	
	}

	

}
