package com.brunswick.ecomm.merclink.core.servlets.wishlist;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.http.Cookie;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.constants.MagentoAttributes;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractWishlistDetailsRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;


@Component(service = Servlet.class, property = { "sling.servlet.methods=POST",
		"sling.servlet.paths=/bin/createMercWishlistServlet" })
public class CreateWishlistServlet extends SlingAllMethodsServlet {

	private static final Logger LOG = LoggerFactory.getLogger(CreateWishlistServlet.class);
	private static final long serialVersionUID = 1L;
	private transient AbstractWishlistDetailsRetriever wishlistRetriever;
	String currentPagePath;

	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.info("inside");
		JSONObject requestObj;
		PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
		try {
			requestObj = new JSONObject(request.getParameter("data"));
			String wishlistName = requestObj.get("wishlistName").toString();
			String visibility = requestObj.get("visibility").toString();
			currentPagePath = requestObj.get("resourcePath").toString();
			
			Resource res=request.getResourceResolver().resolve(request,currentPagePath);
			List<Header> headers = new ArrayList<>();
			String token = CommonUtil.getTokenFromCookie("customerToken", request);
			Cookie[] cookies = request.getCookies();
			String companyNumber = null;
			if (cookies != null) {
				for (Cookie cookie : cookies) {
					if (cookie.getName().equals(MagentoAttributes.CUSTOMER_NUMBER)) {
						// Setting the customer number
						companyNumber = cookie.getValue();
					}
				}
			}
			headers.add(new BasicHeader("Authorization",
					"Bearer " + token));
			MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(res,
					pageManager.getPage(res.getPath()), request, headers);
			wishlistRetriever = new AbstractWishlistDetailsRetriever(magentoGraphqlClient);
			if(wishlistRetriever!=null) {
				String id = wishlistRetriever.createWishlist(wishlistName, visibility, companyNumber);
				response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
				response.setContentType("text/plain");
				response.getWriter().print(id);
			}
		} catch (JSONException e) {
			LOG.error("Json Exception "+e.getMessage());
		}
		catch (RuntimeException e) {
			LOG.error("RunTime Exception {}", e.getMessage());
		}
	}

}
