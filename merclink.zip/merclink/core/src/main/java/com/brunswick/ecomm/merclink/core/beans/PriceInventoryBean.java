package com.brunswick.ecomm.merclink.core.beans;

import org.apache.sling.models.annotations.Optional;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PriceInventoryBean {

	@Optional
	@JsonProperty("item_number")
	private String item_number;

	@Optional
	@JsonProperty("inventory")
	private ProductInventoryBean inventory;

	@Optional
	@JsonProperty("prices")
	private ProductPricesBean prices;

	public String getItem_number() {
		return item_number;
	}

	public void setItem_number(String item_number) {
		this.item_number = item_number;
	}

	public ProductInventoryBean getInventory() {
		return inventory;
	}

	public void setInventory(ProductInventoryBean inventory) {
		this.inventory = inventory;
	}

	public ProductPricesBean getPrices() {
		return prices;
	}

	public void setPrices(ProductPricesBean prices) {
		this.prices = prices;
	}
	
	

}
