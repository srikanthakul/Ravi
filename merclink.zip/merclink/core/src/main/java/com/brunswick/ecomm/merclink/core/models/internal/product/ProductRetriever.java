/*******************************************************************************
 *
 *    Copyright 2019 Adobe. All rights reserved.
 *    This file is licensed to you under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License. You may obtain a copy
 *    of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software distributed under
 *    the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 *    OF ANY KIND, either express or implied. See the License for the specific language
 *    governing permissions and limitations under the License.
 *
 ******************************************************************************/

package com.brunswick.ecomm.merclink.core.models.internal.product;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.magento.graphql.BundleProductQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.FilterEqualTypeInput;
import com.adobe.cq.commerce.magento.graphql.GroupedProductQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Operations;
import com.adobe.cq.commerce.magento.graphql.ProductAttributeFilterInput;
import com.adobe.cq.commerce.magento.graphql.ProductInterfaceQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.ProductsQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.QueryQuery;
import com.adobe.cq.commerce.magento.graphql.SimpleProductQueryDefinition;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.constants.MagentoAttributes;
import com.brunswick.ecomm.merclink.core.models.product.retriever.AbstractProductRetriever;
import com.shopify.graphql.support.CustomFieldQueryDefinition;

class ProductRetriever extends AbstractProductRetriever {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ProductRetriever.class);

    ProductRetriever(MagentoGraphqlClient client) {
        super(client);
    }

    /* --- GraphQL queries --- */
    @Override
    protected String generateQuery(String identifier) {
        // Adds the store config query to the generic query of AbstractProductRetriever
    	LOGGER.info("Product query : {}"+identifier);
        FilterEqualTypeInput identifierFilter = new FilterEqualTypeInput().setEq(identifier);
        ProductAttributeFilterInput filter;
        filter = new ProductAttributeFilterInput().setSku(identifierFilter);

        QueryQuery.ProductsArgumentsDefinition searchArgs = s -> s.filter(filter);

        // GraphQL query
        ProductsQueryDefinition queryArgs = q -> q.items(generateProductQuery());
     
		String productQuery = Operations.query(query -> query
                .products(searchArgs, queryArgs)).toString();        
        
        LOGGER.info("Product query : {}"+productQuery);
        return productQuery;
    }
    
    private CustomFieldQueryDefinition generateImageQuery(){
		return customquery -> customquery.addCustomSimpleField(MagentoAttributes.IMAGE_SET)
				.addCustomSimpleField(MagentoAttributes.PRODUCT_THUMBNAIL)
				.addCustomObjectField(MagentoAttributes.VIDEOS_QUERY, generateVideosQuery())
				.addCustomObjectField(MagentoAttributes.PRODUCT_ATTACHMENT_QUERY, generateImageInnerQuery());

	}
	
	private CustomFieldQueryDefinition generateVideosQuery() {
		return q -> {
			q.addCustomSimpleField(MagentoAttributes.TITLE)
			.addCustomSimpleField(MagentoAttributes.VIDEO_QUERY);
		};
	}

	private CustomFieldQueryDefinition generateImageInnerQuery(){
		return custominnerquery -> custominnerquery.addCustomSimpleField(MagentoAttributes.ATTACH_IDENTIFIER)
				.addCustomSimpleField(MagentoAttributes.LABEL_NAME_QUERY)
				.addCustomSimpleField(MagentoAttributes.DESCRIPTION_QUERY)
				.addCustomSimpleField(MagentoAttributes.ATTACHMENT_QUERY)
				.addCustomSimpleField(MagentoAttributes.VISIBLE_QUERY);

	}

    private SimpleProductQueryDefinition generateSimpleProductQuery() {
        return q -> {        	
            q.sku()
                .name()                
                .description(d -> d.html())
                .image(i -> i.label().url())
                .thumbnail(t -> t.label().url())
                .urlKey()
                .stockStatus()
                .color()
                .priceRange(r -> r
                    .minimumPrice(generatePriceQuery()))
                .mediaGallery(g -> g
                    .disabled()
                    .url()
                    .label()
                    .position());

            // Apply product variant query hook
            if (variantQueryHook != null) {
                variantQueryHook.accept(q);
            }
        };
    }
    

	@Override
    protected ProductInterfaceQueryDefinition generateProductQuery() {
        return q -> {
            	q.sku()
                .name()
                .urlKey()
                .addCustomSimpleField("__typename")
                .addCustomObjectField(MagentoAttributes.SPECIFICATIONS, generateProductSpecificationQuery())
                .addCustomSimpleField(MagentoAttributes.ITEM_STATUS)
				.addCustomSimpleField(MagentoAttributes.PROP65)
                .addCustomSimpleField(MagentoAttributes.BUNDLED_QUANTITY)
                .addCustomSimpleField(MagentoAttributes.BU_SS_TO_PART)
                .addCustomSimpleField(MagentoAttributes.MP_HAZARDOUS_MATERIAL)
                .addCustomSimpleField(MagentoAttributes.MP_PKG_EA_WEIGHT_METRIC)
                .addCustomSimpleField(MagentoAttributes.MP_PKG_EA_WEIGHT_UOM_METRIC)
                .addCustomSimpleField(MagentoAttributes.LONGDESCRIPTION)
                .description(d -> d.html())
                .color()
                .image(i -> i.label().url())
                .thumbnail(t -> t.label().url())
                .stockStatus()
                .metaDescription()
                .addCustomObjectField(MagentoAttributes.IMAGE_DATA, generateImageQuery())
                .metaKeyword()
                .metaTitle()
                .onPhysicalProductInterface(w-> w
                		.weight())
                .priceRange(r -> r
                    .minimumPrice(generatePriceQuery()))
                .mediaGallery(g -> g
                    .disabled()
                    .url()
                    .label()
                    .position())
                .onConfigurableProduct(cp -> cp
                    .priceRange(r -> r
                        .maximumPrice(generatePriceQuery()))
                    .configurableOptions(o -> o
                        .label()
                        .attributeCode()
                        .values(v -> v
                            .valueIndex()
                            .label()))
                    .variants(v -> v
                        .attributes(a -> a
                            .code()
                            .valueIndex())
                        .product(generateSimpleProductQuery())))
                .onGroupedProduct(generateGroupedProductQuery())
                .onBundleProduct(generateBundleProductQuery());

            // Apply product query hook
            if (productQueryHook != null) {
                productQueryHook.accept(q);
            }
        };
    }

    private CustomFieldQueryDefinition generateProductSpecificationQuery() {
		return q -> {
			q.addCustomSimpleField(MagentoAttributes.LABEL_QUERY)
			.addCustomSimpleField(MagentoAttributes.CODE_QUERY)
			.addCustomSimpleField(MagentoAttributes.VALUE_QUERY);
		};
	}

	private GroupedProductQueryDefinition generateGroupedProductQuery() {
        return gp -> gp
            .items(i -> i
                .position()
                .qty()
                .product(p -> p
                    .sku()
                    .name()
                    .priceRange(r -> r
                        .minimumPrice(generatePriceQuery()))));
    }

    private BundleProductQueryDefinition generateBundleProductQuery() {
        return bp -> bp
            .priceRange(r -> r
                .maximumPrice(generatePriceQuery()));
    }
}
