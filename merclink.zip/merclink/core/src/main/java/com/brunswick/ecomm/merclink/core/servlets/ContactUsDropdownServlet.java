package com.brunswick.ecomm.merclink.core.servlets;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.GenericServlet;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.day.cq.dam.api.Asset;


@Component(service = Servlet.class,property = {
        Constants.SERVICE_DESCRIPTION + "=Contact Us Dropdown Servlet",
        "sling.servlet.methods="+HttpConstants.METHOD_GET,
        "sling.servlet.paths="+ "/bin/contactUsDropdownServlet"

})
public class ContactUsDropdownServlet extends SlingSafeMethodsServlet {

private static final long serialVersionUID = 1L;

protected static final Logger LOG = LoggerFactory.getLogger(ContactUsDropdownServlet.class);

@Reference
transient EcommSessionService adminService;
private transient JSONArray jsonObj = null;
private transient Map<String,String> countryList = null;
private transient Map<String,String> stateList = null;
public static final String DELCITY_COUNTRY_STATE_JSON = "/content/dam/delcity/json/country_states.json";
String country = null; 

@Override
protected void doGet(SlingHttpServletRequest request,SlingHttpServletResponse response) throws ServletException,
IOException {

// Reading the JSON File from DAM.
this.country = request.getParameter("data").replaceAll("[\n|\r|\t]", "_"); 
try {
	ResourceResolver resolver = adminService.getWriteServiceResourceResolver();
	Resource resource = resolver.getResource(DELCITY_COUNTRY_STATE_JSON);
	jsonObj = getJsonArray(resource);
	countryList = getCountryList(jsonObj);
	stateList = getStateList(jsonObj, country);
} catch (JSONException e) {
	LOG.error("JSON Exception "+e.getMessage());
} catch (LoginException e1) {
	LOG.error("Login exception "+e1.getMessage());
} catch (Exception e2) {
	LOG.error("Exception "+e2.getMessage(),e2);
} 


response.setContentType("application/json");
if(country.equals("getCountryList")){
	response.getWriter().print(new JSONObject(countryList));	
}
else  {
response.getWriter().print(new JSONObject(stateList));
}
response.setStatus(200); 


}

JSONArray getJsonArray(Resource resource ) {
	Resource original;
	Asset asset = resource.adaptTo(Asset.class);

	original = asset.getOriginal();

	InputStream content = original.adaptTo(InputStream.class);

	StringBuilder sb = new StringBuilder();
	String line;
	BufferedReader br = new BufferedReader(new InputStreamReader(
	content, StandardCharsets.UTF_8));

	try {
		while ((line = br.readLine()) != null) {
		sb.append(line);
		}
	jsonObj = new JSONArray(sb.toString()); 

	} catch (IOException e) {
		LOG.error("IOException "+e.getMessage(),e);
	} catch (JSONException e) {
		LOG.error("JSONException "+e.getMessage(),e);
	}
	
	return jsonObj;
}

HashMap<String,String> getCountryList(JSONArray jsonArray) throws JSONException {

List<String> list = new ArrayList<>();
int index = 1;
HashMap<String,String> map =  new HashMap<>();
for(int i=0; i<jsonArray.length();i++) {
	 list.add(jsonArray.getJSONObject(i).getString("name"));
}
for (String countryName:list) {
	map.put("country-"+index, countryName);	
	index++;
}

return map;
}


HashMap<String,String> getStateList(JSONArray jsonArray, String country) throws JSONException {
	
	HashMap<String,String> map =  new HashMap<>();
	int index = 1;
	
	for(int i=0; i<jsonArray.length();i++) {
		if(jsonArray.getJSONObject(i).getString("name").equalsIgnoreCase(country)) {
			int len = jsonArray.getJSONObject(i).getJSONArray("states").length();
			for(int j=0; j<len;j++) {				
				map.put("state-"+index,jsonArray.getJSONObject(i).getJSONArray("states").getJSONObject(j).getString("name"));
		index++;
			}
		}
	}
	return map;
}
}