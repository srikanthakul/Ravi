package com.brunswick.ecomm.merclink.core.beans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class WareHouses {

	@JsonProperty("quantity")
	private int quantity;
	
	@JsonProperty("warehouse")
	private WareHouse warehouse;

	/**
	 * @return the quantity
	 */
	public final int getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public final void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the warehouse
	 */
	public final WareHouse getWarehouse() {
		return warehouse;
	}

	/**
	 * @param warehouse the warehouse to set
	 */
	public final void setWarehouse(WareHouse warehouse) {
		this.warehouse = warehouse;
	}
}
