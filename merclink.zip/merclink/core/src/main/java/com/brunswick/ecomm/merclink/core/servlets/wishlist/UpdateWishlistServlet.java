package com.brunswick.ecomm.merclink.core.servlets.wishlist;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractWishlistDetailsRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;
import com.shopify.graphql.support.ID;

@Component(service = Servlet.class, property = { "sling.servlet.methods=POST",
		"sling.servlet.paths=/bin/updateMercWishlistServlet" })
public class UpdateWishlistServlet extends SlingAllMethodsServlet {

	private static final Logger LOG = LoggerFactory.getLogger(UpdateWishlistServlet.class);
	private static final long serialVersionUID = 1L;
	private transient AbstractWishlistDetailsRetriever wishlistRetriever;
	String wishlistName;
	ID wishlistId;
	String visibility;
	String currentPagePath;

	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.info("inside");
		JSONObject requestObj;
		try {
			PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
			requestObj = new JSONObject(request.getParameter("data"));
			visibility = requestObj.get("visibility").toString();
			wishlistId = new ID(requestObj.get("wishlistId").toString());
			wishlistName = requestObj.get("wishlistName").toString();
			currentPagePath = requestObj.get("resourcePath").toString();
			Resource res = request.getResourceResolver().resolve(currentPagePath);
			
			wishlistRetriever = new AbstractWishlistDetailsRetriever(
					MagentoGraphqlClient.create(res, pageManager.getPage(res.getPath()), null, null));
			List<Header> headers = new ArrayList<>();
			String token = CommonUtil.getTokenFromCookie("customerToken", request);
			headers.add(new BasicHeader("Authorization",
					"Bearer " + token));
			MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(res,
					pageManager.getPage(res.getPath()), request, headers);
			if(wishlistRetriever!=null) {
				wishlistRetriever = new AbstractWishlistDetailsRetriever(magentoGraphqlClient);
				JSONObject updatedFields = wishlistRetriever.updateWishlist(wishlistId, wishlistName, visibility);
				LOG.debug("updatedfields = {}", updatedFields.toString());
				response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
				response.setContentType("application/json");
				response.getWriter().print(updatedFields);
			}
		} catch (JSONException e) {
			LOG.error("Json Exception "+e.getMessage());
		}
		catch (RuntimeException e) {
			LOG.error("RunTime Exception {}", e.getMessage());
		}
	}

}
