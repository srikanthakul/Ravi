package com.brunswick.ecomm.merclink.core.models;
import java.util.List;
import java.util.Map;

public interface CustomBreadcrumb {
	List<Map<String,String>> getNavDetails();
}