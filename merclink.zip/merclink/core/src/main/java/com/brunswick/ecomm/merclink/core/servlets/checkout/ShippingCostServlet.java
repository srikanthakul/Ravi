package com.brunswick.ecomm.merclink.core.servlets.checkout;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractCheckoutRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonObject;

@Component(service = Servlet.class, property = { "sling.servlet.methods=POST",
"sling.servlet.paths=/bin/merclink/shippingCostServlet" })
public class ShippingCostServlet extends SlingAllMethodsServlet {
	
	private static final Logger LOG = LoggerFactory.getLogger(ShippingMethodServlet.class);
	private static final long serialVersionUID = 1L;
	private transient AbstractCheckoutRetriever checkoutretriever;
	String currentPagePath;
	
	@Reference
	transient EcommSessionService sessionService;

	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		long startTime = System.currentTimeMillis();
		LOG.info(" ShippingCostServlet Request start time :{}", startTime);
		

             JSONObject requestObj;

try{

PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
requestObj = new JSONObject(request.getParameter("data"));
currentPagePath = requestObj.get("resourcePath").toString();
Resource resource = request.getResourceResolver().resolve(currentPagePath);
String token =CommonUtil.getTokenFromCookie("customerToken",request);
//String token = "5v4rznmo657nm4ce2h0fk59o55llms2w";

//CART ID
String cartid = CommonUtil.getTokenFromCookie("cartId", request);

//String cartid ="sMtzHlsIueE9GsgdgAmzUU2Ne5prCKBH";
//CUSTOMER NUMBER
//String customernumber = requestObj.get("customerNumber").toString();
String shippingmode = requestObj.get("shipping_mode").toString();

//LOG.info(" Token=======", customernumber);

List<Header> headers1 = new ArrayList<>();
headers1.add(new BasicHeader("Authorization", "Bearer " + token));
JsonObject jsonresponse = new JsonObject();

if(resource!= null) {
MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(resource,
	pageManager.getPage(resource.getPath()), request, headers1);
checkoutretriever = new AbstractCheckoutRetriever(magentoGraphqlClient);
jsonresponse = checkoutretriever.getShippingCostInformation(cartid, shippingmode);

LOG.info("jsonresponse=" + jsonresponse);
}
response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
response.setContentType("application/json");
response.getWriter().print(jsonresponse);
} catch (JSONException e) {
LOG.error("Json Exception "+e.getMessage());
} 
}
	
	
}

	
