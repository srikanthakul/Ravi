package com.brunswick.ecomm.merclink.core.models;

import java.util.List;

import com.google.gson.JsonPrimitive;

public class ProductListResponse {
	int prodCount;
	List<ProductItem> prodList;
	List<FacetObj> facetList;
	JsonPrimitive errors;

	public int getProdCount() {
		return prodCount;
	}

	public void setProdCount(int prodCount) {
		this.prodCount = prodCount;
	}

	public List<ProductItem> getProdList() {
		return prodList;
	}

	public void setProdList(List<ProductItem> prodList) {
		this.prodList = prodList;
	}

	public List<FacetObj> getFacetList() {
		return facetList;
	}

	public void setFacetList(List<FacetObj> facetList) {
		this.facetList = facetList;
	}

	public JsonPrimitive getErrors() {
		return errors;
	}

	public void setErrors(JsonPrimitive errors) {
		this.errors = errors;
	}

}
