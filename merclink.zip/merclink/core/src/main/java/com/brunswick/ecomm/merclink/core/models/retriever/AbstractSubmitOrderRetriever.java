package com.brunswick.ecomm.merclink.core.models.retriever;

public class AbstractSubmitOrderRetriever {

}
