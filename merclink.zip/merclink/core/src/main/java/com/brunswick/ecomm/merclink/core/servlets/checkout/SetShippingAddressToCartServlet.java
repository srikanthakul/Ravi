package com.brunswick.ecomm.merclink.core.servlets.checkout;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;


import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.merclink.core.beans.checkout.CustomerAddressBean;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractCheckoutRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@Component(service = Servlet.class, property = { "sling.servlet.methods=POST",
		"sling.servlet.paths=/bin/setShippingaddresstocartML" })
public class SetShippingAddressToCartServlet extends SlingAllMethodsServlet {

	private static final Logger LOG = LoggerFactory.getLogger(SetShippingAddressToCartServlet.class);
	private static final long serialVersionUID = 1L;
	private transient AbstractCheckoutRetriever checkoutretriever;
	 

	@Reference
	transient EcommSessionService sessionService;

	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		JSONObject requestObj;
		try {
			long startTime = System.currentTimeMillis();
			LOG.info(" AddShippingaddresstocartServlet Request start time :{}", startTime);
			PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
			LOG.info(" page manager  ==={}", pageManager);
			requestObj = new JSONObject(request.getParameter("data"));
			LOG.info(" request object in set shipping address ==={}", requestObj);
			CustomerAddressBean customerAddrBean = new Gson().fromJson(request.getParameter("data"),
					CustomerAddressBean.class);
			customerAddrBean.setCartId(CommonUtil.getTokenFromCookie("cartId", request));
			String currentPagePath = requestObj.get("resourcePath").toString();
			LOG.info(" current page path in set shipping address ==={}", currentPagePath);
			String token = CommonUtil.getTokenFromCookie("customerToken", request);
			LOG.info("Token ==={}", token);
			Resource resource = request.getResourceResolver().resolve(currentPagePath);
			LOG.info(" resource in set shipping address ==={}", resource);

			
			List<Header> headers = new ArrayList<>();
			headers.add(new BasicHeader("Authorization", "Bearer " + token));
			JsonObject jsonresponse = new JsonObject();
			response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
			response.setContentType("application/json");
			if (resource != null) {
				MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(resource,
						pageManager.getPage(resource.getPath()), request, headers);
				checkoutretriever = new AbstractCheckoutRetriever(magentoGraphqlClient);
				jsonresponse = checkoutretriever.setShippingAddressToCart(customerAddrBean);
				if (null != checkoutretriever.getErrorMessage()) {
					JSONObject respErr = new JSONObject();
					respErr.put("checkoutError",
				CommonUtil.getUserMessage(sessionService.getReadServiceResourceResolver(),
									pageManager.getPage(resource.getPath()), checkoutretriever.getErrorMessage()));
					response.getWriter().print(respErr);
					
				} else if (jsonresponse != null) {
					LOG.debug("jsonresponse=={}", jsonresponse);
					response.getWriter().print(jsonresponse);
				}
			}
			long endTime = System.currentTimeMillis();
		} catch (JSONException e) {
			LOG.error("Json Exception " + e.getMessage(), e);
		} catch (LoginException e) {
			LOG.error("LoginException " + e.getMessage(), e);
		}
	}

}
