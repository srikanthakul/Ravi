package com.brunswick.ecomm.merclink.core.models;

import java.util.List;
import java.util.Map;

import org.apache.sling.api.resource.Resource;

public interface NewsSection {
	
	
	String getCurrentNewsShipingLink();
	String getPaNewsShipingLink();
	String getServiceNewsShipingLink();
	String getSaleNewsShipingLink();
	
	List<Map<String,String>> getNewsSectionDetails();
	List<Map<String,String>> getPaNewsSectionDetails();
	List<Map<String,String>> getServiceNewsSectionDetails();
	List<Map<String,String>> getSaleNewsSectionDetails();
}
