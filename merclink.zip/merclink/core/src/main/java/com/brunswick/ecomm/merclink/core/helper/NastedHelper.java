package com.brunswick.ecomm.merclink.core.helper;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;

public class NastedHelper {
      private String childUserTxt;
      private String childUserPath;
      
      public NastedHelper(Resource resource) {
    	  if(resource.getValueMap().get("childusertxt",String.class) != null) {
				this.childUserTxt = resource.getValueMap().get("childusertxt", String.class);
			}
    	  if(resource.getValueMap().get("childuserpath",String.class) != null) {
				this.childUserPath = resource.getValueMap().get("childuserpath", String.class);
			}
      }
      
      public String getChildUserTxt() {
    	  return childUserTxt;
      }
      
      public String getChildUserPath() {
    	  return childUserPath;
      }
}
