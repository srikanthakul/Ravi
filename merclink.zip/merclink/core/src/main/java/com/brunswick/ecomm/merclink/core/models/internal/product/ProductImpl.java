package com.brunswick.ecomm.merclink.core.models.internal.product;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.servlet.http.Cookie;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.xss.XSSAPI;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.core.components.services.urls.UrlProvider;
import com.adobe.cq.commerce.magento.graphql.BundleProduct;
import com.adobe.cq.commerce.magento.graphql.ComplexTextValue;
import com.adobe.cq.commerce.magento.graphql.ConfigurableAttributeOption;
import com.adobe.cq.commerce.magento.graphql.ConfigurableProduct;
import com.adobe.cq.commerce.magento.graphql.ConfigurableProductOptions;
import com.adobe.cq.commerce.magento.graphql.ConfigurableProductOptionsValues;
import com.adobe.cq.commerce.magento.graphql.ConfigurableVariant;
import com.adobe.cq.commerce.magento.graphql.GroupedProduct;
import com.adobe.cq.commerce.magento.graphql.GroupedProductItem;
import com.adobe.cq.commerce.magento.graphql.MediaGalleryInterface;
import com.adobe.cq.commerce.magento.graphql.ProductImage;
import com.adobe.cq.commerce.magento.graphql.ProductInterface;
import com.adobe.cq.commerce.magento.graphql.ProductStockStatus;
import com.adobe.cq.commerce.magento.graphql.SimpleProduct;
import com.adobe.cq.commerce.magento.graphql.VirtualProduct;
import com.adobe.cq.sightly.SightlyWCMMode;
import com.adobe.cq.wcm.launches.utils.LaunchUtils;
import com.brunswick.ecomm.core.beans.product.PriceInventoryFilter;
import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.brunswick.ecomm.merclink.core.beans.PriceInventoryBean;
import com.brunswick.ecomm.merclink.core.beans.ProductAttachmentBean;
import com.brunswick.ecomm.merclink.core.beans.ProductInventoryBean;
import com.brunswick.ecomm.merclink.core.beans.ProductPricesBean;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.constants.MagentoAttributes;
import com.brunswick.ecomm.merclink.core.models.internal.common.PriceImpl;
import com.brunswick.ecomm.merclink.core.models.product.Asset;
import com.brunswick.ecomm.merclink.core.models.product.GroupItem;
import com.brunswick.ecomm.merclink.core.models.product.Product;
import com.brunswick.ecomm.merclink.core.models.product.Variant;
import com.brunswick.ecomm.merclink.core.models.product.VariantAttribute;
import com.brunswick.ecomm.merclink.core.models.product.VariantValue;
import com.brunswick.ecomm.merclink.core.models.product.common.Price;
import com.brunswick.ecomm.merclink.core.models.product.retriever.AbstractProductRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.designer.Style;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;

@Model(adaptables = SlingHttpServletRequest.class, adapters = Product.class, resourceType = ProductImpl.RESOURCE_TYPE)
public class ProductImpl implements Product {

	protected static final String RESOURCE_TYPE = MagentoAttributes.RESOURCE_TYPE;
	protected static final String PLACEHOLDER_DATA = MagentoAttributes.PLACEHOLDER_DATA;

	private static final Logger LOGGER = LoggerFactory.getLogger(ProductImpl.class);

	private static final boolean LOAD_CLIENT_PRICE_DEFAULT = true;

	@Self
	private SlingHttpServletRequest request;

	@Inject
	private Resource resource;

	@Inject
	private Page currentPage;

	@Inject
	private UrlProvider urlProvider;

	@Inject
	private APIGEEService apigeeService;

	@Inject
	private EcommSessionService adminService;

	@ScriptVariable
	private Style currentStyle;

	@ScriptVariable
	private ValueMap properties;

	@ScriptVariable(name = "wcmmode")
	private SightlyWCMMode wcmMode;

	@Inject
	private XSSAPI xssApi;

	@Inject
	private Externalizer externalizer;
	
	private Boolean configurable;
	private Boolean isGroupedProduct;
	private Boolean isVirtualProduct;
	private Boolean loadClientPrice;
	private String canonicalUrl;
	private Boolean isBundleProduct;

	private AbstractProductRetriever productRetriever;

	private PriceInventoryFilter priceInvFilterBean;

	private JsonObject priceInvResp;

	private Locale locale;
	
	private ProductInterface product;

	@PostConstruct
	private void initModel() {
		String identifier = request.getParameter("sku");
		if (StringUtils.isNotBlank(identifier)) {
			identifier = identifier.toUpperCase();
		}
		LOGGER.info(" Product identifier {}  ", identifier);
		Boolean isCustomerNumberPresent = false;
		String customerNumber = null;
		locale = currentPage.getLanguage(false);
		long startTime = System.currentTimeMillis();
		LOGGER.info(" PDP Request start time :{}", startTime);
		// Get MagentoGraphqlClient from the resource.
		MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(resource, currentPage, null, null);
		if (magentoGraphqlClient != null) {
			if (identifier != null && StringUtils.isNotBlank(identifier)) {
				try {
					// Check and retrieve customer number to make appropriate Magento call
					Cookie[] cookies = request.getCookies();

					if (cookies != null) {
						for (Cookie cookie : cookies) {
							if (cookie.getName().equals(MagentoAttributes.CUSTOMER_NUMBER)) {
								// Setting the customer number
								isCustomerNumberPresent = true;
								customerNumber = cookie.getValue();
							}
						}
					}
					String salesPoolId = getSalesPoolIdByTaxGroup();
					if (!isCustomerNumberPresent) {
						priceInvFilterBean = setPriceInventoryFilterBean(identifier, null, null, null, salesPoolId);
					} else
						priceInvFilterBean = setPriceInventoryFilterBean(identifier, customerNumber, null, "1",
								salesPoolId);
					priceInvResp = apigeeService.getProductInventoryPrice(priceInvFilterBean,
							currentPage.adaptTo(Resource.class), adminService.getWriteServiceResourceResolver());

					LOGGER.info(" Apigee Response : {}", new Gson().toJson(priceInvResp));
					productRetriever = new ProductRetriever(magentoGraphqlClient);
					productRetriever.setIdentifier(identifier);
					loadClientPrice = properties.get(PN_LOAD_CLIENT_PRICE,
							currentStyle.get(PN_LOAD_CLIENT_PRICE, LOAD_CLIENT_PRICE_DEFAULT));
					product = productRetriever.fetchProduct();
					LOGGER.info(" Magento Response : {}", new Gson().toJson(product));
				} catch (LoginException e) {
					LOGGER.error("LoginException :", e);
				}
			} else if (!wcmMode.isDisabled()) {
				// In AEM Sites editor, load some dummy placeholder data for the component.
				try {
					productRetriever = new ProductPlaceholderRetriever(magentoGraphqlClient, PLACEHOLDER_DATA);
				} catch (IOException e) {
					LOGGER.warn("Cannot use placeholder data", e);
				}
				loadClientPrice = false;
			}
		}
		long endTime = System.currentTimeMillis();
		LOGGER.info(" PDP Response end time :"+endTime+" Time difference b/w request and response of PDP Page : {}", (endTime-startTime));
		if (!wcmMode.isDisabled()) {
			canonicalUrl = externalizer.authorLink(resource.getResourceResolver(), request.getRequestURI());
		} else {
			canonicalUrl = externalizer.publishLink(resource.getResourceResolver(), request.getRequestURI());
		}
		LOGGER.info("End of initModel.");
	}

	private String getSalesPoolIdByTaxGroup() {
		String taxGroup = CommonUtil.getCustomerTaxGroupFromCookie(request);
		String salesPoolId="";
		if("Export".equalsIgnoreCase(taxGroup)) {
			salesPoolId = "SPE";
		} else {
			salesPoolId = "SP";
		}
		return salesPoolId;
	}

	private PriceInventoryFilter setPriceInventoryFilterBean(String itemNumber, String customerNumber,
			String customerPriceFlag, String quantity, String salesPoolId) {
		PriceInventoryFilter bean = new PriceInventoryFilter();
		bean.setItemNumber(itemNumber);
		if (null != customerNumber) {
			bean.setCustomerNumber(customerNumber);
		}
		if (null != customerPriceFlag) {
			bean.setCustomerPriceFlag(customerPriceFlag);
		}
		if (null != quantity) {
			bean.setQuantity(quantity);
		}
		if(StringUtils.isNotBlank(salesPoolId)) {
			bean.setSalesPoolId(salesPoolId);
		}
		return bean;
	}

	public ProductInventoryBean getInventory() {
		String json = new Gson().toJson(priceInvResp.getAsJsonObject(MagentoAttributes.DATA));
		LOGGER.info("getInventory  json : {}", json);
		PriceInventoryBean bean = new Gson().fromJson(json, PriceInventoryBean.class);
		LOGGER.info("getInventory  bean :{} ", bean.getInventory().getStatus().getMessage());
		return bean.getInventory();
	}

	public ProductPricesBean getTiredPrices() {

		String json = new Gson().toJson(priceInvResp.getAsJsonObject(MagentoAttributes.DATA));

		PriceInventoryBean bean = null;
		ObjectMapper mapper = new ObjectMapper();
		try {
			bean = mapper.readValue(json, PriceInventoryBean.class);

		} catch (JsonParseException e) {
			LOGGER.error("JsonParseException getTiredPrices", e);
		} catch (JsonMappingException e) {
			LOGGER.error("JsonMappingException getTiredPrices", e);
		} catch (IOException e) {
			LOGGER.error("IOException getTiredPrices", e);
		}
		LOGGER.info("Bean : {}", json);
		return bean.getPrices();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.brunswick.ecomm.delcity.core.models.product.Product#getProductAttachment(
	 * )
	 * 
	 * To print the documents tab on pdp page
	 * 
	 */

	// To retrieve product attachments shown in PDP documents tab
	@Override
	public List<ProductAttachmentBean> getProductAttachment() {
		List<ProductAttachmentBean> productAttachments = new ArrayList<>();
		try {
			JSONObject json = new JSONObject(product.get(MagentoAttributes.IMAGE_DATA).toString());
			JSONArray array = json.getJSONArray(MagentoAttributes.PRODUCTATTACHMENT);

			LOGGER.info("Size of the array json : {}", array.length());
			for (int i = 0; i < array.length(); i++) {
				ProductAttachmentBean p = new ProductAttachmentBean();
				p.setDescription(array.getJSONObject(i).getString(MagentoAttributes.DESCRIPTION));
				p.setAttachment(array.getJSONObject(i).getString(MagentoAttributes.ATTACHMENT).toString());
				p.setLabelName(array.getJSONObject(i).getString(MagentoAttributes.LABEL_NAME).toString());
				productAttachments.add(p);
			}

		} catch (JSONException e) {
			LOGGER.error("IOException getProductAttachment", e);
		}
		return productAttachments;
	}
	@Override
	public ArrayList<String> getLongDescriptionList() {
		ArrayList<String> longDescList = new ArrayList<>();
		String longDesc = StringUtils.EMPTY;
		for(int i = 0; i<=5 ; i++) {
			longDesc = i==0? MagentoAttributes.LONGDESCRIPTION : MagentoAttributes.LONGDESCRIPTION+i;
			if (product.get(longDesc) != null && !(product.get(longDesc) instanceof JsonNull)) 
				longDescList.add(product.get(longDesc).toString().replace(MagentoAttributes.ESCAPE_INVERT_COMMA, MagentoAttributes.EMPTY_STRING));
			
		}
		return longDescList;
	}
	
	@Override
	public ArrayList<String> getBuPartBulletList() {
		ArrayList<String> partStatusList = new ArrayList<>();
		String longDesc = StringUtils.EMPTY;
		for(int i = 0; i<=15 ; i++) {
			longDesc = i==0? MagentoAttributes.BU_PART_BULLET : MagentoAttributes.BU_PART_BULLET+i;
			if (product.get(longDesc) != null && !(product.get(longDesc) instanceof JsonNull)) 
				partStatusList.add(product.get(longDesc).toString().replace(MagentoAttributes.ESCAPE_INVERT_COMMA, MagentoAttributes.EMPTY_STRING));
			
		}
		return partStatusList;
	}
	// To retrieve product specifications shown in PDP tech specs tab
	@Override
	public Map<String, String> getProductSpecifications() {
		LOGGER.info("getProductSpecifications called");
		HashMap<String, String> hm = new HashMap<String, String>();
		try {
			JSONArray json = new JSONArray(product.get(MagentoAttributes.SPECIFICATIONS).toString());
			LOGGER.info("Size of the specifications json--->{}", json.length());
			for (int i = 0; i < json.length(); i++) {
				hm.put(json.getJSONObject(i).optString(MagentoAttributes.LABEL),
						json.getJSONObject(i).optString(MagentoAttributes.VALUE));
			}

		} catch (JSONException e) {
			LOGGER.error("Exception getProductSpecifiaction {}", e);
		}
		return hm;
	}

	// To retrieve product videos shown in PDP videos tab
	@Override
	public List<String> getProductVideos() {
		LOGGER.info("getProductVideos called");
		List<String> videos = new ArrayList<>();
		try {
			JSONObject json = new JSONObject(product.get(MagentoAttributes.IMAGE_DATA).toString());
			if (json.has(MagentoAttributes.VIDEOS)) {
				JSONArray array = json.getJSONArray(MagentoAttributes.VIDEOS);
				for (int i = 0; i < array.length(); i++) {
					videos.add(array.getJSONObject(i).optString(MagentoAttributes.VIDEO));
				}
			}
		} catch (JSONException e) {
			LOGGER.error("Exception getProductVideos", e);
		}
		return videos;
	}

	@Override
	public Boolean getFound() {
		boolean isFound = productRetriever != null && productRetriever.fetchProduct() != null;
		LOGGER.info("Is Product Found: {}", isFound);
		return isFound;
	}

	@Override
	public String getName() {
		return product.getName();
	}

	// To retrieve prop 65 message.
	@Override
	public String getProp65() {
		final String prop65 = MagentoAttributes.PROP65;
		if (product.get(prop65) != null && !(product.get(prop65) instanceof JsonNull))
			return product.get(prop65).toString().replace(MagentoAttributes.ESCAPE_INVERT_COMMA,
					MagentoAttributes.EMPTY_STRING);
		return null;
	}

	// To retrieve brand for the product
	@Override
	public String getBrand() {
		final String brandName = MagentoAttributes.BRAND;
		if (product.get(brandName) != null && !(product.get(brandName) instanceof JsonNull))
			return product.get(brandName).toString().replace(MagentoAttributes.ESCAPE_INVERT_COMMA,
					MagentoAttributes.EMPTY_STRING);
		return "-";
	}

	// To retrieve minimum selling quantity for the product
	@Override
	public String getMasterPartLowestSellinguomqty() {
		String minQty = MagentoAttributes.BUNDLED_QUANTITY;
		if (product.get(minQty) instanceof JsonNull || product.get(minQty).toString().replace("\"", "").equals("0")) {
			return "1";
		}
		return product.get(minQty).toString().replace(MagentoAttributes.ESCAPE_INVERT_COMMA,
				MagentoAttributes.EMPTY_STRING);
	}

	// To retrieve image set for the product
	@Override
	public String getProductImage() {
		String pdpImage  = null;
        try {
            JSONObject json = new JSONObject(product.get(MagentoAttributes.IMAGE_DATA).toString());
			LOGGER.info("getProductImageSet {}", json);
            if(null != json) {
                pdpImage  = json.optString(MagentoAttributes.IMAGE_SET_CUSTOM); 
                LOGGER.info("getProductImage {}", pdpImage);
                if (StringUtils.isNotBlank(pdpImage))
                    return pdpImage.replace(MagentoAttributes.ESCAPE_INVERT_COMMA,
                            MagentoAttributes.EMPTY_STRING);
            }
        } catch (JSONException e) {
            LOGGER.error("IOException getProductImage", e);
        }
        return pdpImage;
	}

	@Override
	public String getDescription() {
		String longDesc = MagentoAttributes.LONGDESCRIPTION;
		if (product.get(longDesc) != null && !(product.get(longDesc) instanceof JsonNull))
			return product.get(longDesc).toString().replace(MagentoAttributes.ESCAPE_INVERT_COMMA,
					MagentoAttributes.EMPTY_STRING);

		return null;
	}

	@Override
	public String getSku() {
		return product.getSku();
	}

	@Override
	public String getCurrency() {
		return getPriceRange().getCurrency();
	}

	@Override
	public Double getPrice() {
		return getPriceRange().getFinalPrice();
	}

	@Override
	public Price getPriceRange() {
		return new PriceImpl(product.getPriceRange(), locale);
	}

	@Override
	public Boolean getInStock() {
		return ProductStockStatus.IN_STOCK.equals(product.getStockStatus());
	}

	@Override
	public Boolean isConfigurable() {
		if (configurable == null) {
			configurable = productRetriever != null && product instanceof ConfigurableProduct;
		}
		return configurable;
	}

	@Override
	public Boolean isGroupedProduct() {
		if (isGroupedProduct == null) {
			isGroupedProduct = productRetriever != null && product instanceof GroupedProduct;
		}
		return isGroupedProduct;
	}

	@Override
	public Boolean isVirtualProduct() {
		if (isVirtualProduct == null) {
			isVirtualProduct = productRetriever != null && product instanceof VirtualProduct;
		}
		return isVirtualProduct;
	}

	@Override
	public String getVariantsJson() {
		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.writeValueAsString(getVariants());
		} catch (JsonProcessingException e) {
			LOGGER.warn("Could not serialize product variants");
			return "[]";
		}
	}

	@Override
	public List<Variant> getVariants() {
		// Don't return any variants if the current product is not of type
		// ConfigurableProduct.
		if (!isConfigurable()) {
			return Collections.emptyList();
		}
		ConfigurableProduct product = (ConfigurableProduct) productRetriever.fetchProduct();

		return product.getVariants().parallelStream().map(this::mapVariant).collect(Collectors.toList());
	}

	@Override
	public List<GroupItem> getGroupedProductItems() {
		// Don't return any items if the current product is not of type GroupedProduct.
		if (!isGroupedProduct()) {
			return Collections.emptyList();
		}
		GroupedProduct product = (GroupedProduct) productRetriever.fetchProduct();

		return product.getItems().parallelStream().sorted(Comparator.comparing(GroupedProductItem::getPosition))
				.map(this::mapGroupedProductItem).collect(Collectors.toList());
	}

	@Override
	public Boolean isBundleProduct() {
		if (isBundleProduct == null) {
			isBundleProduct = productRetriever != null && product instanceof BundleProduct;
		}
		return isBundleProduct;
	}

	@Override
	public List<Asset> getAssets() {
		return filterAndSortAssets(product.getMediaGallery());
	}

	@Override
	public String getAssetsJson() {
		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.writeValueAsString(getAssets());
		} catch (JsonProcessingException e) {
			LOGGER.error(e.getMessage(), e);
			return "";
		}
	}

	@Override
	public List<VariantAttribute> getVariantAttributes() {
		// Don't return any variant selection properties if the current product is not
		// of type ConfigurableProduct.
		if (!isConfigurable()) {
			return Collections.emptyList();
		}

		ConfigurableProduct product = (ConfigurableProduct) productRetriever.fetchProduct();

		List<VariantAttribute> optionList = new ArrayList<>();
		for (ConfigurableProductOptions option : product.getConfigurableOptions()) {
			optionList.add(mapVariantAttribute(option));
		}

		return optionList;
	}

	@Override
	public Boolean loadClientPrice() {
		return loadClientPrice && !LaunchUtils.isLaunchBasedPath(currentPage.getPath());
	}

	@Override
	public AbstractProductRetriever getProductRetriever() {
		return productRetriever;
	}

	/* --- Mapping methods --- */
	private Variant mapVariant(ConfigurableVariant variant) {
		SimpleProduct product = variant.getProduct();

		VariantImpl productVariant = new VariantImpl();
		productVariant.setName(product.getName());
		productVariant.setDescription(safeDescription(product));
		productVariant.setSku(product.getSku());
		productVariant.setColor(product.getColor());
		productVariant.setPriceRange(new PriceImpl(product.getPriceRange(), locale));
		productVariant.setInStock(ProductStockStatus.IN_STOCK.equals(product.getStockStatus()));

		// Map variant attributes
		for (ConfigurableAttributeOption option : variant.getAttributes()) {
			productVariant.getVariantAttributes().put(option.getCode(), option.getValueIndex());
		}

		List<Asset> assets = filterAndSortAssets(product.getMediaGallery());
		productVariant.setAssets(assets);

		return productVariant;
	}

	private GroupItem mapGroupedProductItem(com.adobe.cq.commerce.magento.graphql.GroupedProductItem item) {
		ProductInterface product = item.getProduct();

		GroupItemImpl groupedProductItem = new GroupItemImpl();
		groupedProductItem.setName(product.getName());
		groupedProductItem.setSku(product.getSku());
		groupedProductItem.setPriceRange(new PriceImpl(product.getPriceRange(), locale));
		groupedProductItem.setDefaultQuantity(item.getQty());
		groupedProductItem.setVirtualProduct(product instanceof VirtualProduct);

		return groupedProductItem;
	}

	private List<Asset> filterAndSortAssets(List<MediaGalleryInterface> assets) {
		return assets == null ? Collections.emptyList()
				: assets.parallelStream()
						.filter(a -> (a.getDisabled() == null || !a.getDisabled()) && a instanceof ProductImage)
						.map(this::mapAsset)
						.sorted(Comparator
								.comparing(a -> a.getPosition() == null ? Integer.MAX_VALUE : a.getPosition()))
						.collect(Collectors.toList());
	}

	private Asset mapAsset(MediaGalleryInterface entry) {
		AssetImpl asset = new AssetImpl();
		asset.setLabel(entry.getLabel());
		asset.setPosition(entry.getPosition());
		asset.setType((entry instanceof ProductImage) ? "image" : "video");
		asset.setPath(entry.getUrl());

		return asset;
	}

	private VariantValue mapVariantValue(ConfigurableProductOptionsValues value) {
		VariantValueImpl variantValue = new VariantValueImpl();
		variantValue.setId(value.getValueIndex());
		variantValue.setLabel(value.getLabel());

		return variantValue;
	}

	private VariantAttribute mapVariantAttribute(ConfigurableProductOptions option) {
		// Get list of values
		List<VariantValue> values = option.getValues().parallelStream().map(this::mapVariantValue)
				.collect(Collectors.toList());

		// Create attribute map
		VariantAttributeImpl attribute = new VariantAttributeImpl();
		attribute.setLabel(option.getLabel());
		attribute.setId(option.getAttributeCode());
		attribute.setValues(values);

		return attribute;
	}

	private String safeDescription(ProductInterface product) {
		ComplexTextValue description = product.getDescription();
		if (description == null) {
			return null;
		}

		// Filter HTML
		return xssApi.filterHTML(description.getHtml());
	}

	@Override
	public String getMetaDescription() {
		return product.getMetaDescription();
	}

	@Override
	public String getMetaKeywords() {
		return product.getMetaKeyword();
	}

	@Override
	public String getMetaTitle() {
		return StringUtils.defaultString(product.getMetaTitle(), getName());
	}

	@Override
	public String getCanonicalUrl() {
		return canonicalUrl;
	}

	@Override
	public String getFormattedPrice() {
		return getPriceRange().getFormattedFinalPrice();
	}

	@Override
	public String getBuPartStatus() {
		String itemStatus = MagentoAttributes.ITEM_STATUS;
		if (product.get(itemStatus) != null && !(product.get(itemStatus) instanceof JsonNull))
			return product.get(itemStatus).toString().replace(MagentoAttributes.ESCAPE_INVERT_COMMA,
					MagentoAttributes.EMPTY_STRING);

		return "-";
	}

	@Override
	public String getWeight() {
		String weight = MagentoAttributes.MP_PKG_EA_WEIGHT_METRIC;
		if (product.get(weight) != null && !(product.get(weight) instanceof JsonNull))
			return product.get(weight).toString().replace(MagentoAttributes.ESCAPE_INVERT_COMMA,
					MagentoAttributes.EMPTY_STRING);

		return null;
	}

	@Override
	public String getSsToItem() {
		String ssItemNumber = MagentoAttributes.BU_SS_TO_PART;
		if (product.get(ssItemNumber) != null && !(product.get(ssItemNumber) instanceof JsonNull))
			return product.get(ssItemNumber).toString().replace(MagentoAttributes.ESCAPE_INVERT_COMMA,
					MagentoAttributes.EMPTY_STRING);

		return null;
	}

	@Override
	public String getHazardousCode() {
		String hazardousCode = MagentoAttributes.MP_HAZARDOUS_MATERIAL;
		if (product.get(hazardousCode) != null && !(product.get(hazardousCode) instanceof JsonNull))
			return product.get(hazardousCode).toString().replace(MagentoAttributes.ESCAPE_INVERT_COMMA,
					MagentoAttributes.EMPTY_STRING);
		return null;
	}

	@Override
	public String getWeightUom() {
		String weightUom = MagentoAttributes.MP_PKG_EA_WEIGHT_UOM_METRIC;
		if (product.get(weightUom) != null && !(product.get(weightUom) instanceof JsonNull))
			return product.get(weightUom).toString().replace(MagentoAttributes.ESCAPE_INVERT_COMMA,
					MagentoAttributes.EMPTY_STRING);

		return null;
	}

}
