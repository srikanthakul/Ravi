package com.brunswick.ecomm.merclink.core.models.cart.retriever;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Cart;
import com.adobe.cq.commerce.magento.graphql.CartItemInterface;
import com.adobe.cq.commerce.magento.graphql.CartQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Operations;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractCustomRetriever;

public abstract class AbstractCartRetriever extends AbstractCustomRetriever {

	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractCartRetriever.class);
	protected String cartId;
	protected boolean loggedIn = false;
	protected Collection<CartItemInterface> cartItems;
	protected Cart cart;
	protected String errorMessage;
	List<Error> errors = new ArrayList<Error>();
	

	public String getErrorMessage() {
		return errorMessage;
	}

	protected AbstractCartRetriever(MagentoGraphqlClient client) {
		super(client);
	}

	public void setLoggedIn(boolean loggedIn) {
		this.loggedIn = loggedIn;
	}

	public boolean isLoggedIn() {
		return loggedIn;
	}

	public void setCartId(String cartId) {
		this.cartId = cartId;
	}

	protected GraphqlResponse<Query, Error> executeQuery() {
		if (query == null || query.equals("")) {
			query = generateQuery(cartId);
		}
		LOGGER.info("query :----------------------------" + query);
		return client.execute(query);
	}

	protected GraphqlResponse<Mutation, Error> executeMutation() {
		return client.executeMutation(query);
	}

	protected String generateQuery(String identifier) {
		LOGGER.info("identifier value is {} ", identifier);
		CartQueryDefinition queryArgs = generateCartQuery();
		if (loggedIn) {
			LOGGER.info("loggedIn -- generateQuery");
			return Operations.query(query -> query.customerCart(queryArgs)).toString();
		} else {
			LOGGER.info("loggedIn else part generateQuery");
			return Operations.query(query -> query.cart(identifier, queryArgs)).toString();
		}

	}

	public String createEmptyCart() {
		query = createEmptyCartDefinition();
		GraphqlResponse<Mutation, Error> response = executeMutation();
		query = "";
		Mutation queryResponse = response.getData();
		return queryResponse.getCreateEmptyCart();
	}

	private String createEmptyCartDefinition() {
		return Operations.mutation(mutation -> mutation.createEmptyCart()).toString();
	}

//    abstract protected CreateEmptyCartArgumentsDefinition generateCartArgsQuery();

	@Override
	protected void populate() {
		// Get product list from response
		GraphqlResponse<Query, Error> response = executeQuery();
		LOGGER.info("response under populate" + response);
		if (response != null) {
			Query rootQuery = response.getData();
			if (response.getData() != null
					&& (response.getData().getCustomerCart() != null || response.getData().getCart() != null)) {
				if (loggedIn) {
					LOGGER.info("response under populate logged in user cart");
					cart = rootQuery.getCustomerCart();
				} else {
					LOGGER.info("response under populate Non logged in user cart");
					cart = rootQuery.getCart();
				}
			} else {
				LOGGER.info("response under populate Errors");
				for (Error err:response.getErrors() ) {
					this.errorMessage = err.getMessage();
				}
			}
		}
	}

	public Cart fetchCart() {
		if (this.cart == null) {
			populate();
		}
		return this.cart;
	}

	public List<Error> fetchError() {

		return new ArrayList<>(this.errors);
	}

	protected abstract CartQueryDefinition generateCartQuery();

}
