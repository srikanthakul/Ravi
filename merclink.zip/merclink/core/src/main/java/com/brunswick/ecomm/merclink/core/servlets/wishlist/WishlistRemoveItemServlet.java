package com.brunswick.ecomm.merclink.core.servlets.wishlist;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractWishlistDetailsRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;
import com.shopify.graphql.support.ID;

@Component(service = Servlet.class, property = { "sling.servlet.methods=POST",
		"sling.servlet.paths=/bin/removeMercWishlistItemServlet" })
public class WishlistRemoveItemServlet extends SlingAllMethodsServlet {

	private static final Logger LOG = LoggerFactory.getLogger(WishlistRemoveItemServlet.class);
	private static final long serialVersionUID = 1L;
	private transient AbstractWishlistDetailsRetriever wishlistRetriever;
	private List<ID> wishlistItemIds;
	ID wishlistId;
	String currentPagePath;

	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.info("inside");
		JSONObject requestObj;
		try {
			PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
			requestObj = new JSONObject(request.getParameter("data"));
			wishlistItemIds = new ArrayList<>();
			String itemIdArray[] = requestObj.get("ItemsList").toString().split(",");
			for (String itemId : itemIdArray) {
				wishlistItemIds.add(new ID(itemId));
			}
			currentPagePath = requestObj.get("resourcePath").toString();
			String token = CommonUtil.getTokenFromCookie("customerToken", request);
			Resource res = request.getResourceResolver().resolve(currentPagePath);
			
			wishlistId = new ID(requestObj.get("wishlistId").toString());
			List<Header> headers = new ArrayList<>();
			headers.add(new BasicHeader("Authorization",
					"Bearer " +token));
			MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(res,
					pageManager.getPage(res.getPath()), request, headers);
			wishlistRetriever = new AbstractWishlistDetailsRetriever(magentoGraphqlClient);
			if(wishlistRetriever!=null) {
				String id = wishlistRetriever.removeWishlistItem(wishlistId, wishlistItemIds);
				response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
				response.setContentType("text/plain");
				response.getWriter().print(id);
			}
		} catch (JSONException e) {
			LOG.error("Json Exception "+e.getMessage());

		}
		catch (RuntimeException e) {
			LOG.error("RunTime Exception {}", e.getMessage());
		}
	}

}
