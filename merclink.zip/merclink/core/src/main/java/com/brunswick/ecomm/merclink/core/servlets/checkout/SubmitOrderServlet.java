package com.brunswick.ecomm.merclink.core.servlets.checkout;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.CyberSourceService;
import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.EcommTokenService;
import com.brunswick.ecomm.merclink.core.beans.checkout.SubmitOrderBean;
import com.brunswick.ecomm.merclink.core.beans.personalinformation.UpdateCompany;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractCheckoutRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonObject;


@Component(service = Servlet.class, property = { "sling.servlet.methods=POST",
"sling.servlet.paths=/bin/merclink/submitOrderServlet" })

public class SubmitOrderServlet extends SlingAllMethodsServlet{

	private static final Logger LOG = LoggerFactory.getLogger(SubmitOrderServlet.class);
	private static final long serialVersionUID = 1L;
	private transient AbstractCheckoutRetriever checkoutretriever;
	String currentPagePath;
	@Reference
	EcommTokenService tokenService;

	@Reference
	EcommSessionService sessionService;

	@Reference
	transient CyberSourceService cyberSourceService;

	transient UpdateCompany updatecustomerPersonalInfo;
	
	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {

		LOG.debug("Entering into doPost() Method.");
		JSONObject requestObj;
		try {
			requestObj = new JSONObject(request.getParameter("data"));
			SubmitOrderBean submitorder = new Gson().fromJson(request.getParameter("data"), SubmitOrderBean.class);
             LOG.info("requestObj=====================" + requestObj );
			currentPagePath = requestObj.get("componentPath").toString();

			 
			MagentoGraphqlClient magentoGraphqlClient = CommonUtil.getMagentoGraphqlClient(request, currentPagePath);
			checkoutretriever = new AbstractCheckoutRetriever(magentoGraphqlClient);
			JsonObject resp = null;
			if (checkoutretriever != null) {
				resp = checkoutretriever.submitOrder(submitorder);
			}
			if (resp != null) {
				LOG.info("Response=====================" + new Gson().toJson(resp) );
				response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
				response.setContentType("application/json");
				response.getWriter().print(new Gson().toJson(resp));
			}
			
		} catch (JSONException e) {
			LOG.error("Json Exception " + e.getMessage(),e);
		} catch (RuntimeException e) {
			LOG.error("RunTime Exception {}", e.getMessage(),e);
		}
		
		LOG.debug("Exit from doPost() Method.");
	
		
	}

	
}
