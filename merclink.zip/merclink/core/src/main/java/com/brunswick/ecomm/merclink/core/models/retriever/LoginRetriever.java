package com.brunswick.ecomm.merclink.core.models.retriever;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.CartItemInterfaceQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.CartQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.CustomerQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.GenerateCustomerTokenAsAdminInput;
import com.adobe.cq.commerce.magento.graphql.GenerateCustomerTokenAsAdminOutput;
import com.adobe.cq.commerce.magento.graphql.GenerateCustomerTokenAsAdminOutputQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Operations;
import com.adobe.cq.commerce.magento.graphql.ProductInterfaceQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.QueryQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

public class LoginRetriever extends AbstractCustomRetriever {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginRetriever.class);

	public LoginRetriever(MagentoGraphqlClient client) {
		super(client);
	}

	@Override
	protected void populate() {

	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return client.execute(query);
	}

	private GraphqlResponse<Mutation, Error> executeMutation() {
		return client.executeMutation(query);
	}

	public String generateCustomerToken(String emailId) {
		query = generateCustomerTokenDefinition(emailId);
		LOGGER.info("customer token query" + query);
		GraphqlResponse<Mutation, Error> response = executeMutation();
		LOGGER.info("customer token query response" + response);
		List<Error> errors = response.getErrors();
		if (errors != null) {
			for (Error error : errors) {
				LOGGER.info("error message token===" + error.getMessage());

			}
		}
		Mutation queryResponse = response.getData();
		LOGGER.info("customer token query response1" + queryResponse);
		GenerateCustomerTokenAsAdminOutput token = queryResponse.getGenerateCustomerTokenAsAdmin();
		LOGGER.info("customer token query token" + token);
		if (token != null) {
			LOGGER.info("customer token query token1" + token.getCustomerToken());
			return token.getCustomerToken();

		}
		return null;

	}

	private String generateCustomerTokenDefinition(String emailId) {
		GenerateCustomerTokenAsAdminInput input = new GenerateCustomerTokenAsAdminInput(emailId);
		GenerateCustomerTokenAsAdminOutputQueryDefinition queryDef = i -> i.customerToken();
		return Operations.mutation(mutation -> mutation.generateCustomerTokenAsAdmin(input, queryDef)).toString();
	}

	public String getCustomerCart() {
		query = generateCustomerCartQuery();
		LOGGER.info("Query in cart :" + query);
		GraphqlResponse<Query, Error> response = executeQuery();
		LOGGER.info("customer cart query response" + response);
		List<Error> errors = response.getErrors();
		if (errors != null) {
			for (Error error : errors) {
				LOGGER.info("error message customer cart===" + error.getMessage());
				return error.getMessage();
			}
			
		}
		Query queryResponse = response.getData();
		return queryResponse.getCustomerCart().getId().toString();
	}

	private String generateCustomerCartQuery() {
		ProductInterfaceQueryDefinition product = p -> p.name().sku();
		CartItemInterfaceQueryDefinition query = q -> q.uid().quantity().product(product);
		CartQueryDefinition cartdef = de -> de.id() .items(query);
		QueryQueryDefinition def = d -> d.customerCart(cartdef);
		return Operations.query(def).toString();
	}

}
