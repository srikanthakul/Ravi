package com.brunswick.ecomm.merclink.core.servlets.wishlist;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.http.Cookie;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Wishlist;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.constants.MagentoAttributes;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractWishlistDetailsRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@Component(service = Servlet.class, property = { "sling.servlet.methods=GET",
		"sling.servlet.paths=/bin/getMercCustomerWishlists" })
public class GetCustomerWishlists extends SlingAllMethodsServlet {

	private static final Logger LOG = LoggerFactory.getLogger(GetCustomerWishlists.class);
	private static final long serialVersionUID = 1L;
	private transient AbstractWishlistDetailsRetriever wishlistRetriever;
	String currentPagePath;

	@Override
	public void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.debug("Entering into doPost() Method.");
		JSONObject requestObj;
		PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
		try {
			requestObj = new JSONObject(request.getParameter("data"));
			currentPagePath = requestObj.get("resourcePath").toString();

			Resource res = request.getResourceResolver().resolve(request, currentPagePath);
			List<Header> headers = new ArrayList<>();
			String token = CommonUtil.getTokenFromCookie("customerToken", request);
			String pageSize = requestObj.get("pageSize").toString().replaceAll("\"", "");
			Cookie[] cookies = request.getCookies();
			String companyNumber = null;
			if (cookies != null) {
				for (Cookie cookie : cookies) {
					if (cookie.getName().equals(MagentoAttributes.CUSTOMER_NUMBER)) {
						// Setting the customer number
						companyNumber = cookie.getValue();
					}
				}
			}
			String page = requestObj.get("currentPage").toString().replaceAll("\"", "");
			headers.add(new BasicHeader("Authorization", "Bearer " + token));
			MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(res,
					pageManager.getPage(res.getPath()), request, headers);
			wishlistRetriever = new AbstractWishlistDetailsRetriever(magentoGraphqlClient);
			JsonObject customerWishlist = null;
			if (wishlistRetriever != null) {
				customerWishlist = wishlistRetriever.getCustomerWishlist(pageSize, page, companyNumber);
			}
			response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
			response.setContentType("application/json");
			response.getWriter().print(customerWishlist);
		} catch (JSONException e) {
			LOG.error("Json Exception " + e.getMessage());
		} catch (RuntimeException e) {
			LOG.error("RunTime Exception {}", e.getMessage());
		}
		LOG.debug("Exit from doPost() Method.");
	}

}
