package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;

import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "= CPQ Redirection Servlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_POST,
		"sling.servlet.paths=" + "/bin/merclink/cpqRedirection" })
public class CpqRedirectionServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	@Reference
	transient EcommSessionService adminService;
	@Reference
	transient APIGEEService apigeeService;
	private static final Logger LOG = LoggerFactory.getLogger(CpqRedirectionServlet.class);

	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.debug("inside do post Merclink CPQ Redirection");
		ResourceResolver resourceResolver = null;
		JSONObject cpqData = null;
		try {
			resourceResolver = adminService.getWriteServiceResourceResolver();
			response.setContentType("application/json");
			LOG.info("inside CPQ Redirection of do get");
			JSONObject data = new JSONObject(request.getParameter("data"));
			String customerEmail = data.getString("customerEmail");
			String currentPage = data.getString("resourcePath");
			LOG.info("customerEmail===> ",customerEmail);
			Resource res = request.getResourceResolver().resolve(currentPage);
			PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
			
			String storeCode = CommonUtil.getMagentoStoreCode(res, pageManager.getPage(res.getPath()));
			String customerToken = CommonUtil.getTokenFromCookie("customerToken", request);
			
			
			Resource currentPageRes = resourceResolver.getResource((resourceResolver.resolve(currentPage).getPath()));
			cpqData = apigeeService.getCpqUrl(customerEmail, storeCode,customerToken,
						currentPageRes, adminService.getWriteServiceResourceResolver());
			
			LOG.debug("cpqData::: {}", cpqData);
			response.getWriter().println(cpqData);
		} catch (LoginException | JSONException e) {
			LOG.error("JSON/Login exception occurred %f", e);
		} finally {
			adminService.closeResourceResolver(resourceResolver);
		}
	}
}
