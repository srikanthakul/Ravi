package com.brunswick.ecomm.merclink.core.helper;

import org.apache.sling.api.resource.Resource;

public class subNastedHelper {
	  private String subMenuTxt;
	    private String subMenuPath;
	    private String SPrmsnCode;
	    private String analyticsTxt;
	public subNastedHelper(Resource resource) {

	  	  if(resource.getValueMap().get("submenutxt",String.class) != null) {
					this.subMenuTxt = resource.getValueMap().get("submenutxt", String.class);
				}
	  	  if(resource.getValueMap().get("submenupath",String.class) != null) {
					this.subMenuPath = resource.getValueMap().get("submenupath", String.class);
				}
	  	 if(resource.getValueMap().get("sPrmsnCode",String.class) != null) {
				this.SPrmsnCode = resource.getValueMap().get("sPrmsnCode", String.class);
			}
	  	if(resource.getValueMap().get("analyticstxt",String.class) != null) {
			this.analyticsTxt = resource.getValueMap().get("analyticstxt", String.class);
		}
	    
	
	}
	public String getSubMenuTxt() {
		return subMenuTxt;
	}
	public String getSubMenuPath() {
		return subMenuPath;
	}
	public String getSPrmsnCode() {
			return SPrmsnCode;
	}
	public String getAnalyticsTxt() {
		return analyticsTxt;
	}
	
	
	
	

}
