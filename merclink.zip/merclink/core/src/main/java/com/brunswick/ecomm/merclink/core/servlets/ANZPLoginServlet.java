package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.opensaml.saml2.core.AuthnRequest;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.constants.CommonConstants;
import com.brunswick.ecomm.core.services.ANZPEcommSAMLService;
import com.brunswick.ecomm.core.util.AuthenticationRequestUtil;

@Component(service = Servlet.class, property = {
        Constants.SERVICE_DESCRIPTION + "=Login Servlet",
        "sling.servlet.methods="+HttpConstants.METHOD_POST, "sling.servlet.paths="
        + "/bin/anzploginServlet"
})
public class ANZPLoginServlet extends SlingAllMethodsServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1709847442756706556L;
	private static final Logger LOGGER = LoggerFactory.getLogger(ANZPLoginServlet.class);
	
	@Reference
	transient ANZPEcommSAMLService samlService;
	String federationResponseUrl = StringUtils.EMPTY;
	
	@Override
    public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		
		LOGGER.debug("Entering into Merclink doPost() method.");
		boolean external = true;
		response.setContentType("text/html");
		federationResponseUrl = request.getParameter("resourcePath");
		
		if(null != federationResponseUrl) {
			federationResponseUrl = federationResponseUrl + ".html";
		} else {
			federationResponseUrl = CommonConstants.ANZP_HOME_PAGE;
		}
		request.getSession().setAttribute("currentPage", federationResponseUrl);
		doAuthenticationRedirect(request,response, external,CommonConstants.ANZP_RESPONSE_SERVLET,samlService.getEntityId(),samlService.getIdpUrl());
		LOGGER.debug("Exit from Merclink doPost() method.");
		
	}

	private void doAuthenticationRedirect(SlingHttpServletRequest request, SlingHttpServletResponse response,
			boolean external, String responseUrl, String entityId, String idpUrl) {
		
		final AuthenticationRequestUtil authRequestUtil = new AuthenticationRequestUtil();
		HttpServletResponse httpResponse = response;
		HttpServletRequest httpRequest = request;

		final AuthnRequest authnRequest = authRequestUtil.generateAuthnRequest(httpRequest, external,responseUrl ,true,entityId,idpUrl);
		
		authRequestUtil.executeSAMLRequest(httpResponse, authnRequest,
				federationResponseUrl,samlService.getIdpUrl());
	}

}
