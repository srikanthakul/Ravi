package com.brunswick.ecomm.merclink.core.models.retriever;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.google.gson.JsonObject;

import java.util.List;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AbstractBulkOrderRetriever extends AbstractCustomRetriever {
	Customer customer;
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractBulkOrderRetriever.class);
	private String query;

	enum User {
		ACTIVE
	}

	public AbstractBulkOrderRetriever(MagentoGraphqlClient client) {
		super(client);

	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return client.execute(query);
	}

	protected GraphqlResponse<JsonObject, Error> excecuteQueryGraphql() {
		return client.executeQuery(query);
	}

	protected GraphqlResponse<Mutation, Error> executeMutation() {
		return client.executeMutation(query);
	}

	protected GraphqlResponse<JsonObject, Error> excecuteJsonMutation() {
		return client.executeJsonMutation(query);
	}

	@Override
	protected void populate() {
		// Nothing to do
	}

	/**
	 * creating query and return .
	 */
	public JsonObject placeBulkOrderSingleItem(String cart_id, String po_number, String order_comment,
			String requested_ship_date, String payment_method, String shipping_method, String attribute19, String shipping_cost,
			String is_dropship, String items_data) {
		try {
			query = generateplaceBulkOrderSingleItemQuery(cart_id, po_number, order_comment, requested_ship_date,
					payment_method, shipping_method, shipping_cost, attribute19, is_dropship, items_data);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" placeBulkOrderSingleItem==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  placeBulkOrderSingleItem  ==" + error.getMessage());
				errorjsonobject.addProperty("placeBulkOrderSingleItem", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" placeBulkOrderSingleItem ==" + response.getData());
		return response.getData();
	}

	/**
	 * creating query to change email.
	 */
	private String generateplaceBulkOrderSingleItemQuery(String cart_id, String po_number, String order_comment,
			String requested_ship_date, String payment_method, String shipping_method, String attribute19, String shipping_cost,
			String is_dropship, String items_data) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();

		_queryBuilder.append(" mutation ");
		_queryBuilder.append(" { ");
		_queryBuilder.append(" placeBulkOrder( ");
		_queryBuilder.append(" input:{ ");
		_queryBuilder.append(" cart_id:\"" + cart_id + "\"");
		_queryBuilder.append(" po_number:\"" + po_number + "\"");
		_queryBuilder.append(" order_comment:\"" + order_comment + "\" ");
		_queryBuilder.append(" requested_ship_date:\"" + requested_ship_date + "\" ");
		_queryBuilder.append(" payment_method:\"" + payment_method + "\" ");
		_queryBuilder.append(" shipping_method:\"" + shipping_method + "\" ");
		_queryBuilder.append(" shipping_cost:\"" + shipping_cost + "\" ");
		_queryBuilder.append(" attribute19:\"" + attribute19 + "\" ");
		_queryBuilder.append(" is_dropship:" + is_dropship);
		_queryBuilder.append(" items_data:" + items_data);
		_queryBuilder.append(" } ");
		_queryBuilder.append(" ){ ");
		_queryBuilder.append(" status ");
		_queryBuilder.append(" message ");
		_queryBuilder.append(" data{ ");
		_queryBuilder.append(" order_numer ");
		_queryBuilder.append(" created ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" errors{ ");
		_queryBuilder.append(" message ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		return _queryBuilder.toString();
	}

	/**
	 * creating query and return .
	 */
	public JsonObject createBulkCart(String companyNumber) {
		try {
			query = generatecreateBulkCartQuery(companyNumber);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" createBulkCart==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  createBulkCart  ==" + error.getMessage());
				errorjsonobject.addProperty("createBulkCart", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" createBulkCart ==" + response.getData());
		return response.getData();
	}

	/**
	 * creating query to change email.
	 */
	private String generatecreateBulkCartQuery(String companyNumber) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();

		_queryBuilder.append(" { ");
		_queryBuilder.append(" customerCart(company_customer_number: \"" + companyNumber + "\" is_bulk:true){ ");
		_queryBuilder.append(" id ");
		_queryBuilder.append(" erp_errors{ ");
		_queryBuilder.append(" message ");
		_queryBuilder.append(" code ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" } ");
		return _queryBuilder.toString();
	}
}