package com.brunswick.ecomm.merclink.core.models.internal.common;

import java.text.NumberFormat;
import java.util.Currency;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Utils {

    private static final Logger LOGGER = LoggerFactory.getLogger(Utils.class);

    /**
     * Builds a NumberFormat instance used for formatting prices based on the given
     * locale and currency code. If the given currency code is not valid in respect to
     * ISO 4217, the default currency for the given locale is used.
     *
     * @param locale Price locale
     * @param currencyCode Additional currency code
     * @return Price formatter
     */
    public static NumberFormat buildPriceFormatter(Locale locale, String currencyCode) {
        NumberFormat formatter = NumberFormat.getCurrencyInstance(locale);
        if (currencyCode == null) {
            return formatter;
        }

        // Try to overwrite with the given currencyCode, otherwise keep using default for locale
            Currency currency = Currency.getInstance(currencyCode);
            formatter.setCurrency(currency);

        return formatter;
    }
}
