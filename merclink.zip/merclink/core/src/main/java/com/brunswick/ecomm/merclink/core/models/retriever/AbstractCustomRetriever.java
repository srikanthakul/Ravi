package com.brunswick.ecomm.merclink.core.models.retriever;


import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
/**
 * Abstract implementation of retriever that fetches data using GraphQL.
 */
public abstract class AbstractCustomRetriever {

    /**
     * Generated or fully customized query.
     */
    protected String query;

    /**
     * Instance of the Magento GraphQL client.
     */
    protected MagentoGraphqlClient client;

    public AbstractCustomRetriever(MagentoGraphqlClient client) {
        if (client == null) {
            throw new java.lang.Error("No GraphQL client provided");
        }
        this.client = client;
    }

    /**
     * Replace the query with your own fully customized query.
     *
     * @param query GraphQL query
     */
    public void setQuery(String query) {
        this.query = query;
    }

    /**
     * Executes the query and parses the response.
     */
    abstract protected void populate();

    /**
     * Execute the GraphQL query with the GraphQL client.
     *
     * @return GraphqlResponse object
     */
    abstract protected GraphqlResponse<Query, Error> executeQuery();

}
