package com.brunswick.ecomm.merclink.core.beans;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.models.annotations.Optional;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerQuotedPriceBean {
	
//	@Optional
	@JsonProperty("listing_price")
	private Float listingPrice;
	
//	@Optional
	@JsonProperty("selling_price")
	private Float sellingPrice;
	
//	@Optional
	@JsonProperty("adjustments")
	private List<PriceAdjustmentsBean> adjustments;

	public Float getListingPrice() {
		return listingPrice;
	}

	public void setListingPrice(Float listingPrice) {
		this.listingPrice = listingPrice;
	}

	public Float getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(Float sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public List<PriceAdjustmentsBean> getAdjustments() {
		return new ArrayList<>(adjustments);
	}

	public void setAdjustments(List<PriceAdjustmentsBean> adjustments) {
		this.adjustments = new ArrayList<>(adjustments);
	}

	
	
}
