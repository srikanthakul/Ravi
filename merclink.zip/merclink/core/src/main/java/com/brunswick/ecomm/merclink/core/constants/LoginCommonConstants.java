package com.brunswick.ecomm.merclink.core.constants;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.DamConstants;
import com.day.cq.replication.ReplicationStatus;
import com.day.cq.tagging.TagConstants;
import com.day.cq.wcm.api.NameConstants;

public class LoginCommonConstants {

    /** The Constant PIPE. */
    public static final String PIPE = "\\|";
    public static final String SLASH_STRING = "/";

    /** The Constant TXT_EXTN. */
    public static final String TXT_EXTN = ".txt";

    /** The Constant HTML_EXTN. */
    public static final String HTML_EXTN = ".html";

    /** The Constant CONTENT_ROOT_PATH. */
    public static final String ASSET_CONTENT = "asset";
    
    /** The Constant COLON. */
	public static final String COLON = ":";
	
	/** The Constant for HYPHEN -*/
	public static final String HYPHEN = "-";
	
	/** The Constant HOMEPAGE. */
	public static final String HOMEPAGE = "home";

    /** The Constant WWW. */
    public static final String WWW = "www.";

    /** The Constant HTTP_SLASH. */
    public static final String HTTP_SLASH = "http://";

    /** The Constant UTF_8. */
    public static final String UTF_8 = "UTF-8";
    /**
     * The Constant The Constant JCR_DATA
     */
    public static final String JCR_DATA = JcrConstants.JCR_DATA;

    /** The Constant JCR_PRIMARY_TYPE. */
    public static final String JCR_PRIMARY_TYPE = JcrConstants.JCR_PRIMARYTYPE;

    /** The Constant JCR_DESC. */
    public static final String JCR_DESC = JcrConstants.JCR_DESCRIPTION;

    /** The Constant JCR_CONTENT. */
    public static final String JCR_CONTENT = JcrConstants.JCR_CONTENT;

    /** The Constant JCR_MODIFIED. */
    public static final String JCR_MODIFIED = JcrConstants.JCR_LASTMODIFIED;

    /** The Constant JCR_CREATED. */
    public static final String JCR_CREATED = JcrConstants.JCR_CREATED;

    /** The Constant CQ_LAST_REPLICATED. */
    public static final String CQ_LAST_REPLICATED = ReplicationStatus.NODE_PROPERTY_LAST_REPLICATED;

    /** The Constant DC_CREATOR. */
    public static final String DC_CREATOR = DamConstants.DC_CREATOR;

    /** The Constant DC_LANGUAGE. */
    public static final String DC_LANGUAGE = DamConstants.DC_LANGUAGE;

    /** The Constant DAM_SIZE. */
    public static final String DAM_SIZE = DamConstants.DAM_SIZE;

    /** The Constant DC_TITLE. */
    public static final String DC_TITLE = DamConstants.DC_TITLE;

    /** The Constant DC_DESCRIPTION. */
    public static final String DC_DESCRIPTION = DamConstants.DC_DESCRIPTION;

    /** The Constant DC_FORMAT. */
    public static final String DC_FORMAT = DamConstants.DC_FORMAT;

    /** The Constant CQ_TAGS. */
    public static final String CQ_TAGS = TagConstants.PN_TAGS;

    /**
     * The Constant The Constant JCR_LANGUAGE
     */
    public static final String JCR_LANGUAGE = JcrConstants.JCR_LANGUAGE;

    /** The Constant HOME_PAGE_PATH_PROP_NAME. */
    public static final String HOME_PAGE_PATH_PROP_NAME = "homePagePath";

    /** The Constant CLOUD_SERVICES. */
    public static final String CLOUD_SERVICES = com.day.cq.wcm.webservicesupport.ConfigurationConstants.PN_CONFIGURATIONS;

    /** The Constant REFERER_URL. */
    public static final String REFERER_URL = "referer";

    /** The Constant CONTENT_ROOT_PATH. */
    public static final String CONTENT_ROOT_PATH = "/content/";

    /** The Constant DAM_ROOT_PATH. */
    public static final String DAM_ROOT_PATH = "/content/dam/";

    /** The Constant COUNTRY_PAGE_DEPTH. */
    public static final int COUNTRY_PAGE_DEPTH = 4;

    /** The Constant LANGUAGE_PAGE_DEPTH. */
    public static final int LANGUAGE_PAGE_DEPTH = 5;

    /** The Constant LOCATION. */
    public static final String LOCATION = "Location";

    /** The Constant HTTP. */
    public static final String HTTP = "http";

    /** The Constant HTTPS. */
    public static final String HTTPS = "https";

    /** The Constant CAMPAIGN_PATH. */
    public static final String CAMPAIGN_PATH = "/content/campaigns/";

    /** The Constant STAR_CHAR. */
    public static final char STAR_CHAR = '*';

    /** The Constant STAR_ESCAPE_CHAR. */
    public static final String STAR_ESCAPE_CHAR = "%2A";

    /** The Constant SPACE_ESCAPE_CHAR1. */
    public static final String SPACE_ESCAPE_CHAR1 = "%20";

    /** The Constant PLUS_CHAR. */
    public static final char PLUS_CHAR = '+';

    /** The Constant PERCENTAGE_CHAR. */
    public static final char PERCENTAGE_CHAR = '%';

    /** The Constant E_CHAR. */
    public static final char E_CHAR = 'E';

    /** The Constant TILD_CHAR. */
    public static final char TILD_CHAR = '~';

    /** The Constant REG_EXPR. */
    public static final String REG_EXPR = "(?s)<[^>]*>(\\s*<[^>]*>)*";

    /** The Constant SEVEN_CHAR. */
    public static final char SEVEN_CHAR = '7';

    /** The Constant SPACE_STRING. */
    public static final String SPACE_STRING = " ";
    /** The Constant BACKSLASH_SINGLE_QUOTE. */
    public static final String BACKSLASH_SINGLE_QUOTE = "\\'";

    /** The Constant SINGLE_QUOTE. */
    public static final String SINGLE_QUOTE = "'";

    /** The Constant PERIOD. */
    public static final String PERIOD = ".";

    /** The Constant DATE_FORMAT_WITH_OUT_TIME. */
    public static final String DATE_FORMAT_WITH_OUT_TIME = "yyyy-MM-dd";

    /** The Constant EMPTY_ARRAY. */
    public static final String[] EMPTY_ARRAY = new String[0];

    /** The Constant LIST_COMP_PROP_IMAGE_ALT_TXT. */
    public static final String LIST_COMP_PROP_IMAGE_ALT_TXT = "altText";

    /** The Constant MEGA_BYTE. */
    public static final String MEGA_BYTE = "MB";

    /** The Constant KILO_BYTE. */
    public static final String KILO_BYTE = "KB";

    /** The Constant BYTE. */
    public static final String BYTE = "B";

    /** The Constant UNDERSCORE. */
    public static final String UNDERSCORE = "_";

    /** The Constant CONTENT_ROOT_PATH. */
    public static final String SITE_CONTENT = "content";

    /** The Constant CQ_LAST_MODIFIED. */
    public static final String CQ_LAST_MODIFIED = NameConstants.PN_PAGE_LAST_MOD;

    /** The Constant BRAND_PAGE_DEPTH. */
    public static final int BRAND_PAGE_DEPTH = 3;

    /** The Constant TRUE. */
    public static final String TRUE = "true";
    
    /** The Constant TRUE. */
    public static final String ADMIN_USER_NAME = "username";
    
    /** The Constant TRUE. */
    public static final String ADMIN_TEXT = "password";

    /** The Constant DELCITY_BLOG_CATEGORIES. */
    public static final String DELCITY_BLOG_CATEGORIES = "/etc/acs-commons/lists/ecommerce/delcity/blogcategories";

    /** The Constant MERCNET_BLOG_CATEGORIES. */
    public static final String MERCNET_BLOG_CATEGORIES = "/etc/acs-commons/lists/ecommerce/mercnet/blogcategories";

    /** The Constant DELCITY_BLOG_CATEGORIES. */
    public static final String LANDNSEA_BLOG_CATEGORIES = "/etc/acs-commons/lists/ecommerce/landnsea/blogcategories";
    
   // public static final String ANZP_RESPONSE_SERVLET = "/bin/loginResponseServlet";
	
    public static final String SAML_RESPONSE = "SAMLResponse";
    
    public static final String ANZP_HOME_PAGE = "/content/ecommerce/merclink/au/en/home.html";
	
	   /** Constants for Merclink NZ Login **/
	public static final String ANZP_NZ_RESPONSE_SERVLET = "/bin/anzpnzloginresponseservlet";
	public static final String ANZP_NZ_HOME_PAGE = "/content/ecommerce/merclink/nz/en/home.html";
	public static final String ANZP_NZ_ERROR_PAGE = "/content/ecommerce/merclink/nz/en/errors/500.html";

    private LoginCommonConstants() {

    }

}
