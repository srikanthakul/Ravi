package com.brunswick.ecomm.merclink.core.models.wishlist;

import java.util.Map;

import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.wcm.core.components.models.Component;
import com.drew.lang.annotations.NotNull;

public interface WishlistDetails extends Component{
	@NotNull
	Customer getCustomerWishlists();
	Map<Integer, String> getProp65Code();
	
}
