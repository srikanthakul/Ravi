package com.brunswick.ecomm.merclink.core.beans.productdetailsrecommendations;

import java.util.ArrayList;
import java.util.List;

import com.brunswick.ecomm.core.beans.productdetailsrecommendations.RecommendationsBean;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Items {

	
	@JsonProperty("items")
	 private List<RecommendationsBean> items;

	public List<RecommendationsBean> getItems() {
		return new ArrayList<>(items);
	}

	public void setItems(List<RecommendationsBean> items) {
		this.items = new ArrayList<>(items);
	}

	
	
	
	


}
