package com.brunswick.ecomm.merclink.core.beans.product;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductDataResultBean {
	@JsonProperty("data")
	private ProductDataBean data;
	
	public ProductDataBean getData() {
		return data;
	}
	public void setData(ProductDataBean data) {
		this.data = data;
	}

}
