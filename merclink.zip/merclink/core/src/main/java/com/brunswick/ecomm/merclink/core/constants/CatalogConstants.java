package com.brunswick.ecomm.merclink.core.constants;

public class CatalogConstants {

	/* Magento attribute constants */
	public static final String PRODUCTS = "products";

	public static final String PRODUCT_ERRORS = "productListErrors";

	public static final String PRODUCT_ITEMS = "items";

	public static final String PRODUCT_AGGREGATIONS = "aggregations";

	public static final String PRODUCT_COUNT = "total_count";

	public static final String ATTRIBUTE_CODE = "attribute_code";

	public static final String LABEL = "label";
	
	public static final String ATTR_COUNT = "count";

	public static final String OPTIONS = "options";

	public static final String PRICE = "price";

	public static final String CATEGORY_ID = "category_id";

	public static final String ID = "id";

	public static final String SKU = "sku";

	public static final String NAME = "name";

	public static final String IMAGE_DATA_CUSTOM = "image_data_custom_";

	public static final String PRODUCT_THUMBNAIL_CUSTOM = "product_thumbnail_custom_";

	public static final String QUANTITY = "masterpartlowestsellinguomqty_custom_";

	public static final String PROP65_CODE = "masterpartprop65code_custom_";
	
	public static final String HAZARDOUS_CODE = "mp_hazardous_material_custom_";

	public static final String VALUE = "value";
	
	/* prop65 code  */

	public static final String PROP65_CANCER = "Cancer";

	public static final String PROP65_CANCER_REPRODUCTIVE = "Cancer and Reproductive Harm";

	public static final String PROP65_REPRODUCTIVE = "Reproductive Harm";

	public static final String PROP65_003 = "003";

	public static final String PROP65_002 = "002";

	public static final String PROP65_001 = "001";

	public static final String PROP65_YES = "Yes";

	public static final String PROP65_N = "N";

	/* General Constants */

	public static final String DATA = "data";

	public static final String GENERIC_DATA = "genericData";

	public static final String REQ_CATEGORYID = "categoryId";

	public static final String CATEGORY_PATH = "catPath";

	public static final String PAGE = "page";

	public static final String ITEM_SIZE = "size";

	public static final String SORT = "sort";

	public static final String RESOURCE_PATH = "resourcePath";

	public static final String TOKEN_PARAM = "tokenparam";
	
	public static final String CONTENT_TYPE = "application/json";
	
	

}
