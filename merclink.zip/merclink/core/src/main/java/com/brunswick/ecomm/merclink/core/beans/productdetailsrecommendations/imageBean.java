package com.brunswick.ecomm.merclink.core.beans.productdetailsrecommendations;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.models.annotations.Optional;

import com.fasterxml.jackson.annotation.JsonProperty;

public class imageBean {
	@Optional
	@JsonProperty("image_set_custom_")
	 private String image_set_custom_;
	@Optional
	@JsonProperty("product_thumbnail_custom_")
	 private String product_thumbnail_custom_;
	
	@Optional
	@JsonProperty("videos_custom_")
	 private String videos_custom_;
	@Optional
	@JsonProperty("productattachment_custom_")
	 private List<VideoBean> productattachment_custom_;
	public String getImage_set_custom_() {
		return image_set_custom_;
	}
	public void setImage_set_custom_(String image_set_custom_) {
		this.image_set_custom_ = image_set_custom_;
	}
	public String getProduct_thumbnail_custom_() {
		return product_thumbnail_custom_;
	}
	public void setProduct_thumbnail_custom_(String product_thumbnail_custom_) {
		this.product_thumbnail_custom_ = product_thumbnail_custom_;
	}
	public String getVideos_custom_() {
		return videos_custom_;
	}
	public void setVideos_custom_(String videos_custom_) {
		this.videos_custom_ = videos_custom_;
	}
	public List<VideoBean> getProductattachment_custom_() {
		return new ArrayList<>(productattachment_custom_);
	}
	public void setProductattachment_custom_(List<VideoBean> productattachment_custom_) {
		this.productattachment_custom_ = new ArrayList<>(productattachment_custom_);
	}
	
	
}
