package  com.brunswick.ecomm.merclink.core.models.internal.productlist;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.magento.graphql.CategoryTreeQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.internal.productlist.AbstractCategoryRetriever;
import com.adobe.cq.commerce.magento.graphql.gson.QueryDeserializer;

class CategoryPlaceholderRetriever extends AbstractCategoryRetriever {
    private static final Logger LOGGER = LoggerFactory.getLogger(CategoryPlaceholderRetriever.class);

    CategoryPlaceholderRetriever(MagentoGraphqlClient client, String placeholderPath) throws IOException {
        super(client);
        LOGGER.info("client************" + client);
        LOGGER.info("placeholderPath************" + placeholderPath);
        String json = IOUtils.toString(getClass().getClassLoader().getResourceAsStream(placeholderPath), StandardCharsets.UTF_8);
        LOGGER.info("json************" + json);
        Query rootQuery = QueryDeserializer.getGson().fromJson(json, Query.class);
        LOGGER.info("rootQuery************" + rootQuery);
        category = rootQuery.getCategory();
        LOGGER.info("category************" + category);
    }

    @Override
    protected CategoryTreeQueryDefinition generateCategoryQuery() {
        return null;
    }
}
