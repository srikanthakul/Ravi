package com.brunswick.ecomm.merclink.core.models.cart;

import com.adobe.cq.commerce.magento.graphql.Cart;
import com.adobe.cq.commerce.magento.graphql.CartItemInterface;

import java.util.Collection;

public interface CartList {

    public Cart getCart();
    public String getError();
}
