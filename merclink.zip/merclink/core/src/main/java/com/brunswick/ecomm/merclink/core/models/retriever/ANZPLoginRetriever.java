package com.brunswick.ecomm.merclink.core.models.retriever;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.CartItemInterfaceQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.CartQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.GenerateCustomerTokenAsAdminInput;
import com.adobe.cq.commerce.magento.graphql.GenerateCustomerTokenAsAdminOutput;
import com.adobe.cq.commerce.magento.graphql.GenerateCustomerTokenAsAdminOutputQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Operations;
import com.adobe.cq.commerce.magento.graphql.ProductInterfaceQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.QueryQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.RevokeCustomerTokenOutputQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.MutationQuery.MergeCartsArgumentsDefinition;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractCustomRetriever;
import com.brunswick.ecomm.merclink.core.models.retriever.LoginRetriever;
import com.google.gson.JsonObject;

public class ANZPLoginRetriever  extends AbstractCustomRetriever{

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginRetriever.class);

	public ANZPLoginRetriever(MagentoGraphqlClient client) {
		super(client);
	}

	@Override
	protected void populate() {

	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return client.execute(query);
	}

	private GraphqlResponse<Mutation, Error> executeMutation() {
		return client.executeMutation(query);
	}
	
	protected GraphqlResponse<JsonObject , Error> executeQuerygraphql() {
		return client.executeQuery(query);
	}

	public String generateCustomerToken(String emailId) {
		query = generateCustomerTokenDefinition(emailId);
		LOGGER.info("customer token query {}", query);
		try {
			GraphqlResponse<Mutation, Error> response = executeMutation();
			LOGGER.info("customer token query response {}", response);
			List<Error> errors = response.getErrors();
			if (errors != null) {
				for (Error error : errors) {
					LOGGER.info("error message token {}", error.getMessage());
	
				}
				return null;
			}
			Mutation queryResponse = response.getData();
			LOGGER.info("customer token query response1 {}", queryResponse);
			GenerateCustomerTokenAsAdminOutput token = queryResponse.getGenerateCustomerTokenAsAdmin();
			LOGGER.info("customer token query token {}" , token);
			if (token != null) {
				LOGGER.info("customer token query token1 {}", token.getCustomerToken());
				return token.getCustomerToken();
	
			}
		}catch(Exception e) {
			LOGGER.error("GraphQL query response is giving error {}",e.getMessage());
		}
		return null;

	}

	private String generateCustomerTokenDefinition(String emailId) {
		GenerateCustomerTokenAsAdminInput input = new GenerateCustomerTokenAsAdminInput(emailId);
		GenerateCustomerTokenAsAdminOutputQueryDefinition queryDef = i -> i.customerToken();
		return Operations.mutation(mutation -> mutation.generateCustomerTokenAsAdmin(input, queryDef)).toString();
	}

	public Boolean revokeCustomerToken() throws Exception{
		query = Operations.mutation(mutation -> mutation.revokeCustomerToken(generateRevokeCustomerTokenDefinition()))
				.toString();
		LOGGER.info("customer token revoke query : {}" , query);
		GraphqlResponse<Mutation, Error> response = executeMutation();
		List<Error> errors = response.getErrors();
		if (errors != null) {
			for (Error error : errors) {
				LOGGER.info("error message token=== {}", error.getMessage());

			}
			return null;
		}
		Mutation queryResponse = response.getData();
		LOGGER.info("customer token revoke query response: {}", queryResponse);
		if (null != queryResponse) {
			return queryResponse.getRevokeCustomerToken().getResult();
		}
		return null;
	}

	private RevokeCustomerTokenOutputQueryDefinition generateRevokeCustomerTokenDefinition() {
		return q -> q.result();
	}

	public String getCustomerCart() {
		String cartId = StringUtils.EMPTY;
		query = generateCustomerCartQuery();
		LOGGER.info("Query in cart {}", query);
		try {
			GraphqlResponse<Query, Error> response = executeQuery();
			LOGGER.info("customer cart query response {}",  response);
			if (null != response) {
				List<Error> errors = response.getErrors();
				if (errors != null) {
					for (Error error : errors) {
						LOGGER.info("error message customer cart=== {}", error.getMessage());
						return cartId;
					}
	
				}
				Query queryResponse = response.getData();
				cartId = queryResponse.getCustomerCart().getId().toString();
			}
		}catch(Exception e) {
			LOGGER.error("GraphQL query response is giving error {}",e.getMessage());
		}
		return cartId;

	}

	public String mergeCarts(String srcCartId, String desCartId) {
		CartQueryDefinition c = q -> q.id();
		MergeCartsArgumentsDefinition mergeCartQuery = q -> q.destinationCartId(desCartId);
		query = Operations.mutation(mutation -> mutation.mergeCarts(srcCartId, mergeCartQuery, c)).toString();
		LOGGER.info("merge cart query :" + query);
		GraphqlResponse<Mutation, Error> response = executeMutation();
		List<Error> errors = response.getErrors();
		if (errors != null) {
			for (Error error : errors) {
				LOGGER.info("error message in merge carts = {}", error.getMessage());

			}
			return desCartId;
		}
		Mutation queryResponse = response.getData();
		LOGGER.info("merge cart query response:" + queryResponse);
		if (null != queryResponse) {
			LOGGER.info("=---------= {}", queryResponse.toString());
			return queryResponse.toString();
		}
		return desCartId;
	}
	
	public String mergeCarts(String srcCartId) {
		CartQueryDefinition c = q -> q.id();
		query = Operations.mutation(mutation -> mutation.mergeCarts(srcCartId, c)).toString();
		LOGGER.info("merge cart query : {}",  query);
		GraphqlResponse<Mutation, Error> response = executeMutation();
		List<Error> errors = response.getErrors();
		if (errors != null) {
			for (Error error : errors) {
				LOGGER.info("error message in merge carts = {}", error.getMessage());

			}
			return null;
		}
		String retrievedCartId = response.getData().getMergeCarts().getId().toString();
		LOGGER.info("merge cart query cart id in response: {}",  retrievedCartId);
		if (null != retrievedCartId) {			
			return retrievedCartId;
		}
		return null;
	}
 
	
	private String generateCustomerCartQuery() {
		ProductInterfaceQueryDefinition product = p -> p.name().sku();
		CartItemInterfaceQueryDefinition query = q -> q.uid().quantity().product(product);
		CartQueryDefinition cartdef = de -> de.id().items(query);
		QueryQueryDefinition def = d -> d.customerCart(cartdef);
		return Operations.query(def).toString();
	}

	public JsonObject getCustomerRecentOrder() {
		query = getRecentOrderDefinition();
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(String.format("Recent orders query %s", query));
		}
		GraphqlResponse<JsonObject, Error> response = executeQuerygraphql();
		LOGGER.info("response= {}" , response.toString());
		JsonObject jsonResponse = response.getData().getAsJsonObject("salesRecentOrder");

		return jsonResponse;
	}
	
	private String getRecentOrderDefinition() {	
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("{");
		_queryBuilder.append(" salesRecentOrder{");
		_queryBuilder.append("increment_id");
		
		_queryBuilder.append(" customer_name");
		_queryBuilder.append(" items {");
		_queryBuilder.append(" title ");
		_queryBuilder.append(" sku");
		_queryBuilder.append(" price");
		_queryBuilder.append(" image");
		_queryBuilder.append("}}}");
		return _queryBuilder.toString();
		
	}
}
