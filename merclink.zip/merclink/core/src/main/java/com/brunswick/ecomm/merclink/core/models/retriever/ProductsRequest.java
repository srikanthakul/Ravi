package com.brunswick.ecomm.merclink.core.models.retriever;

import java.util.List;

import com.brunswick.ecomm.merclink.core.models.FacetObj;

public class ProductsRequest {

	String categoryId;
	String categoryPath;
	String currentPageNo;
	String pageSize;
	String sort;
	List<FacetObj> filterMap;
	String customerNumber;

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryPath() {
		return categoryPath;
	}

	public void setCategoryPath(String categoryPath) {
		this.categoryPath = categoryPath;
	}

	public String getCurrentPageNo() {
		return currentPageNo;
	}

	public void setCurrentPageNo(String currentPageNo) {
		this.currentPageNo = currentPageNo;
	}

	public String getPageSize() {
		return pageSize;
	}

	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

	public List<FacetObj> getFilterMap() {
		return filterMap;
	}

	public void setFilterMap(List<FacetObj> filterMap) {
		this.filterMap = filterMap;
	}

	public String getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

}
