package com.brunswick.ecomm.merclink.core.beans.product;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ProductsDataResultBean {
	@JsonProperty("data")
	private List<ProductDataBean> data;

	public List<ProductDataBean> getData() {
		return new ArrayList<>(data);
	}

	public void setData(List<ProductDataBean> data) {
		this.data = new ArrayList<>(data);
	}

}
