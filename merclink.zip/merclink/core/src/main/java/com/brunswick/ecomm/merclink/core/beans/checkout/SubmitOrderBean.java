package com.brunswick.ecomm.merclink.core.beans.checkout;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SubmitOrderBean {

	private String cartId;
	private String ponumber;
	private String ordercomment;
	private String requestedshipdate;
	private String payment_method;
	private String shipping_method;
	private String shipping_cost;
	private String attribute19;
	private boolean is_dropship;

	public boolean isIs_dropship() {
		return is_dropship;
	}

	public void setIs_dropship(boolean is_dropship) {
		this.is_dropship = is_dropship;
	}

	public String getAttribute19() {
		return attribute19;
	}

	public void setAttribute19(String attribute19) {
		this.attribute19 = attribute19;
	}

	public String getCartId() {
		return cartId;
	}

	public void setCartId(String cartId) {
		this.cartId = cartId;
	}

	public String getPonumber() {
		return ponumber;
	}

	public void setPonumber(String ponumber) {
		this.ponumber = ponumber;
	}

	public String getOrdercomment() {
		return ordercomment;
	}

	public void setOrdercomment(String ordercomment) {
		this.ordercomment = ordercomment;
	}

	public String getRequestedshipdate() {
		return requestedshipdate;
	}

	public void setRequestedshipdate(String requestedshipdate) {
		this.requestedshipdate = requestedshipdate;
	}

	public String getPayment_method() {
		return payment_method;
	}

	public void setPayment_method(String payment_method) {
		this.payment_method = payment_method;
	}

	public String getShipping_method() {
		return shipping_method;
	}

	public void setShipping_method(String shipping_method) {
		this.shipping_method = shipping_method;
	}

	public String getShipping_cost() {
		return shipping_cost;
	}

	public void setShipping_cost(String shipping_cost) {
		this.shipping_cost = shipping_cost;
	}

}
