package com.brunswick.ecomm.merclink.core.beans.personalinformation;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.models.annotations.Optional;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerDetailsBean {
	
	@Optional
	@JsonProperty("firstname")
	private String firstname;
	@Optional
	@JsonProperty("lastname")                            
	private String lastname;
	@Optional
	@JsonProperty("email")
	private String email;
	@Optional
	@JsonProperty("company_email")
	private String company_email;
	@Optional
	@JsonProperty("company_name")
	private String company_name;
	@Optional
	@JsonProperty("suffix")
	private String suffix;
	@Optional
	@JsonProperty("addresses")
	//private List<String> addresses;
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCompany_email() {
		return company_email;
	}
	public void setCompany_email(String company_email) {
		this.company_email = company_email;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getSuffix() {
		return suffix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	/*public List<String> getAddresses() {
		return new ArrayList<>(addresses);
	}
	public void setAddresses(List<String> addresses) {
		this.addresses = new ArrayList<>(addresses);
	}
*/
	
}
