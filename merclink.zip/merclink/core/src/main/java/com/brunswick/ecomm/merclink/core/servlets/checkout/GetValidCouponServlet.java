package com.brunswick.ecomm.merclink.core.servlets.checkout;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.EcommTokenService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonObject;

@Component(service = Servlet.class, property = { "sling.servlet.methods=GET",
		"sling.servlet.paths=/bin/merclink/getValidCoupon" })
public class GetValidCouponServlet extends SlingAllMethodsServlet {

	private static final Logger LOG = LoggerFactory.getLogger(GetValidCouponServlet.class);
	private static final long serialVersionUID = 1L;

	@Reference
	transient EcommTokenService tokenService;
	@Reference
	transient APIGEEService apigeeservice;
	@Reference
	transient EcommSessionService ecommservice;

	@Override
	public void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		long startTime = System.currentTimeMillis();
		LOG.info(" GetValidCouponServlet Request start time :{}", startTime);
		LOG.debug("valid coupon");

		JSONObject requestObj;
		try {

			JsonObject jsonresponse = null;
			if (request != null) {
				PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
				LOG.info(" pagemanager in validcoupon servlet====={}", pageManager);
				requestObj = new JSONObject(request.getParameter("data"));
				String currentPage = requestObj.get("resourcePath").toString();
				LOG.info(" currentPage in validcoupon servlet====={}", currentPage);
				Resource resource = request.getResourceResolver().resolve(currentPage);
				LOG.info(" resource in validcoupon servlet====={}", resource);
				String couponNumber = requestObj.get("couponNumber").toString();
				LOG.info(" coupon number in validcoupon servlet====={}", couponNumber);

				if (resource != null) {

					jsonresponse = apigeeservice.getValidCouponDetails(couponNumber, resource.getPath(),
							ecommservice.getReadServiceResourceResolver());
					LOG.info(" GetValidCouponServlet jsonresponse== {}", jsonresponse);

				}
			}
			response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
			response.setContentType("application/json");
			response.getWriter().print(jsonresponse);

		}

		catch (JSONException | LoginException e) {
			LOG.error("Json Exception =={} ", e.getMessage());
		}
	}
}