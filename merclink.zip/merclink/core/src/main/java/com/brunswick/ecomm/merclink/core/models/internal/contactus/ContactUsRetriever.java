package com.brunswick.ecomm.merclink.core.models.internal.contactus;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractCustomRetriever;
import com.google.gson.JsonObject;

public class ContactUsRetriever extends AbstractCustomRetriever{
	private static final Logger LOGGER = LoggerFactory.getLogger(ContactUsRetriever.class);
	public ContactUsRetriever(MagentoGraphqlClient client) {
		super(client);
	}
	
	
	protected GraphqlResponse<JsonObject , Error> executeMutationgraphql() {
		LOGGER.info("in executeMutationgraphql");
		return client.executeJsonMutation(queryString);
	}
	private String queryString;
	public JsonObject getResponse(Map<String, String> data) {
		LOGGER.info("in getResponse");

		queryString = getResponseDefinition(data);
		GraphqlResponse<JsonObject , Error> response = executeMutationgraphql();
		LOGGER.info("response: "+response.getData()); 
		return response.getData();
	}
	private String getResponseDefinition(Map<String, String> data) {
		LOGGER.info("in getResponseDefinition");

			StringBuilder queryBuilder = new StringBuilder();
			queryBuilder.append("mutation {");
			queryBuilder.append(" SubmitContactForm(");
			queryBuilder.append("input:{");
			queryBuilder.append("firstname: \""+data.get("fname")+"\"");
			queryBuilder.append("lastname: \""+data.get("lname")+"\"");
			queryBuilder.append("email: \""+data.get("email")+"\"");
			queryBuilder.append("phone: \""+data.get("phone")+"\"");
			queryBuilder.append("account_name: \""+data.get("companyname")+"\"");
			queryBuilder.append("customer_number: \""+data.get("customerno")+"\"");
			queryBuilder.append("department: \""+data.get("dept")+"\"");
			queryBuilder.append("subject: \""+data.get("subject")+"\"");
			queryBuilder.append("message: \""+data.get("message")+"\"");
			queryBuilder.append(" } ) {");
			queryBuilder.append(" success_message ");
			queryBuilder.append("}}");
			LOGGER.info("query : "+queryBuilder.toString());
			return queryBuilder.toString();
			
		
		
	}
	@Override
	protected void populate(){
		//Nothing to do
	}
	
	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return null;
	}


	public JsonObject getResponseforCreditApp(Map<String, String> data) {
		LOGGER.info("in getResponseforCreditApp");
		queryString = getResponseDefinitionforCreditApp(data);
		try {
			GraphqlResponse<JsonObject , Error> response = executeMutationgraphql();
			LOGGER.info("response: "+response.getData());
			return response.getData();
		}catch (Exception e) {
			LOGGER.error("error occurred : {}",e.getMessage(),e);
			return null;
		}
		
			
	}


	private String getResponseDefinitionforCreditApp(Map<String, String> data) {
		LOGGER.info("in getResponseDefinition");

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("mutation {");
		queryBuilder.append(" SubmitContactForm(");
		queryBuilder.append("input:{");
		queryBuilder.append("attchmentsFilesInput: {");
		queryBuilder.append("w9_file_name: \""+data.get("w9_file")+"\"" );
		queryBuilder.append("sales_certificate_name: \""+data.get("sales_file")+"\"");
		queryBuilder.append("addtional_file: \""+data.get("add_file")+"\"}");
		queryBuilder.append("department: \""+data.get("department")+"\"");
		queryBuilder.append("company: \""+data.get("company")+"\"");
		queryBuilder.append("contact_name: \""+data.get("contact_name")+"\"");
		queryBuilder.append("title: \""+data.get("title")+"\"");
		queryBuilder.append("address1: \""+data.get("address1")+"\"");
		queryBuilder.append("address2: \""+data.get("address2")+"\""); 
		queryBuilder.append("phone: \""+data.get("phone")+"\"");
		queryBuilder.append("city: \""+data.get("city")+"\"");
		queryBuilder.append("state: \""+data.get("state")+"\"");
		queryBuilder.append("zipcode: \""+data.get("zipcode")+"\"");
		queryBuilder.append("fax: \""+data.get("fax")+"\"");
		queryBuilder.append("email: \""+data.get("email")+"\"");
		queryBuilder.append("type: \""+data.get("type")+"\"");
		queryBuilder.append("db_number: \""+data.get("db_number")+"\"");
		queryBuilder.append("employee_id: \""+data.get("employee_id")+"\"");
		queryBuilder.append("annual_spend: \""+data.get("annual_spend")+"\"");
		queryBuilder.append("documents: \""+data.get("documents")+"\"");
		queryBuilder.append("agree_name: \""+data.get("agree_name")+"\"");
		queryBuilder.append(" } ) {");
		queryBuilder.append(" success_message ");
		queryBuilder.append("}}");
		LOGGER.info("query : "+queryBuilder.toString());
		return queryBuilder.toString();
		
			
			 
			
	}

}
