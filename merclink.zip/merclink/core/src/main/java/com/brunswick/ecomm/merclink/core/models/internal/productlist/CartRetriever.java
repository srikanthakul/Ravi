package com.brunswick.ecomm.merclink.core.models.internal.productlist;

import java.util.List;

import com.adobe.cq.commerce.magento.graphql.AddConfigurableProductsToCartInput;
import com.adobe.cq.commerce.magento.graphql.AddSimpleProductsToCartInput;
import com.adobe.cq.commerce.magento.graphql.ConfigurableProductCartItemInput;
import com.adobe.cq.commerce.magento.graphql.MutationQuery.AddConfigurableProductsToCartArgumentsDefinition;
import com.adobe.cq.commerce.magento.graphql.MutationQuery.AddSimpleProductsToCartArgumentsDefinition;
import com.adobe.cq.commerce.magento.graphql.MutationQuery.CreateEmptyCartArgumentsDefinition;
import com.adobe.cq.commerce.magento.graphql.SimpleProductCartItemInput;
import com.adobe.cq.commerce.magento.graphql.createEmptyCartInput;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

public class CartRetriever extends AbstractCartRetrieverV2 {
    public CartRetriever(MagentoGraphqlClient client) {
        super(client);
        // TODO Auto-generated constructor stub
    }

    @Override
    protected CreateEmptyCartArgumentsDefinition generateCartArgsQuery(String cartId) {
        createEmptyCartInput input = new createEmptyCartInput().setCartId(cartId);
        return c -> c.input(input);
    }

    
    @Override
    protected AddSimpleProductsToCartArgumentsDefinition generateaddtoCartArgsQuery(String cartId,List<SimpleProductCartItemInput> cartItems) {
        AddSimpleProductsToCartInput obj= new AddSimpleProductsToCartInput(cartId, cartItems);

    	return c-> c.input(obj);
        		
    }
    
    @Override
    protected AddConfigurableProductsToCartArgumentsDefinition generateconfigurableaddtoCartArgsQuery(String cartId,List<ConfigurableProductCartItemInput> cartItems) {
    	AddConfigurableProductsToCartInput obj= new AddConfigurableProductsToCartInput(cartId, cartItems);

    	return c-> c.input(obj);
        		
    }

}

