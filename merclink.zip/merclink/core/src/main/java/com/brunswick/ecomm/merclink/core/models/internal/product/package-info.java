/**
 * 
 */
/**
 * @author Praveen_Vatchavayi
 *
 */
@Version("1.0")
package com.brunswick.ecomm.merclink.core.models.internal.product;
import org.osgi.annotation.versioning.Version;
