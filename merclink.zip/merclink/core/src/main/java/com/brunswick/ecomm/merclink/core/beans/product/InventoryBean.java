package com.brunswick.ecomm.merclink.core.beans.product;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class InventoryBean {
	@JsonProperty("status")
	private InventoryStatusBean status;
	
	
	public InventoryStatusBean getStatus() {
		return status;
	}
	public void setStatus(InventoryStatusBean status) {
		this.status = status;
	}
	
}
