package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractPersonalInformationRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
@Component(service = Servlet.class, property = { "sling.servlet.methods=POST",
"sling.servlet.paths=/bin/merclinkCustomerPersonalInfo" })
public class CustomerPersonalInformation extends SlingAllMethodsServlet{
	private static final Logger LOG = LoggerFactory.getLogger(CustomerPersonalInformation.class);
	private static final long serialVersionUID = 1L;
	//private transient AbstractQuoteRetriever retriever;
	String currentPagePath;
	private String customerEmail;
	private String adminToken;
	String customerNumber = StringUtils.EMPTY;
	
	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.debug("Entering into doPost() Method.");
		JSONObject requestObj;
		PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
		try {
			requestObj = new JSONObject(request.getParameter("data"));
			currentPagePath = requestObj.get("resourcePath").toString();
			LOG.info("currentPagePath=="+currentPagePath);
			Resource res = request.getResourceResolver().resolve(currentPagePath);
			
			 //String token=requestObj.get("token").toString(); LOG.info("token=="+token);
			 String token = CommonUtil.getTokenFromCookie("customerToken", request);
			//String token = "h2g6ooftlwpx9rw7whpjw2gmrh3u39gv";
			  List<Header> headers = new ArrayList<>(); headers.add(new
			  BasicHeader("Authorization", "Bearer " + token));
			 
			
			MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(res,
					pageManager.getPage(res.getPath()), request, headers);
			AbstractPersonalInformationRetriever personalInformationRetriever;
			personalInformationRetriever = new AbstractPersonalInformationRetriever(magentoGraphqlClient);
			JsonObject resp = null;
			if (personalInformationRetriever != null) {
				resp = personalInformationRetriever.getCustomerPersonalInformation();
				/*
				 * JsonElement token = resp.get("customer_token");
				 * LOG.info("token=====================" +token); //Setting cookie for 4 hours
				 * setCookie(response, "customerToken", token.toString(), 14400);
				 */
			}
			if (resp != null) {
				LOG.info("Response=====================" + new Gson().toJson(resp) );
				response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
				response.setContentType("application/json");
				response.getWriter().print(new Gson().toJson(resp));
			}
			/*
			 * JsonObject personalInfo =
			 * personalInformationRetriever.getCustomerPersonalInformation();
			 * LOG.info("personalInfo----"+personalInfo.toString());
			 * customerNumber=personalInfo.getAsJsonObject("customer").get("customer_number"
			 * ).getAsString();
			 * LOG.info("Customer number in homepagegetcustomerdetailsservelet---"
			 * +customerNumber);
			 */
			/*
			 * setCookie(response,"customerNumber");
			 * response.setContentType("application/json");
			 * response.getWriter().print(personalInfo);
			 * response.setStatus(response.getStatus());
			 */
		} catch (JSONException e) {
		LOG.error("Json Exception " + e.getMessage(),e);
	} catch (RuntimeException e) {
		LOG.error("RunTime Exception {}", e.getMessage(),e);
	}
	LOG.debug("Exit from doPost() Method.");
	}
	/*
	 * private void setCookie(SlingHttpServletResponse response, String name, String
	 * value, int maxAge) {
	 * 
	 * Cookie cookie = new Cookie(name, value); cookie.setMaxAge(maxAge);
	 * cookie.setPath("/"); response.addCookie(cookie); }
	 */


}
