package com.brunswick.ecomm.merclink.core.beans.productdetailsrecommendations;

import org.apache.sling.models.annotations.Optional;

import com.fasterxml.jackson.annotation.JsonProperty;

public class VideoBean {
	
	@Optional
	@JsonProperty("attach_identifer_custom_")
	 private String attach_identifer_custom_;
	@Optional
	@JsonProperty("label_name_custom_")
	 private String label_name_custom_;
	
	@Optional
	@JsonProperty("description_custom_")
	 private String description_custom_;
	@Optional
	@JsonProperty("attachment_custom_")
	 private String attachment_custom_;
	
	@Optional
	@JsonProperty("visible_custom_")
	 private String visible_custom_;

	public String getAttach_identifer_custom_() {
		return attach_identifer_custom_;
	}

	public void setAttach_identifer_custom_(String attach_identifer_custom_) {
		this.attach_identifer_custom_ = attach_identifer_custom_;
	}

	public String getLabel_name_custom_() {
		return label_name_custom_;
	}

	public void setLabel_name_custom_(String label_name_custom_) {
		this.label_name_custom_ = label_name_custom_;
	}

	public String getDescription_custom_() {
		return description_custom_;
	}

	public void setDescription_custom_(String description_custom_) {
		this.description_custom_ = description_custom_;
	}

	public String getAttachment_custom_() {
		return attachment_custom_;
	}

	public void setAttachment_custom_(String attachment_custom_) {
		this.attachment_custom_ = attachment_custom_;
	}

	public String getVisible_custom_() {
		return visible_custom_;
	}

	public void setVisible_custom_(String visible_custom_) {
		this.visible_custom_ = visible_custom_;
	}
	
	

}
