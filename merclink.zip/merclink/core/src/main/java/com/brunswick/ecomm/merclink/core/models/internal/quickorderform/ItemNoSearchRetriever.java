package com.brunswick.ecomm.merclink.core.models.internal.quickorderform;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.magento.graphql.ProductImageQuery;
import com.adobe.cq.commerce.magento.graphql.ProductImageQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.ProductInterfaceQuery;
import com.adobe.cq.commerce.magento.graphql.ProductInterfaceQueryDefinition;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.shopify.graphql.support.CustomFieldQueryDefinition;

public class ItemNoSearchRetriever extends AbstractItemNoSearchRetriever{
                private static final Logger LOG = LoggerFactory.getLogger(ItemNoSearchRetriever.class);
                public ItemNoSearchRetriever(MagentoGraphqlClient client) {
                                super(client); 
                }
                @Override
                protected ProductInterfaceQueryDefinition generateProductQuery() {
                                ProductImageQueryDefinition imgurl = (ProductImageQuery queryDef) -> {queryDef.url();};
                                return (ProductInterfaceQuery q) -> {
                                                                q.sku()
                .name()
                .stockStatus()
                .addCustomObjectField("image_data", generateImageQuery())
                .addCustomSimpleField("masterpartlowestsellinguomqty")
                .addCustomSimpleField("bupartstatus");
        };
                }
                
                private CustomFieldQueryDefinition generateImageQuery(){
                                return customquery -> customquery.addCustomSimpleField("image_set").addCustomSimpleField("product_thumbnail").addCustomObjectField("productattachment", generateImageInnerQuery());
                                
                }
                
                private CustomFieldQueryDefinition generateImageInnerQuery(){
                                return custominnerquery ->custominnerquery.addCustomSimpleField("attach_identifer").addCustomSimpleField("label_name").addCustomSimpleField("description").addCustomSimpleField("attachment").addCustomSimpleField("visible");
                                
                }

}
