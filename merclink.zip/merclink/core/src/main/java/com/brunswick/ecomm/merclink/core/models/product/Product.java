/*******************************************************************************
 *
 *    Copyright 2019 Adobe. All rights reserved.
 *    This file is licensed to you under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License. You may obtain a copy
 *    of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software distributed under
 *    the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 *    OF ANY KIND, either express or implied. See the License for the specific language
 *    governing permissions and limitations under the License.
 *
 ******************************************************************************/

package com.brunswick.ecomm.merclink.core.models.product;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.brunswick.ecomm.merclink.core.beans.ProductAttachmentBean;
import com.brunswick.ecomm.merclink.core.beans.ProductInventoryBean;
import com.brunswick.ecomm.merclink.core.beans.ProductPricesBean;
import com.brunswick.ecomm.merclink.core.models.product.common.Price;
import com.brunswick.ecomm.merclink.core.models.product.retriever.AbstractProductRetriever;

/**
 * Product is the sling model interface for the CIF core product component.
 */
public interface Product {

    /**
     * Name of the boolean resource property indicating if the product component should load prices on the client-side.
     */
    String PN_LOAD_CLIENT_PRICE = "loadClientPrice";
    
    ProductInventoryBean getInventory();
    
    ProductPricesBean getTiredPrices();
    
    Boolean getFound();

    String getName();

    String getDescription();

    String getSku();

    Price getPriceRange();

    Boolean getInStock();

    Boolean isConfigurable();

    Boolean isGroupedProduct();

    Boolean isVirtualProduct();

    String getVariantsJson();

    List<Variant> getVariants();

    List<GroupItem> getGroupedProductItems();

    List<Asset> getAssets();

    String getAssetsJson();

    List<VariantAttribute> getVariantAttributes();

    Boolean loadClientPrice();

    AbstractProductRetriever getProductRetriever();

	String getMetaDescription();

	String getMetaKeywords();

	String getMetaTitle();

	String getCanonicalUrl();

	String getCurrency();

	Double getPrice();

	String getFormattedPrice();

	Boolean isBundleProduct();
	
	String getBrand();	
	
	String getMasterPartLowestSellinguomqty();
	
	String getProductImage();
	
	List<ProductAttachmentBean> getProductAttachment();	
	
	String getProp65();
	
	String getBuPartStatus();
	
	Map<String,String> getProductSpecifications();
	
	List<String> getProductVideos();
	
	ArrayList<String> getLongDescriptionList();

	ArrayList<String> getBuPartBulletList();
	
	String getWeight();
	
	String getSsToItem();
	
	String getHazardousCode();
	
	String getWeightUom();
}
