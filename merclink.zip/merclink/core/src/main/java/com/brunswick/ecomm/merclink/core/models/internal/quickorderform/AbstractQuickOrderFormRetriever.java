package com.brunswick.ecomm.merclink.core.models.internal.quickorderform;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.FilterEqualTypeInput;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Operations;
import com.adobe.cq.commerce.magento.graphql.ProductAttributeFilterInput;
import com.adobe.cq.commerce.magento.graphql.ProductInterface;
import com.adobe.cq.commerce.magento.graphql.ProductInterfaceQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.ProductsQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.QueryQuery;
import com.adobe.cq.commerce.magento.graphql.SearchResultPageInfoQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.product.retriever.AbstractRetriever;

public abstract class AbstractQuickOrderFormRetriever extends AbstractRetriever {

	protected ProductInterface product;
	protected String identifier;
	// Commented as part of CIF upgrade
	// protected ProductIdentifierType productIdentifierType;
	protected List<String> identifiers;
	private List<ProductInterface> products = Collections.emptyList();
	private String totalCount;
	private static final Logger LOG = LoggerFactory.getLogger(AbstractQuickOrderFormRetriever.class);

	public AbstractQuickOrderFormRetriever(MagentoGraphqlClient client) {
		super(client);
		LOG.info("AbstractQuickOrderFormRetriever client.." + client);
	}

	public ProductInterface fetchProduct() {
		if (this.product == null) {
			populate();
		}
		return this.product;
	}

	public List<ProductInterface> fetchProducts() {
		if (this.product == null) {
			populatebundle();
		}
		return new ArrayList<ProductInterface>(this.products);
	}

	public String getTotalCount() {
		return this.totalCount;
	}

	// Commented as part of CIF upgrade

	/*
	 * public void setIdentifier(ProductIdentifierType productIdentifierType, String
	 * identifier) { product = null; query = null; this.identifier = identifier;
	 * this.productIdentifierType = productIdentifierType; } public void
	 * setIdentifier(ProductIdentifierType productIdentifierType, List<String>
	 * identifier) { product = null; query = null; this.identifiers = identifier;
	 * this.productIdentifierType = productIdentifierType; }
	 */
	// Added as part of CIF upgrade
	public void setIdentifier(String identifier) {
		product = null;
		query = null;
		this.identifier = identifier;
		// this.productIdentifierType = productIdentifierType;
	}

	public void setIdentifier(List<String> identifier) {
		product = null;
		query = null;
		this.identifiers = identifier;
		// this.productIdentifierType = productIdentifierType;
	}

	// End
	protected GraphqlResponse<Query, Error> executeQuery() {
		if (query == null) {
			query = generateQuery(identifier);
		}
		return client.execute(query);
	}

	protected GraphqlResponse<Query, Error> executeQueryforBundle() {
		if (query == null) {
			query = generateQuery(identifiers);
		}
		return client.execute(query);
	}

	@Override
	protected void populate() {
		// Get product list from response
		GraphqlResponse<Query, Error> response = executeQuery();
		LOG.info("populate...response(executeQuery()) " + response.toString());
		Query rootQuery = response.getData();
		LOG.info("populate...response.getData() " + response.getData().toString());

		List<ProductInterface> products = rootQuery.getProducts().getItems();

		LOG.info("populate...products--rootQuery.getProducts().getItems() " + rootQuery.getProducts().getItems());

		// Return first product in list
		if (products.size() > 0) {
			product = products.get(0);
			LOG.info(product + ".......product");

		}
	}

	protected void populatebundle() {
		// Get product list from response
		GraphqlResponse<Query, Error> response = executeQueryforBundle();
		LOG.info("populate...response " + response.toString());
		Query rootQuery = response.getData();

		List<ProductInterface> products = rootQuery.getProducts().getItems();
		String json = (String) rootQuery.get("total_count");
		this.totalCount = json;
		LOG.info("populate...products--rootQuery.getProducts().getItems() " + rootQuery.getProducts().getItems());

		// Return first product in list
		if (products.size() > 0) {
			this.products = products;
			LOG.info(products + ".......product");

		}
	}

	public String generateQuery(String identifier) {
		FilterEqualTypeInput identifierFilter = new FilterEqualTypeInput().setEq(identifier);
		ProductAttributeFilterInput filter;

		filter = new ProductAttributeFilterInput().setSku(identifierFilter);

		QueryQuery.ProductsArgumentsDefinition searchArgs = s -> s.filter(filter);

		ProductsQueryDefinition queryArgs = q -> q.items(generateProductQuery());
		LOG.info("\n\nthe query : " + Operations.query(query -> query.products(searchArgs, queryArgs)).toString());
		return Operations.query(query -> query.products(searchArgs, queryArgs)).toString();
	}

	public String generateQuery(List<String> identifier) {
		FilterEqualTypeInput identifierFilter = new FilterEqualTypeInput().setIn(identifier);
		ProductAttributeFilterInput filter;

		filter = new ProductAttributeFilterInput().setSku(identifierFilter);

		QueryQuery.ProductsArgumentsDefinition searchArgs = s -> s.filter(filter).pageSize(999);

		SearchResultPageInfoQueryDefinition queryDef = d -> d.pageSize();
		ProductsQueryDefinition queryArgs = q -> q.totalCount().pageInfo(queryDef).items(generateProductQuery());
		LOG.info("\n\nthe query for list : "
				+ Operations.query(query -> query.products(searchArgs, queryArgs)).toString());
		return Operations.query(query -> query.products(searchArgs, queryArgs)).toString();
	}

	abstract protected ProductInterfaceQueryDefinition generateProductQuery();

	protected GraphqlResponse<Mutation, Error> executeMutation() {
		return null;
	}

}
