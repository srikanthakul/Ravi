package com.brunswick.ecomm.merclink.core.models.retriever;

import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.FacetObj;
import com.brunswick.ecomm.merclink.core.models.FacetOption;
import com.google.gson.JsonObject;

public class AbstractProductsListingRetriever extends AbstractCustomRetriever {
	private String queryString;
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractProductsListingRetriever.class);

	public AbstractProductsListingRetriever(MagentoGraphqlClient client) {
		super(client);
	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return client.execute(queryString);
	}

	protected GraphqlResponse<JsonObject, Error> executeJsonQuery() {
		return client.executeQuery(query);
	}

	protected GraphqlResponse<Mutation, Error> executeMutation() {
		return client.executeMutation(query);
	}

	protected GraphqlResponse<JsonObject, Error> executeJsonMutation() {
		return client.executeJsonMutation(query);
	}

	public JsonObject getProductsList(ProductsRequest prodRequest) {
		query = getproductListingQuery(prodRequest);

		LOGGER.info(" magento productlist QUERY=={}", query);
		GraphqlResponse<JsonObject, Error> response = executeJsonMutation();
		LOGGER.info("magento productlist response===={}", response);
		List<Error> errors = response.getErrors();
		if (errors != null) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				errorjsonobject.addProperty("productListErrors", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info("product list response===={}", response.getData());
		return response.getData();

	}

	private String getproductListingQuery(ProductsRequest prodRequest) {

		StringBuilder sb = new StringBuilder();
		sb.append("{ ");
		sb.append(" products( ");
		sb.append(" currentPage: " + prodRequest.getCurrentPageNo());
		sb.append(" pageSize: " + prodRequest.getPageSize());
		sb.append(" filter: { category_id: { eq: \"" + prodRequest.getCategoryId() + "\"");
		sb.append(" }, company_customer_number: { eq: \"" + prodRequest.getCustomerNumber() + "\"");
		if (!prodRequest.getFilterMap().isEmpty()) {
			sb.append(" }, " + prepareFilterQuery(prodRequest) + " ");
		} else {
			sb.append(" } ");
		}
		sb.append(" } ");
		sb.append(" sort: {  " + prodRequest.getSort() + " }");
		sb.append(") {");

		sb.append("total_count ");
		sb.append("items { ");
		sb.append("__typename ");
		sb.append("id ");
		sb.append("sku ");
		sb.append("name ");
		sb.append("image_data_custom_ : image_data { ");
		sb.append("image_set_custom_: image_set ");

		sb.append("product_thumbnail_custom_: product_thumbnail ");
		sb.append("productattachment_custom_: productattachment { ");
		sb.append("attach_identifer_custom_: attach_identifer ");
		sb.append("label_name_custom_: label_name ");
		sb.append("description_custom_: description ");
		sb.append("attachment_custom_: attachment ");
		sb.append("visible_custom_: visible ");
		sb.append("} ");
		sb.append("} ");

		sb.append("masterpartlowestsellinguomqty_custom_: masterpartlowestsellinguomqty ");
		sb.append("small_image { ");

		sb.append("url ");
		sb.append("} ");
		sb.append("color ");
		sb.append("stock_status ");
		sb.append("type_id ");
		sb.append("masterpartprop65code_custom_: masterpartprop65code ");
		sb.append("mp_hazardous_material_custom_: mp_hazardous_material ");

		sb.append("url_key ");
		sb.append("price_range { ");
		sb.append("minimum_price { ");
		sb.append("regular_price { ");
		sb.append("value ");
		sb.append("currency ");
		sb.append("} ");

		sb.append("final_price { ");
		sb.append("value ");
		sb.append("currency ");
		sb.append("} ");
		sb.append("discount { ");
		sb.append("amount_off ");
		sb.append("percent_off ");
		sb.append("} ");
		sb.append("} ");

		sb.append("maximum_price { ");
		sb.append("regular_price { ");
		sb.append("value ");
		sb.append("currency ");
		sb.append("} ");

		sb.append("final_price { ");
		sb.append("value ");
		sb.append("currency ");
		sb.append("} ");
		sb.append("discount { ");
		sb.append("amount_off ");
		sb.append("percent_off ");
		sb.append("} ");
		sb.append("} ");
		sb.append("} ");

		sb.append("... on ConfigurableProduct { ");

		sb.append("price_range { ");
		sb.append("maximum_price { ");
		sb.append("regular_price { ");
		sb.append("value ");
		sb.append("currency ");
		sb.append("} ");

		sb.append("final_price { ");
		sb.append("value ");
		sb.append("currency ");
		sb.append("} ");
		sb.append("discount { ");
		sb.append("amount_off ");
		sb.append("percent_off ");
		sb.append("} ");
		sb.append("} ");
		sb.append("} ");

		sb.append("configurable_options { ");
		sb.append("label ");
		sb.append("attribute_code ");
		sb.append("values { ");
		sb.append("value_index ");
		sb.append("label ");
		sb.append("} ");
		sb.append("} ");

		sb.append("variants { ");
		sb.append("attributes { ");
		sb.append("code ");
		sb.append("value_index ");
		sb.append("} ");
		sb.append("} ");
		sb.append("} ");

		sb.append("... on BundleProduct { ");
		sb.append("price_range { ");
		sb.append("maximum_price { ");
		sb.append("regular_price { ");
		sb.append("value ");
		sb.append("currency ");
		sb.append("} ");

		sb.append("final_price { ");
		sb.append("value ");
		sb.append("currency ");
		sb.append("} ");
		sb.append("discount { ");
		sb.append("amount_off ");
		sb.append("percent_off ");
		sb.append("} ");
		sb.append("} ");
		sb.append("} ");
		sb.append("} ");
		sb.append("} ");

		sb.append("aggregations { ");
		sb.append("options { ");
		sb.append("count ");
		sb.append("label ");
		sb.append("value ");
		sb.append("level_custom_: level ");
		sb.append("name_custom_: name ");
		sb.append("path_custom_: path ");
		sb.append("path_name_custom_: path_name ");
		sb.append("url_key_custom_: url_key ");
		sb.append("url_path_custom_: url_path ");
		sb.append("} ");
		sb.append("attribute_code ");
		sb.append("count ");
		sb.append("label ");
		sb.append("} ");
		sb.append("} ");
		sb.append("category(id: " + prodRequest.getCategoryId() + " ) { ");
		sb.append("id ");
		sb.append("description ");

		sb.append("name ");
		sb.append("image ");
		sb.append("product_count ");
		sb.append("meta_description ");
		sb.append("meta_keywords ");
		sb.append("meta_title ");
		sb.append("url_path ");
		sb.append("} ");
		sb.append("} ");

		return sb.toString();
	}

	private String prepareFilterQuery(ProductsRequest prodRequest) {
		StringBuilder sb = new StringBuilder();

		if (!prodRequest.getFilterMap().isEmpty()) {
			Iterator iterator = prodRequest.getFilterMap().iterator();
			while (iterator.hasNext()) {
				FacetObj facetObj = (FacetObj) iterator.next();

				if (null != facetObj && facetObj.getFacetList() != null && !facetObj.getFacetList().isEmpty()) {
					if (sb.length() != 0) {
						sb.append(" , ");
					}
					if (facetObj.getFacetList().size() > 1) {
						sb.append(facetObj.getAttrCode()).append(" : { in : [")
								.append(wrapwithQuotes(facetObj.getFacetList())).append("] }");
					} else {
						sb.append(facetObj.getAttrCode())
								.append(" : { eq : \"" + facetObj.getFacetList().get(0).getAttrCode() + "\"" + "}");
					}
				}
			}
		}
		return sb.toString();
	}

	private Object wrapwithQuotes(List<FacetOption> options) {
		return options.stream().map(a -> String.valueOf(a.getAttrCode()))
				.collect(Collectors.joining("\", \"", "\"", "\""));
	}

	@Override
	protected void populate() {
		// TODO Auto-generated method stub

	}

}
