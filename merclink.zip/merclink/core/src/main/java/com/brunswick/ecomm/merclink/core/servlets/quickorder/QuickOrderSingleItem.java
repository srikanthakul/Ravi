package com.brunswick.ecomm.merclink.core.servlets.quickorder;

import java.io.IOException;

import javax.servlet.Servlet;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(service = Servlet.class, property = { "sling.servlet.methods=" + HttpConstants.METHOD_POST,
		"sling.servlet.resourceTypes=" + "sling/servlet/default", "sling.servlet.selectors=" + "merclinkquickordersingleitems",
		"sling.servlet.extensions=" + "json" })
public class QuickOrderSingleItem extends SlingAllMethodsServlet{
	private static final Logger LOG = LoggerFactory.getLogger(QuickOrderSingleItem.class);
	private static final long serialVersionUID = 1L;
	String currentPagePath;
	String customerNumber = StringUtils.EMPTY;
	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		
	}
}
