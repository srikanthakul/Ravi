package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.Servlet;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "= Invoice Download Servlet",
        "sling.servlet.methods=" + HttpConstants.METHOD_POST,
        "sling.servlet.paths=" + "/bin/merclink/invoiceMercdownload" })
public class ANZPInvoiceDownloadServlet extends SlingAllMethodsServlet {

    private static final long serialVersionUID = 1L;
    @Reference
    transient EcommSessionService adminService;
    @Reference
    transient APIGEEService apigeeService;
    private static final Logger LOG = LoggerFactory.getLogger(ANZPInvoiceDownloadServlet.class);

    @Override
    public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
        LOG.debug("inside do get Merclink Product Superssion");
        ResourceResolver resourceResolver = null;
        byte[] bytes = null;
        OutputStream responseOutputStream = null;
        try {
            resourceResolver = adminService.getWriteServiceResourceResolver();
            LOG.info("inside Invoice download of do post");

            String url = request.getParameter("pdf_hidden_url");
            String currentPage = request.getParameter("currentPage");
            LOG.info("pdf_url {}", url);
            String urlName = url.substring(url.lastIndexOf("/") + 1);
            LOG.info("pdf_url_after_split {}", urlName);
            bytes = apigeeService.getinvoiceMercdownload(adminService.getWriteServiceResourceResolver(), currentPage,
                    url);

            responseOutputStream = response.getOutputStream();
            response.setContentType("application/pdf");
            response.addHeader("Content-Disposition", "inline; filename=" + urlName + ".pdf");

            for (int i = 0; i < bytes.length; i++) {
                responseOutputStream.write(bytes[i]);

            }

        } catch (Exception e) {
            LOG.error("JSON/Login exception occurred %f", e);
        } finally {
            adminService.closeResourceResolver(resourceResolver);

            if (responseOutputStream != null) {
                responseOutputStream.flush();

                responseOutputStream.close();
            }
        }
    }

}