package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.http.Cookie;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.beans.ANZPInvoiceParamBean;
import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.google.gson.Gson;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "= Start a Invoice",
		"sling.servlet.methods=" + HttpConstants.METHOD_GET, "sling.servlet.paths=" + "/bin/merclink/invoiceMerclink" })
public class ANZPInvoiceServlet  extends SlingAllMethodsServlet {
	private static final long serialVersionUID = 1L;
	@Reference
	transient EcommSessionService adminService;
	@Reference
	transient APIGEEService apigee;
	private static final Logger LOG = LoggerFactory.getLogger(ANZPInvoiceServlet.class);
	
	@Override
	public void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.info("inside do get InvoiceServlet");
		Gson gson = new Gson();
		String currentPage;
		ResourceResolver resolver = null;
		try {
			resolver = adminService.getWriteServiceResourceResolver();
			LOG.debug("resolver: {}", resolver);
			if(resolver != null){
				if (request.getParameter("data") != null) {
					JSONObject requestdata = new JSONObject(request.getParameter("data"));
					currentPage = requestdata.getString("currentPage");
					ANZPInvoiceParamBean anzpInvoiceParamBean = gson.fromJson(request.getParameter("data"),
							ANZPInvoiceParamBean.class);
						
					anzpInvoiceParamBean.setCustomerNumber(requestdata.getString("customerNumber"));
					if(requestdata.getString("start_date") != null) {
					anzpInvoiceParamBean.setStart_date(requestdata.getString("start_date"));
					}
					if(requestdata.getString("end_date") != null) {
					anzpInvoiceParamBean.setEnd_date(requestdata.getString("end_date"));
					}
					if(requestdata.getString("orderNumber") != null) {
					anzpInvoiceParamBean.setOrderNumber(requestdata.getString("orderNumber"));
					}
					if(requestdata.getString("invoiceNumber") != null) {
					anzpInvoiceParamBean.setInvoiceNumber(requestdata.getString("invoiceNumber"));
					}
					LOG.info(" customer number-------- {}",requestdata.getString("customerNumber"));
					LOG.info(" start_date-------- {}",requestdata.getString("start_date"));
					LOG.info(" end_date -------- {}",requestdata.getString("end_date"));
					LOG.info(" currentPage -------- {}",requestdata.getString("currentPage"));
					LOG.info(" invoiceNumber -------- {}",requestdata.getString("invoiceNumber"));
					LOG.info(" orderNumber -------- {}",requestdata.getString("orderNumber"));
					JSONObject invoiceJson = apigee.getinvoiceMerclink(resolver, currentPage, anzpInvoiceParamBean);
					LOG.info("data-------------------{}", invoiceJson);
					setResponseData(response, invoiceJson);
				}
			}			
		} catch (Exception e) {
			LOG.error("Exception occured %f", e);
		} finally {
			adminService.closeResourceResolver(resolver);
		}
	}

	private void setResponseData(SlingHttpServletResponse response, JSONObject invoiceJson2) throws IOException{
		response.setContentType("application/json");
		response.getWriter().println(invoiceJson2);
		response.getWriter().flush();
		response.getWriter().close();
	}
}
