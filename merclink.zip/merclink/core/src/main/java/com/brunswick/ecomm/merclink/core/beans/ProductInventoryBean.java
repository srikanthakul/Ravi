package com.brunswick.ecomm.merclink.core.beans;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductInventoryBean {
	
	@JsonProperty("status")
	private InventoryStatus status;
	
	@JsonProperty("warehouses")
	private List<WareHouses> warehouses;
	
	@JsonProperty("total_quantity")
	private int total_quantity;
	
	@Optional
	@JsonProperty("date")
	private String date;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ProductInventoryBean.class);

	/**
	 * @return the status
	 */
	public final InventoryStatus getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public final void setStatus(InventoryStatus status) {
		this.status = status;
	}

	/**
	 * @return the warehouses
	 */
	public final List<WareHouses> getWarehouses() {
		if(warehouses!=null) {
			return new ArrayList<>(warehouses);
		}
		return null;
	}

	/**
	 * @param warehouses the warehouses to set
	 */
	public final void setWarehouses(List<WareHouses> warehouses) {
		if(warehouses!=null) {
			this.warehouses = new ArrayList<>(warehouses);
		}
	}

	public int getTotal_quantity() {
		setTotal_quantity(total_quantity);
		LOGGER.info("Total Quantity for getter : "+total_quantity);
		return total_quantity;
	}

	public void setTotal_quantity(int total_quantity) {
		this.total_quantity=0;
		LOGGER.info("Total Quantity for setter : "+total_quantity);
		List<WareHouses> wareHouses= new ArrayList<>();
		if(this.getWarehouses()!=null) {
			wareHouses = this.getWarehouses();
			for(WareHouses w : wareHouses)
			{
				WareHouse tempWareHouse=w.getWarehouse();
				String name= tempWareHouse.getName().toUpperCase();
				if(name.startsWith("DEL"))
				{
					LOGGER.info("Total Quantity in loop : "+this.total_quantity);
					this.total_quantity += w.getQuantity();
				}
			}
			LOGGER.info("Final Total Quantity : "+this.total_quantity);
		}
	}	

	/**
	 * @return the date
	 */
	public final String getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public final void setDate(String date) {
		this.date = date;
	}
}
