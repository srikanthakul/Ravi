package com.brunswick.ecomm.merclink.core.beans.personalinformation;

import org.apache.sling.models.annotations.Optional;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
public class Region {
	
	
	@Optional
	@JsonProperty("region")
	 private String region;
	
	@JsonProperty("region_code")
	 private String region_code;
	
	@JsonProperty("region_id")
	 private Integer region_id;

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getRegion_code() {
		return region_code;
	}

	public void setRegion_code(String region_code) {
		this.region_code = region_code;
	}

	public Integer getRegion_id() {
		return region_id;
	}

	public void setRegion_id(Integer region_id) {
		this.region_id = region_id;
	}

	
}
