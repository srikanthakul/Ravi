package com.brunswick.ecomm.merclink.core.beans.checkout;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PlaceOrderBean {
	private String cartId;
	private String ponumber;
	private String ordercomment;
	private String requestedshipdate;
	private String credit_card_approval_code;
	private String credit_card_approval_date;
	private String credit_card_token;
	private String credit_card_holder_name;
	private String credit_card_expiration_date;
	private String payment_method;
	private String shipping_method;
	private String shipping_cost;
	private String shipping_discount_amount;
	private String shipping_tax_amount;
	private String csRequestId;
	private String collectAccNumber;
	
	public final String getCollectAccNumber() {
		return collectAccNumber;
	}
	public final void setCollectAccNumber(String collectAccNumber) {
		this.collectAccNumber = collectAccNumber;
	}
	public String getCsRequestId() {
		return csRequestId;
	}
	public void setCsRequestId(String csRequestId) {
		this.csRequestId = csRequestId;
	}
	public String getCredit_card_approval_code() {
		return credit_card_approval_code;
	}
	public void setCredit_card_approval_code(String credit_card_approval_code) {
		this.credit_card_approval_code = credit_card_approval_code;
	}
	public String getCredit_card_approval_date() {
		return credit_card_approval_date;
	}
	public void setCredit_card_approval_date(String credit_card_approval_date) {
		this.credit_card_approval_date = credit_card_approval_date;
	}
	public String getCredit_card_token() {
		return credit_card_token;
	}
	public void setCredit_card_token(String credit_card_token) {
		this.credit_card_token = credit_card_token;
	}
	public String getCredit_card_holder_name() {
		return credit_card_holder_name;
	}
	public void setCredit_card_holder_name(String credit_card_holder_name) {
		this.credit_card_holder_name = credit_card_holder_name;
	}
	public String getCredit_card_expiration_date() {
		return credit_card_expiration_date;
	}
	public void setCredit_card_expiration_date(String credit_card_expiration_date) {
		this.credit_card_expiration_date = credit_card_expiration_date;
	}
	public String getPayment_method() {
		return payment_method;
	}
	public void setPayment_method(String payment_method) {
		this.payment_method = payment_method;
	}
	public String getShipping_method() {
		return shipping_method;
	}
	public void setShipping_method(String shipping_method) {
		this.shipping_method = shipping_method;
	}
	public String getShipping_cost() {
		return shipping_cost;
	}
	public void setShipping_cost(String shipping_cost) {
		this.shipping_cost = shipping_cost;
	}
	public String getShipping_discount_amount() {
		return shipping_discount_amount;
	}
	public void setShipping_discount_amount(String shipping_discount_amount) {
		this.shipping_discount_amount = shipping_discount_amount;
	}
	public String getShipping_tax_amount() {
		return shipping_tax_amount;
	}
	public void setShipping_tax_amount(String shipping_tax_amount) {
		this.shipping_tax_amount = shipping_tax_amount;
	}
	public String getCartId() {
		return cartId;
	}
	public void setCartId(String cartId) {
		this.cartId = cartId;
	}
	public String getPonumber() {
		return ponumber;
	}
	public void setPonumber(String ponumber) {
		this.ponumber = ponumber;
	}
	public String getOrdercomment() {
		return ordercomment;
	}
	public void setOrdercomment(String ordercomment) {
		this.ordercomment = ordercomment;
	}
	public String getRequestedshipdate() {
		return requestedshipdate;
	}
	public void setRequestedshipdate(String requestedshipdate) {
		this.requestedshipdate = requestedshipdate;
	}
}
