package com.brunswick.ecomm.merclink.core.models;

public class FacetOption {
	String attrCode;
	String attrLabel;
	String attrCount;
	public String getAttrCode() {
		return attrCode;
	}
	public void setAttrCode(String attrCode) {
		this.attrCode = attrCode;
	}
	public String getAttrLabel() {
		return attrLabel;
	}
	public void setAttrLabel(String attrLabel) {
		this.attrLabel = attrLabel;
	}
	public String getAttrCount() {
		return attrCount;
	}
	public void setAttrCount(String attrCount) {
		this.attrCount = attrCount;
	}

}
