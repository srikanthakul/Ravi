package com.brunswick.ecomm.merclink.core.models.impl;

import java.util.List;
import java.util.Map;

import com.brunswick.ecomm.merclink.core.models.CustomBreadcrumb;
import com.brunswick.ecomm.merclink.core.models.FaqModel;

import java.util.ArrayList;
import java.util.HashMap;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;

@Model(
		adaptables = Resource.class,
		adapters = CustomBreadcrumb.class,
		 defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
		)
public class CustomBreadcrumbImpl implements CustomBreadcrumb {
	
private static final Logger LOG = LoggerFactory.getLogger(CustomBreadcrumbImpl.class);
	
	@SlingObject
	Resource componentResource;
	
    
	@Override
	public List<Map<String, String>> getNavDetails() {
        List<Map<String, String>> navDetails=new ArrayList<>();
        try {
            Resource navDetail=componentResource.getChild("navItemList");
            if(navDetail!=null){
                for (Resource nav : navDetail.getChildren()) {
                    Map<String,String> navMap=new HashMap<>();
                    navMap.put("pagelabel",nav.getValueMap().get("pagelabel",String.class));
                    navMap.put("pagelink",nav.getValueMap().get("pagelink",String.class));
                    navDetails.add(navMap);
                }
            }
        }catch (Exception e){
            LOG.info("\n ERROR while getting Nav Details {} ",e.getMessage());
        }
        LOG.info("\n SIZE {} ",navDetails.size());
        return navDetails;
	}

}
