package com.brunswick.ecomm.merclink.core.models.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.models.NewsListing;

@Model(adaptables = Resource.class, adapters = NewsListing.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class NewsListingImpl implements NewsListing {

	private static final Logger LOG = LoggerFactory.getLogger(NewsListingImpl.class);

	@SlingObject
	Resource componentResource;

	@ValueMapValue
	private String newsHeading;

	@ValueMapValue
	private List<String> news;

	@Inject
	private ResourceResolver resolver;

	@Override
	public List<Map<String, String>> getNewsDetails() {
		List<Map<String, String>> newsDetails = new ArrayList<>();
		try {
			LOG.info("\n componentResource {}", componentResource.getValueMap().get("parentPage", String.class));
			String parentPath = componentResource.getValueMap().get("parentPage", String.class);
			Integer maxItem = componentResource.getValueMap().get("maxItems", Integer.class);
			Resource parentPagePath = resolver.getResource(parentPath);
			if (parentPagePath != null) {
				Integer itemCount = 0;
				for (Resource pagePath : parentPagePath.getChildren()) {
					LOG.info("\n pagePath  {}", pagePath.getPath());
					Resource currentDataPath = resolver
							.getResource(pagePath.getPath() + "/jcr:content/root/container/container/news");
					if (currentDataPath != null) {
						if (itemCount < maxItem) {
							ValueMap property = currentDataPath.getValueMap();
							Map<String, String> newsMap = new HashMap<>();
							newsMap.put("currentnewslinktext", property.get("currentnewslinktext", String.class));
							newsMap.put("currentnewsdata", property.get("currentnewsdata", String.class));
							newsMap.put("currentnewsicons", property.get("currentnewsicons", String.class));
							newsMap.put("currentnewslink", pagePath.getPath().toString());
							newsMap.put("currentnewspdf", property.get("currentnewspdf", String.class));
							newsMap.put("currentnewslctn", property.get("currentnewslctn", String.class));
							newsMap.put("currentnewsdt", property.get("currentnewsdt", String.class));
							LOG.info("\n news item  {}", newsMap);
							newsDetails.add(newsMap);
							itemCount++;
						}
					}

				}
			}
		} catch (Exception e) {
			LOG.info("\n ERROR while getting Current News Section {} ", e.getMessage());

		}
		return newsDetails;
	}

	@Override
	public String getNewsHeading() {
		try {
			newsHeading = componentResource.getValueMap().get("currentnewsheading", String.class);
		} catch (Exception e) {
			LOG.info("\n ERROR while getting Current News Section {} ", e.getMessage());

		}
		return newsHeading;
	}

}
