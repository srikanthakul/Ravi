package com.brunswick.ecomm.merclink.core.servlets;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.http.Cookie;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractRecentOrderRetriever;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.JsonObject;

@Component(service = Servlet.class,property = {
        Constants.SERVICE_DESCRIPTION + "=Customer Details Servlet",
        "sling.servlet.methods="+HttpConstants.METHOD_POST, "sling.servlet.paths="
        + "/bin/anzpGetCustomerDetails"
})
public class HomePageGetCustomerDetailsServlet extends SlingAllMethodsServlet{
    
	private static final long serialVersionUID = 1L;
    private static final Logger LOG=LoggerFactory.getLogger(HomePageGetCustomerDetailsServlet.class);
    String currentPagePath;
    String customerNumber = StringUtils.EMPTY;
    
	@Override
    public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		JSONObject requestObj;
		PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
		try {
			requestObj = new JSONObject(request.getParameter("data"));
			currentPagePath = requestObj.get("resourcePath").toString();
			LOG.info("currentPagePath=="+currentPagePath);
			Resource res = request.getResourceResolver().resolve(currentPagePath);
			
			String token=requestObj.get("token").toString();
			LOG.info("token=="+token);
			List<Header> headers = new ArrayList<>();
			headers.add(new BasicHeader("Authorization",
					"Bearer " + token));
			MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(res,
					pageManager.getPage(res.getPath()), request, headers);
			AbstractRecentOrderRetriever recentorderRetriever;
			recentorderRetriever = new AbstractRecentOrderRetriever(magentoGraphqlClient);
			JsonObject orders=	recentorderRetriever.getCustomerDetails();
			LOG.info("orders----"+orders.toString());
			customerNumber=orders.getAsJsonObject("customer").get("customer_number").getAsString();
			LOG.info("Customer number in homepagegetcustomerdetailsservelet---"+customerNumber);
			setCookie(response,"customerNumber");
			  response.setContentType("application/json");
		        response.getWriter().print(orders);
		        response.setStatus(response.getStatus());
		} catch (JSONException e) {
			  LOG.error("context", e);
		}         
         
    }
	
	private void setCookie(SlingHttpServletResponse response, String name) {

		Cookie cookie = new Cookie(name, customerNumber);
		cookie.setMaxAge(-1);
		cookie.setPath("/");
		response.addCookie(cookie);
	}


}

 

