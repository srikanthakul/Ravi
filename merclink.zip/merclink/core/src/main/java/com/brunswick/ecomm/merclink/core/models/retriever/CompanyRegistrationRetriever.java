package com.brunswick.ecomm.merclink.core.models.retriever;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Country;
import com.adobe.cq.commerce.magento.graphql.CountryQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Operations;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.QueryQuery;
import com.adobe.cq.commerce.magento.graphql.Region;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.google.gson.JsonObject;

public class CompanyRegistrationRetriever extends AbstractCustomRetriever {

	private static final Logger LOGGER = LoggerFactory.getLogger(CompanyRegistrationRetriever.class);

	public CompanyRegistrationRetriever(MagentoGraphqlClient client) {
		super(client);
	}

	@Override
	protected void populate() {

	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return client.execute(query);
	}

	protected GraphqlResponse<JsonObject, Error> executeMutation() {
		return client.executeJsonMutation(query);
	}
	protected GraphqlResponse<JsonObject, Error> executeJsonQuery() {
		return client.executeQuery(query);
	}

	public JsonObject createCompany(Map<String, String> filtereddata) {
		query = generateCompanyQuery(filtereddata);
		LOGGER.debug("Customer Registration Query==" + query);
		GraphqlResponse<JsonObject, Error> response = executeMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			for (Error err:errors ) {
				if(err.getMessage().equalsIgnoreCase("A customer with the same email address already exists in an associated website")) {
					JsonObject errRes = new JsonObject();
					
					errRes.addProperty("createCompany", "A customer with the same email address already exists in an associated website");
					return errRes;
				}
				else if(err.getMessage().equalsIgnoreCase("A customer with the same email address already exists in an associated website.")) {
					JsonObject errRes = new JsonObject();
					
					errRes.addProperty("createCompany", "A customer with the same email address already exists in an associated website.");
					return errRes;
				}
				else if(err.getMessage().equalsIgnoreCase("Account already exits based upon email domain.Please contact Sales Support")) {
					JsonObject errRes = new JsonObject();
					
					errRes.addProperty("createCompany", "Account already exits based upon email domain.Please contact Sales Support");
					return errRes;
				}
			}
		}
		return response.getData();
	}

	public JsonObject getClassifications() {
		GraphqlResponse<JsonObject, Error> response = client.executeQuery("query { getCustomerClassification {data { code label}}}");
		return response.getData().getAsJsonObject("getCustomerClassification");
	}


	private String generateCompanyQuery(Map<String, String> data) {

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("mutation {createCompany(input: {");
		queryBuilder.append("company_name: \"" + data.get("company_name") + "\" ");
		queryBuilder.append("company_email: \"" + data.get("emailbusiness") + "\" ");
		queryBuilder.append("company_admin: {email:\"" + data.get("emailbusiness") + "\" ");
		queryBuilder.append("firstname: \"" + data.get("bfname") + "\" ");
		queryBuilder.append("lastname: \"" + data.get("blname") + "\" ");
		queryBuilder.append("} telephone: \"" + data.get("phonenobusiness") + "\" ");
		queryBuilder.append("customer_type: \"" + data.get("classification") + "\" ");
		queryBuilder.append("billing_address: { firstname: \"" + data.get("billfname") + "\" ");
		queryBuilder.append("lastname: \"" + data.get("billlname") + "\" ");
		queryBuilder.append("city: \"" + data.get("billcity") + "\" ");
		queryBuilder.append("region: { region:  \"" + data.get("billStateName") + "\" ");
		queryBuilder.append("region_code:  \"" + data.get("billStateId") + "\"");
		//queryBuilder.append("region_id: \"" + data.get("selectStatebtnbill") + "\"");
		queryBuilder.append("} country_code:  " + data.get("billCountry") + " ");
		queryBuilder.append("street:[\"" + data.get("billStreet") + "\"] ");
		queryBuilder.append("postcode: \"" + data.get("billpost") + "\" ");
		queryBuilder.append("address_type: \"billing\" primary_flag: \"Y\" } shipping_address: {");
		queryBuilder.append("firstname: \"" + data.get("shipfname") + "\" ");
		queryBuilder.append("lastname: \"" + data.get("shiplname") + "\" ");
		queryBuilder.append("region: { region:\"" + data.get("shipStateName") + "\" ");
		queryBuilder.append("region_code:\"" + data.get("shipStateId") + "\"");
		//queryBuilder.append("region_id: \"" + data.get("regionShip") + "\" } ");
		queryBuilder.append("} country_code: " + data.get("shipCountry") + " ");
		queryBuilder.append("address_type: \"shipping\" ");
		queryBuilder.append("street: [\"" + data.get("shipStreet") + "\"] ");
		queryBuilder.append("postcode: \"" + data.get("shippost") + "\" ");
		queryBuilder.append("primary_flag: \"Y\" ");
		queryBuilder.append("city: \"" + data.get("shipcity")+ "\"} ");
		queryBuilder.append("legal_name: \"" + data.get("company_name")+ "\" ");
		queryBuilder.append("legal_address: { customer_address_id: 0 address_type:\"billing\" street:[\"" + data.get("billStreet") + "\"] ");
		queryBuilder.append("city: \"" + data.get("billcity") + "\" ");
		queryBuilder.append("region: { region_code:  \"" + data.get("billStateId") + "\"} ");
		queryBuilder.append("postcode: \"" + data.get("billpost") + "\" ");
		queryBuilder.append("telephone: \"" + data.get("phonenobusiness") + "\" ");
		queryBuilder.append("country_id: " + data.get("billCountry") + " ");
		queryBuilder.append("primary_flag:\"Y\"}}){ company { id name company_admin { email firstname lastname } }}}");
		

		return queryBuilder.toString();
	}
	public JsonObject getCountriesAsJson() {
		query = Operations.query(q -> q.countries(generateCountryQuery())).toString();
		LOGGER.debug("Country List Query==" + query);
		GraphqlResponse<JsonObject, Error> response = executeJsonQuery();
		return response.getData();
	}
	
	public List<Country> getCountryList() {
		query = Operations.query(q -> q.countries(generateCountryQuery())).toString();
		LOGGER.debug("Country List Query==" + query);
		GraphqlResponse<Query, Error> response = executeQuery();
		return response.getData().getCountries();
	}

	private CountryQueryDefinition generateCountryQuery() {
		return q -> {
			q.id().fullNameEnglish().threeLetterAbbreviation();
		};

	}

	public List<Region> getRegionList(String countryCode) {
		QueryQuery.CountryArgumentsDefinition args = s -> s.id(countryCode);
		query = Operations.query(query -> query.country(args, generateRegionListQuery())).toString();
		LOGGER.debug("Region List Query==" + query);
		GraphqlResponse<Query, Error> response = executeQuery();
		return response.getData().getCountry().getAvailableRegions();
	}

	private CountryQueryDefinition generateRegionListQuery() {
		return cqd -> cqd.id().fullNameEnglish().threeLetterAbbreviation().availableRegions(rqd -> rqd.code().name());
	}

	
}
