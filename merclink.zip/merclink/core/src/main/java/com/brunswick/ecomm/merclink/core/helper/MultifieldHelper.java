package com.brunswick.ecomm.merclink.core.helper;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MultifieldHelper {
	private static final Logger LOG = LoggerFactory.getLogger(MultifieldHelper.class);
	private String changeAccounttxt;
	private String managePaymenttxt;
	private String logoutTxt;
	private List<NastedHelper> myProfile;
	private String currentNewsLinkText;
	private String currentNewsData;
	private String currentNewsIcons;
	private String currentNewsLink;
	private String currentnewspdf;
	private String currentNewsDate;
	private String currentNewsLocation;
	
	

	public MultifieldHelper(Resource resource) {
		try {
			if(StringUtils.isNotBlank(resource.getValueMap().get("changeaccounttxt",String.class))) {
				this.changeAccounttxt = resource.getValueMap().get("changeaccounttxt", String.class);
			}
			if(StringUtils.isNotBlank(resource.getValueMap().get("managePaymenttxt",String.class))) {
				this.managePaymenttxt = resource.getValueMap().get("managePaymenttxt", String.class);
			}
			if(StringUtils.isNotBlank(resource.getValueMap().get("logoutTxt",String.class))) {
				this.logoutTxt = resource.getValueMap().get("logoutTxt", String.class);
			}
			
			if(StringUtils.isNotBlank(resource.getValueMap().get("currentnewslinktext",String.class))) {
				this.currentNewsLinkText = resource.getValueMap().get("currentnewslinktext", String.class);
			}
			if(StringUtils.isNotBlank(resource.getValueMap().get("currentnewsdata",String.class))) {
				this.currentNewsData = resource.getValueMap().get("currentnewsdata", String.class);
			}
			if(StringUtils.isNotBlank(resource.getValueMap().get("currentnewsicons",String.class))) {
				this.currentNewsIcons = resource.getValueMap().get("currentnewsicons", String.class);
			}
			if(StringUtils.isNotBlank(resource.getValueMap().get("currentnewslink",String.class))) {
				this.currentNewsLink = resource.getValueMap().get("currentnewslink", String.class);
			}
			if(StringUtils.isNotBlank(resource.getValueMap().get("currentnewspdf",String.class))) {
				this.currentnewspdf = resource.getValueMap().get("currentnewspdf", String.class);
			}
			if(StringUtils.isNotBlank(resource.getValueMap().get("currentnewsdt",String.class))) {
				this.currentNewsDate = resource.getValueMap().get("currentnewsdt", String.class);
			}
			if(StringUtils.isNotBlank(resource.getValueMap().get("currentnewslctn",String.class))) {
				this.currentNewsLocation = resource.getValueMap().get("currentnewslctn", String.class);
			}
		}catch(Exception e) {
			LOG.info("\n BEAN ERROR : {}",e.getMessage());
			
		}
		
	}
	
	public String getChangeAccountTxt() {
		return changeAccounttxt;
	}
	
	public String getManagePaymentTxt() {
		return managePaymenttxt;
	}
	
	public String getLogoutTxt() {
		return logoutTxt;
	}
	
	public List<NastedHelper> getMyProfile(){
		return new ArrayList<>(myProfile);
	}
	
	public void setMyProfile(List<NastedHelper> myProfile){
		this.myProfile = new ArrayList<>(myProfile);
	}

	public String getCurrentNewsLinkText() {
		return currentNewsLinkText;
	}

	public String getCurrentNewsData() {
		return currentNewsData;
	}

	public String getCurrentNewsIcons() {
		return currentNewsIcons;
	}

	public String getCurrentNewsLink() {
		return currentNewsLink;
	}
	
	public String getCurrentnewspdf() {
		return currentnewspdf;
	}

	public String getCurrentNewsDate() {
		return currentNewsDate;
	}

	public String getCurrentNewsLocation() {
		return currentNewsLocation;
	}


}
