package com.brunswick.ecomm.merclink.core.models.retriever;
import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.google.gson.JsonObject;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AbstractQuickOrderRetriever extends AbstractCustomRetriever{
    Customer customer;
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractQuickOrderRetriever.class);
	private String query;
	
	enum User {
		  ACTIVE
		}

	public AbstractQuickOrderRetriever(MagentoGraphqlClient client) {
		super(client);

	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return client.execute(query);
	}

	protected GraphqlResponse<JsonObject, Error> excecuteQueryGraphql() {
		return client.executeQuery(query);
	}

	protected GraphqlResponse<Mutation, Error> executeMutation() {
		return client.executeMutation(query);
	}

	protected GraphqlResponse<JsonObject, Error> excecuteJsonMutation() {
		return client.executeJsonMutation(query);
	}

	@Override
	protected void populate() {
		// Nothing to do
	}

    /**
	 * creating query and return .
	 */
	public JsonObject quickOrderSingleItem(String sku, String customer_number) {
		try {
			query = generatequickOrderSingleItemQuery(sku, customer_number);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" quickOrderSingleItem==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  quickOrderSingleItem  ==" + error.getMessage());
				errorjsonobject.addProperty("quickOrderSingleItem", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" quickOrderSingleItem ==" +response.getData());
		return response.getData();
	}
	
	/**
	 * creating query to change email.
	 */
	private String generatequickOrderSingleItemQuery(String sku, String customer_number) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();
		
		_queryBuilder.append("{ ");
		_queryBuilder.append(" quickOrderProductsAnzp( ");
		_queryBuilder.append(" filter: { sku: { in: [\"" + sku + "\"] }}");
		_queryBuilder.append(" pageSize: 999");
		_queryBuilder.append(" erpData: {");
		_queryBuilder.append(" customer_number :\""+ customer_number + "\"");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" ) { ");
		_queryBuilder.append(" items { ");
		_queryBuilder.append(" id ");
		_queryBuilder.append(" sku ");
		_queryBuilder.append(" stock_status ");
		_queryBuilder.append(" masterpartlowestsellinguomqty ");
		_queryBuilder.append(" item_number ");
		_queryBuilder.append(" ss_item_number ");
		_queryBuilder.append(" description ");
		_queryBuilder.append(" availability ");
		_queryBuilder.append(" warehouse_total ");
		_queryBuilder.append(" estimated_availability_date ");
		_queryBuilder.append("  }");
		_queryBuilder.append(" user_errors { ");
		_queryBuilder.append(" message ");
		_queryBuilder.append(" }");
		_queryBuilder.append(" }");
		_queryBuilder.append("}");

		return _queryBuilder.toString();
	}

	public JsonObject bulkItemSearch(String sku, String customer_number) {
		try {
			query = generatebulkItemSearchQuery(sku, customer_number);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" bulkItemSearch==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  bulkItemSearch  ==" + error.getMessage());
				errorjsonobject.addProperty("bulkItemSearch", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" bulkItemSearch ==" + response.getData());
		return response.getData();
	}

	/**
	 * creating query to change email.
	 */
	private String generatebulkItemSearchQuery(String sku, String customer_number) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();

		_queryBuilder.append("{ ");
		_queryBuilder.append(" quickOrderProductsAnzp( ");
		_queryBuilder.append(" filter: { sku: { in: [\"" + sku + "\"] }}");
		_queryBuilder.append(" pageSize: 999");
		_queryBuilder.append(" erpData: {");
		_queryBuilder.append(" customer_number :\"" + customer_number + "\"");
		_queryBuilder.append(" is_bulk_order:true");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" ) { ");
		_queryBuilder.append(" items { ");
		_queryBuilder.append(" id ");
		_queryBuilder.append(" sku ");
		_queryBuilder.append(" item_number ");
		_queryBuilder.append(" ss_item_number ");
		_queryBuilder.append(" description ");
		_queryBuilder.append(" masterpartlowestsellinguomqty ");
		_queryBuilder.append(" mp_pkg_ea_weight_uom_metric ");
		_queryBuilder.append(" mp_pkg_ea_weight_metric ");
		_queryBuilder.append("  }");
		_queryBuilder.append(" user_errors { ");
		_queryBuilder.append(" message ");
		_queryBuilder.append(" }");
		_queryBuilder.append(" }");
		_queryBuilder.append("}");

		return _queryBuilder.toString();
	}
}