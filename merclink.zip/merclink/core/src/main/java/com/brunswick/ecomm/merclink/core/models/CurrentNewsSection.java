package com.brunswick.ecomm.merclink.core.models;

import java.util.List;

import com.brunswick.ecomm.merclink.core.helper.MultifieldHelper;

public interface CurrentNewsSection {
	
	String getCurrentNewsHeading();
	List<MultifieldHelper> getCurrentNewsDetails();
	
	
	
}