package com.brunswick.ecomm.merclink.core.models;

import java.util.List;
import java.util.Map;

public interface NewsListing {
	String getNewsHeading();

	List<Map<String, String>> getNewsDetails();
}