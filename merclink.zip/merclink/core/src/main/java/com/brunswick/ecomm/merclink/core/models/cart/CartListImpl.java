package com.brunswick.ecomm.merclink.core.models.cart;

import com.adobe.cq.commerce.graphql.client.RequestOptions;
import com.adobe.cq.commerce.magento.graphql.Cart;
import com.adobe.cq.commerce.magento.graphql.CartItemInterface;
import com.adobe.cq.commerce.magento.graphql.ProductInterface;
import com.adobe.cq.commerce.magento.graphql.Wishlist;
import com.adobe.cq.commerce.magento.graphql.WishlistItemInterface;
import com.adobe.cq.sightly.SightlyWCMMode;
import com.brunswick.ecomm.core.services.EcommSAMLService;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.HomePageHeaderModel;
//import com.brunswick.ecomm.merclink.core.models.retriever.AbstractWishlistDetailsRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.brunswick.ecomm.merclink.core.models.cart.retriever.AbstractCartRetriever;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.designer.Style;
import com.google.gson.Gson;
import com.google.gson.JsonNull;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.xss.XSSAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

@Model(
        adaptables = {SlingHttpServletRequest.class,Resource.class},
        adapters = CartList.class,
        resourceType = {CartListImpl.RESOURCE_TYPE,"delcity/components/content/ordersummary"})
public class CartListImpl implements CartList {

    public static final String CART_ITEM_ID = "item_id";
    public static final String CART_ID = "cart_id";
    protected static final String RESOURCE_TYPE = "delcity/components/content/cartlisting";
    private static final Logger LOGGER = LoggerFactory.getLogger(CartListImpl.class);

    @Self
    private SlingHttpServletRequest request;

    @Inject
    private Resource resource;

    @Inject
    private Page currentPage;

//    @Inject
//    private UrlProvider urlProvider;
  /*  
    @Inject
    private String customerToken;
    
    @Inject
    private String cartId;

    @ScriptVariable
    private Style currentStyle;

    @ScriptVariable
    private ValueMap properties;

    @ScriptVariable(name = "wcmmode")
    private SightlyWCMMode wcmMode;*/
    private String cartId;

    private AbstractCartRetriever cartRetriever;

    private String error;
    
    private Cart cart =null;
    
    private String changePasswordUrl;
    EcommSAMLService ecommSAMLService;
    
    @PostConstruct
    protected void initModel() {
    	String customerToken = CommonUtil.getTokenFromCookie("customerToken",request);
    	cartId= CommonUtil.getTokenFromCookie("cartId",request);
    	    	
    	
    	LOGGER.info("cartId is {} ", cartId);

        LOGGER.info("customerToken is -----------------------------------{} ", customerToken);
        List<Header> headers = new ArrayList<>();
        if (null != customerToken && ! customerToken.isEmpty() && ! customerToken.equals("1")) {
            headers.add(new BasicHeader("Authorization", "Bearer " + customerToken));
            RequestOptions requestOptions = new RequestOptions();
            requestOptions.withHeaders(headers);
            MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(resource, currentPage, null, headers);
            if (null != magentoGraphqlClient && null != cartId && ! cartId.isEmpty()) {
                cartRetriever = new CartRetriever(magentoGraphqlClient);
                cartRetriever.setCartId(cartId);
                cartRetriever.setLoggedIn(true);
            }
            else if (null != magentoGraphqlClient && (null == cartId || cartId.isEmpty())) {
            	LOGGER.info("logged in create cart");
            	cartRetriever = new CartRetriever(magentoGraphqlClient);
            	cartId = cartRetriever.createEmptyCart();
            	request.getSession().setAttribute("cartId", cartId);
            	cartRetriever.setLoggedIn(true);
            }
        } else if (null != cartId && !cartId.isEmpty()) {
            // Get MagentoGraphqlClient from the resource.
            MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(resource, currentPage, null, null);
            if (null != magentoGraphqlClient) {
            	 cartRetriever = new CartRetriever(magentoGraphqlClient);
                 cartRetriever.setCartId(cartId);
                cartRetriever.setLoggedIn(false);
            }
        } 
        else if ((null == cartId ||cartId.isEmpty()) && (null == customerToken || customerToken.isEmpty() || customerToken == "1")) {
        	MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(resource, currentPage, null, null);
        	cartRetriever = new CartRetriever(magentoGraphqlClient);
        	LOGGER.info("create a cart with cartId");
        	cartId = cartRetriever.createEmptyCart();
        	cartRetriever.setCartId(cartId);
        	cartRetriever.setLoggedIn(false);
        	request.getSession().setAttribute("cartId", cartId);
        	LOGGER.info("created a cart with cartId-"+cartId);
        }
        
        else{
            error = "Something Went Wrong";
            LOGGER.info(""+error);
        }
        cart = this.getCart();
    }

    public String getCartId() {
		return cartId;
	}

	@Override
    public Cart getCart() {
		if(cart == null) {
    	LOGGER.info("getCart:----------"+cartRetriever.fetchCart());
        return cartRetriever != null ? cartRetriever.fetchCart() : null;
		}
		return cart;
    }

    @Override
    public String getError(){
    	LOGGER.info("error:----------"+error);
        return error;
    }
    
	public Map<String,String> getProp65Code(){
		LOGGER.info("in getprop65");
		Map<String,String> prop65map= new HashMap<>();
		if(getCart()!=null) {
			List<CartItemInterface> getCart=getCart().getItems();
				for(CartItemInterface item:getCart) {		
					prop65map.put(item.getProduct().getSku(),item.getProduct().get("masterpartprop65code").toString().replace("\"",""));
					}

		}
		return prop65map;
	}
	public Map<String,String> getMinQuantity(){
		LOGGER.info("in getMinQuantity");
		Map<String,String> getMinQuantity= new HashMap<>();
		if(getCart()!=null) {
			List<CartItemInterface> getCart=getCart().getItems();
				for(CartItemInterface item:getCart) {	
					if(item.getProduct().get("masterpartlowestsellinguomqty").toString().replace("\"","").equals("0") || item.getProduct().get("masterpartlowestsellinguomqty") == null ) {
						getMinQuantity.put(item.getProduct().getSku(),"1");
					}
					else {
					getMinQuantity.put(item.getProduct().getSku(),item.getProduct().get("masterpartlowestsellinguomqty").toString().replace("\"",""));
					}
				}

		}
		return getMinQuantity;
	}
	public Map<String,Object> getBackorderQty() {
		Map<String,Object> getBackorderQty= new HashMap<>();
		if(getCart()!=null) {			
			List<CartItemInterface> getCart=getCart().getItems();
				for(CartItemInterface item:getCart) {
					String[] str=item.get("item_attributes").toString().split(":");
					String[] backorderQuantity= str[1].split(",");
					Integer qty = Integer.parseInt(backorderQuantity[0]);
					getBackorderQty.put(item.getProduct().getSku(),qty);
					}

		}
		return getBackorderQty;
	}
	public Map<String,Object> getAvailableDate() {
		Map<String,Object> getAvailableDate= new HashMap<>();
		if(getCart()!=null) {			
			List<CartItemInterface> getCart=getCart().getItems();
				for(CartItemInterface item:getCart) {
					String[] str=item.get("item_attributes").toString().split(":");
					String[] availableDate= str[2].split("}");
					if(availableDate !=null && availableDate[0] !=null && ! availableDate[0].isEmpty() && availableDate[0].length() !=0) {
						LOGGER.info("qtynot null -------"+availableDate[0]);
						getAvailableDate.put(item.getProduct().getSku(),availableDate[0]);
					}
					else {
						getAvailableDate.put(item.getProduct().getSku(),"N/A");
											
					}
					}

		}
		return getAvailableDate;
	}
	
	public Map<String,Object> getImageThumbnail() {
		Map<String,Object> getImageThumbnail= new HashMap<>();
		if(getCart()!=null) {			
			List<CartItemInterface> getCart=getCart().getItems();
				for(CartItemInterface item:getCart) {
					String str[]= item.getProduct().get("image_data").toString().split(",");
					LOGGER.info("productimage length=="+str[0].toString());
					String[] prodImage= str[0].split(":");
					LOGGER.info("productimage length=="+prodImage.length);
					if(prodImage.length>2) {
					if(!prodImage[1].isEmpty() && !prodImage[2].isEmpty() ) {
					LOGGER.info("productimage=="+prodImage[1]+":"+prodImage[2]);
					getImageThumbnail.put(item.getProduct().getSku(), prodImage[1].replace("\"","")+":"+prodImage[2].replace("\"}",""));
					}
					}else {
						getImageThumbnail.put(item.getProduct().getSku(), null);
					}					
					}

		}
		return getImageThumbnail;
	}
	public Integer getItemCount() {
		if(cart != null) {
			List<CartItemInterface> cartitems = cart.getItems();
			return cartitems.size();
		}
		return 0;
	}
}


