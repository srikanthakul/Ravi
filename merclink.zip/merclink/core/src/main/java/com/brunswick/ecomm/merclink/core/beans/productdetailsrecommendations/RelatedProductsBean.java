package com.brunswick.ecomm.merclink.core.beans.productdetailsrecommendations;

import org.apache.sling.models.annotations.Optional;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RelatedProductsBean {
	@Optional
	@JsonProperty("sku")
	 private String sku;
	@Optional
	@JsonProperty("name")
	 private String name;
	
	@Optional
	@JsonProperty("price_range")
	 private PriceRange price_range;
	@Optional
	@JsonProperty("image_data_custom_")
	 private imageBean image_data_custom_;
	

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public PriceRange getPrice_range() {
		return price_range;
	}

	public void setPrice_range(PriceRange price_range) {
		this.price_range = price_range;
	}

	public imageBean getImage_data_custom_() {
		return image_data_custom_;
	}

	public void setImage_data_custom_(imageBean image_data_custom_) {
		this.image_data_custom_ = image_data_custom_;
	}
	
	
	
}
