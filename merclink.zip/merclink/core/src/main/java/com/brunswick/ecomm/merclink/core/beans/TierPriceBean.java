package com.brunswick.ecomm.merclink.core.beans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TierPriceBean {

	@JsonProperty("name")
	private String name;
	
	@JsonProperty("price")
	private String price;

	/**
	 * @return the name
	 */
	public final String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public final void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the price
	 */
	public final String getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public final void setPrice(String price) {
		this.price = price;
	}
}
