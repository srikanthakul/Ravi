package com.brunswick.ecomm.merclink.core.beans.personalinformation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.sling.models.annotations.Optional;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerShippingAddressBean {
	@Optional
	@JsonProperty("id")
	private Integer id;
	@Optional
	@JsonProperty("customer_id")
	private Integer customer_id;
	@Optional
	@JsonProperty("firstname")
	private String firstname;
	@Optional
	@JsonProperty("lastname")
	private String lastname;
	@Optional
	@JsonProperty("street")
	private List<String> street;
	@Optional
	@JsonProperty("city")
	private String city;
	@Optional
	@JsonProperty("country_id")
	private String country_id;
	@Optional
	@JsonProperty("country_code")
	private String country_code;

	@Optional
	@JsonProperty("country_name")
	private String country_name;
	@Optional
	@JsonProperty("postcode")
	private String postcode;
	@Optional
	@JsonProperty("region_id")
	private Integer region_id;

	@JsonProperty("region")
	private String region;
	@Optional
	@JsonProperty("region_code")
	private String region_code;

	@Optional
	@JsonProperty("primary_flag")
	private String primary_flag;
	@Optional
	@JsonProperty("default_shipping")
	private Boolean default_shipping;
	@Optional
	@JsonProperty("default_billing")
	private Boolean default_billing;

	public String getRegion_code() {
		return region_code;
	}

	public void setRegion_code(String region_code) {
		this.region_code = region_code;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public List<String> getStreet() {
		if (street != null && street.get(0).contains("|")) {
			final String[] address = street.get(0).split("//|");
			street = Arrays.asList(address);
		}
		return new ArrayList<>(street);
	}

	public void setStreet(List<String> street) {
		this.street = new ArrayList<>(street);
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry_id() {
		return country_id;
	}

	public void setCountry_id(String country_id) {
		this.country_id = country_id;
	}

	public String getCountry_code() {
		return country_code;
	}

	public void setCountry_code(String country_code) {
		this.country_code = country_code;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getPrimary_flag() {
		return primary_flag;
	}

	public void setPrimary_flag(String primary_flag) {
		this.primary_flag = primary_flag;
	}

	public Boolean getDefault_shipping() {
		return default_shipping;
	}

	public void setDefault_shipping(Boolean default_shipping) {
		this.default_shipping = default_shipping;
	}

	public Boolean getDefault_billing() {
		return default_billing;
	}

	public void setDefault_billing(Boolean default_billing) {
		this.default_billing = default_billing;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(Integer customer_id) {
		this.customer_id = customer_id;
	}

	public Integer getRegion_id() {
		return region_id;
	}

	public void setRegion_id(Integer region_id) {
		this.region_id = region_id;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCountry_name() {
		return country_name;
	}

	public void setCountry_name(String country_name) {
		this.country_name = country_name;
	}

}
