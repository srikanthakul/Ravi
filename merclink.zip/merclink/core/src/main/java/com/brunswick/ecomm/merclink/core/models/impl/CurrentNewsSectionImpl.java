package com.brunswick.ecomm.merclink.core.models.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.helper.MultifieldHelper;
import com.brunswick.ecomm.merclink.core.models.CurrentNewsSection;

@Model(adaptables = Resource.class,
       adapters = CurrentNewsSection.class,
       defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
       )
public class CurrentNewsSectionImpl implements CurrentNewsSection{
	
	
	private static final Logger LOG = LoggerFactory.getLogger(CurrentNewsSectionImpl.class);
 
	@SlingObject
	Resource componentResource;
	
	@ValueMapValue
	@Default(values = "Current News")
	private String currentnewsheading;
	
	@ValueMapValue
	private List<String> news;
	
	@Override
	public List<MultifieldHelper> getCurrentNewsDetails() {
		List<MultifieldHelper> currentNewsDetails = new ArrayList<>();
		try {
			Resource currentNewssDetails = componentResource.getChild("currentnews");
			if(currentNewssDetails != null) {
				for (Resource currentNewss : currentNewssDetails.getChildren()) {
					LOG.info("\n PATH Current News {}",currentNewss.getPath());
					LOG.info("\n CURRENT NEWS PRO {}",currentNewss.getValueMap().get("currentnewslinktext",String.class));
					
					currentNewsDetails.add(new MultifieldHelper(currentNewss));
					
				}
				
			}
			
		}catch(Exception e) {
			LOG.info("\n ERROR while getting Current News Section {} ", e.getMessage());
			
		}
		return currentNewsDetails;
	}



	@Override
	public String getCurrentNewsHeading() {
		// TODO Auto-generated method stub
		return currentnewsheading;
	}

}
