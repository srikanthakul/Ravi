package com.brunswick.ecomm.merclink.core.models.retriever;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.google.gson.JsonObject;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AbstractQuoteRetriever extends AbstractCustomRetriever {
	Customer customer;
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractQuoteRetriever.class);
	private String query;
	
	enum User {
		  ACTIVE
		}

	public AbstractQuoteRetriever(MagentoGraphqlClient client) {
		super(client);

	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return client.execute(query);
	}

	protected GraphqlResponse<JsonObject, Error> excecuteQueryGraphql() {
		return client.executeQuery(query);
	}

	protected GraphqlResponse<Mutation, Error> executeMutation() {
		return client.executeMutation(query);
	}

	protected GraphqlResponse<JsonObject, Error> excecuteJsonMutation() {
		return client.executeJsonMutation(query);
	}

	@Override
	protected void populate() {
		// Nothing to do

	}

	/**
	 * Create and execute requestNegotiableQuote query.
	 * @param requestObj
	 * @return response
	 * @throws JSONException
	 */
	 
	public JsonObject createQuote(JSONObject requestObj) throws JSONException {
		query = generateCreateQuotesQueryDefinition(requestObj);
		LOGGER.info("QUERY==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in creating quote==" + error.getMessage());
				errorjsonobject.addProperty("quoteExists", error.getMessage());
			}
			return errorjsonobject;
		}
		//LOGGER.info(" creating quote number==" +response.getData().getAsJsonObject("requestNegotiableQuote").toString());
		return response.getData().getAsJsonObject("requestNegotiableQuote");
	}

	public JsonObject createManualLogin(String email) throws JSONException {
		query = generateCustomerToken(email);
		LOGGER.info("createManualLoginQUERY==" + query);
		
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		LOGGER.info("respons==" + response);
		
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in createManualLogin==" + error.getMessage());
				errorjsonobject.addProperty("createManualLogin", error.getMessage());
			}
			return errorjsonobject;
		}
		//LOGGER.info(" creating quote number==" +response.getData().getAsJsonObject("requestNegotiableQuote").toString());
		return response.getData().getAsJsonObject("generateCustomerTokenAsAdmin");
	}
	/**
	 * create requestNegotiableQuote query
	 * @param requestObj
	 * @return query
	 * @throws JSONException
	 */
	 
	private String generateCreateQuotesQueryDefinition(JSONObject requestObj) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();
		
		StringBuilder items = new StringBuilder();
		JSONArray array = requestObj.getJSONArray("items");
		int itemsLength = array.length();

		if (itemsLength > 0) {

			for (int i = 0; i < itemsLength; i++) {
				JSONObject item = array.getJSONObject(i);
				items.append("{ item_sku: \"" + item.getString("sku") + "\" ");
				items.append("order_quantity: " + item.getInt("quantity") + " ");
				items.append("estimated_annual_usage: \"" + item.getString("annualUsage") + "\" ");
				items.append("target_price: \"" + item.getString("targetPrice") + "\" } ");
			}
		}

		_queryBuilder.append("mutation { requestNegotiableQuote( input: { ");
		_queryBuilder.append("quote_name: \"" + requestObj.getString("quote_name") + "\" ");
		_queryBuilder.append("customer_number: \"" + requestObj.getString("customer_number") + "\" ");
		_queryBuilder.append("firstname: \"" + requestObj.getString("firstName") + "\" ");
		_queryBuilder.append("lastname: \"" + requestObj.getString("lastName") + "\" ");
		_queryBuilder.append("account_name: \"" + requestObj.getString("account_name") + "\" ");
		_queryBuilder.append("email: \"" + requestObj.getString("emailAddress") + "\" ");
		_queryBuilder.append("phone_number: \"" + requestObj.getString("phone") + "\" ");
		_queryBuilder.append("company_name: \"" + requestObj.getString("account_name") + "\" ");
		_queryBuilder.append("items: [ " + items.toString() + " ] ");
		_queryBuilder.append("comment: { ");
		_queryBuilder.append("comment: \"" + requestObj.getString("comment") + "\" ");
		_queryBuilder.append("} }  ) { quote { uid }}}");

		return _queryBuilder.toString();
	}
	
	private String generateCustomerToken(String email) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();
		
		_queryBuilder.append("mutation{ ");
		_queryBuilder.append("generateCustomerTokenAsAdmin(input: {");
		_queryBuilder.append("customer_email: \""+ email + "\"");
		_queryBuilder.append("}){");
		_queryBuilder.append("customer_token");
		_queryBuilder.append("} }");

		return _queryBuilder.toString();
	}

	/**
	 * Create update quote to update quantity and comment
	 * @param cartID, 
	 * @param comment
	 * @param requestObj, quantities for item selected
	 * @return response data or error
	 * @throws JSONException
	 */
	public JsonObject createUpdateQuote(String cartID, String comment, JSONArray requestObj) throws JSONException {
		query = updateNegotiableQuoteQuantities(cartID,comment,requestObj);
		LOGGER.info("QUERY==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in updating quote==" + error.getMessage());
				errorjsonobject.addProperty("updateError", error.getMessage());
			}
			return errorjsonobject;
 	}
		return response.getData().getAsJsonObject("updateNegotiableQuoteQuantities");
	}
	
	
	/**
	 * create and execute close quote query
	 * @param cartid
	 * @param rejectionReason
	 * @return response data or error
	 */
	public JsonObject createCloseQuote(String cartid,String rejectionReason) {
		query = generateCloseQuote(cartid,rejectionReason);
		LOGGER.info("QUERY==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in creating close quote==" + error.getMessage());
				errorjsonobject.addProperty("closeError", error.getMessage());
			}
			return errorjsonobject;
	}
		return response.getData().getAsJsonObject("closeNegotiableQuotes");
	}

	/**
	 * Generate close quote query
	 * @param cartid
	 * @param rejectionReason
	 * @return string query
	 */
	private String generateCloseQuote(String cartid, String rejectionReason) {
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append(" mutation {");
		_queryBuilder.append(" closeNegotiableQuotes(");
		_queryBuilder.append(" input: {quote_uids: [");
		_queryBuilder.append(" \"" +cartid + "\" ");
		_queryBuilder.append(" ]");
		_queryBuilder.append(" quote_close_reason:");
		_queryBuilder.append(" \"" + rejectionReason+ "\"");
		_queryBuilder.append(" }");
		_queryBuilder.append(" ) {");
		_queryBuilder.append(" closed_quotes {");
		_queryBuilder.append(" uid");
		_queryBuilder.append(" name");
		_queryBuilder.append(" status");
		_queryBuilder.append(" }");
		_queryBuilder.append(" negotiable_quotes {");
		_queryBuilder.append(" total_count");
		_queryBuilder.append(" items {");
		_queryBuilder.append(" uid");
		
		_queryBuilder.append(" name");
		_queryBuilder.append(" status");
		_queryBuilder.append(" }");
		_queryBuilder.append(" }");
		_queryBuilder.append(" }");
		_queryBuilder.append(" }");
		
		return _queryBuilder.toString();
	}

	/**
	 * Get and execute my quotes query
	 * @return query response
	 */
	public JsonObject getNegotiableQuotes() {
		query = getNegotiableQuotesDefinition();
		LOGGER.info("QUERY==" + query);
		JsonObject queryResponse = null;
		GraphqlResponse<JsonObject, Error> response = excecuteQueryGraphql();
		if (response != null) {
			if (response.getData() != null) {
				queryResponse = response.getData().getAsJsonObject("negotiableQuotes");
			}
		}
		LOGGER.info("queryResponse==" + queryResponse);
		return queryResponse;

	}
	
	/**
	 * Get and execute quote detail query.
	 * @param cartId
	 * @return query response.
	 */
	public JsonObject getNegotiableQuote(String cartId) {
		query = getNegotiableQuotesDefinition(cartId);
		LOGGER.info("QUERY==" + query);
		JsonObject queryResponse = null;
		GraphqlResponse<JsonObject, Error> response = excecuteQueryGraphql();
		if (response != null) {
			if (response.getData() != null) {
				queryResponse = response.getData().getAsJsonObject("negotiableQuote");
			}
		}
		LOGGER.info("queryResponse==" + queryResponse);
		return queryResponse;

	}
	
	/**
	 * Generate my quotes query
	 * @return query
	 */
	public String getNegotiableQuotesDefinition() {

		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("query {");
		_queryBuilder.append("	negotiableQuotes(filter: {");
		_queryBuilder.append("	name: {");
		_queryBuilder.append("	match: " + '"' + "request" + '"' +" } }) {");
		_queryBuilder.append("	items {	");
		_queryBuilder.append("  uid");
		_queryBuilder.append("  name");
		_queryBuilder.append("  buyer {");
		_queryBuilder.append("  firstname");
		_queryBuilder.append("  lastname");
		_queryBuilder.append("  }");
		_queryBuilder.append("  salesRep");
		_queryBuilder.append("	created_at");
		_queryBuilder.append("  expiration_date");
		_queryBuilder.append("	status");
		_queryBuilder.append("	}");
		_queryBuilder.append("	total_count");
		_queryBuilder.append(" }");
		_queryBuilder.append(" }");

		return _queryBuilder.toString();

	}
	
	/**
	 * Generate quote detail query
	 * @param cartId
	 * @return query
  */
	public String getNegotiableQuotesDefinition(String cartId) {

		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("query {");
		_queryBuilder.append("	negotiableQuote(uid: \"" + cartId + "\") {");
		_queryBuilder.append("	uid");
		_queryBuilder.append("	updated_at");
		_queryBuilder.append("	status");
		
		_queryBuilder.append("	items {	");
		_queryBuilder.append("	uid");
		_queryBuilder.append("	product {");
		_queryBuilder.append(" name");
		_queryBuilder.append(" estimated_annual_usage");
		_queryBuilder.append(" sku");
		_queryBuilder.append(" uid");
		_queryBuilder.append(" description {");
		_queryBuilder.append(" html");
		_queryBuilder.append(" }");
		_queryBuilder.append(" price_range {");
		_queryBuilder.append("	maximum_price {");
		_queryBuilder.append(" regular_price {");
		_queryBuilder.append("	value");
		_queryBuilder.append("}");
		_queryBuilder.append("	}");
		_queryBuilder.append("}");
		_queryBuilder.append("	}");
		_queryBuilder.append("	quantity");
		_queryBuilder.append("}");
		
		_queryBuilder.append("comments {");
		_queryBuilder.append("	uid");
		_queryBuilder.append("	created_at");
		_queryBuilder.append("	author {");
		_queryBuilder.append(" firstname");
		_queryBuilder.append(" lastname");
		_queryBuilder.append("	}");
		_queryBuilder.append("	text");
		_queryBuilder.append("	}");
		_queryBuilder.append("	history {");
		_queryBuilder.append("	uid");
		_queryBuilder.append("	created_at");
		_queryBuilder.append("	author {");
		_queryBuilder.append(" firstname");
		_queryBuilder.append(" lastname");
		_queryBuilder.append("	}");
		_queryBuilder.append("	change_type");
		_queryBuilder.append("	changes {");
		
		_queryBuilder.append("	total {");
		_queryBuilder.append("	new_price {");
		_queryBuilder.append("	value");
		_queryBuilder.append("	}");
		_queryBuilder.append("	old_price {");
		_queryBuilder.append("	value");
		_queryBuilder.append("	}");
		_queryBuilder.append("	}");
		
		_queryBuilder.append(" comment_added {");
		_queryBuilder.append("	comment");
		_queryBuilder.append(" }");
		
		_queryBuilder.append("statuses {");
		_queryBuilder.append("	changes {");
		_queryBuilder.append("	new_status");
		_queryBuilder.append("	old_status");
		_queryBuilder.append("	}");
		_queryBuilder.append("}");
		
		_queryBuilder.append(" expiration {");
		_queryBuilder.append("	new_expiration");
		_queryBuilder.append("	old_expiration");
		_queryBuilder.append("}");
		_queryBuilder.append("}");
	_queryBuilder.append("}");
		_queryBuilder.append("}");
		_queryBuilder.append("}");
		
		return _queryBuilder.toString();
	}
	
	/**
	 * Generate update quantity and comment query
	 * @param cartId
	 * @param comment
	 * @param jsonArray
	 * @return StringBuilder
	 */
	public String updateNegotiableQuoteQuantities(String cartId, String comment, JSONArray jsonArray) {
		
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation {");
		_queryBuilder.append("	updateNegotiableQuoteQuantities(input: {");
		_queryBuilder.append("	quote_uid: \"" + cartId + "\"");
		_queryBuilder.append(" comment: \"" + comment+"\"");
		_queryBuilder.append("	items: [");
		for(int i=0; i<jsonArray.length();i++) {
				JSONObject map;
				try {
					map = (JSONObject) jsonArray.get(i);
				_queryBuilder.append("	{ quote_item_uid: \""+ map.get("skuuid").toString() +'"'+"," );
				_queryBuilder.append("	quantity: "+ map.get("modifiedquantity").toString()+"}");
				} catch (JSONException e) {
					LOGGER.error("Json Exception " + e.getMessage(),e);
				}
			}
		_queryBuilder.append(" ]");
		_queryBuilder.append(" }");
		_queryBuilder.append(" ){");
		_queryBuilder.append(" quote {");
		_queryBuilder.append(" uid");
		_queryBuilder.append(" name");
		_queryBuilder.append(" updated_at");
		_queryBuilder.append(" items {");
		_queryBuilder.append(" uid");
		_queryBuilder.append(" product {");
		_queryBuilder.append(" uid");
		_queryBuilder.append(" sku");
		_queryBuilder.append(" name");
		_queryBuilder.append(" }");
		_queryBuilder.append(" quantity");
		_queryBuilder.append(" prices {");
		_queryBuilder.append(" price {");
		_queryBuilder.append(" value");
		_queryBuilder.append(" }");
		_queryBuilder.append(" }");
		_queryBuilder.append(" }");
		_queryBuilder.append(" }");
		_queryBuilder.append(" }");
		_queryBuilder.append(" }");
		return _queryBuilder.toString();
		
	}


	public JsonObject childUserDetails(Integer company_number) {
		try {
			query = generateChildUserDetailQuery(company_number);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info("All ChildUserDetail==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting all child users ==" + error.getMessage());
				errorjsonobject.addProperty("AllChildUserDetail", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" ChildUsers ==" +response.getData());
		return response.getData();
	}
	
	private String generateChildUserDetailQuery(Integer company_number) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();
		
		_queryBuilder.append("query{ ");
		_queryBuilder.append("ChildUsers(companyNumber: "+ company_number );
		_queryBuilder.append(" ){ ");
		_queryBuilder.append(" customerid ");
		_queryBuilder.append(" firstname ");
		_queryBuilder.append(" middlename ");
		_queryBuilder.append(" lastname ");
		_queryBuilder.append(" email ");
		_queryBuilder.append(" telephone ");
		_queryBuilder.append(" permissions ");
		_queryBuilder.append(" start_date ");
		_queryBuilder.append(" end_date ");
		_queryBuilder.append("} }");

		return _queryBuilder.toString();
	}

	public JsonObject createCompanyUser(JSONObject requestObj) {
		query = generatecreateCompanyUserQuery(requestObj);
		LOGGER.info(" Company user creation Query==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in creating company user ==" + error.getMessage());
				errorjsonobject.addProperty("companyUserError", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" companyUser ==" +response.getData().getAsJsonObject("createCompanyUser"));
		return response.getData();
	}

	private String generatecreateCompanyUserQuery(JSONObject requestObj) {
		String email, firstname, lastname, middlename,job_title,telephone, start_date,end_date,permissions ;
		email = firstname = lastname = middlename = job_title = telephone = start_date = end_date = permissions = null;
		
		try {
			email = requestObj.get("email").toString();
			firstname = requestObj.get("firstname").toString();
			lastname = requestObj.get("lastname").toString();
			middlename = requestObj.get("middlename").toString();
			job_title = requestObj.get("job_title").toString();
			telephone = requestObj.get("telephone").toString();
			start_date = requestObj.get("start_date").toString();
			end_date = requestObj.get("end_date").toString();
			permissions = requestObj.get("permissions").toString();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation { ");
		_queryBuilder.append("createCompanyUser( ");
		_queryBuilder.append(" input: { ");
		_queryBuilder.append("	email: \"" + email + "\"");
		_queryBuilder.append("	firstname: \"" + firstname + "\"");
		_queryBuilder.append("	lastname: \"" + lastname + "\"");
		_queryBuilder.append("	middlename: \"" + middlename + "\"");
		_queryBuilder.append("	job_title: \"" + job_title + "\"");
		_queryBuilder.append("	status: " + User.ACTIVE );
		_queryBuilder.append("	telephone: \"" + telephone + "\"");
		_queryBuilder.append("	start_date: \"" + start_date + "\"");
		_queryBuilder.append("	end_date: \"" + end_date + "\"");
		_queryBuilder.append("	permissions: \"" + permissions + "\"");
		_queryBuilder.append(" } ){ ");
		_queryBuilder.append(" user { ");
		_queryBuilder.append(" created_at ");
		_queryBuilder.append(" email ");
		_queryBuilder.append(" } } } ");

		return _queryBuilder.toString();
	}

}
