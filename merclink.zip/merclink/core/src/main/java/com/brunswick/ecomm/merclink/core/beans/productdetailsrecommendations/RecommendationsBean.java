package com.brunswick.ecomm.merclink.core.beans.productdetailsrecommendations;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.models.annotations.Optional;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RecommendationsBean {
	@Optional
	@JsonProperty("uid")
	 private String uid;
	@Optional
	@JsonProperty("name")
	 private String name;
	@Optional
	@JsonProperty("related_products")
	 private List<RelatedProductsBean> related_products;
	
	
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<RelatedProductsBean> getRelated_products() {
		return new ArrayList<>(related_products);
	}
	public void setRelated_products(List<RelatedProductsBean> related_products) {
		this.related_products = new ArrayList<>(related_products);
	}
	
}
