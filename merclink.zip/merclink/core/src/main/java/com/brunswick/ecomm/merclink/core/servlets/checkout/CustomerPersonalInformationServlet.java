package com.brunswick.ecomm.merclink.core.servlets.checkout;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Servlet;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.EcommSAMLService;
import com.brunswick.ecomm.core.services.EcommTokenService;
import com.brunswick.ecomm.merclink.core.beans.personalinformation.CustomerInformationDetailsBean;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractPersonalInformationRetriever;
import com.brunswick.ecomm.merclink.core.utils.CommonUtil;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@Component(service = Servlet.class, property = { "sling.servlet.methods=POST",
		"sling.servlet.paths=/bin/personalInformationML" })

public class CustomerPersonalInformationServlet extends SlingAllMethodsServlet {

	private static final Logger LOG = LoggerFactory.getLogger(CustomerPersonalInformationServlet.class);
	private static final long serialVersionUID = 1L;
	private transient AbstractPersonalInformationRetriever personalinfoRetriever;
	String currentPagePath;
	@Reference
	transient EcommTokenService tokenService;
	transient CustomerInformationDetailsBean customerPersonalInfo;
	
	@Reference
	transient EcommSAMLService ecommSaml;
	
	public static final int SERVER_PORT_EIGHTY = 80;

	public static final int SERVER_PORT_FOURFORTYTHREE = 443;
	
	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		long startTime = System.currentTimeMillis();
		LOG.info(" CustomerPersonalInformationServlet Request start time :{}", startTime);
		PageManager pageManager = request.getResourceResolver().adaptTo(PageManager.class);
		currentPagePath = request.getParameter("data").toString();													
		
		String token =CommonUtil.getTokenFromCookie("customerToken",request);
		String cartid = CommonUtil.getTokenFromCookie("cartId",request);
		Resource resource = request.getResourceResolver().resolve(currentPagePath);
		LOG.info("inside post"+cartid);
		LOG.info("Token ===" + token);
		List<Header> headers1 = new ArrayList<>();
		headers1.add(new BasicHeader("Authorization",
				"Bearer " + token));
		JsonObject jsonresponse = new JsonObject ();   
		if(resource!= null) {
			
			MagentoGraphqlClient magentoGraphqlClient = MagentoGraphqlClient.create(resource,
				pageManager.getPage(resource.getPath()), request, headers1);
			personalinfoRetriever = new AbstractPersonalInformationRetriever(magentoGraphqlClient);
			 jsonresponse = personalinfoRetriever.getCustomerPersonalInformation();
			 String cpLink = getChangepassword(request);
			 jsonresponse.addProperty("cplink", cpLink);
			customerPersonalInfo = new Gson().fromJson(jsonresponse, CustomerInformationDetailsBean.class);
			long endTime = System.currentTimeMillis();
			LOG.info(" CustomerPersonalInformationServlet Response end time :"+endTime+" Time difference b/w request and response of CustomerPersonalInformationServlet : {}", (endTime-startTime));
		}
		response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
		response.setContentType("application/json");
		response.getWriter().print(jsonresponse);
	}
	
	public CustomerInformationDetailsBean getCustomerPersonalInfo() {
		return customerPersonalInfo;
	}

	public void setCustomerPersonalInfo(CustomerInformationDetailsBean customerPersonalInfo) {
		this.customerPersonalInfo = customerPersonalInfo;
	}
	
	public String getChangepassword(SlingHttpServletRequest request) {
		final String protocol = request.getScheme();
		StringBuilder domain = new StringBuilder(protocol).append("://").append(request.getServerName());
		final Integer serverPort = request.getServerPort();
		if (serverPort != null && serverPort > 0 && serverPort != SERVER_PORT_EIGHTY
				&& serverPort != SERVER_PORT_FOURFORTYTHREE) {
			domain.append(':').append(serverPort);
		}
		String myResponseUrl = domain + "/en.html";
		LOG.info("myResponseUrl="+myResponseUrl);
		//String myResponseUrl ="https://qac-www.merclink.net/en.html";
		String clientId = ecommSaml.getClientId();
		String entityId = ecommSaml.getChangePasswordEntityID();
		String idpUrl = ecommSaml.getChangePasswordUrl();
		return idpUrl+"?p="+entityId+"&client_id="+clientId+"&nonce=defaultNonce&redirect_uri="+myResponseUrl+"&scope=openid&response_type=id_token";
	}
}
