package com.brunswick.ecomm.merclink.core.beans.checkout;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerAddressBean {
	private String cartId;
	private String customerId;
	private String firstname;
	private String lastname;
	private String company;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String regioncode;
	private String country;
	private String postalcode;
	private String addresstype;
	private String customertype;
	private Boolean addressbook;
	private String telephone;
	private Integer companyAddrId;
	private String sameasshipping;
	
	public String getSameasshipping() {
		return sameasshipping;
	}
	public void setSameasshipping(String sameasshipping) {
		this.sameasshipping = sameasshipping;
	}
	public String getCartId() {
		return cartId;
	}
	public void setCartId(String cartId) {
		this.cartId = cartId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getRegioncode() {
		return regioncode;
	}
	public void setRegioncode(String regioncode) {
		this.regioncode = regioncode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPostalcode() {
		return postalcode;
	}
	public void setPostalcode(String postalcode) {
		this.postalcode = postalcode;
	}
	public String getAddresstype() {
		return addresstype;
	}
	public void setAddresstype(String addresstype) {
		this.addresstype = addresstype;
	}
	public String getCustomertype() {
		return customertype;
	}
	public void setCustomertype(String customertype) {
		this.customertype = customertype;
	}
	public Boolean getAddressbook() {
		return addressbook;
	}
	public void setAddressbook(Boolean addressbook) {
		this.addressbook = addressbook;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public Integer getCompanyAddrId() {
		return companyAddrId;
	}
	public void setCompanyAddrId(Integer companyAddrId) {
		this.companyAddrId = companyAddrId;
	}
}
