package com.brunswick.ecomm.merclink.core.models.retriever;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.google.gson.JsonObject;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AbstractUamRetriever extends AbstractCustomRetriever {
	Customer customer;
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractUamRetriever.class);
	private String query;
	
	enum User {
		  ACTIVE
		}

	public AbstractUamRetriever(MagentoGraphqlClient client) {
		super(client);

	}

	@Override
	protected GraphqlResponse<Query, Error> executeQuery() {
		return client.execute(query);
	}

	protected GraphqlResponse<JsonObject, Error> excecuteQueryGraphql() {
		return client.executeQuery(query);
	}

	protected GraphqlResponse<Mutation, Error> executeMutation() {
		return client.executeMutation(query);
	}

	protected GraphqlResponse<JsonObject, Error> excecuteJsonMutation() {
		return client.executeJsonMutation(query);
	}

	@Override
	protected void populate() {
		// Nothing to do
	}

	/**
	 * creating query to generate customer token to perform manual login.
	 */
	public JsonObject createManualLogin(String email) throws JSONException {
		query = generateCustomerToken(email);
		LOGGER.info("createManualLoginQUERY==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in createManualLogin==" + error.getMessage());
				errorjsonobject.addProperty("createManualLogin", error.getMessage());
			}
			return errorjsonobject;
		}
		//LOGGER.info(" creating quote number==" +response.getData().getAsJsonObject("requestNegotiableQuote").toString());
		return response.getData().getAsJsonObject("generateCustomerTokenAsAdmin");
	}
	
	/**
	 * creating query to generate customer token.
	 */
	private String generateCustomerToken(String email) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();
		
		_queryBuilder.append("mutation{ ");
		_queryBuilder.append("generateCustomerTokenAsAdmin(input: {");
		_queryBuilder.append("customer_email: \""+ email + "\"");
		_queryBuilder.append("}){");
		_queryBuilder.append("customer_token");
		_queryBuilder.append("} }");

		return _queryBuilder.toString();
	}
	/**
	 * creating query and return list of child users.
	 */
	public JsonObject childUserDetails(Integer status,Integer company_number) {
		try {
			query = generateChildUserDetailsQuery(status,company_number);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info("All ChildUserDetail==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting all child users ==" + error.getMessage());
				errorjsonobject.addProperty("AllChildUserDetail", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" ChildUsers ==" +response.getData());
		return response.getData();
	}
	
	/**
	 * creating query to get ChildUsers.
	 */
	private String generateChildUserDetailsQuery(Integer status,Integer company_number) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();
		
		_queryBuilder.append("query{ ");
		_queryBuilder.append("GetChildUsers(status: "+status+",companyNumber: "+ company_number);
		_queryBuilder.append(" ){ ");
		_queryBuilder.append(" customerid ");
		_queryBuilder.append(" firstname ");
		_queryBuilder.append(" middlename ");
		_queryBuilder.append(" lastname ");
		_queryBuilder.append(" email ");
		_queryBuilder.append(" telephone ");
		_queryBuilder.append(" start_date ");
		_queryBuilder.append(" end_date ");
		_queryBuilder.append(" status ");
		_queryBuilder.append("} }");

		return _queryBuilder.toString();
	}


    /**
	 * creating query and return list of child users.
	 */
	public JsonObject childSecondaryUserDetails(Integer customer_Id, Integer company_number) {
		try {
			query = generateSecondaryChildUserDetailsQuery(customer_Id, company_number);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info("All SecondaryChildUserDetail==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting all child users ==" + error.getMessage());
				errorjsonobject.addProperty("SecondaryChildUserDetail", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" SecondaryChildUserDetail ==" +response.getData());
		return response.getData();
	}
	
	/**
	 * creating query to get ChildUsers.
	 */
	private String generateSecondaryChildUserDetailsQuery(Integer customer_Id, Integer company_number) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();
		
		_queryBuilder.append("query{ ");
		_queryBuilder.append("ChildUserDetail(customerId: "+ customer_Id +", companyNumber: "+ company_number);
		_queryBuilder.append(" ){ ");
		_queryBuilder.append(" customerid ");
		_queryBuilder.append(" firstname ");
		_queryBuilder.append(" middlename ");
		_queryBuilder.append(" lastname ");
		_queryBuilder.append(" email ");
		_queryBuilder.append(" telephone ");
		_queryBuilder.append(" permissions ");
		_queryBuilder.append(" roles ");
		_queryBuilder.append(" start_date ");
		_queryBuilder.append(" end_date ");
		_queryBuilder.append("} }");

		return _queryBuilder.toString();
	}


    /**
	 * creating query and return set Default user.
	 */
	public JsonObject setDefaultAccount(String company_number) {
		try {
			query = generateSetDefaultAccountQuery(company_number);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" setDefaultAccount==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  setDefaultAccount  ==" + error.getMessage());
				errorjsonobject.addProperty("setDefaultAccount", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" setDefaultAccount ==" +response.getData());
		return response.getData();
	}
	
	/**
	 * creating query to get ChildUsers.
	 */
	private String generateSetDefaultAccountQuery(String company_number) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();
		
		_queryBuilder.append("mutation { ");
		_queryBuilder.append(" setAnzpDefaultCompany( ");
		_queryBuilder.append(" input: {");
		_queryBuilder.append(" companynumber :\""+ company_number + "\"");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" ) { ");
		_queryBuilder.append(" message ");
		_queryBuilder.append("} }");

		return _queryBuilder.toString();
	}

    /**
	 * creating query and return change email.
	 */
	public JsonObject changeUserEmail(String email) {
		try {
			query = generateChangeUserEMailQuery(email);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		LOGGER.info(" changeUserEmail==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in getting  changeUserEmail  ==" + error.getMessage());
				errorjsonobject.addProperty("changeUserEmail", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" changeUserEmail ==" +response.getData());
		return response.getData();
	}
	
	/**
	 * creating query to change email.
	 */
	private String generateChangeUserEMailQuery(String email) throws JSONException {
		StringBuilder _queryBuilder = new StringBuilder();
		
		_queryBuilder.append("mutation { ");
		_queryBuilder.append(" changeAnzpEmail ( ");
		_queryBuilder.append(" input: {");
		_queryBuilder.append(" email :\""+ email + "\"");
		_queryBuilder.append(" } ");
		_queryBuilder.append(" ) { ");
		_queryBuilder.append(" message ");
		_queryBuilder.append("} }");

		return _queryBuilder.toString();
	}


	/**
	 * creating query and executing it for company user creation.
	 */
	public JsonObject createCompanyUser(JSONObject requestObj) {
		query = generatecreateCompanyUserQuery(requestObj);
		LOGGER.info(" Company user creation Query==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in creating company user ==" + error.getMessage());
				errorjsonobject.addProperty("companyUserError", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" companyUser ==" +response.getData().getAsJsonObject("createCompanyUser"));
		return response.getData();
	}

	/**
	 * creating new company creation query.
	 */
	private String generatecreateCompanyUserQuery(JSONObject requestObj) {
		String company_account_number, job_title, email, firstname, lastname, middlename,updated_by,telephone, start_date,end_date,permissions,roles ;
		email = firstname = lastname = middlename = job_title = telephone = start_date = end_date = permissions = company_account_number = roles = updated_by = null;
		
		try {
			company_account_number = requestObj.get("company_account_number").toString();
			email = requestObj.get("email").toString();
			firstname = requestObj.get("firstname").toString();
			lastname = requestObj.get("lastname").toString();
			middlename = requestObj.get("middlename").toString();
			updated_by = requestObj.get("updated_by").toString();
			telephone = requestObj.get("telephone").toString();
			start_date = requestObj.get("start_date").toString();
			end_date = requestObj.get("end_date").toString();
			roles = requestObj.get("roles").toString();
			permissions = requestObj.get("permissions").toString();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation { ");
		_queryBuilder.append("createChildUser( ");
		_queryBuilder.append(" input: { ");
		_queryBuilder.append("	company_account_number: \"" + company_account_number + "\"");
		_queryBuilder.append("	email: \"" + email + "\"");
		_queryBuilder.append("	firstname: \"" + firstname + "\"");
		_queryBuilder.append("	lastname: \"" + lastname + "\"");
		_queryBuilder.append("	middlename: \"" + middlename + "\"");
		//_queryBuilder.append("	job_title: \"" + job_title + "\"");
		//_queryBuilder.append("	status: " + User.ACTIVE );
		_queryBuilder.append("	telephone: \"" + telephone + "\"");
		_queryBuilder.append("	start_date: \"" + start_date + "\"");
		_queryBuilder.append("	end_date: \"" + end_date + "\"");
		_queryBuilder.append("	roles: \"" + roles + "\"");
		_queryBuilder.append("	updated_by: \"" + updated_by + "\"");
		_queryBuilder.append("	permissions: \"" + permissions + "\"");
		_queryBuilder.append(" } ){ ");
		_queryBuilder.append(" user { ");
		_queryBuilder.append(" created_at ");
		_queryBuilder.append(" email ");
		_queryBuilder.append(" } } } ");

		return _queryBuilder.toString();
	}

	/**
	 * executing query for updating child user.
	 */
	public JsonObject getUpdateChildMutation(JSONObject requestObj,Integer customerid,Integer companyId) {
		query = generateUpdateCompanyUserQuery(requestObj,customerid,companyId);
		LOGGER.info(" Company user updation Query==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in updating company user ==" + error.getMessage());
				errorjsonobject.addProperty("companyUserUpdateError", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" companyUser ==" +response.getData().getAsJsonObject("updateCompanyUser"));
		return response.getData();
	}
	
	/**
	 * creating company user updation query.
	 */
	private String generateUpdateCompanyUserQuery(JSONObject requestObj, Integer customerid, Integer companyId) {
		String updated_by, roles, company_account_number, remove_user, email, firstname, lastname, middlename,telephone, start_date,end_date,permissions ;
		email = firstname = lastname = middlename = telephone = start_date = end_date = permissions = company_account_number = remove_user = roles = updated_by = "";
		
		LOGGER.info(" Company edit requestObj==" + requestObj.toString());
		
		try {
		//	company_account_number = requestObj.get("company_account_number").toString();
			company_account_number = companyId.toString();
			email = requestObj.get("email").toString();
			firstname = requestObj.get("firstname").toString();
			lastname = requestObj.get("lastname").toString();
			middlename = requestObj.get("middlename").toString();
			remove_user = requestObj.get("remove_user").toString();
			telephone = requestObj.get("telephone").toString();
			start_date = requestObj.get("start_date").toString();
			end_date = requestObj.get("end_date").toString();
			permissions = requestObj.get("permissions").toString();
			roles = requestObj.get("roles").toString();
			updated_by = requestObj.get("updated_by").toString();
			
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		StringBuilder _queryBuilder = new StringBuilder();
		_queryBuilder.append("mutation { ");
		_queryBuilder.append("updateChildUser( ");
		_queryBuilder.append(" input: { ");
		_queryBuilder.append(" id: "+customerid);
		_queryBuilder.append("	company_account_number: \"" + company_account_number + "\"");
		_queryBuilder.append("	email: \"" + email + "\"");
		_queryBuilder.append("	firstname: \"" + firstname + "\"");
		_queryBuilder.append("	lastname: \"" + lastname + "\"");
		_queryBuilder.append("	middlename: \"" + middlename + "\"");
		
		//_queryBuilder.append("	status: " + User.ACTIVE );
		_queryBuilder.append("	telephone: \"" + telephone + "\"");
		_queryBuilder.append("	start_date: \"" + start_date + "\"");
		_queryBuilder.append("	end_date: \"" + end_date + "\"");
		_queryBuilder.append("	remove_user: \"" + remove_user + "\"");
		_queryBuilder.append("	roles: \"" + roles + "\"");
		_queryBuilder.append("	updated_by: \"" + updated_by + "\"");
		_queryBuilder.append("	permissions: \"" + permissions + "\"");
		_queryBuilder.append(" } ){ ");
		_queryBuilder.append(" message ");
		_queryBuilder.append(" user { ");
		_queryBuilder.append(" email ");
		_queryBuilder.append(" firstname ");
		_queryBuilder.append(" lastname ");
		//_queryBuilder.append(" job_title ");
		//_queryBuilder.append(" telephone ");
		_queryBuilder.append(" status ");
		//_queryBuilder.append(" role { ");
		//_queryBuilder.append(" id ");
		//_queryBuilder.append(" name ");
		//_queryBuilder.append(" users_count ");
		_queryBuilder.append(" } } }");

		return _queryBuilder.toString();
	}

	/**
	 * executing edit child user query.
	 */
	public JsonObject getEditChildUserDetail(Integer customerid, Integer company_number) {
		query = generateEditChildUserQuery(customerid, company_number);
		LOGGER.info(" Company edit user Query==" + query);
		GraphqlResponse<JsonObject, Error> response = excecuteJsonMutation();
		List<Error> errors = response.getErrors();
		if (null != errors) {
			JsonObject errorjsonobject = new JsonObject();
			for (Error error : errors) {
				LOGGER.info("Error in edit company user ==" + error.getMessage());
				errorjsonobject.addProperty("companyUserEditError", error.getMessage());
			}
			return errorjsonobject;
		}
		LOGGER.info(" childUser ==" +response.getData().getAsJsonObject("userdetail"));
		return response.getData();
	}

	/**
	 * creating edit child user query.
	 */
	private String generateEditChildUserQuery(Integer customerid, Integer company_number) {
		StringBuilder _queryBuilder = new StringBuilder();

		_queryBuilder.append("query{ ");
		_queryBuilder.append("ChildUserDetail(customerId: " + customerid +"companyNumber: " +company_number);
		_queryBuilder.append(" ){ ");
		_queryBuilder.append(" customerid ");
		_queryBuilder.append(" firstname ");
		_queryBuilder.append(" middlename ");
		_queryBuilder.append(" lastname ");
		_queryBuilder.append(" email ");
		_queryBuilder.append(" telephone ");
		_queryBuilder.append(" permissions ");
		_queryBuilder.append(" start_date ");
		_queryBuilder.append(" end_date ");
		_queryBuilder.append("} }");

		return _queryBuilder.toString();
	}

}
