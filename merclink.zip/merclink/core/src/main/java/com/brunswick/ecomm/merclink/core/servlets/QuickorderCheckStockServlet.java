package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;

import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.merclink.core.beans.product.ProductDataResultBean;
import com.brunswick.ecomm.merclink.core.beans.product.ProductsDataResultBean;
import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;



@Component(service = Servlet.class, property = { "sling.servlet.methods=" + HttpConstants.METHOD_POST,
		"sling.servlet.resourceTypes=" + "sling/servlet/default", "sling.servlet.selectors=" + "productdetails",
		"sling.servlet.extensions=" + "json" })
public class QuickorderCheckStockServlet extends SlingAllMethodsServlet{ 
	
	private static final long serialVersionUID = 1L;
	@Reference
	transient EcommSessionService adminService;
	
	@Reference
	transient APIGEEService apigee;
	
	private static final Logger LOG = LoggerFactory.getLogger(QuickorderCheckStockServlet.class);
	private transient JsonObject productDataBean;
	private transient JsonObject productsDataBean;
	@Override
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.info("inside do post");
		Gson gson = new Gson();
		String currentPage;
		try (ResourceResolver resolver = adminService.getWriteServiceResourceResolver()){
			LOG.info(request.getParameter("data"));
		if(request.getParameter("data")!=null) { 
			JSONObject requestdata = new JSONObject(request.getParameter("data"));
			currentPage = requestdata.getString("currentPage");
			if(requestdata.getString("itemno").split(",").length>1) {
				productsDataBean = apigee.getProductsDetails(resolver, currentPage, requestdata.getString("itemno"));
				response.getWriter().println(productsDataBean.toString());
			}
			else {
				productDataBean = apigee.getProductDetails(resolver, currentPage, requestdata.getString("itemno"));
				response.getWriter().write(productDataBean.toString());
			}
			
		}
		setResponseData(response);
		} 
		catch (LoginException e) {
			LOG.error("Login exception occurred "+e);
		}
		catch(Exception e) {
			LOG.error("Exception occured "+e.getMessage());
		}
	}
	public String setResponseData(SlingHttpServletResponse response) throws IOException {
		 response.setContentType("text/plain");
			response.getWriter().flush();
			response.getWriter().close();
		 return "success";
	 } 

}
