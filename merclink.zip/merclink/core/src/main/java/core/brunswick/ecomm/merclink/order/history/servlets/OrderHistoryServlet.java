package core.brunswick.ecomm.merclink.order.history.servlets;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.servlet.http.Cookie;
import com.brunswick.ecomm.core.beans.orderhistory.OrderHistoryFilterDataBean;
import com.brunswick.ecomm.core.beans.orderhistory.OrderResultBean;
import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.google.gson.Gson;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=Order History Servlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_GET, "sling.servlet.paths=" + "/bin/merclink/orderhistory" })

public class OrderHistoryServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	@Reference
	transient EcommSessionService adminService;
	@Reference
	transient APIGEEService apigee;
	private static final Logger LOG = LoggerFactory.getLogger(OrderHistoryServlet.class);
	transient OrderResultBean order;
	private final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	@Override
	public void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.info("inside do Get OrderHistoryServlet");
		Gson gson = new Gson();
		String currentPage;
		String orderInLast;
		ResourceResolver resolver = null;
		try {
			resolver = adminService.getWriteServiceResourceResolver();
			LOG.info(request.getParameter("data"));
			if (request.getParameter("data") != null) {
				JSONObject requestdata = new JSONObject(request.getParameter("data"));
				OrderHistoryFilterDataBean orderhistoryfilterbean = gson.fromJson(request.getParameter("data"),
						OrderHistoryFilterDataBean.class);
						Cookie[] cookies = request.getCookies();
						if (cookies != null) {
							for (Cookie cookie : cookies) {
								if (cookie.getName().equals("customerNumber")) {
									// Setting the customer number
									orderhistoryfilterbean.setCustomerNumber(requestdata.getString("customerNumber"));
								}
							}
						}
				currentPage = requestdata.getString("currentPage");
				orderInLast = requestdata.getString("orderInLast");
				LOG.info("after orderinlast string");

				order = apigee.getOrderHistoryFilter(orderhistoryfilterbean, resolver, currentPage);
				LOG.info("Order data :{}", order);
				if (order !=null) {
					JSONObject json = new JSONObject(new Gson().toJson(order));
					response.getWriter().println(json);
				}
			}
			setResponseData(response);
		} catch (JSONException | LoginException e) {
			LOG.error("JSON/Login exception occurred %f", e);
		} catch (Exception e) {
			LOG.error("Exception occured %f", e);
		} finally {
			adminService.closeResourceResolver(resolver);
		}
	}

	public String setResponseData(SlingHttpServletResponse response) throws IOException {
		response.setContentType("text/plain");
		response.getWriter().flush();
		response.getWriter().close();
		return "success";
	}

}

