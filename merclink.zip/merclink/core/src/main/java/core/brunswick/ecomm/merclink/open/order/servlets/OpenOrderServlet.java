package core.brunswick.ecomm.merclink.open.order.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.http.Cookie;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.magento.graphql.ProductInterface;
import com.brunswick.ecomm.core.beans.openorder.OpenOrderFilterBean;
import com.brunswick.ecomm.core.beans.openorder.OpenOrderItemsBean;
import com.brunswick.ecomm.core.beans.openorder.OpenOrderResultBean;
import com.brunswick.ecomm.core.beans.openorder.ShipToAddressBean;
import com.brunswick.ecomm.core.beans.orderhistory.OrderHistoryFilterDataBean;
import com.brunswick.ecomm.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.core.models.internal.quickorderform.AbstractQuickOrderFormRetriever;
import com.brunswick.ecomm.core.models.internal.quickorderform.QuickOrderFormRetriever;
import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.day.cq.wcm.api.PageManager;
import com.google.gson.Gson;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "= Open Order Servlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_GET, "sling.servlet.paths=" + "/bin/merclink/openorder" })

public class OpenOrderServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	
	@Reference
	transient EcommSessionService adminService;
	
	@Reference
	transient APIGEEService apigee;
	
	transient OpenOrderResultBean order;
	
	private static final Logger LOG = LoggerFactory.getLogger(OpenOrderServlet.class);
	

	@Override
	public void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LOG.info("inside do get OpenOrderServlet");
		Gson gson = new Gson();
		String currentPage;
		String orderInLast;
		ResourceResolver resolver = null;
		try {
			resolver = adminService.getWriteServiceResourceResolver();
			LOG.info(request.getParameter("data"));
			if (request.getParameter("data") != null) {
				JSONObject requestdata = new JSONObject(request.getParameter("data"));
				OrderHistoryFilterDataBean orderhistoryfilterbean = gson.fromJson(request.getParameter("data"),
						OrderHistoryFilterDataBean.class);
				Cookie[] cookies = request.getCookies();
				if (cookies != null) {
					for (Cookie cookie : cookies) {
						if (cookie.getName().equals("customerNumber")) {
							// Setting the customer number
							orderhistoryfilterbean.setCustomerNumber(requestdata.getString("customerNumber"));
						}
					}
				}
				currentPage = requestdata.getString("currentPage");
				orderInLast = requestdata.getString("orderInLast");
				if (orderhistoryfilterbean.getOrderNumber() != null && orderhistoryfilterbean.getPoNumber() != null
						&& orderInLast != null && orderhistoryfilterbean.getCreditHold() != null) {

					LOG.info("after orderinlast string");
					order = apigee.getOpenOrderFilter(orderhistoryfilterbean, resolver, currentPage);
					JSONArray jsonArray = new JSONArray();
					ArrayList<String> itemNumbers = new ArrayList<>();
					HashMap<String, String> itemMinQtyMap = new HashMap<>();
					if (order != null) {
						for (OpenOrderFilterBean or : order.getOrderResults()) {
							for (OpenOrderItemsBean item : or.getItems()) {
								itemNumbers.add(item.getItemNumber());
							}
						}
					}
					if (order != null) {
						for (OpenOrderFilterBean or : order.getOrderResults()) {
							for (OpenOrderItemsBean item : or.getItems()) {
								JSONObject json = new JSONObject();
								json.append("itemNumber", item.getItemNumber());
								json.append("itemDescription", item.getDescription());
								json.append("orderNumber", or.getOrderNumber());
								json.append("orderDate", or.getOrderedDate());
								json.append("poNumber", or.getPoNumber());
								json.append("orderedQuantity", item.getOrderedQuantity());
								json.append("requestDate", or.getRequestDate());
								json.append("estimatedAvailabilityDate", item.getAvailabilityDate());
								json.append("warehouse", item.getWarehouseName());
								ShipToAddressBean shipToAddress = or.getShipping();
								json.append("shipTo", shipToAddress.getShipTo().getBusinessName());
								json.append("holdFlag", item.getHoldFlag());
								jsonArray.put(json);

							}

						}
					}
					LOG.info("before response");
					if (order != null && jsonArray != null) {
						response.getWriter().println(jsonArray);
						response.setStatus(200);
						setResponseData(response);
					} else {
						response.setStatus(400);
					}

				}
			}

		} catch (JSONException | LoginException e) {
			LOG.error("JSON/Login exception occurred %f", e);
		} catch (Exception e) {
			LOG.error("Exception occured %f", e);
		} finally {
			adminService.closeResourceResolver(resolver);
		}
	}

	public String setResponseData(SlingHttpServletResponse response) throws IOException {
		response.setContentType("text/plain");
		response.getWriter().flush();
		response.getWriter().close();
		return "success";
	}

}
