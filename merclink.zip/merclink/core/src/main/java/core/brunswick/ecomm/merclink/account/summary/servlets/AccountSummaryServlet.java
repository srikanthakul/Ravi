package core.brunswick.ecomm.merclink.account.summary.servlets;

import java.io.IOException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.resource.ResourceResolver;

import com.brunswick.ecomm.core.beans.AccountSummaryBean;
import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.Calendar;
import java.util.Date;
import org.apache.sling.api.servlets.HttpConstants;
import javax.servlet.Servlet;

import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import com.google.gson.JsonObject;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "= Statements information servlet",
        "sling.servlet.methods=" + HttpConstants.METHOD_GET, "sling.servlet.paths=" + "/bin/merclink/accountsummary" })
public class AccountSummaryServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
    @Reference
    transient EcommSessionService adminService;
    @Reference
    transient APIGEEService apigee;
    private static final Logger LOG = LoggerFactory.getLogger(AccountSummaryServlet.class);
    
    transient AccountSummaryBean accountSummary;
    @Override
    public void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
        LOG.debug("inside do get Merclink getAccountSummary");
        ResourceResolver resourceResolver = null;
        try {
            resourceResolver = adminService.getWriteServiceResourceResolver();
            response.setContentType("application/json");
            LOG.info("inside getAccountSummary of do get");
                JSONObject data = new JSONObject(request.getParameter("data"));
                if (data != null)
                {
                    LOG.info("input data {}",  data.get("customerNumber"));
                    Date currentDate = new Date();
                    Calendar c = Calendar.getInstance();
                    c.setTime(currentDate);
                    LOG.info("after getAccountSummary string");

                    JSONObject json = apigee.getAccountSummary(data.get("customerNumber").toString(), resourceResolver, data.get("resourcePath").toString());
                    LOG.info("data-------------------{}", json);
                    response.getWriter().println(json);
                }
            
        } catch (JSONException e) {
            LOG.error("JSON/Login exception occurred %f", e);
        } catch (Exception e) {
            LOG.error("Exception occured %f", e);
        } finally {
			adminService.closeResourceResolver(resourceResolver);
		}
    }
}