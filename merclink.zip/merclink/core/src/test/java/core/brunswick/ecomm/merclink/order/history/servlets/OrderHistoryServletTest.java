package core.brunswick.ecomm.merclink.order.history.servlets;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.apache.sling.testing.resourceresolver.MockResourceResolverFactory;
import org.junit.Before;
import org.junit.Rule;
import org.mockito.Mockito;
import org.junit.Test;
import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.brunswick.ecomm.core.services.apigee.impl.APIGEEServiceImpl;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

public class OrderHistoryServletTest {
	@Rule
	public final AemContext context = createContext("/context/jcr-content-wishlist.json");
	private EcommSessionService adminService;
	private ResourceResolver resolver;
	private OrderHistoryServlet fixture = new OrderHistoryServlet();
	private APIGEEService apigee;
	private APIGEEServiceImpl mockServiceImpl;
	

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");
		}, ResourceResolverType.JCR_MOCK);
	}
	@Before
	public void setup() throws IOException, LoginException {
		fixture = new OrderHistoryServlet();
		apigee = Mockito.mock(APIGEEService.class);
		APIGEEService apigee = Mockito.mock(APIGEEService.class);
		resolver = context.resourceResolver();
		adminService = Mockito.mock(EcommSessionService.class);
		MockResourceResolverFactory factory = new MockResourceResolverFactory();
		resolver = factory.getResourceResolver(null);
		context.registerService(EcommSessionService.class, adminService);
		context.registerService(APIGEEService.class,apigee);
		context.registerService(ResourceResolver.class,resolver);
		context.registerInjectActivateService(fixture);
		
	}
	@Test
	public void orderNoSearchTest() throws IOException {
		String data = "{\"type\":\"orderNoSearch\",\"orderNumber\":\"2270785\",\"currentPage\":\"/content/ecommerce/delcity/language-masters/en/home/my-account.html\",\"customerNumber\":\"450972\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		fixture.doGet(context.request(), context.response());
	}
	@Test
	public void poNoSearchTest() throws IOException {
		String data = "{\"type\":\"poNoSearch\",\"poNumber\":\"111\",\"orderNumber\":\"2270785\",\"currentPage\":\"/content/ecommerce/delcity/language-masters/en/home/my-account.html\",\"customerNumber\":\"450972\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		fixture.doGet(context.request(), context.response());
	}
	@Test
	public void filterOrderstatusTest() throws IOException {
		String data = "{\"orderInLast\":\"\",\"poNumber\":\"111\",\"startDate\":\"\",\"endDate\":\"\",\"invoiceNo\":\"\",\"orderStatus\":\"status\",\"type\":\"filter\",\"orderNumber\":\"2270785\",\"currentPage\":\"/content/ecommerce/delcity/language-masters/en/home/my-account.html\",\"customerNumber\":\"450972\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		fixture.doGet(context.request(), context.response());
	}
	@Test
	public void filterDateTest() throws IOException, LoginException {
		String data = "{\"orderInLast\":\"\",\"poNumber\":\"111\",\"startDate\":\"1/11/11\",\"endDate\":\"1/12/12\",\"invoiceNo\":\"\",\"orderStatus\":\"\",\"type\":\"filter\",\"orderNumber\":\"2270785\",\"currentPage\":\"/content/ecommerce/delcity/language-masters/en/home/my-account.html\",\"customerNumber\":\"450972\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		Mockito.when(adminService.getWriteServiceResourceResolver()).thenReturn(resolver);
		fixture.doGet(context.request(), context.response());
	}
	@Test
	public void InvoiceNumberTest() throws IOException {
		String data = "{\"orderInLast\":\"\",\"poNumber\":\"111\",\"startDate\":\"\",\"endDate\":\"\",\"invoiceNo\":\"111\",\"orderStatus\":\"\",\"type\":\"filter\",\"orderNumber\":\"2270785\",\"currentPage\":\"/content/ecommerce/delcity/language-masters/en/home/my-account.html\",\"customerNumber\":\"450972\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		fixture.doGet(context.request(), context.response());
	}
	@Test
	public void StartdateTest() throws IOException {
		String data = "{\"orderInLast\":\"\",\"poNumber\":\"111\",\"startDate\":\"1/11/11\",\"endDate\":\"\",\"invoiceNo\":\"\",\"orderStatus\":\"\",\"type\":\"filter\",\"orderNumber\":\"2270785\",\"currentPage\":\"/content/ecommerce/delcity/language-masters/en/home/my-account.html\",\"customerNumber\":\"450972\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		fixture.doGet(context.request(), context.response());
	}
	@Test
	public void OrderLastTest() throws IOException {
		String data = "{\"orderInLast\":\"11/11/11\",\"poNumber\":\"111\",\"startDate\":\"\",\"endDate\":\"\",\"invoiceNo\":\"\",\"orderStatus\":\"\",\"type\":\"filter\",\"orderNumber\":\"2270785\",\"currentPage\":\"/content/ecommerce/delcity/language-masters/en/home/my-account.html\",\"customerNumber\":\"450972\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		fixture.doGet(context.request(), context.response());
	}
	@Test
	public void NoFilterTest() throws IOException {
		String data = "{\"orderInLast\":\"\",\"poNumber\":\"111\",\"startDate\":\"\",\"endDate\":\"\",\"invoiceNo\":\"\",\"orderStatus\":\"\",\"type\":\"filter\",\"orderNumber\":\"2270785\",\"currentPage\":\"/content/ecommerce/delcity/language-masters/en/home/my-account.html\",\"customerNumber\":\"450972\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		fixture.doGet(context.request(), context.response());
	}
	@Test
	public void AllFilterTest() throws IOException {
		String data = "{\"orderInLast\":\"11/11/11\",\"poNumber\":\"111\",\"startDate\":\"1/1/11\",\"endDate\":\"11/11/12\",\"invoiceNo\":\"111\",\"orderStatus\":\"status\",\"type\":\"filter\",\"orderNumber\":\"2270785\",\"currentPage\":\"/content/ecommerce/delcity/language-masters/en/home/my-account.html\",\"customerNumber\":\"450972\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		fixture.doGet(context.request(), context.response());
	}
	@Test
	public void StartDateEmptyTest() throws IOException {
		String data = "{\"orderInLast\":\"11/11/11\",\"poNumber\":\"111\",\"startDate\":\"\",\"endDate\":\"11/11/12\",\"invoiceNo\":\"111\",\"orderStatus\":\"status\",\"type\":\"filter\",\"orderNumber\":\"2270785\",\"currentPage\":\"/content/ecommerce/delcity/language-masters/en/home/my-account.html\",\"customerNumber\":\"450972\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		fixture.doGet(context.request(), context.response());
	}
}

