package core.brunswick.ecomm.merclink.open.order.servlets;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.apache.sling.testing.resourceresolver.MockResourceResolverFactory;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

public class OpenOrderServletTest {
	private static final Logger LOG = LoggerFactory.getLogger(OpenOrderServletTest.class);
	@Rule
	public final AemContext context = createContext("/context/jcr-content-wishlist.json");
	private EcommSessionService adminService;
	private ResourceResolver resolver;
	private OpenOrderServlet fixture = new OpenOrderServlet();
	private APIGEEService apigee;

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");
		}, ResourceResolverType.JCR_MOCK);
	}

	@Before
	public void setup() throws IOException, LoginException {
		fixture = new OpenOrderServlet();
		apigee = Mockito.mock(APIGEEService.class);
		APIGEEService apigee = Mockito.mock(APIGEEService.class);
		resolver = context.resourceResolver();
		adminService = Mockito.mock(EcommSessionService.class);
		MockResourceResolverFactory factory = new MockResourceResolverFactory();
		resolver = factory.getResourceResolver(null);
		context.registerService(EcommSessionService.class, adminService);
		context.registerService(APIGEEService.class, apigee);
		context.registerService(ResourceResolver.class, resolver);
		context.registerInjectActivateService(fixture);

	}

	@Test
	public void orderNoSearchTest() throws IOException {
		String data = "{\"orderInLast\":\"\",\"creditHold\":\"on\",\"startDate\":\"\",\"endDate\":\"\",\"currentPage\":\"/content/ecommerce/delcity/language-masters/en/open-order\",\"customerNumber\":\"590271\",\"orderNumber\":\"\",\"poNumber\":\"\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		try {
			if (context != null) {
				fixture.doGet(context.request(), context.response());
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the OpenOrderServletTest {}", e.getMessage());
		}
	}
}
