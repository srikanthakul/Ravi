package com.brunswick.ecomm.merclink.core.models.impl;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith(AemContextExtension.class)
class NewsSectionImplTest {
	
	@InjectMocks
	Resource componentResource;
	@Mock
	private ResourceResolver resolver;
	
	public AemContext context = new AemContext();
	public String path = "/content/ecommerce/merclink/au/en/home/news";

	@BeforeEach
	void setUp() throws Exception {
		context.addModelsForPackage("com.brunswick.ecomm.merclink.core.models.impl");
		context.addModelsForClasses(NewsSectionImpl.class);
		context.load().json("/context/newsSection.json", path);
	}

	@Test
	void testGetCurrentNewsShipingLink() {
		Resource resource = context.resourceResolver().getResource(path +"/current-news/jcr:content/root/container/container/allnews");
		assertNotNull(resource);
		NewsSectionImpl newsSection = resource.adaptTo(NewsSectionImpl.class);
		assertEquals("/content/ecommerce/merclink/au/en/home/news/current-news/shipping-updates.html",newsSection.getCurrentNewsShipingLink());
		
	}

	@Test
	void testGetPaNewsShipingLink() {
		Resource resource = context.resourceResolver().getResource(path +"/P-ANews/jcr:content/root/container/container/allnews");
		assertNotNull(resource);
		NewsSectionImpl newsSection = resource.adaptTo(NewsSectionImpl.class);
		assertEquals("/content/ecommerce/merclink/au/en/home/news/P-ANews/Shipping-Updates.html",newsSection.getPaNewsShipingLink());
	}

	@Test
	void testGetServiceNewsShipingLink() {
		Resource resource = context.resourceResolver().getResource(path +"/ServiceNews/jcr:content/root/container/container/allnews");
		assertNotNull(resource);
		NewsSectionImpl newsSection = resource.adaptTo(NewsSectionImpl.class);
		assertEquals("/content/ecommerce/merclink/au/en/home/news/ServiceNews/Shipping-Updates.html",newsSection.getServiceNewsShipingLink());
	}

	@Test
	void testGetSaleNewsShipingLink() {
		Resource resource = context.resourceResolver().getResource(path +"/SalesNews/jcr:content/root/container/container/allnews");
		assertNotNull(resource);
		NewsSectionImpl newsSection = resource.adaptTo(NewsSectionImpl.class);
		assertEquals("/content/ecommerce/merclink/au/en/home/news/SalesNews/Shipping-Updates.html",newsSection.getSaleNewsShipingLink());
	}

	@Test
	void testGetNewsSectionDetails() {
		Resource resource = context.resourceResolver().getResource("/content/ecommerce/merclink/au/en/home/news/current-news/jcr:content/root/container/container/allnews");
		Resource loginDetailNasted=resource.getChild("currentnews");
		NewsSectionImpl newsSection = resource.adaptTo(NewsSectionImpl.class);
		if(loginDetailNasted != null) {
			for (Resource loginNasted : loginDetailNasted.getChildren()) {
			ValueMap property = loginNasted.adaptTo(ValueMap.class);
			Map<String,String> newsMap = new HashMap<>();
			newsMap.put("currentnewslinktext", property.get("currentnewslinktext", String.class));
			newsMap.put("currentnewsdata", property.get("currentnewsdata", String.class));
			newsMap.put("currentnewsicons", property.get("currentnewsicons", String.class));
			newsMap.put("currentnewslink", property.get("currentnewslink", String.class));
			newsMap.put("currentnewspdf", property.get("currentnewspdf", String.class));
			newsMap.put("currentnewslctn", property.get("currentnewslctn", String.class));
			newsMap.put("currentnewsdt", property.get("currentnewsdt", String.class));
			assertNotNull(newsMap);
			assertNotNull(newsSection.getNewsSectionDetails());
			//assertEquals("news destribution center – Shipping Updates ", newsSection.getNewsSectionDetails().get(0).get("currentnewslinktext"));
			}
		}
	}

	@Test
	void testGetPaNewsSectionDetails() {
		Resource resource = context.resourceResolver().getResource(path +"/P-ANews/jcr:content/root/container/container/allnews");
		Resource loginDetailNasted=resource.getChild("currentnews");
		NewsSectionImpl newsSection = resource.adaptTo(NewsSectionImpl.class);
		if(loginDetailNasted != null) {
			for (Resource loginNasted : loginDetailNasted.getChildren()) {
			ValueMap property = loginNasted.adaptTo(ValueMap.class);
			Map<String,String> newsMap = new HashMap<>();
			newsMap.put("currentnewslinktext", property.get("currentnewslinktext", String.class));
			newsMap.put("currentnewsdata", property.get("currentnewsdata", String.class));
			newsMap.put("currentnewsicons", property.get("currentnewsicons", String.class));
			newsMap.put("currentnewslink", property.get("currentnewslink", String.class));
			newsMap.put("currentnewspdf", property.get("currentnewspdf", String.class));
			newsMap.put("currentnewslctn", property.get("currentnewslctn", String.class));
			newsMap.put("currentnewsdt", property.get("currentnewsdt", String.class));
			assertNotNull(newsMap);
			assertNotNull(newsSection.getPaNewsSectionDetails());
			}
		}
	}

	@Test
	void testGetServiceNewsSectionDetails() {
		Resource resource = context.resourceResolver().getResource(path +"/ServiceNews/jcr:content/root/container/container/allnews");
		Resource loginDetailNasted=resource.getChild("currentnews");
		NewsSectionImpl newsSection = resource.adaptTo(NewsSectionImpl.class);
		if(loginDetailNasted != null) {
			for (Resource loginNasted : loginDetailNasted.getChildren()) {
			ValueMap property = loginNasted.adaptTo(ValueMap.class);
			Map<String,String> newsMap = new HashMap<>();
			newsMap.put("currentnewslinktext", property.get("currentnewslinktext", String.class));
			newsMap.put("currentnewsdata", property.get("currentnewsdata", String.class));
			newsMap.put("currentnewsicons", property.get("currentnewsicons", String.class));
			newsMap.put("currentnewslink", property.get("currentnewslink", String.class));
			newsMap.put("currentnewspdf", property.get("currentnewspdf", String.class));
			newsMap.put("currentnewslctn", property.get("currentnewslctn", String.class));
			newsMap.put("currentnewsdt", property.get("currentnewsdt", String.class));
			assertNotNull(newsMap);
			assertNotNull(newsSection.getServiceNewsSectionDetails());
			}
		}
	}

	@Test
	void testGetSaleNewsSectionDetails() {
		Resource resource = context.resourceResolver().getResource(path +"/SalesNews/jcr:content/root/container/container/allnews");
		Resource loginDetailNasted=resource.getChild("currentnews");
		NewsSectionImpl newsSection = resource.adaptTo(NewsSectionImpl.class);
		if(loginDetailNasted != null) {
			for (Resource loginNasted : loginDetailNasted.getChildren()) {
			ValueMap property = loginNasted.adaptTo(ValueMap.class);
			Map<String,String> newsMap = new HashMap<>();
			newsMap.put("currentnewslinktext", property.get("currentnewslinktext", String.class));
			newsMap.put("currentnewsdata", property.get("currentnewsdata", String.class));
			newsMap.put("currentnewsicons", property.get("currentnewsicons", String.class));
			newsMap.put("currentnewslink", property.get("currentnewslink", String.class));
			newsMap.put("currentnewspdf", property.get("currentnewspdf", String.class));
			newsMap.put("currentnewslctn", property.get("currentnewslctn", String.class));
			newsMap.put("currentnewsdt", property.get("currentnewsdt", String.class));
			assertNotNull(newsMap);
			assertNotNull(newsSection.getSaleNewsSectionDetails());
			}
		}
	}

}
