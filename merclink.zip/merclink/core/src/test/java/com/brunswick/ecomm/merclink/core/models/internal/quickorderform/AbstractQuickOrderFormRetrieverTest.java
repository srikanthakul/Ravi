package com.brunswick.ecomm.merclink.core.models.internal.quickorderform;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

import junitx.framework.Assert;

public class AbstractQuickOrderFormRetrieverTest {
	private QuickOrderFormRetriever retriever;
	private static final Logger LOG = LoggerFactory.getLogger(AbstractQuickOrderFormRetrieverTest.class);
	private MagentoGraphqlClient mockClient;

	@Before
	public void setUp() throws NullPointerException {

		GraphqlResponse<Mutation, Error> response = mock(GraphqlResponse.class);
		Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
		Mutation mutation = mock(Mutation.class);
		mockClient = mock(MagentoGraphqlClient.class);
		GraphqlResponse mockResponse = mock(GraphqlResponse.class);
		when(mockClient.execute(any())).thenReturn(mockResponse);
		when(mockResponse.getData()).thenReturn(mockQuery);
		when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());
		when(mockQuery.getCart().getItems()).thenReturn(Collections.EMPTY_LIST);
		when(mockQuery.getStoreConfig().getSecureBaseMediaUrl()).thenReturn("");
		retriever = new QuickOrderFormRetriever(mockClient);

	}

	@Test
	public void testSetIdentifier() throws NullPointerException {
		String identifier = "AS123456";
		try {
			if (retriever != null) {
				retriever.setIdentifier(identifier);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the testSetIdentifier of AbstractQuickOrderFormRetrieverTest {}", e.getMessage());
		}
		assertNotNull(identifier);

	}

	@Test
	public void testSkuIdentifierType() throws NullPointerException {
		String identifier = "my-sku";
		try {
			if (retriever != null) {
				retriever.setIdentifier("my-sku");
				retriever.fetchProduct();
				ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
				verify(mockClient, times(1)).execute(captor.capture());
				String queryStartsWith = "{products(filter:{sku:{eq:\"my-sku\"}})";
				Assert.assertTrue(captor.getValue().startsWith(queryStartsWith));
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the testSkuIdentifierType of AbstractQuickOrderFormRetrieverTest{}", e.getMessage());
		}
		assertNotNull(identifier);

		
	}

	@Test
	public void testSku() throws NullPointerException {
		String identifier = "my-id";

		try {
			if (retriever != null) {

				retriever.setIdentifier("my-id");
				retriever.fetchProduct();
				ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);

				verify(mockClient, times(1)).execute(captor.capture());

				String queryStartsWith = "{products(filter:{sku:{eq:\"my-id\"}})";
				Assert.assertTrue(captor.getValue().startsWith(queryStartsWith));
				
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the testSku of AbstractQuickOrderFormRetrieverTest {}", e.getMessage());
		}

		assertNotNull(identifier);

	}

}
