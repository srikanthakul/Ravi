package com.brunswick.ecomm.merclink.core.servlets;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.caconfig.ConfigurationBuilder;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.adobe.cq.commerce.core.components.internal.services.UrlProviderImpl;
import com.adobe.cq.commerce.core.components.services.ComponentsConfiguration;
import com.adobe.cq.commerce.core.components.services.urls.UrlProvider;
import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.brunswick.ecomm.merclink.core.components.testing.MockExternalizer;
import com.brunswick.ecomm.merclink.core.components.testing.Utils;
import com.day.cq.commons.Externalizer;
import com.google.common.collect.ImmutableMap;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

class ANZPLoginServletTest {
	@Rule
	private EcommSessionService adminService;
	private ANZPLoginServlet fixture = new ANZPLoginServlet();
	private APIGEEService apigee;

	@Rule
	public final AemContext context = createContext("/context/categoryTree.json");

	private static final ValueMap MOCK_CONFIGURATION = new ValueMapDecorator(
			ImmutableMap.of("cq:graphqlClient", "default", "magentoStore", "my-store"));

	private static final ComponentsConfiguration MOCK_CONFIGURATION_OBJECT = new ComponentsConfiguration(
			MOCK_CONFIGURATION);

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			context.load().json(contentPath, "/content");

			UrlProviderImpl urlProvider = new UrlProviderImpl();
			context.registerService(UrlProvider.class, urlProvider);

			context.registerAdapter(Resource.class, ComponentsConfiguration.class,
					(Function<Resource, ComponentsConfiguration>) input -> !((Resource) input).getPath()
							.contains("pageB") ? MOCK_CONFIGURATION_OBJECT : ComponentsConfiguration.EMPTY);

			context.registerService(Externalizer.class, new MockExternalizer());

			ConfigurationBuilder mockConfigBuilder = Utils.getDataLayerConfig(true);
			context.registerAdapter(Resource.class, ConfigurationBuilder.class, mockConfigBuilder);
		}, ResourceResolverType.JCR_MOCK);
	}

	@Before
	public void setup() throws IOException, JSONException {
		fixture = new ANZPLoginServlet();
		apigee = Mockito.mock(APIGEEService.class);
		APIGEEService apigee = Mockito.mock(APIGEEService.class);
		adminService = Mockito.mock(EcommSessionService.class);
		context.registerService(EcommSessionService.class, adminService);
		context.registerService(APIGEEService.class, apigee);
		context.registerInjectActivateService(fixture);
	}

	@Test
	public void testDoPostSlingHttpServletRequestSlingHttpServletResponse() throws IOException, LoginException {
		ResourceResolver resolver = mock(ResourceResolver.class);
		try {
			if (resolver != null) {
				when(adminService.getWriteServiceResourceResolver()).thenReturn(resolver);
				return;
			}
		} catch (NullPointerException e) {
			e.getMessage();
		}
		String data = "{\"itemno\":\"ABC\",\"resourcePath\":\"/content/ecommerce/delcity/us/en/home/quick-order\",\"token\":\"23pjbqgrhwict6xjzvg2tdr9vfjmkhja\",\"operatingUnit\":\"DC\"}}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		try {
			fixture.doPost(null, null);
			fixture.doPost(context.request(), context.response());
		} catch (Exception e) {
			e.getMessage();
		}
	}
}
