package com.brunswick.ecomm.merclink.core.servlets.checkout;

import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.jcr.Session;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.apache.sling.testing.resourceresolver.MockResourceResolverFactory;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.brunswick.ecomm.core.services.apigee.impl.APIGEEServiceImpl;
import com.google.gson.JsonObject;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

public class GetAddressServletTest {
	private static final Logger LOG = LoggerFactory.getLogger(GetAddressServletTest.class);
	@Rule
	public final AemContext context = createContext("/context/jcr-homepage-header-model.json");
	private EcommSessionService adminService;
	private ResourceResolver resolver;
	private GetAddressServlet fixture = new GetAddressServlet();
	private APIGEEService apigeeservice;
	private APIGEEServiceImpl mockServiceImpl;
	ResourceResolver resourceResolver;
	SlingHttpServletResponse response;
	SlingHttpServletRequest request;
	Session currentSession;
	Resource resource;
	private Resource pageResource;
	private Resource productResource;

	private JsonObject magResponse;
	ResourceResolverFactory resourceResolverFactory;

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");
		}, ResourceResolverType.JCR_MOCK);
	}

	@Before
	public void setup() throws IOException, LoginException {
		fixture = new GetAddressServlet();
		apigeeservice = Mockito.mock(APIGEEService.class);
		APIGEEService apigee = Mockito.mock(APIGEEService.class);
		resolver = context.resourceResolver();
		adminService = Mockito.mock(EcommSessionService.class);
		MockResourceResolverFactory factory = new MockResourceResolverFactory();
		resolver = factory.getResourceResolver(null);
		context.registerService(EcommSessionService.class, adminService);
		context.registerService(APIGEEService.class, apigee);
		context.registerService(ResourceResolver.class, resolver);
		final Map<String, Object> serviceMap = new ConcurrentHashMap<>();
		serviceMap.put(ResourceResolverFactory.SUBSERVICE, "ecommReadService");
		try {
			if (context != null) {
				when(resourceResolverFactory.getServiceResourceResolver(serviceMap)).thenReturn(resourceResolver);
				when(adminService.getReadServiceResourceResolver()).thenReturn(resourceResolver);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the GetAddressServletTest {}", e.getMessage());
		}
	}

	@Test
	public void getAddressTest() throws IOException, LoginException {
		String data = "{\"customerNumber\":\"test\",\"startTime\":\"test\",\"endTime\":\"test\",\"companyname\":\"test\",\"addressLineship1\":\"890 TOWNSHIP ROAD #184\",\"addressLineship2\":\"\",\"shipcity\":\"Fond du Lac\",\"shipStateId\":\"WI\",\"shipStateName\":\"Wisconsin\",\"shippost\":\"54935\",\"shipCountry\":\"US\",\"billfname\":\"test\",\"billlname\":\"billing\",\"addressLinebill1\":\"4450 TOWNSHIP ROAD #184\",\"addressLinebill2\":\"\",\"billcity\":\"Fond du Lac\",\"billStateId\":\"WI\",\"billStateName\":\"Wisconsin\",\"billpost\":\"54935\",\"billCountry\":\"US\",\"resourcePath\":\"/content/ecommerce/merclink/language-masters/en/registration\"}";

		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		try {
			if (context != null) {
				fixture.doGet(context.request(), context.response());

				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the GetAddressServlet {}", e.getMessage());
		}
	}
}
