package com.brunswick.ecomm.merclink.core.models.internal.product;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GroupItemImplTest {
	GroupItemImpl fixture;
	String test;
	Double digits;
	Boolean value;
	
	

	@BeforeEach
	void setUp() throws Exception {
		fixture = new GroupItemImpl();

	}

	@Test
	void testGetName() {
		test="word";
		fixture.setName(test);
		assertEquals(test,fixture.getName());
		
	}

	

	@Test
	void testGetSku() {
		test="word";
		fixture.setSku(test);
		assertEquals(test,fixture.getSku());
	}

	
	

	@Test
	void testGetDefaultQuantity() {
		
	   digits=1.1d;
	   fixture.setDefaultQuantity(digits);
	   assertEquals(digits,fixture.getDefaultQuantity());
	   
	}

	

	@Test
	void testIsVirtualProduct() {
		value=true;
		fixture.setVirtualProduct(value);
		assertEquals(value,fixture.isVirtualProduct());
		
	}

	

}
