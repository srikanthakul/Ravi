package com.brunswick.ecomm.merclink.core.beans;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AssetImplTest {
	public AssetImpl fixture;
	String test;

	@BeforeEach
	void setUp() throws Exception {
		fixture = new AssetImpl();
	}

	@Test
	void getLabelTest() {
		test = "Label";
		fixture.setLabel(test);
		assertEquals(test, fixture.getLabel());
		
	}

	@Test
	void getPositionTest() {
		Integer expectedOutput = 1;
		fixture.setPosition(1);
		assertEquals(expectedOutput, fixture.getPosition());
	}

	@Test
	void getTypeTest() {
		String expectedOutput = "Type";
		fixture.setType(expectedOutput);
		assertEquals(expectedOutput, fixture.getType());
	}

	@Test
	void getPathTest() {
		String expectedOutput = "Path";
		fixture.setPath(expectedOutput);
		assertEquals(expectedOutput, fixture.getPath());
	}

}
