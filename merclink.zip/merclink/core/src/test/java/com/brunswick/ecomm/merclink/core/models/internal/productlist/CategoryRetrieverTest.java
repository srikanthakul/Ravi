package com.brunswick.ecomm.merclink.core.models.internal.productlist;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

class CategoryRetrieverTest {
	private CategoryRetriever retriever;
	private MagentoGraphqlClient mockClient;
	private static final Logger LOG = LoggerFactory.getLogger(CategoryRetrieverTest.class);

	GraphqlResponse<Mutation, Error> response = mock(GraphqlResponse.class);
	Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	Mutation mutation = mock(Mutation.class);

	@BeforeEach
	void setUp() throws Exception {
		mockClient = mock(MagentoGraphqlClient.class);

		GraphqlResponse mockResponse = mock(GraphqlResponse.class);
		when(mockClient.execute(any())).thenReturn(mockResponse);
		when(response.getData()).thenReturn(mutation);
		when(mockResponse.getData()).thenReturn(mockQuery);
		when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());
		when(mockQuery.getCart().getItems()).thenReturn(Collections.EMPTY_LIST);
		mockClient = mock(MagentoGraphqlClient.class);
		Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);

		when(mockClient.execute(any())).thenReturn(mockResponse);
		when(mockResponse.getData()).thenReturn(mockQuery);
		when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());

		retriever = new CategoryRetriever(mockClient);
		retriever.setIdentifier("5");
	}

	@Test
	public void testQueryOverride() {

		try {
			if (retriever != null) {
				String sampleQuery = "{ my_sample_query }";
				retriever.setQuery(sampleQuery);
				retriever.fetchCategory();
				assertNotNull(sampleQuery);
				verify(mockClient, times(1)).execute(sampleQuery);
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateQuery {}", e.getMessage());
		}

	}

	@Test
	public void testExtendCategoryQuery() throws NullPointerException {

		retriever.extendCategoryQueryWith(c -> c.childrenCount().addCustomSimpleField("level"));
		retriever.extendCategoryQueryWith(c -> c.staged()); // use extend method twice to test the "merge"
															// feature
		retriever.fetchCategory();
		final ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
		verify(mockClient, times(1)).execute(captor.capture());

	}

}