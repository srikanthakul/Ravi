package com.brunswick.ecomm.merclink.core.servlets;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.apache.http.client.HttpClient;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.scripting.SlingBindings;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.caconfig.ConfigurationBuilder;
import org.apache.sling.servlethelpers.MockRequestPathInfo;
import org.apache.sling.servlethelpers.MockSlingHttpServletRequest;
import org.apache.sling.servlethelpers.MockSlingHttpServletResponse;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.apache.sling.testing.resourceresolver.MockResourceResolverFactory;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.core.components.internal.services.UrlProviderImpl;
import com.adobe.cq.commerce.core.components.services.ComponentsConfiguration;
import com.adobe.cq.commerce.core.components.services.urls.UrlProvider;
import com.adobe.cq.commerce.graphql.client.GraphqlClient;
import com.adobe.cq.commerce.graphql.client.GraphqlClientConfiguration;
import com.adobe.cq.commerce.graphql.client.HttpMethod;
import com.adobe.cq.commerce.graphql.client.impl.GraphqlClientImpl;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.gson.MutationDeserializer;
import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.brunswick.ecomm.merclink.core.components.testing.MockExternalizer;
import com.brunswick.ecomm.merclink.core.components.testing.Utils;
import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.scripting.WCMBindingsConstants;
import com.google.common.collect.ImmutableMap;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

public class ProductSupersessionServletTest {

	@Rule
	public final AemContext context = createContext("/context/jcr-content-product.json");

	private static final Logger LOG = LoggerFactory.getLogger(ProductSupersessionServlet.class);
	
	private static final ValueMap MOCK_CONFIGURATION = new ValueMapDecorator(
			ImmutableMap.of("cq:graphqlClient", "default", "magentoStore", "my-store"));

	private static final ComponentsConfiguration MOCK_CONFIGURATION_OBJECT = new ComponentsConfiguration(
			MOCK_CONFIGURATION);

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");

			UrlProviderImpl urlProvider = new UrlProviderImpl();
			//urlProvider.activate(new MockUrlProviderConfiguration());
			context.registerService(UrlProvider.class, urlProvider);

			context.registerAdapter(Resource.class, ComponentsConfiguration.class,
					(Function) input -> !((Resource) input).getPath().contains("pageB")
							? MOCK_CONFIGURATION_OBJECT
							: ComponentsConfiguration.EMPTY);

			context.registerService(Externalizer.class, new MockExternalizer());

			ConfigurationBuilder mockConfigBuilder = Utils.getDataLayerConfig(true);
			context.registerAdapter(Resource.class, ConfigurationBuilder.class, mockConfigBuilder);
		}, ResourceResolverType.JCR_MOCK);
	}

	private ProductSupersessionServlet fixture;
	private MockSlingHttpServletRequest request;
	private MockSlingHttpServletResponse response;
	private static final String PAGE = "/content/productList";
	private static final String PRODUCT_SS = "/content/productList/jcr:content/root/responsivegrid_1/products";
	private Resource pageResource;
	private Resource productResource;
	private String product;
	private GraphqlClient graphqlClient;
	private ResourceResolver resolver;
	private EcommSessionService adminService;
	private APIGEEService apigeeService;
	private HttpClient httpClient;
	private String customerToken;

	@Before
	public void setUp() throws Exception {
		fixture = new ProductSupersessionServlet();
		apigeeService = Mockito.mock(APIGEEService.class);
		APIGEEService apigeeService = Mockito.mock(APIGEEService.class);
		resolver = context.resourceResolver();
		adminService = Mockito.mock(EcommSessionService.class);
		MockResourceResolverFactory factory = new MockResourceResolverFactory();
		resolver = factory.getResourceResolver(null);
		context.registerService(EcommSessionService.class, adminService);
		context.registerService(APIGEEService.class,apigeeService);
		context.registerService(ResourceResolver.class,resolver);
		context.registerInjectActivateService(fixture);
	}
	
	@Test
	public void getStatementsDoGetTest() throws IOException{
		String data = "{\"itemNumber\":\"12345\",\"resourcePath\":\"/content/ecommerce/merclink/language-masters/en/statements\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		try {
			if(fixture != null) {
				fixture.doPost(context.request(), context.response());
			}
		}catch(Exception e) {
			e.getMessage();
		}
		
	}
}
