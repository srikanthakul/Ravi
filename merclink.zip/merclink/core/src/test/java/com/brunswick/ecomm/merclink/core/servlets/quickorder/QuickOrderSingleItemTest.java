package com.brunswick.ecomm.merclink.core.servlets.quickorder;

import static org.mockito.Mockito.mock;

import java.io.IOException;

import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.xfa.ut.StringUtils;

@Component(service = Servlet.class, property = { "sling.servlet.methods=" + HttpConstants.METHOD_POST,
		"sling.servlet.resourceTypes=" + "sling/servlet/default",
		"sling.servlet.selectors=" + "merclinkquickordersingleitems", "sling.servlet.extensions=" + "json" })
class QuickOrderSingleItemTest {
	private static final Logger LOG = LoggerFactory.getLogger(QuickOrderSingleItem.class);
	private static final long serialVersionUID = 1L;
	String currentPagePath;
	String customerNumber = StringUtils.WHITE_SPACE;

	private SlingHttpServletRequest request;
	private SlingHttpServletResponse response;

	private QuickOrderSingleItem quickOrderSingleItem;

	@BeforeEach
	void setUp() {
		quickOrderSingleItem = new QuickOrderSingleItem();
		request = mock(SlingHttpServletRequest.class);
		response = mock(SlingHttpServletResponse.class);
	}

	@Test
	void doPostTest() throws IOException {
		quickOrderSingleItem.doPost(request, response);

	}
}
