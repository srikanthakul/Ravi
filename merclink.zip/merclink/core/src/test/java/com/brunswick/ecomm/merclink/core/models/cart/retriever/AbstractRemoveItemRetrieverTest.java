package com.brunswick.ecomm.merclink.core.models.cart.retriever;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import java.util.List;
import java.util.Collections;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.CartItemInterface;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.RemoveItemFromCartOutputQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.MutationQuery.RemoveItemFromCartArgumentsDefinition;
import com.adobe.cq.commerce.magento.graphql.gson.Error;

//import com.brunswick.ecomm.merclink.core.models.remove.RemoveItemRetriever;

public class AbstractRemoveItemRetrieverTest {
	
	 private AbstractRemoveItemRetriever retriever ;
	 private static final Logger LOG = LoggerFactory.getLogger(AbstractRemoveItemRetriever.class);
	    private  MagentoGraphqlClient mockClient;
	    Customer customer;
	    Integer itemId;
	    List<CartItemInterface> cartItems;
	    GraphqlResponse<Mutation, Error> response= mock(GraphqlResponse.class);
	    Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	    Mutation mutation= mock(Mutation.class);
	    @BeforeEach
	    public void setUp() {
	         mockClient = mock(MagentoGraphqlClient.class);
	       
	       
	        GraphqlResponse mockResponse = mock(GraphqlResponse.class);
	        when(mockClient.execute(any())).thenReturn(mockResponse);
	        when(response.getData()).thenReturn(mutation);
	        when(mockResponse.getData()).thenReturn(mockQuery);
	        when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());
	        
	        retriever = new AbstractRemoveItemRetriever(mockClient) {
				
				@Override
				protected RemoveItemFromCartOutputQueryDefinition generateRemoveItemQuery() {
					// TODO Auto-generated method stub
					return null;
				}
				
				@Override
				protected RemoveItemFromCartArgumentsDefinition generateRemoveItemInputQuery(String cartId, int itemId) {
					// TODO Auto-generated method stub
					return null;
				}
			};
	      
	    }
	     
	   

	    

	@Test
	 void testSetIdentifier() {
		String cartId = "ABC123";
		Integer itemId = 123;
		retriever.setIdentifier(cartId, itemId);
		
		try {
			if(retriever !=null) {
				
				assertNotNull(retriever.cartId);	
			}
		} catch(NullPointerException e) {
			LOG.error("Null pointer exception");
		}
		
	}

	@Test
	 void testExecuteMutation() {
		String cartId = "ABC123";
		Integer itemId = 123;
		retriever.setIdentifier(cartId, itemId);
		//retriever.executeMutation();
		try {
			if(retriever !=null) {
				assertNotNull(retriever.itemId);
			}
		} catch(NullPointerException e) {
			LOG.error("Null pointer exception");
		}
		
	}


}

