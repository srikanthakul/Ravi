package com.brunswick.ecomm.merclink.core.beans.product;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.brunswick.ecomm.core.beans.product.InventoryStatusBean;


public class InventoryStatusBeanTest {
	InventoryStatusBean fixture;
	
	@BeforeEach
	public void setup() {
		fixture = new InventoryStatusBean();
	}
	
	@Test
	public void getIdTest() {
		String id = "id";
		fixture.setId(id);
		assertEquals(id, fixture.getId());
	}
	
	@Test
	public void getMessageTest() {
		String expectedmessage = "message";
		fixture.setMessage(expectedmessage );
		assertEquals(expectedmessage, fixture.getMessage());
	}
	
}
