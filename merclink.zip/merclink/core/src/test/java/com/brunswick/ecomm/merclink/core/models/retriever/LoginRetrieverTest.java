package com.brunswick.ecomm.merclink.core.models.retriever;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import java.util.Collections;
import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.CustomerToken;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
class LoginRetrieverTest {
	
	
	private LoginRetriever retriever;
    private MagentoGraphqlClient mockClient;
    Customer customer;
    
    GraphqlResponse<Mutation, Error> response= mock(GraphqlResponse.class);
    Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
    Mutation mutation= mock(Mutation.class);
    private static final Logger LOG = LoggerFactory.getLogger(CompanyRegistrationRetriever.class);
    @BeforeEach
    public void setUp() {
        mockClient = mock(MagentoGraphqlClient.class);
       
       
        GraphqlResponse mockResponse = mock(GraphqlResponse.class);
        when(mockClient.execute(any())).thenReturn(mockResponse);
        when(mockClient.executeMutation(any())).thenReturn(response);
        when(response.getData()).thenReturn(mutation);
        when(mockResponse.getData()).thenReturn(mockQuery);
        when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());
        when(mockQuery.getCart().getItems()).thenReturn(Collections.emptyList());
        retriever = new LoginRetriever(mockClient);        
        
    }
	@Test
	 void testPopulate() {							  
    	retriever.populate();
	}

	@Test
	void generateCustomerToken() {
		 String sampleQuery = "{mutation {\r\n" + 
	        		" generateCustomerToken(\r\n" + 
	        		" email: \"raj.mohanrajendran@infosys.com\"\r\n" + 
	        		" ) {\r\n" + 
	        		" token\r\n" + 
	        		" }\r\n" + 
	        		"}\r\n" + 
	        		" }";
	        retriever.setQuery(sampleQuery);
	       // mockClient.executeMutation(sampleQuery);
	        CustomerToken token =mock(CustomerToken.class);
	        when(mutation.getGenerateCustomerToken()).thenReturn(token);
	        when( token.getToken()).thenReturn("12345");
	        retriever.generateCustomerToken("raj.mohanrajendran@infosys.com");
	}

	@Test
	void testGetCustomerCart() {  							  
		String sampleQuery="{SimpleProduct\r\n"+
	                        "CYmiiQRjPVc2gJUc5r7IsBmwegVIFO43\r\n"+
				            "}";   								
		retriever.setQuery(sampleQuery);
    	mockClient.execute(sampleQuery);
        mockClient.executeMutation(sampleQuery);
    	//retriever.getCustomerCart();
    	try {
			if (retriever != null) {
				retriever.getCustomerCart();
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the testGetCustomerCart {}", e.getMessage());
		}
	
	}
	

}
