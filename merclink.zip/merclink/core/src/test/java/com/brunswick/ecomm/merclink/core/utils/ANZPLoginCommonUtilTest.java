package com.brunswick.ecomm.merclink.core.utils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

//import com.adobe.cq.commerce.core.components.internal.services.SpecificPageStrategy.Configuration;
import com.day.cq.wcm.api.Page;
import com.adobe.cq.commerce.core.components.models.product.Asset;
import com.adobe.cq.social.calendar.client.api.Calendar;
import com.adobe.granite.asset.api.AssetManager;
import com.brunswick.ecomm.core.util.PropertyUtil;
import com.day.cq.wcm.webservicesupport.ConfigurationManagerFactory;
import com.day.cq.wcm.webservicesupport.Configuration;

import acscommons.com.jcraft.jsch.Logger;



public class ANZPLoginCommonUtilTest {
		
	private static final byte LOGGER = 0;
	
	@Test
	void testDaysBetween() {
      Date d1 = new Date(1220227200000L); // Aug 31, 2008
     Date d2 = new Date(1221124800000L); // Sep 11, 2008
     
    int Date = (int) (( d2.getTime())-(d1.getTime()));
        
        assertEquals(897600000, Date, "Days between d1 and d2 should be 11");
    }

	 @Test
		
		public void testGetTokenFromCookie() {
			// Setup
			String cookieName = "test-cookie";
			String cookieValue = "test-cookie-value";
			Cookie cookie = new Cookie(cookieName, cookieValue);
			SlingHttpServletRequest request = mock(SlingHttpServletRequest.class);
			when(request.getCookies()).thenReturn(new Cookie[] {cookie});

			// Test
			String token = getTokenFromCookie(cookieName, request);

			// Verify
			assertEquals(token, token);
			//((object) LOGGER).info("Token value {}", token);
		}

		private static Logger LoggerFactory(Class<ANZPLoginCommonUtilTest> class1) {
			// TODO Auto-generated method stub
			return null;
		}

		private String getTokenFromCookie(String cookieName, SlingHttpServletRequest request) {
			// TODO Auto-generated method stub
			return null;
		}

		@Test
		  void testEncode() {
		    // given
		    String value = "Hello World!";
		    String encType = "UTF-8";
		    String expected = "Hello%20World%21";
		    
		    // mock the logger
		    Logger logger = mock(Logger.class);
		    
		    // create an instance of the class under test
		    ANZPLoginCommonUtil obj = new ANZPLoginCommonUtil();
		    //obj.setLogger(logger); // set the mocked logger

		    // when
		    String actual = obj.encode(value, encType);
		    
		    // then
		    assertEquals(expected, actual);
		  }
private String encode(String value, String encType) {
			// TODO Auto-generated method stub
			return null;
		}
private void setLogger(Logger logger2) {
	// TODO Auto-generated method stub
	
}
@Test
void testEscapeHTML() {
    String htmlString = "<p>Hello, world!</p>";
    String expectedOutput = "Hello, world!";
    String actualOutput = ANZPLoginCommonUtil.escapeHTML(htmlString);
    assertEquals(expectedOutput, actualOutput);
}
@Test
void testDecodeWithUrlParam() {
    String urlParam = "Hello%20World";
    String expectedOutput = "Hello World";
    String actualOutput = ANZPLoginCommonUtil.decode(urlParam);
    assertEquals(expectedOutput, actualOutput);
}

@Test
void testDecodeWithNullUrlParam() {
    String urlParam = null;
    String expectedOutput = null;
    String actualOutput = ANZPLoginCommonUtil.decode(urlParam);
    assertEquals(expectedOutput, actualOutput);
}

@Test
void testDecodeWithBlankUrlParam() {
    String urlParam = "";
    String expectedOutput = "";
    String actualOutput = ANZPLoginCommonUtil.decode(urlParam);
    assertEquals(expectedOutput, actualOutput);
}
@Test
void testGenerateHashValue() {
    String pagePath = "/example/page/path";
    String expectedOutput = "bccc7926";
    String actualOutput =  ANZPLoginCommonUtil.generateHashValue(pagePath);
    assertEquals(expectedOutput, actualOutput);
}
@Test
void testGetListFromStringMap() {
    String[] inputStringArray = {"key1~value1", "key2~value2"};
    Map<String, String> expectedOutput = new HashMap<>();
    expectedOutput.put("key1", "value1");
    expectedOutput.put("key2", "value2");
    Map<String, String> actualOutput = ANZPLoginCommonUtil.getListFromStringMap(inputStringArray);
    assertEquals(expectedOutput, actualOutput);
}
@Test
void testGetType() {
    Asset mockAsset = mock(Asset.class);
  //  when(mockAsset.getName()).thenReturn("example.txt");

    String expectedOutput = "TXT";
   // String actualOutput = ANZPLoginCommonUtil.getType(mockAsset);
    //assertEquals(expectedOutput, actualOutput);
}
@Test
void testGetUniqueID() {
	String uniqueID = ANZPLoginCommonUtil.getUniqueID();
	assertNotNull(uniqueID);
	assertTrue(uniqueID.matches("[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[8|9|aA|bB][0-9a-f]{3}-[0-9a-f]{12}"));
}
	}



 

	   