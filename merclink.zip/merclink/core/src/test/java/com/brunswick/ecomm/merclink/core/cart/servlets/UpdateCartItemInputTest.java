package com.brunswick.ecomm.merclink.core.cart.servlets;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.shopify.graphql.support.ID;
import com.shopify.graphql.support.Input;

class UpdateCartItemInputTest {
    UpdateCartItemInput fixture;
    private int quantity;
    private int sku;
    private String parentSkuTest;
    private Input<List<ID>> selectedOptions = Input.undefined();
    private Input<String> parentSku = Input.undefined();

    @BeforeEach
    void setUp() throws Exception {
        fixture = new UpdateCartItemInput(quantity, sku);
    }

    @Test
    void testGetQuantity() {
        quantity = 1;
        fixture.setQuantity(quantity);
        assertEquals(quantity, fixture.getQuantity());
    }

    @Test
    void testGetSku() {
        sku = 123;
        fixture.setSku(sku);
        assertEquals(sku, fixture.getSku());
    }

    @Test
    void testGetParentSku() {
        parentSkuTest = "123";
        fixture.setParentSku(parentSkuTest);
        assertEquals(parentSkuTest, fixture.getParentSku());
    }
    
    @Test
    void testGetSelectedOptions() {
        List<ID> selectedOptions = new ArrayList<>();
        fixture.setSelectedOptions(selectedOptions);
        assertEquals(selectedOptions, fixture.getSelectedOptions());
    }
}
