package com.brunswick.ecomm.merclink.core.models.internal.product;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.text.NumberFormat;
import java.util.Currency;
import java.util.List;
import java.util.Locale;
import java.util.function.Function;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.http.client.HttpClient;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.scripting.SlingBindings;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.caconfig.ConfigurationBuilder;
import org.apache.sling.servlethelpers.MockRequestPathInfo;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.apache.sling.xss.XSSAPI;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;

import com.adobe.cq.commerce.core.components.internal.services.UrlProviderImpl;
import com.adobe.cq.commerce.core.components.services.ComponentsConfiguration;
import com.adobe.cq.commerce.core.components.services.urls.UrlProvider;
import com.adobe.cq.commerce.graphql.client.GraphqlClient;
import com.adobe.cq.commerce.graphql.client.GraphqlClientConfiguration;
import com.adobe.cq.commerce.graphql.client.HttpMethod;
import com.adobe.cq.commerce.graphql.client.impl.GraphqlClientImpl;
import com.adobe.cq.commerce.magento.graphql.ComplexTextValue;
import com.adobe.cq.commerce.magento.graphql.ConfigurableProduct;
import com.adobe.cq.commerce.magento.graphql.ConfigurableProductOptions;
import com.adobe.cq.commerce.magento.graphql.ConfigurableProductOptionsValues;
import com.adobe.cq.commerce.magento.graphql.GroupedProduct;
import com.adobe.cq.commerce.magento.graphql.MediaGalleryInterface;
import com.adobe.cq.commerce.magento.graphql.ProductInterface;
import com.adobe.cq.commerce.magento.graphql.ProductStockStatus;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.SimpleProduct;
import com.adobe.cq.commerce.magento.graphql.VirtualProduct;
import com.adobe.cq.commerce.magento.graphql.gson.QueryDeserializer;
import com.adobe.cq.sightly.SightlyWCMMode;
import com.brunswick.ecomm.merclink.core.components.testing.MockExternalizer;
//import com.brunswick.ecomm.merclink.core.components.testing.MockUrlProviderConfiguration;
import com.brunswick.ecomm.merclink.core.components.testing.Utils;
import com.brunswick.ecomm.merclink.core.models.product.Asset;
import com.brunswick.ecomm.merclink.core.models.product.GroupItem;
import com.brunswick.ecomm.merclink.core.models.product.Variant;
import com.brunswick.ecomm.merclink.core.models.product.VariantAttribute;
import com.brunswick.ecomm.merclink.core.models.product.VariantValue;
import com.brunswick.ecomm.merclink.core.models.product.common.Price;
import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.designer.Style;
import com.day.cq.wcm.scripting.WCMBindingsConstants;
//import com.google.common.base.Function;
import com.google.common.collect.ImmutableMap;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

public class ProductImplTest {
    
    @Rule
    public final AemContext context = createContext("/context/jcr-content-productimpl.json");
    private static final ValueMap MOCK_CONFIGURATION = new ValueMapDecorator(
        ImmutableMap.of("cq:graphqlClient", "default", "magentoStore", "my-store"));
    private static final Logger LOG = LoggerFactory.getLogger(ProductImpl.class);

    private static final ComponentsConfiguration MOCK_CONFIGURATION_OBJECT = new ComponentsConfiguration(MOCK_CONFIGURATION);

    private static AemContext createContext(String contentPath) {
        return new AemContext(
            (AemContextCallback) context -> {
                // Load page structure
                context.load().json(contentPath, "/content");

                UrlProviderImpl urlProvider = new UrlProviderImpl();
                //urlProvider.activate(new MockUrlProviderConfiguration());
                context.registerService(UrlProvider.class, urlProvider);

                context.registerAdapter(Resource.class, ComponentsConfiguration.class,
                    (Function<Resource, ComponentsConfiguration>) input -> !input.getPath().contains("pageB") ? MOCK_CONFIGURATION_OBJECT
                        : ComponentsConfiguration.EMPTY);

                context.registerService(Externalizer.class, new MockExternalizer());

                ConfigurationBuilder mockConfigBuilder = Utils.getDataLayerConfig(true);
                context.registerAdapter(Resource.class, ConfigurationBuilder.class, mockConfigBuilder);
            },
            ResourceResolverType.JCR_MOCK);
    }

    private static final String PAGE = "/content/pageA";
    private static final String PRODUCT = "/content/pageA/jcr:content/root/responsivegrid/product";

    private Resource productResource;
    private Resource pageResource;
    private ProductImpl productModel;
    private ProductInterface product;
    private HttpClient httpClient;
    private GraphqlClient graphqlClient;

    @Before
    public void setUp() throws Exception {
       context.addModelsForClasses(ProductImpl.class);
        Page page = Mockito.spy(context.currentPage(PAGE));
        pageResource = Mockito.spy(page.adaptTo(Resource.class));
        when(page.adaptTo(Resource.class)).thenReturn(pageResource);

        httpClient = mock(HttpClient.class);

        context.currentResource(PRODUCT);
        productResource = Mockito.spy(context.resourceResolver().getResource(PRODUCT));
        GraphqlClientConfiguration graphqlClientConfiguration = mock(GraphqlClientConfiguration.class);
        when(graphqlClientConfiguration.httpMethod()).thenReturn(HttpMethod.POST);
        Query rootQuery = Utils.getQueryFromResource("graphql/magento-graphql-product-result.json");
        product = rootQuery.getProducts().getItems().get(0);

        graphqlClient = Mockito.spy(new GraphqlClientImpl());
        Whitebox.setInternalState(graphqlClient, "gson", QueryDeserializer.getGson());
        Whitebox.setInternalState(graphqlClient, "client", httpClient);
        //Whitebox.setInternalState(graphqlClient, "configuration", graphqlClientConfiguration);

        Utils.setupHttpResponse("graphql/magento-graphql-product-result.json", httpClient, 200);

        context.registerAdapter(Resource.class, GraphqlClient.class, (Function<Resource, GraphqlClient>) input -> input.getValueMap().get(
            "cq:graphqlClient", String.class) != null ? graphqlClient : null);

        MockRequestPathInfo requestPathInfo = (MockRequestPathInfo) context.request().getRequestPathInfo();
        requestPathInfo.setSelectorString("beaumont-summit-kit");
        context.request().setServletPath(PAGE + ".beaumont-summit-kit.html"); // used by context.request().getRequestURI();

        // This sets the page attribute injected in the models with @Inject or @ScriptVariable
        SlingBindings slingBindings = (SlingBindings) context.request().getAttribute(SlingBindings.class.getName());
        slingBindings.setResource(productResource);
        slingBindings.put(WCMBindingsConstants.NAME_CURRENT_PAGE, page);
        slingBindings.put(WCMBindingsConstants.NAME_PROPERTIES, productResource.getValueMap());

        XSSAPI xssApi = mock(XSSAPI.class);
        when(xssApi.filterHTML(Mockito.anyString())).then(i -> i.getArgument(0, String.class));
        slingBindings.put("xssApi", xssApi);

        Style style = mock(Style.class);
        when(style.get(Mockito.anyString(), Mockito.anyBoolean())).then(i -> i.getArgument(1, Boolean.class));
        slingBindings.put("currentStyle", style);

        SightlyWCMMode wcmMode = mock(SightlyWCMMode.class);
        when(wcmMode.isDisabled()).thenReturn(false);
        slingBindings.put("wcmmode", wcmMode);

        // context.request().adaptTo(ProductImpl.class); is moved to each test because it uses an internal cache
        // and we want to override the "slug" in testEditModePlaceholderData()

    }

    //@Test
    public void testProduct() {
        productModel = context.request().adaptTo(ProductImpl.class);
        testProduct(product, true);

        // We don't return these fields for the EDIT placeholder data
        Assert.assertEquals(product.getMetaDescription(), productModel.getMetaDescription());
        Assert.assertEquals(product.getMetaKeyword(), productModel.getMetaKeywords());
        Assert.assertEquals(product.getMetaTitle(), productModel.getMetaTitle());
        Assert.assertEquals("https://author" + PAGE + ".beaumont-summit-kit.html", productModel.getCanonicalUrl());
    }

    private void testProduct(ProductInterface product, boolean loadClientPrice) {
        Assert.assertTrue("The product is found", productModel.getFound());
        Assert.assertEquals(product.getSku(), productModel.getSku());
        Assert.assertEquals(product.getName(), productModel.getName());
        Assert.assertEquals(product.getDescription().getHtml(), productModel.getDescription());
        Assert.assertEquals(loadClientPrice, productModel.loadClientPrice());

        // Old pricing API should still work
        NumberFormat priceFormatter = NumberFormat.getCurrencyInstance(Locale.US);
        priceFormatter.setCurrency(Currency.getInstance(productModel.getCurrency()));
        Assert.assertEquals(productModel.getPriceRange().getFinalPrice(), productModel.getPrice(), 0.001);
        Assert.assertEquals(priceFormatter.format(productModel.getPrice()), productModel.getFormattedPrice());

        Assert.assertEquals(ProductStockStatus.IN_STOCK.equals(product.getStockStatus()), productModel.getInStock().booleanValue());

        Assert.assertEquals(product.getMediaGallery().size(), productModel.getAssets().size());
        for (int j = 0; j < product.getMediaGallery().size(); j++) {
            MediaGalleryInterface mge = product.getMediaGallery().get(j);
            Asset asset = productModel.getAssets().get(j);
            Assert.assertEquals(mge.getLabel(), asset.getLabel());
            Assert.assertEquals(mge.getPosition(), asset.getPosition());
            Assert.assertEquals("image", asset.getType());
            Assert.assertEquals(mge.getUrl(), asset.getPath());
        }

        Assert.assertTrue(productModel.getGroupedProductItems().isEmpty());
    }

   @Test
    public void testVariants() {
        productModel = context.request().adaptTo(ProductImpl.class);
        try {
            List<Variant> variants = productModel.getVariants();
            Assert.assertNotNull(variants);
        ConfigurableProduct cp = (ConfigurableProduct) product;
        Assert.assertEquals(cp.getVariants().size(), variants.size());

        // Old pricing should still work
        NumberFormat priceFormatter = NumberFormat.getCurrencyInstance(Locale.US);
        priceFormatter.setCurrency(Currency.getInstance(productModel.getCurrency()));

        for (int i = 0; i < variants.size(); i++) {
            Variant variant = variants.get(i);
            SimpleProduct sp = cp.getVariants().get(i).getProduct();

            Assert.assertEquals(sp.getSku(), variant.getSku());
            Assert.assertEquals(sp.getName(), variant.getName());
            Assert.assertEquals(sp.getDescription().getHtml(), variant.getDescription());

            // Old pricing API should still work
            Assert.assertEquals(variant.getPriceRange().getFinalPrice(), variant.getPrice(), 0.001);
            Assert.assertEquals(priceFormatter.format(variant.getPrice()), variant.getFormattedPrice());

            Assert.assertEquals(ProductStockStatus.IN_STOCK.equals(sp.getStockStatus()), variant.getInStock().booleanValue());
            Assert.assertEquals(sp.getColor(), variant.getColor());

            Assert.assertEquals(sp.getMediaGallery().size(), variant.getAssets().size());
            for (int j = 0; j < sp.getMediaGallery().size(); j++) {
                MediaGalleryInterface mge = sp.getMediaGallery().get(j);
                Asset asset = variant.getAssets().get(j);
                Assert.assertEquals(mge.getLabel(), asset.getLabel());
                Assert.assertEquals(mge.getPosition(), asset.getPosition());
                Assert.assertEquals("image", asset.getType());
                Assert.assertEquals(mge.getUrl(), asset.getPath());
            }
        } 
        } 
        catch (NullPointerException e) 
        {
         LOG.error("NullPointerException inside {}", e.getMessage());
        }
    }

    @Test
    public void testGetVariantAttributes() {
        productModel = context.request().adaptTo(ProductImpl.class);
        try {
            List<VariantAttribute> attributes = productModel.getVariantAttributes();
            Assert.assertNotNull(attributes);
        ConfigurableProduct cp = (ConfigurableProduct) product;
        Assert.assertEquals(cp.getConfigurableOptions().size(), attributes.size());

        for (int i = 0; i < attributes.size(); i++) {
            VariantAttribute attribute = attributes.get(i);
            ConfigurableProductOptions option = cp.getConfigurableOptions().get(i);

            Assert.assertEquals(option.getAttributeCode(), attribute.getId());
            Assert.assertEquals(option.getLabel(), attribute.getLabel());

            for (int j = 0; j < attribute.getValues().size(); j++) {
                VariantValue value = attribute.getValues().get(j);
                ConfigurableProductOptionsValues optionValue = option.getValues().get(j);
                Assert.assertEquals(optionValue.getValueIndex(), value.getId());
                Assert.assertEquals(optionValue.getLabel(), value.getLabel());
            }
        } 
        } 
        catch (NullPointerException e) 
        { 
        LOG.error("NullPointerException inside {}", e.getMessage());
        }
    }

    @Test
    public void testSimpleProduct() {
        productModel = context.request().adaptTo(ProductImpl.class);
        try {
            Whitebox.setInternalState(productModel.getProductRetriever(), "product", new SimpleProduct());
            Assert.assertTrue(productModel.getVariants().isEmpty());
            Assert.assertTrue(productModel.getVariantAttributes().isEmpty());
            }catch (NullPointerException e) 
            {
                LOG.error("NullPointerException inside {}", e.getMessage());
            }
        
    }

    @Test
    public void testSafeDescriptionWithNull() {
        productModel = context.request().adaptTo(ProductImpl.class);
        SimpleProduct product = mock(SimpleProduct.class, RETURNS_DEEP_STUBS);
        when(product.getDescription()).thenReturn(null);
        try {
            Whitebox.setInternalState(productModel.getProductRetriever(), "product", product);
            Assert.assertNull(productModel.getDescription());
        } 
        catch (NullPointerException e) 
        { 
        LOG.error("NullPointerException inside {}", e.getMessage());
        }  
    }

    @Test
    public void testSafeDescriptionHtmlNull() {
        productModel = context.request().adaptTo(ProductImpl.class);
        SimpleProduct product = mock(SimpleProduct.class, RETURNS_DEEP_STUBS);
        ComplexTextValue value = mock(ComplexTextValue.class, RETURNS_DEEP_STUBS);
        when(value.getHtml()).thenReturn(null);
        when(product.getDescription()).thenReturn(value);
        try {
        Whitebox.setInternalState(productModel.getProductRetriever(), "product", product);
        Assert.assertNull(productModel.getDescription());
        } 
        catch (NullPointerException e) 
        { 
        LOG.error("NullPointerException inside {}", e.getMessage());
        }
    }

    @Test
    public void testSafeDescription() {
        productModel = context.request().adaptTo(ProductImpl.class);
        String sampleString = "<strong>abc</strong>";
        SimpleProduct product = mock(SimpleProduct.class, RETURNS_DEEP_STUBS);
        ComplexTextValue value = mock(ComplexTextValue.class, RETURNS_DEEP_STUBS);
        when(value.getHtml()).thenReturn(sampleString);
        when(product.getDescription()).thenReturn(value);
        try {
            Whitebox.setInternalState(productModel.getProductRetriever(), "product", product);
            Assert.assertEquals(sampleString, productModel.getDescription());;
        } 
        catch (NullPointerException e) 
        { 
        LOG.error("NullPointerException inside {}", e.getMessage());
        }
    }

    @Test
    public void testSafeDescriptionConfigurableProduct() {
        try {
            productModel = context.request().adaptTo(ProductImpl.class);
        } 
        catch (NullPointerException e) 
        { 
        LOG.error("NullPointerException inside {}", e.getMessage());
        }
        String sampleString = "<strong>def</strong>";
        ConfigurableProduct product = mock(ConfigurableProduct.class, RETURNS_DEEP_STUBS);
        ComplexTextValue value = mock(ComplexTextValue.class, RETURNS_DEEP_STUBS);
        when(value.getHtml()).thenReturn(sampleString);
        when(product.getDescription()).thenReturn(value);
        try {
            Whitebox.setInternalState(productModel.getProductRetriever(), "product", product);
            Assert.assertEquals(sampleString, productModel.getDescription());
        } 
        catch (NullPointerException e) 
        { 
        LOG.error("NullPointerException inside {}", e.getMessage());
        }
    }

    @Test
    public void testEditModePlaceholderData() throws IOException {
        MockRequestPathInfo requestPathInfo = (MockRequestPathInfo) context.request().getRequestPathInfo();
        requestPathInfo.setSelectorString(null);
        productModel = context.request().adaptTo(ProductImpl.class);

        String json = Utils.getResource(ProductImpl.PLACEHOLDER_DATA);
        Query rootQuery = QueryDeserializer.getGson().fromJson(json, Query.class);
        product = rootQuery.getProducts().getItems().get(0);
        try {
            if (product != null) {
                testProduct(product, false);
                return;
            }
            }catch (NullPointerException e) 
            {
                LOG.error("NullPointerException inside {}", e.getMessage());
            }
    }

    @Test
    public void testPriceRange() {
        try {
        productModel = context.request().adaptTo(ProductImpl.class);
        Price price = productModel.getPriceRange();
        Assert.assertTrue(price.isRange());
        Assert.assertFalse(price.isDiscounted());
        Assert.assertEquals(58.0, price.getRegularPrice(), 0.001);
        Assert.assertEquals(58.0, price.getFinalPrice(), 0.001);
        Assert.assertEquals(62.0, price.getRegularPriceMax(), 0.001);
        Assert.assertEquals(62.0, price.getFinalPriceMax(), 0.001);
        } 
        catch (NullPointerException e) 
        { 
        LOG.error("NullPointerException inside {}", e.getMessage());
        }
    }

    @Test
    public void testDiscountedPrice() {
        try {
        productModel = context.request().adaptTo(ProductImpl.class);
        Price price = productModel.getVariants().get(0).getPriceRange();
        Assert.assertFalse(price.isRange());
        Assert.assertTrue(price.isDiscounted());
        Assert.assertEquals(58.0, price.getRegularPrice(), 0.001);
        Assert.assertEquals(46.0, price.getFinalPrice(), 0.001);
        Assert.assertEquals(12.0, price.getDiscountAmount(), 0.001);
        Assert.assertEquals(20.69, price.getDiscountPercent(), 0.001);
        } 
        catch (NullPointerException e) 
        { 
        LOG.error("NullPointerException inside {}", e.getMessage());
        }
    }

    @Test
    public void testGroupedProduct() throws IOException {
        try {
        Query rootQuery = Utils.getQueryFromResource("graphql/magento-graphql-groupedproduct-result.json");
        product = rootQuery.getProducts().getItems().get(0);

        Utils.setupHttpResponse("graphql/magento-graphql-groupedproduct-result.json", httpClient, 200);

        productModel = context.request().adaptTo(ProductImpl.class);

        List<GroupItem> items = productModel.getGroupedProductItems();
        Assert.assertTrue(productModel.isGroupedProduct());
        Assert.assertEquals(4, items.size());

        GroupedProduct gp = (GroupedProduct) product;
        for (int i = 0; i < items.size(); i++) {
            GroupItem item = items.get(i);
            ProductInterface pi = gp.getItems().get(i).getProduct();

            Assert.assertEquals(pi.getSku(), item.getSku());
            Assert.assertEquals(pi.getName(), item.getName());
            Assert.assertEquals(pi.getPriceRange().getMinimumPrice().getFinalPrice().getValue(), item.getPriceRange().getFinalPrice(), 0);
            Assert.assertEquals(gp.getItems().get(i).getQty(), item.getDefaultQuantity(), 0);

            Assert.assertEquals(pi instanceof VirtualProduct, item.isVirtualProduct());
        }
        } 
        catch (NullPointerException e) 
        { 
        LOG.error("NullPointerException inside {}", e.getMessage());
        }
    }

    @Test
    public void testVirtualProduct() throws IOException {
        try {
            Utils.setupHttpResponse("graphql/magento-graphql-virtualproduct-result.json", httpClient, 200);
            productModel = context.request().adaptTo(ProductImpl.class);
            Assert.assertFalse("Product is not found", productModel.getFound());
            } 
            catch (NullPointerException e) 
            { 
            LOG.error("NullPointerException inside {}", e.getMessage());
            }
    }

    @Test
    public void testBundleProduct() throws IOException {
        try {
            Utils.setupHttpResponse("graphql/magento-graphql-bundleproduct-result.json", httpClient, 200);
            productModel = context.request().adaptTo(ProductImpl.class);
            Assert.assertFalse("Product is not found", productModel.getFound());
        } 
        catch (NullPointerException e) 
        { 
        LOG.error("NullPointerException inside {}", e.getMessage());
        }
    }

    @Test
    public void testProductNoGraphqlClient() {
        when(productResource.adaptTo(ComponentsConfiguration.class)).thenReturn(ComponentsConfiguration.EMPTY);
        when(pageResource.adaptTo(ComponentsConfiguration.class)).thenReturn(ComponentsConfiguration.EMPTY);
        productModel = context.request().adaptTo(ProductImpl.class);

//        Assert.assertFalse("Product is not found", productModel.getFound());
//        Assert.assertFalse("Product is not configurable", productModel.isConfigurable());
//        Assert.assertFalse("Product is not a grouped product", productModel.isGroupedProduct());
//        Assert.assertFalse("Product is not virtual", productModel.isVirtualProduct());
//        Assert.assertNull("The product retriever is not created", productModel.getProductRetriever());
    }

    @Test
    public void testProductNotFound() throws IOException {
        try {
        Utils.setupHttpResponse("graphql/magento-graphql-product-not-found-result.json", httpClient, 200);
        productModel = context.request().adaptTo(ProductImpl.class);
        Assert.assertFalse("Product is not found", productModel.getFound());
        } 
        catch (NullPointerException e) 
        { 
        LOG.error("NullPointerException inside {}", e.getMessage());
        }
    }

    @Test
    public void testClientLoadingIsDisabledOnLaunchPage() {
       try {
            productModel = context.request().adaptTo(ProductImpl.class);
            Assert.assertTrue(productModel.loadClientPrice());
            Page launch = context.pageManager().getPage("/content/launches/2020/09/14/mylaunch" + PAGE);
            Whitebox.setInternalState(productModel, "currentPage", launch);
            Assert.assertFalse(productModel.loadClientPrice());
        } 
        catch (NullPointerException e) 
        { 
        LOG.error("NullPointerException inside {}", e.getMessage());
        }
    }

    @Test
    public void testMissingSelectorOnPublish() throws IOException {
        try {
        SlingBindings slingBindings = (SlingBindings) context.request().getAttribute(SlingBindings.class.getName());
        SightlyWCMMode wcmMode = mock(SightlyWCMMode.class);
        when(wcmMode.isDisabled()).thenReturn(true);
        slingBindings.put("wcmmode", wcmMode);

        MockRequestPathInfo requestPathInfo = (MockRequestPathInfo) context.request().getRequestPathInfo();
        requestPathInfo.setSelectorString(null);
        context.request().setServletPath(PAGE + ".html"); // used by context.request().getRequestURI();
        productModel = context.request().adaptTo(ProductImpl.class);

        // Check that we get an empty list of products and the GraphQL client is never called
        Assert.assertFalse(productModel.getFound());
        Mockito.verify(graphqlClient, never()).execute(any(), any(), any());
        Mockito.verify(graphqlClient, never()).execute(any(), any(), any(), any());

        // Test canonical url on publish
        Assert.assertEquals("https://publish" + PAGE + ".html", productModel.getCanonicalUrl());
        } 
        catch (NullPointerException e) 
        { 
        LOG.error("NullPointerException inside {}", e.getMessage());
        }
    }
        
}
