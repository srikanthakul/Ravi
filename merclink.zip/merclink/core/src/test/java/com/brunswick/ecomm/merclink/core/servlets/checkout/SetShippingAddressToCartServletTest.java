package com.brunswick.ecomm.merclink.core.servlets.checkout;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.servlethelpers.MockSlingHttpServletRequest;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.brunswick.ecomm.merclink.core.beans.checkout.CustomerAddressBean;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractCheckoutRetriever;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

public class SetShippingAddressToCartServletTest {
	private static final Logger LOG = LoggerFactory.getLogger(GetAddressServletTest.class);
	MockSlingHttpServletRequest request;
	@Rule
	public final AemContext context = createContext("/context/jcr-content-quickorder.json");
	private EcommSessionService adminService;
	private SetShippingAddressToCartServlet fixture = new SetShippingAddressToCartServlet();
	private APIGEEService apigee;
	private transient AbstractCheckoutRetriever checkoutretriever;
	private CustomerAddressBean databean;

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");
		}, ResourceResolverType.JCR_MOCK);
	}

	@Before
	public void setup() throws IOException, JSONException {
		fixture = new SetShippingAddressToCartServlet();
		request = context.request();
		databean = mock(CustomerAddressBean.class);
		apigee = Mockito.mock(APIGEEService.class);
		APIGEEService apigee = Mockito.mock(APIGEEService.class);
		adminService = Mockito.mock(EcommSessionService.class);
		context.registerService(EcommSessionService.class, adminService);
		context.registerService(APIGEEService.class, apigee);
		// context.registerInjectActivateService(fixture);
	}

	@Test
	public void doPostTest() throws IOException, LoginException {
		Gson gson = new Gson();
		ResourceResolver resolver = mock(ResourceResolver.class);
		when(adminService.getWriteServiceResourceResolver()).thenReturn(resolver);
		String data = "{\"customerNumber\":\"test\",\"startTime\":\"test\",\"endTime\":\"test\",\"companyname\":\"test\",\"addressLineship1\":\"890 TOWNSHIP ROAD #184\",\"addressLineship2\":\"\",\"shipcity\":\"Fond du Lac\",\"shipStateId\":\"WI\",\"shipStateName\":\"Wisconsin\",\"shippost\":\"54935\",\"shipCountry\":\"US\",\"billfname\":\"test\",\"billlname\":\"billing\",\"addressLinebill1\":\"4450 TOWNSHIP ROAD #184\",\"addressLinebill2\":\"\",\"billcity\":\"Fond du Lac\",\"billStateId\":\"WI\",\"billStateName\":\"Wisconsin\",\"billpost\":\"54935\",\"billCountry\":\"US\",\"resourcePath\":\"/content/ecommerce/merclink/language-masters/en/registration\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		String customerToken = "23pjbqgrhwict6xjzvg2tdr9vfjmkhja";
		request.setHeader("Authorization", "Bearer " + customerToken);
		JsonObject jsondata = new JsonObject();
		jsondata = gson.fromJson(data, JsonObject.class);
		databean.setCartId("cartid");
		databean.setAddress1("4450 TOWNSHIP ROAD #184");
		databean.setSameasshipping("test");
		try {
			if (context != null) {
				fixture.doPost(context.request(), context.response());
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the GetAddressServlet {}", e.getMessage());
		}
	}
}
