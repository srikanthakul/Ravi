package com.brunswick.ecomm.merclink.core.models.retriever;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

class AbstractCheckoutRetrieverTest {
	private AbstractCheckoutRetriever retriever;
	private MagentoGraphqlClient mockClient;
	Customer customer;
	private static final Logger LOG = LoggerFactory.getLogger(AbstractQuoteRetrieverTest.class);
	GraphqlResponse<Mutation, Error> response = mock(GraphqlResponse.class);
	Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	Mutation mutation = mock(Mutation.class);

	@BeforeEach
	public void setUp() {
		mockClient = mock(MagentoGraphqlClient.class);

		GraphqlResponse mockResponse = mock(GraphqlResponse.class);
		when(mockClient.execute(any())).thenReturn(mockResponse);
		when(response.getData()).thenReturn(mutation);
		when(mockResponse.getData()).thenReturn(mockQuery);
		when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());

		retriever = new AbstractCheckoutRetriever(mockClient);
	}

	@Test
	public void addShippingRatesDefinition() {
		String queryString = "mutation{\r\n" + "addShippingRates(\r\n" + "addShippingRates:{ \r\n" + "cart_id:"
				+ "cart_id: \\\r\n" + "shipping_method:\r\n" + "\\r\n" + "shipping_rate:\r\n" + "}){\r\n" + "cart {\r\n"
				+ "street:" + "shipping_addresses {\r\n" + "shipping_cost\r\n" + "}}\r\n" + "erp_quote_info\r\n"
				+ "}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateCloseQuote {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.addShippingRates(queryString, queryString, queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateCloseQuote {}", e.getMessage());
		}
	}

	@Test
	public void getCheckoutDefinition() {
		String queryString = "mutation{\r\n" + "updateCart(\r\n" + "input:{( \r\n" + "cart_id\r\n" + "order_source\r\n"
				+ "order_type: \\\"NAEUS Del Web\\\r\n" + "is_catalog_checked:\r\n" + "}) {\r\n" + "erp_quote_info\r\n"
				+ "cart{ \r\n" + "shipping_addresses {\r\n" + "available_shipping_methods{\r\n" + "amount {\r\n"
				+ "currency\r\n" + "value\r\n" + "} \r\n" + "available\r\n" + "carrier_code \r\n" + "carrier_title\r\n"
				+ "error_message\r\n" + "method_code\r\n" + "method_title\r\n" + "}\r\n" + "items { \r\n"
				+ "item_attributes{  availability_date backorder_qty\r\n" + "customer_adjustments\r\n"
				+ "item_attributes_custom_:item_attributes{backorder_qty_custom_:backorder_qty availability_date_custom_:availability_date}\r\n"
				+ "id \r\n" + "product {\r\n"
				+ "weight length width masterpartprop65code_custom_: masterpartprop65code masterparteachesweight_custom_: masterparteachesweight \\r\n"
				+ "sku\r\n" + "name\r\n" + "image_data_custom_: image_data {\r\n" + "}\r\n" + "}\r\n" + "quantity\r\n"
				+ "}\r\n" + "available_payment_methods\r\n" + "code:\r\n" + "title\r\n" + "}\r\n" + "}\r\n"
				+ "applied_coupons\r\n" + "code\r\n" + "code:\r\n" + "prices{\r\n" + "grand_total {\r\n" + "value\r\n"
				+ "currency\r\n" + "}}}}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateCloseQuote {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.getCheckoutInformation(queryString, 0);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateCloseQuote {}", e.getMessage());
		}
	}

	@Test
	public void setShippingAddressToCartDefinition() {
		String queryString = "mutation{\r\n" + "setShippingAddressesOnCart(\r\n" + "input:{ \r\n" + "cart_id: \\\r\n"
				+ "shipping_addresses:[\r\n" + "{\r\n" + "address: {\r\n" + "company_address_id:\r\n" + "firstname:\r\n"
				+ "lastname:\r\n" + "company:\r\n" + "street:\r\n" + "city:\r\n" + "region:\r\n" + "postcode:\r\n"
				+ "country_code: {\r\n" + "telephone:\r\n" + "\\r\n" + "save_in_address_book :\r\n" + "} } ] }	) {\r\n"
				+ "cart  {\r\n" + "lastname:\r\n" + "company:\r\n" + "street:\r\n" + "city:\r\n" + "region:\r\n"
				+ "postcode:\r\n" + "shipping_addresses {:\r\n" + "firstname\r\n" + "lastname\r\n" + "company\r\n"
				+ "street\r\n" + "city\r\n" + "region {\r\n" + "code\r\n" + "label\r\n" + "}\r\n" + "postcode\r\n"
				+ "telephone\r\n" + "country {\r\n" + "code\r\n" + "label\r\n" + "}\r\n" + "pickup_location_code\r\n"
				+ "}\r\n" + "erp_errors {\r\n" + "message\r\n" + "code\r\n" + "}}\r\n" + "shipping_methods{\r\n"
				+ "shipping_method_name\r\n" + "sub_methods {\r\n" + "free_shipping\r\n" + "method_code\r\n"
				+ "method_title\r\n" + "amount{\r\n" + "currency\r\n" + "value\r\n" + "}} }\r\n" + "}\r\n" + "}\r\n"
				+ "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setShippingAddressToCartDefinition {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.setShippingAddressToCart(null);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setShippingAddressToCartDefinition {}", e.getMessage());
		}
	}

	@Test
	public void setEmailOnGuestCartDefinition() {
		String queryString = "mutation{\r\n" + "  setGuestEmailOnCart(\r\n" + "    input: {\r\n" + "      cart_id: \""
				+ "\"\r\n" + "      email: \"" + "\"\r\n" + "    }\r\n" + "  ) {\r\n" + "    cart {\r\n"
				+ "      email\r\n" + "    }\r\n" + "  }\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setEmailOnGuestCartDefinition {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.setEmailOnGuestCart(queryString, queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setEmailOnGuestCartDefinition {}", e.getMessage());
		}
	}

	@Test
	public void setBillingAddressToCartDefinition() {
		String queryString = "mutation{\r\n" + "setBillingAddressOnCart(\r\n" + "input:{ \r\n" + "cart_id: \\ \r\n"
				+ "billing_address: {\r\n" + "address: {\r\n" + "company_address_id:\r\n" + "firstname\r\n" + "\\r\n"
				+ "lastname\r\n" + "\\r\n" + "street:\r\n" + "\\r\n" + "[ {\r\n" + "city:\r\n" + "\\r\n" + "region:\r\n"
				+ "\\r\n" + "postcode\r\n" + "\\r\n" + "country_code\r\n" + "\\r\n" + "telephone\r\n" + "\\r\n"
				+ "save_in_address_book\r\n" + "\\r\n" + " primary_flag: \r\n" + "}\r\n" + "same_as_shipping :\r\n"
				+ "}}){\r\n" + "cart { \r\n" + "cart { \r\n" + "firstname\r\n" + "\\r\n" + "lastname\r\n"
				+ "company\r\n" + "street\r\n" + "city\r\n" + "region { \r\n" + "code\r\n" + "lable\r\n" + "}\r\n"
				+ "postcode {\r\n" + "telephone {\r\n" + "country { \r\n" + "code\r\n" + "label\r\n" + "lastname\r\n"
				+ "}\r\n" + "}\r\n" + "}\r\n" + "}\r\n" + "}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setBillingAddressToCartDefinition {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.setBillingAddressToCart(null);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setBillingAddressToCartDefinition {}", e.getMessage());
		}
	}

	@Test
	public void getShippingMethodInformationDefinition() {
		String queryString = "mutation{\r\n" + "shippingMethodAnzp(\r\n" + "input:{\r\n" + "customer_number\r\n"
				+ "cart_id:\r\n" + "}\r\n" + "){\r\n" + "\\r\n" + "}\r\n" + "shipping_method\r\n"
				+ "shipping_method \r\n" + "}\r\n" + "}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the getShippingMethodInformationDefinition {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.getShippingMethodInformation(queryString, queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the getShippingMethodInformationDefinition {}", e.getMessage());
		}
	}

	@Test
	public void placeOrderDefinition() {
		String queryString = "mutation{\r\n" + "placeOrder(\r\n" + "input:{ \r\n" + "cart_id: \\\r\n" + "po_number:\r\n"
				+ "\\r\n" + "order_comment:\r\n" + "\\r\n" + "requested_ship_date:\r\n" + "\\r\n"
				+ "credit_card_approval_code: \r\n" + "credit_card_approval_date:\r\n" + "credit_card_token: \r\n"
				+ "credit_card_holder_name :\r\n" + "credit_card_expiration_date:\r\n" + "payment_method :\r\n"
				+ "shipping_method:\r\n" + "shipping_cost :\r\n" + "shipping_discount_amount:\r\n"
				+ "shipping_tax_amount:\r\n" + "request_id :\r\n" + "collect_account_number :\r\n" + "}){\r\n"
				+ "order {\r\n" + "order_number\r\n" + "order_id\r\n" + "}\r\n" + "}\r\n" + "}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the placeOrderDefinition {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.placeOrder(null);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the placeOrderDefinition {}", e.getMessage());
		}
	}

	@Test
	public void getShippingCostInformationDefinition() {
		String queryString = "mutation{\r\n" + "shippingCost(\r\n" + "input:{ \r\n" + "cart_id: \\\r\n"
				+ "shipping_mode : \\r\n" + "}){\r\n" + "shipping_cost\r\n" + "shipping_mode\r\n" + "}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the getShippingCostInformationDefinition {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.getShippingCostInformation(queryString, queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the getShippingCostInformationDefinition {}", e.getMessage());
		}
	}

	@Test
	public void getDropShipCostQuery() {
		String queryString = "mutation{\r\n" + "setDropShip(\r\n" + "input:{ \r\n" + "cart_id: \\\r\n"
				+ "queryString:\r\n" + "}){\r\n" + "is_dropship\r\n" + "}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the getDropShipCostQuery {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.getShippingCostInformation(queryString, queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the getDropShipCostQuery {}", e.getMessage());
		}
	}

	@Test
	public void submitOrderDefinition() {
		String queryString = "mutation{\r\n" + "placeOrder( \r\n" + "input:{ \r\n" + "cart_id: \\" + "po_number\r\n"
				+ "order_comment: \\\r\n" + "requested_ship_date:\r\n" + " payment_method:\r\n" + "shipping_method:\r\n"
				+ "shipping_cost:\r\n" + " attribute19:\r\n" + "is_dropship :\r\n" + "}){\r\n" + "order  {\r\n"
				+ "order_number\r\n" + "order_id \r\n" + "erp_order_number\r\n" + "}\r\n" + "}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the submitOrderDefinition {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.submitOrder(null);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the submitOrderDefinition {}", e.getMessage());
		}
	}

	@Test
	public void getShippingPriorityInformationDefinition() {
		String queryString = "mutation{\r\n" + "shippingPriority(\r\n" + "input: { \r\n" + "StringBuilder\r\n"
				+ "shipping_type: \\\r\n" + "}\r\n" + "\r\n" + "shipping_type\r\n" + "message\r\n" + "}\r\n" + "}\r\n"
				+ "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the getShippingPriorityInformationDefinition {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.getShippingPriorityInformation(queryString, queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the getShippingPriorityInformationDefinition {}", e.getMessage());
		}
	}

}
