package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.apache.sling.testing.resourceresolver.MockResourceResolverFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.brunswick.ecomm.core.services.apigee.impl.APIGEEServiceImpl;

import io.wcm.testing.mock.aem.junit5.AemContext;

class CustomerPersonalInformationTest {

	public AemContext context;
	private EcommSessionService adminService;
	private APIGEEService apigee;
	private ResourceResolver resolver;
	private CustomerPersonalInformation fixture = new CustomerPersonalInformation();
	private APIGEEServiceImpl mockServiceImpl;
	
	@BeforeEach
	public void setup() throws IOException, LoginException {
		context =  new AemContext(ResourceResolverType.JCR_MOCK);
		context.load().json("/context/jcr-homepage.json", "/content/ecommerce/merclink/au/en/open-order");
		fixture = new CustomerPersonalInformation();
		apigee = Mockito.mock(APIGEEService.class);
		APIGEEService apigee = Mockito.mock(APIGEEService.class);
		resolver = context.resourceResolver();
		adminService = Mockito.mock(EcommSessionService.class);
		MockResourceResolverFactory factory = new MockResourceResolverFactory();
		resolver = factory.getResourceResolver(null);
		context.registerService(EcommSessionService.class, adminService);
		context.registerService(APIGEEService.class,apigee);
		context.registerService(ResourceResolver.class,resolver);
		context.registerInjectActivateService(fixture);
	}
	
	@Test
	public void testDoPost() throws IOException{
		String data = "{\"resourcePath\":\"/content/ecommerce/merclink/au/en/open-order\"}";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("data", data);
		context.request().setParameterMap(params);
		fixture.doPost(context.request(), context.response());
	}
	
	
	
}
