package com.brunswick.ecomm.merclink.core.delta.servlets;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

class PowerOfChoiceTest {

	private static final Logger LOG = LoggerFactory.getLogger(PowerOfChoiceTest.class);
	@Rule
	public final AemContext context = createContext("/context/powerofchoice.json");
	private EcommSessionService adminService;
	private PowerOfChoice fixture = new PowerOfChoice();
	private APIGEEService apigee;
	
	

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			context.load().json(contentPath, "/content");
		}, ResourceResolverType.JCR_MOCK);
	}

	@Before
	public void setup() throws IOException, JSONException {
		fixture = new PowerOfChoice();
		apigee = Mockito.mock(APIGEEService.class);
		APIGEEService apigee = Mockito.mock(APIGEEService.class);
		adminService = Mockito.mock(EcommSessionService.class);
		context.registerService(EcommSessionService.class, adminService);
		context.registerService(APIGEEService.class,apigee);
		context.registerInjectActivateService(fixture);
	}
	
	@Test
	public void doGetPowerOfChoice() throws IOException, LoginException {
		ResourceResolver resolver = mock(ResourceResolver.class);
		try {
			if (resolver != null) {
				when(adminService.getWriteServiceResourceResolver()).thenReturn(resolver);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the PowerOfChoiceTest {}", e.getMessage());
		}
		String data = "{\"PowerOfChoice\":\"ABC,123,234\",\"currentPage\":\"/content/ecommerce/delcity/us/en/power-of-choice\",\"token\":\"23pjbqgrhwict6xjzvg2tdr9vfjmkhja\",\"operatingUnit\":\"DC\"}}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		try {
			if (fixture != null) {
				fixture.doGet(context.request(), context.response());
				assertNotNull(fixture);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the PowerOfChoiceTest {}", e.getMessage());
		}
		
	}
}
