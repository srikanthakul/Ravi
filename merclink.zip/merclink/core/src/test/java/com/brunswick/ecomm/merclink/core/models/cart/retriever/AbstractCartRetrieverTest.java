package com.brunswick.ecomm.merclink.core.models.cart.retriever;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.brunswick.ecomm.merclink.core.models.cart.CartRetriever;

public class AbstractCartRetrieverTest {
	 private AbstractCartRetriever retriever;
	    private  MagentoGraphqlClient mockClient;
	    Customer customer;
	    
	    private static final Logger LOG = LoggerFactory.getLogger(AbstractCartRetriever.class);
	    
	    GraphqlResponse<Mutation, Error> response= mock(GraphqlResponse.class);
	    Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	    Mutation mutation= mock(Mutation.class);
	    @BeforeEach
	    public void setUp() {
	         mockClient = mock(MagentoGraphqlClient.class);
	       
	       
	        GraphqlResponse mockResponse = mock(GraphqlResponse.class);
	        when(mockClient.execute(any())).thenReturn(mockResponse);
	        when(response.getData()).thenReturn(mutation);
	        when(mockResponse.getData()).thenReturn(mockQuery);
	        when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());
	        when(mockQuery.getCart().getItems()).thenReturn(Collections.EMPTY_LIST);
	        

	        retriever = new CartRetriever(mockClient);


	    }
	@Test
	public void testSetCartId() {
		String cartId = "AS123";
		
		try {
			if(retriever !=null) {
				retriever.setCartId(cartId);
				assertNotNull(cartId);
				
			}
		} catch(NullPointerException e) {
			LOG.error("Null pointer exception");
		}
	}
	

	
	@Test
	public void testGenerateQuery() {
		String identifier = "123";
		try {
			if(retriever !=null) {
				retriever.setQuery(identifier);
				mockClient.execute(identifier);
				retriever.generateQuery(identifier);
				assertNotNull(identifier);	
			}
		} catch(NullPointerException e) {
			LOG.error("Null pointer exception");
		}
		
		
	}
	
	@Test
	public void testCartItemInterfaceQueryDefinition() {
		try {
			if(retriever !=null) {
				assertNotNull(retriever.generateCartQuery());;	
			}
		} catch(NullPointerException e) {
			LOG.error("Null pointer exception");
		}
		
		
	}

}


