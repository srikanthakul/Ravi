package com.brunswick.ecomm.merclink.core.helper;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class MultifieldHelperTest {

    @Test
    public void testConstructor() {
        
        Resource resource = Mockito.mock(Resource.class);
        try {
        	if(resource != null) {
        	Mockito.when(resource.getValueMap().get("changeaccounttxt", String.class)).thenReturn("Change Account");
        	Mockito.when(resource.getValueMap().get("managePaymenttxt", String.class)).thenReturn("Manage Payment");
        	  Mockito.when(resource.getValueMap().get("logoutTxt", String.class)).thenReturn("Logout");
              Mockito.when(resource.getValueMap().get("currentnewslinktext", String.class)).thenReturn("Current News Link Text");
              Mockito.when(resource.getValueMap().get("currentnewsdata", String.class)).thenReturn("Current News Data");
              Mockito.when(resource.getValueMap().get("currentnewsicons", String.class)).thenReturn("Current News Icons");
              Mockito.when(resource.getValueMap().get("currentnewslink", String.class)).thenReturn("Current News Link");
              Mockito.when(resource.getValueMap().get("currentnewspdf", String.class)).thenReturn("Current News PDF");
              Mockito.when(resource.getValueMap().get("currentnewsdt", String.class)).thenReturn("Current News Date");
              Mockito.when(resource.getValueMap().get("currentnewslctn", String.class)).thenReturn("Current News Location");
        	}
		} catch (NullPointerException e) {
			e.getMessage();
		}
     
        MultifieldHelper multifieldHelper = new MultifieldHelper(resource);
        
        try {
        	if(resource != null) {

        	}
		} catch (NullPointerException e) {
			e.getMessage();
		}

    }

    @Test
   public void testMyProfile() {
        
        MultifieldHelper multifieldHelper = new MultifieldHelper(Mockito.mock(Resource.class));
        List<NastedHelper> myProfile = new ArrayList<>();
        
        multifieldHelper.setMyProfile(myProfile);

        
        List<NastedHelper> result = multifieldHelper.getMyProfile();
        assertEquals(0, result.size());
    }
}