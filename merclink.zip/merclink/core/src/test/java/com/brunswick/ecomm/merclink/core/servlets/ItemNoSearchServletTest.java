package com.brunswick.ecomm.merclink.core.servlets;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.apache.sling.testing.resourceresolver.MockResourceResolverFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.brunswick.ecomm.core.services.apigee.impl.APIGEEServiceImpl;
import com.day.cq.dam.api.Asset;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

public class ItemNoSearchServletTest {

	@Rule
	public final AemContext context = createContext("/context/jcr-content-statement.json");
	private EcommSessionService adminService;
	private APIGEEService apigee;
	private ResourceResolver resolver;
	private ItemNoSearchServlet fixture = new ItemNoSearchServlet();
	private APIGEEServiceImpl mockServiceImpl;
	
	private AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");
		}, ResourceResolverType.JCR_MOCK);
	}
	
	@Before
	public void setup() throws IOException, LoginException {
		fixture = new ItemNoSearchServlet();
		apigee = Mockito.mock(APIGEEService.class);
		APIGEEService apigee = Mockito.mock(APIGEEService.class);
		resolver = context.resourceResolver();
		adminService = Mockito.mock(EcommSessionService.class);
		MockResourceResolverFactory factory = new MockResourceResolverFactory();
		resolver = factory.getResourceResolver(null);
		context.registerService(EcommSessionService.class, adminService);
		context.registerService(APIGEEService.class,apigee);
		context.registerService(ResourceResolver.class,resolver);
		context.registerInjectActivateService(fixture);
	}
	
	@Test
	public void getStatementsDoGetTest() throws IOException{
		String data = "{\"customerNumber\":\"12345\",\"resourcePath\":\"/content/ecommerce/merclink/language-masters/en/statements\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		fixture.doPost(context.request(), context.response());
	}
}
