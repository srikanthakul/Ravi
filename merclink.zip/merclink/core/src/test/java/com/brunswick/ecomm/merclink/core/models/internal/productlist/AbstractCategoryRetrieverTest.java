package com.brunswick.ecomm.merclink.core.models.internal.productlist;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.CategoryInterface;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.brunswick.ecomm.core.client.MagentoGraphqlClient;

class AbstractCategoryRetrieverTest {
	private AbstractCategoryRetriever retriever;
	private MagentoGraphqlClient mockClient;
	private static final String RETURNS_DEEP_STUBS = null;
	GraphqlResponse<Mutation, Error> response = mock(GraphqlResponse.class);
	Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	Mutation mutation = mock(Mutation.class);
	private static final CategoryInterface CategoryMock = null;
	private static final Logger LOG = LoggerFactory.getLogger(AbstractCategoryRetrieverTest.class);

	@BeforeEach
	public void setUp() {
		mockClient = mock(MagentoGraphqlClient.class);

		GraphqlResponse mockResponse = mock(GraphqlResponse.class);
		when(mockClient.execute(any())).thenReturn(mockResponse);
		when(response.getData()).thenReturn(mutation);
		when(mockResponse.getData()).thenReturn(mockQuery);
		try {
			when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setUp {}", e.getMessage());
		}

	}

	@Test
	public void fetchCategory() {

		try {
			if (retriever != null) {
				retriever.setQuery(RETURNS_DEEP_STUBS);
				mockClient.execute(RETURNS_DEEP_STUBS);
				retriever.executeQuery();
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the fetchCategory {}", e.getMessage());
		}

	}

	@Test
	public void generateQuery() {

		try {
			if (retriever != null) {
				retriever.setQuery(RETURNS_DEEP_STUBS);
				mockClient.execute(RETURNS_DEEP_STUBS);
				retriever.generateCategoryQuery();
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateQuery {}", e.getMessage());
		}

	}

	@Test
	public void populate() {

		try {
			if (retriever != null) {
				retriever.setQuery(RETURNS_DEEP_STUBS);
				mockClient.execute(RETURNS_DEEP_STUBS);
				retriever.executeQuery();
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the populate {}", e.getMessage());
		}

	}
}
