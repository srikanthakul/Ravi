package com.brunswick.ecomm.merclink.core.beans;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MetaDataBeanTest {
	MetaDataBean fixture;
	String expectedOutput;

	@BeforeEach
	void setUp() throws Exception {
		fixture = new MetaDataBean();
	}

	@Test
	void testGetCanonicalURL() {
		expectedOutput = "Text";
		fixture.setCanonicalURL(expectedOutput);
		assertEquals(expectedOutput,fixture.getCanonicalURL());
	}

	@Test
	void testGetKeywords() {
		expectedOutput = "Text";
		fixture.setKeywords(expectedOutput);
		assertEquals(expectedOutput,fixture.getKeywords());
	}

	@Test
	void testGetDescription() {
		expectedOutput = "Text";
		fixture.setDescription(expectedOutput);
		assertEquals(expectedOutput,fixture.getDescription());
	}

	@Test
	void testGetTags() {
		expectedOutput = "Text";
		fixture.setTags(expectedOutput);
		assertEquals(expectedOutput,fixture.getTags());
	}

	@Test
	void testGetContentType() {
		expectedOutput = "Text";
		fixture.setContentType(expectedOutput);
		assertEquals(expectedOutput,fixture.getContentType());
	}

	@Test
	void testGetLastModifiedDate() {
		expectedOutput = "Text";
		fixture.setLastModifiedDate(expectedOutput);
		assertEquals(expectedOutput,fixture.getLastModifiedDate());
	}

	@Test
	void testGetThumbnail() {
		expectedOutput = "Text";
		fixture.setThumbnail(expectedOutput);
		assertEquals(expectedOutput,fixture.getThumbnail());
	}

	@Test
	void testGetRobots() {
		expectedOutput = "Text";
		fixture.setRobots(expectedOutput);
		assertEquals(expectedOutput,fixture.getRobots());
	}

	@Test
	void testGetOgLocale() {
		expectedOutput = "Text";
		fixture.setOgLocale(expectedOutput);
		assertEquals(expectedOutput,fixture.getOgLocale());
	}

	@Test
	void testGetOgTitle() {
		expectedOutput = "Text";
		fixture.setOgTitle(expectedOutput);
		assertEquals(expectedOutput,fixture.getOgTitle());
	}

	@Test
	void testGetOgType() {
		expectedOutput = "Text";
		fixture.setOgType(expectedOutput);
		assertEquals(expectedOutput,fixture.getOgType());
	}

	@Test
	void testGetOgURL() {
		expectedOutput = "Text";
		fixture.setOgURL(expectedOutput);
		assertEquals(expectedOutput,fixture.getOgURL());
	}

	@Test
	void testGetOgDesc() {
		expectedOutput = "Text";
		fixture.setOgDesc(expectedOutput);
		assertEquals(expectedOutput,fixture.getOgDesc());
	}

	@Test
	void testGetOgImage() {
		expectedOutput = "Text";
		fixture.setOgImage(expectedOutput);
		assertEquals(expectedOutput,fixture.getOgImage());
	}

	@Test
	void testGetOgSitename() {
		expectedOutput = "Text";
		fixture.setOgSitename(expectedOutput);
		assertEquals(expectedOutput,fixture.getOgSitename());
	}

	@Test
	void testGetTwitterSite() {
		expectedOutput = "Text";
		fixture.setTwitterSite(expectedOutput);
		assertEquals(expectedOutput,fixture.getTwitterSite());
	}

	@Test
	void testGetTwitterDesc() {
		expectedOutput = "Text";
		fixture.setTwitterDesc(expectedOutput);
		assertEquals(expectedOutput,fixture.getTwitterDesc());
	}

	@Test
	void testGetTwitterTitle() {
		expectedOutput = "Text";
		fixture.setTwitterTitle(expectedOutput);
		assertEquals(expectedOutput,fixture.getTwitterTitle());
	}

	@Test
	void testGetTwitterImage() {
		expectedOutput = "Text";
		fixture.setTwitterImage(expectedOutput);
		assertEquals(expectedOutput,fixture.getTwitterImage());
	}

	@Test
	void testGetYoutubeTitle() {
		expectedOutput = "Text";
		fixture.setYoutubeTitle(expectedOutput);
		assertEquals(expectedOutput,fixture.getYoutubeTitle());
	}

	@Test
	void testGetYoutubeDesc() {
		expectedOutput = "Text";
		fixture.setYoutubeDesc(expectedOutput);
		assertEquals(expectedOutput,fixture.getYoutubeDesc());
	}

	@Test
	void testGetYoutubeImage() {
		expectedOutput = "Text";
		fixture.setYoutubeImage(expectedOutput);
		assertEquals(expectedOutput,fixture.getYoutubeImage());
	}

	@Test
	void testGetLinkedinTitle() {
		expectedOutput = "Text";
		fixture.setLinkedinTitle(expectedOutput);
		assertEquals(expectedOutput,fixture.getLinkedinTitle());
	}

	@Test
	void testGetLinkedinDesc() {
		expectedOutput = "Text";
		fixture.setLinkedinDesc(expectedOutput);
		assertEquals(expectedOutput,fixture.getLinkedinDesc());
	}

	@Test
	void testGetLinkedinImage() {
		expectedOutput = "Text";
		fixture.setLinkedinImage(expectedOutput);
		assertEquals(expectedOutput,fixture.getLinkedinImage());
	}

}
