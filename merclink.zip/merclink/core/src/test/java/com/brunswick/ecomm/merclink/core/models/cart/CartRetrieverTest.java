package com.brunswick.ecomm.merclink.core.models.cart;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

public class CartRetrieverTest {
		 private CartRetriever retriever;
		    private  MagentoGraphqlClient mockClient;
		    Customer customer;
		    
		    GraphqlResponse<Mutation, Error> response= mock(GraphqlResponse.class);
		    Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
		    Mutation mutation= mock(Mutation.class);
		    @BeforeEach
		    public void setUp() {
		         mockClient = mock(MagentoGraphqlClient.class);
		       
		       
		        GraphqlResponse mockResponse = mock(GraphqlResponse.class);
		        when(mockClient.execute(any())).thenReturn(mockResponse);
		        when(response.getData()).thenReturn(mutation);
		        when(mockResponse.getData()).thenReturn(mockQuery);
		        when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());

		        retriever = new CartRetriever(mockClient);
		    }

		@Test
		public void testPopulate() {
	        String sampleQuery = "query {\r\n" + 
	        		"  cart(cart_id: \"v7jYJUjvPeHbdMJRcOfZIeQhs2Xc2ZKT\"){\r\n" + 
	        		"    items {\r\n" + 
	        		"      uid\r\n" + 
	        		"      quantity\r\n" + 
	        		"      product{\r\n" + 
	        		"        name\r\n" + 
	        		"        sku\r\n" + 
	        		"        price_tiers {\r\n" + 
	        		"          quantity\r\n" + 
	        		"          final_price {\r\n" + 
	        		"            value\r\n" + 
	        		"          }\r\n" + 
	        		"          discount {\r\n" + 
	        		"            amount_off\r\n" + 
	        		"            percent_off\r\n" + 
	        		"          }\r\n" + 
	        		"        }\r\n" + 
	        		"      }\r\n" + 
	        		"      prices{\r\n" + 
	        		"        price{\r\n" + 
	        		"          value\r\n" + 
	        		"        }\r\n" + 
	        		"      }\r\n" + 
	        		"    }\r\n" + 
	        		"    prices {\r\n" + 
	        		"      discounts {\r\n" + 
	        		"        label\r\n" + 
	        		"        amount {\r\n" + 
	        		"          value\r\n" + 
	        		"        }\r\n" + 
	        		"      }\r\n" + 
	        		"      subtotal_excluding_tax {\r\n" + 
	        		"        value\r\n" + 
	        		"      }\r\n" + 
	        		"      applied_taxes {\r\n" + 
	        		"        label\r\n" + 
	        		"        amount {\r\n" + 
	        		"          value\r\n" + 
	        		"        }\r\n" + 
	        		"      }\r\n" + 
	        		"    }\r\n" + 
	        		"  }\r\n" + 
	        		"}\r\n" + 
	        		"";
	        retriever.setQuery(sampleQuery);
	        mockClient.execute(sampleQuery);
	        //retriever.populate();
	        retriever.generateCartQuery();
	        retriever.generatePriceQuery();
		}


	}



