package com.brunswick.ecomm.merclink.core.beans.productdetailsrecommendations;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RecommendationsBeanTest {
	RecommendationsBean fixture;
	String expectedOut;

	@BeforeEach
	void setUp() {
		fixture = new RecommendationsBean();
	}

	@Test
	void testGetUid() {
		expectedOut = "Uid";
		fixture.setUid(expectedOut);
		assertEquals(expectedOut, fixture.getUid());
	}

	@Test
	void testGetName() {
		expectedOut = "Name";
		fixture.setName(expectedOut);
		assertEquals(expectedOut, fixture.getName());
	}

	@Test
	void testGetRelated_products() {
		List<RelatedProductsBean> expectedData = new ArrayList<RelatedProductsBean>();
		RelatedProductsBean data = new RelatedProductsBean();
		expectedData.add(data);
		fixture.setRelated_products(expectedData);
		assertEquals(expectedData, fixture.getRelated_products());
	}

}

