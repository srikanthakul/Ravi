package com.brunswick.ecomm.merclink.core.models.retriever;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;

import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.google.gson.JsonObject;

class AbstractRecentOrderRetrieverTest {

	private AbstractRecentOrderRetriever retriever;
    private MagentoGraphqlClient mockClient;
    Customer customer;
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractRecentOrderRetriever.class);
    
    Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
    JsonObject mutation= new JsonObject();
    @BeforeEach
    public void setUp() {
        mockClient = mock(MagentoGraphqlClient.class);
       
       
        GraphqlResponse<JsonObject , Error> mockResponse = mock(GraphqlResponse.class);
        when(mockClient.executeQuery(any())).thenReturn(mockResponse);
        when(mockClient.executeJsonMutation(any())).thenReturn(mockResponse);
        when(mockResponse.getData()).thenReturn(mutation);

        retriever = new AbstractRecentOrderRetriever(mockClient);
//        retriever.setIdentifier(CategoryIdentifierType.ID, "5");
    }

	@Test
	public void getCustomerRecentOrderTest() {
   	 String sampleQuery = "{\r\n" + 
   	 		"salesOrder{ \r\n" + 
   	 		"increment_id\r\n" + 
   		 "customer_name\r\n" + 
   		 "items {\r\n" + 
   		" title\r\n" + 
   		 "sku\r\n" + 
   		 "price\r\n" + 
   		 "image\r\n" + 
   		" }\r\n" + 
   		 "}\r\n" + 
   		 "}";
   	try {
		if (retriever != null) {
			retriever.setQuery(sampleQuery);
			mockClient.execute(sampleQuery);
			
			return;
		}
	} catch (NullPointerException e) {
		LOGGER.error("NullPointerException inside the AbstractRecentOrderRetrieverTest {}", e.getMessage());
	}
   	try {
		if (retriever != null) {
			retriever.getCustomerRecentOrder();
			return;
		}
	} catch (NullPointerException e) {
		LOGGER.error("NullPointerException inside the AbstractRecentOrderRetrieverTest {}", e.getMessage());
	}
   }
	@Test
	 public void getNewsletterSubscriptionTest() {
   	 String sampleQuery = "mutation{\r\n" + 
	    	 		"subscribeEmailToNewsletter( \r\n" + 
	    	 		"email:\r\n" + 
	    		 "Radhikam@gmail.com\r\n" + 
	    		" )\r\n" + 
	    		 "{status}\r\n" + 
	    		 "}}";
   	try {
		if (retriever != null) {
			retriever.setQuery(sampleQuery);
			mockClient.execute(sampleQuery);
			
			return;
		}
	} catch (NullPointerException e) {
		LOGGER.error("NullPointerException inside the AbstractRecentOrderRetrieverTest {}", e.getMessage());
	}
   	try {
		if (retriever != null) {
			retriever.getNewsletterSubscription("Radhikam@gmail.com");
			return;
		}
	} catch (NullPointerException e) {
		LOGGER.error("NullPointerException inside the AbstractRecentOrderRetrieverTest {}", e.getMessage());
	}
   }

	@Test
	public void getCustomerDetailsTest() {
   	 String sampleQuery = "{\r\n" + 
	    	 		" customer { \r\n" + 
	    	 		"firstname\r\n" + 
	    		 "lastname\r\n" + 
	    		" suffix\r\n" + 
	    		 "email\r\n" + 
	    		 "account_name\r\n" +
	    		 "customer_number\r\n" +
	    		 "addresses {\r\n" + 
	    		 "firstname\r\n" + 
	    		 "lastname\r\n" + 
	    		 "street\r\n" +
	    		 "city\r\n" +
	    		 "region {\r\n" +
	    		 "region_code\r\n" +
	    		 "region\r\n" +
	    		 "}\r\n" +
	    		 "postcode\r\n" +
	    		 "country_code\r\n" +
	    		 "telephone\r\n" + 
	    		 "}}}";
   	try {
		if (retriever != null) {
			retriever.setQuery(sampleQuery);
			mockClient.execute(sampleQuery);
			
			return;
		}
	} catch (NullPointerException e) {
		LOGGER.error("NullPointerException inside the AbstractRecentOrderRetrieverTest {}", e.getMessage());
	}
   	try {
		if (retriever != null) {
			retriever.getCustomerDetails();
			return;
		}
	} catch (NullPointerException e) {
		LOGGER.error("NullPointerException inside the AbstractRecentOrderRetrieverTest {}", e.getMessage());
	}
   }
}
