package com.brunswick.ecomm.merclink.core.servlets;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;

import org.apache.http.client.HttpClient;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.scripting.SlingBindings;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.caconfig.ConfigurationBuilder;
import org.apache.sling.servlethelpers.MockRequestPathInfo;
import org.apache.sling.servlethelpers.MockSlingHttpServletRequest;
import org.apache.sling.servlethelpers.MockSlingHttpServletResponse;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.apache.sling.xss.XSSAPI;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.adobe.cq.commerce.core.components.internal.services.UrlProviderImpl;
import com.adobe.cq.commerce.core.components.services.ComponentsConfiguration;
import com.adobe.cq.commerce.core.components.services.urls.UrlProvider;
import com.adobe.cq.commerce.graphql.client.GraphqlClient;
import com.adobe.cq.commerce.graphql.client.GraphqlClientConfiguration;
import com.adobe.cq.commerce.graphql.client.HttpMethod;
import com.adobe.cq.commerce.graphql.client.impl.GraphqlClientImpl;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.gson.MutationDeserializer;
import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.brunswick.ecomm.merclink.core.components.testing.MockExternalizer;
import com.brunswick.ecomm.merclink.core.components.testing.Utils;
import com.brunswick.ecomm.merclink.core.utils.ValidateContactUsServlet;
import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.scripting.WCMBindingsConstants;
import java.util.function.*;
import com.google.common.collect.ImmutableMap;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;


public class ANZPInvoiceDownloadServletTest { 
	
	@Rule
	public final AemContext context = createContext("/context/jcr-content-cartprice.json");
	private EcommSessionService adminService;
	private ANZPInvoiceDownloadServlet fixture ;
	private APIGEEService apigee;
	
	

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");
		}, ResourceResolverType.JCR_MOCK);
	}

	@Before
	public void setup() throws IOException, JSONException {
		fixture = new ANZPInvoiceDownloadServlet();
		apigee = Mockito.mock(APIGEEService.class);
		APIGEEService apigee = Mockito.mock(APIGEEService.class);
		adminService = Mockito.mock(EcommSessionService.class);
		context.registerService(EcommSessionService.class, adminService);
		context.registerService(APIGEEService.class,apigee);
		context.registerInjectActivateService(fixture);
	}
	@Test
	public void doPostTest() throws IOException, LoginException {
		ResourceResolver resolver = mock(ResourceResolver.class);
		when(adminService.getWriteServiceResourceResolver()).thenReturn(resolver);
		

		String data = "{\"currentPage\":\"/content/ecommerce/merclink/au/en/cart/bulk-order-checkout\",\"token\":\"23pjbqgrhwict6xjzvg2tdr9vfjmkhja\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("currentPage", data);
		context.request().setParameterMap(params);
		fixture.doPost(context.request(), context.response());
		assertNotNull(fixture);
	}
       
}  
    
    
