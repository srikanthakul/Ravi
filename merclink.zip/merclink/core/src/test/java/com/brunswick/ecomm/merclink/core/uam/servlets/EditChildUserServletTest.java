package com.brunswick.ecomm.merclink.core.uam.servlets;


import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
//import com.google.common.base.Function;
import java.util.function.Function;

import org.apache.http.client.HttpClient;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.scripting.SlingBindings;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.caconfig.ConfigurationBuilder;
import org.apache.sling.servlethelpers.MockRequestPathInfo;
import org.apache.sling.servlethelpers.MockSlingHttpServletRequest;
import org.apache.sling.servlethelpers.MockSlingHttpServletResponse;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;

import com.adobe.cq.commerce.core.components.internal.services.UrlProviderImpl;
import com.adobe.cq.commerce.core.components.services.ComponentsConfiguration;
import com.adobe.cq.commerce.core.components.services.urls.UrlProvider;
import com.adobe.cq.commerce.graphql.client.GraphqlClient;
import com.adobe.cq.commerce.graphql.client.GraphqlClientConfiguration;
import com.adobe.cq.commerce.graphql.client.HttpMethod;
import com.adobe.cq.commerce.graphql.client.impl.GraphqlClientImpl;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.QueryDeserializer;
//import com.brunswick.ecomm.merclink.core.components.testing.AemContext;
import com.brunswick.ecomm.merclink.core.components.testing.MockExternalizer;
import com.brunswick.ecomm.merclink.core.components.testing.Utils;
import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.scripting.WCMBindingsConstants;
import com.google.common.collect.ImmutableMap;


import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;


public class EditChildUserServletTest {
	
	@Rule
	public final AemContext context = createContext("/context/jcr-homepage-header-model.json");

	private static final ValueMap MOCK_CONFIGURATION = new ValueMapDecorator(
			ImmutableMap.of("cq:graphqlClient", "default", "magentoStore", "anzpau_store_view_en"));

	private static final ComponentsConfiguration MOCK_CONFIGURATION_OBJECT = new ComponentsConfiguration(
			MOCK_CONFIGURATION);

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");

			UrlProviderImpl urlProvider = new UrlProviderImpl();
			//urlProvider.activate(new MockUrlProviderConfiguration());
			context.registerService(UrlProvider.class, urlProvider);

			context.registerAdapter(Resource.class, ComponentsConfiguration.class,
					(Function<Resource, ComponentsConfiguration>) input -> !input.getPath().contains("pageB")
							? MOCK_CONFIGURATION_OBJECT
							: ComponentsConfiguration.EMPTY);

			context.registerService(Externalizer.class, new MockExternalizer());

			ConfigurationBuilder mockConfigBuilder = Utils.getDataLayerConfig(true);
			context.registerAdapter(Resource.class, ConfigurationBuilder.class, mockConfigBuilder);
		}, ResourceResolverType.JCR_MOCK);
		
		   
	}

	private EditChildUserServlet fixture;
	private MockSlingHttpServletRequest request;
	private MockSlingHttpServletResponse response;
	private static final String PAGE = "/content/";
	private static final String ChildUser_RES = "/content/jcr:content/root/header";
	private Resource pageResource;
	private Resource productResource;
	private String description;
	private GraphqlClientImpl graphqlClient;
	private HttpClient httpClient;
	private String customerToken;

	@Before
	public void setUp() throws Exception {
		fixture = new EditChildUserServlet();
		
		
		prepareModel(ChildUser_RES, PAGE);
		
	}

	@Test
	public void testDoPost() throws IOException {
		
		request = context.request();
		response = context.response();
		String data = "{ \"company_number\" : 12345, \"customerid\" : 590271, \"componentPath\": \"/content\",\"token\": \"r7ccftt50cguuu55wgvny13dxzlm5bum\" }";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		request.setParameterMap(params);
		request.setHeader("Authorization", "Bearer "+customerToken);
		//addCommentToWishlist.doPost(request, response);
		try {
				if(fixture != null) {
					fixture.doPost(request, response);
				}
			}catch (NullPointerException e){
				e.getMessage();
			}


	}

	private void prepareModel(String resourcePath, String currentPage) throws Exception {
		Page page = Mockito.spy(context.currentPage(currentPage));
		pageResource = Mockito.spy(page.adaptTo(Resource.class));
		when(page.adaptTo(Resource.class)).thenReturn(pageResource);

		httpClient = mock(HttpClient.class);

		context.currentResource(resourcePath);
		productResource = Mockito.spy(context.resourceResolver().getResource(resourcePath));
				
		
		
		Query rootMutation = Utils.getQueryFromResource("graphql/magento-graphql-customerdetails-result.json");
		
		GraphqlClientConfiguration graphqlClientConfiguration = mock(GraphqlClientConfiguration.class);
		when(graphqlClientConfiguration.httpMethod()).thenReturn(HttpMethod.POST);
		when(graphqlClientConfiguration.maxHttpConnections()).thenReturn(10);

		graphqlClient = Mockito.spy(new GraphqlClientImpl());
		graphqlClient.activate(graphqlClientConfiguration);
		Whitebox.setInternalState(graphqlClient, "gson", QueryDeserializer.getGson());
		Whitebox.setInternalState(graphqlClient, "client", httpClient);
	
	
		Utils.setupHttpResponse("graphql/magento-graphql-customerdetails-result.json", httpClient, 200);
				context.registerAdapter(Resource.class, GraphqlClient.class, (Function<Resource, GraphqlClient>) input -> input
				.getValueMap().get("cq:graphqlClient", String.class) != null ? graphqlClient : null);
		
		

		MockRequestPathInfo requestPathInfo = (MockRequestPathInfo) context.request().getRequestPathInfo();
		requestPathInfo.setSelectorString("beaumont-summit-kit");
		context.request().setServletPath(PAGE + ".beaumont-summit-kit.html"); // used by
																				// context.request().getRequestURI();
		// This sets the page attribute injected in the models with @Inject or @ScriptVariable
        SlingBindings slingBindings = (SlingBindings) context.request().getAttribute(SlingBindings.class.getName());
        slingBindings.setResource(productResource);
        slingBindings.put(WCMBindingsConstants.NAME_CURRENT_PAGE, page);
        slingBindings.put(WCMBindingsConstants.NAME_PROPERTIES, productResource.getValueMap());
	}


}

