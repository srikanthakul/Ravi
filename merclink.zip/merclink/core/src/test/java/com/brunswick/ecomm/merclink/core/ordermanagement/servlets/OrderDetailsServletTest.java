package com.brunswick.ecomm.merclink.core.ordermanagement.servlets;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

class OrderDetailsServletTest {

	private static final Logger LOG = LoggerFactory.getLogger(OrderDetailsServletTest.class);
	@Rule
	public final AemContext context = createContext("/context/jcr-content-bulkplaceorder.json");
	private EcommSessionService adminService;
	private OrderDetailsServlet fixture = new OrderDetailsServlet();
	private APIGEEService apigee;
	
	

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");
		}, ResourceResolverType.JCR_MOCK);
	}

	@Before
	public void setup() throws IOException, JSONException {
		fixture = new OrderDetailsServlet();
		apigee = Mockito.mock(APIGEEService.class);
		APIGEEService apigee = Mockito.mock(APIGEEService.class);
		adminService = Mockito.mock(EcommSessionService.class);
		context.registerService(EcommSessionService.class, adminService);
		context.registerService(APIGEEService.class,apigee);
		context.registerInjectActivateService(fixture);
	}
	
	@Test
	public void doGetOrderDetailsServletTest() throws IOException, LoginException {
		ResourceResolver resolver = mock(ResourceResolver.class);
		try {
			if (resolver != null) {
				when(adminService.getWriteServiceResourceResolver()).thenReturn(resolver);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the doGetOrderDetailsServletTest {}", e.getMessage());
		}

		String data = "{\"itemno\":\"ABC\",\"currentPage\":\"/content/ecommerce/delcity/us/en/home/quick-order\",\"token\":\"23pjbqgrhwict6xjzvg2tdr9vfjmkhja\",\"operatingUnit\":\"DC\"}}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		try {
			if (fixture != null) {
				fixture.doGet(null, null);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the doGetOrderDetailsServletTest {}", e.getMessage());
		}
	}

}
