package com.brunswick.ecomm.merclink.core.beans;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CustomerQuotedPriceBeanTest {
	private CustomerQuotedPriceBean fixture;

	@BeforeEach
	void setUp() throws Exception {
		fixture = new CustomerQuotedPriceBean();
		
	}

	@Test
	void getListingPriceTest() {
		Float expectedOutput = 0.5f;
		fixture.setListingPrice(expectedOutput);
		assertEquals(expectedOutput, fixture.getListingPrice());
	}

	@Test
	void getSellingPriceTest() {
		Float expectedOutput = 0.5f;
		fixture.setSellingPrice(expectedOutput);
		assertEquals(expectedOutput, fixture.getSellingPrice());
	}
	
	@Test
	void getAdjustmentsTest() {
		List<PriceAdjustmentsBean> expectedData = new ArrayList<PriceAdjustmentsBean>();
		PriceAdjustmentsBean data = new PriceAdjustmentsBean();
		expectedData.add(data);
		fixture.setAdjustments(expectedData);
		assertEquals(expectedData, fixture.getAdjustments());
	}

	

}
