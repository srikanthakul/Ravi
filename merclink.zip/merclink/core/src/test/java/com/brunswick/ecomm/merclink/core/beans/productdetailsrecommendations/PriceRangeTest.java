package com.brunswick.ecomm.merclink.core.beans.productdetailsrecommendations;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PriceRangeTest {
	PriceRange fixture;

	@BeforeEach
	void setUp() throws Exception {
		fixture = new PriceRange();
	}

	@Test
	void testGetMinimum_price() {
		MinimumPrice expectedData = new MinimumPrice();
		fixture.setMinimum_price(expectedData);
		assertEquals(expectedData, fixture.getMinimum_price());
		
	}

}
