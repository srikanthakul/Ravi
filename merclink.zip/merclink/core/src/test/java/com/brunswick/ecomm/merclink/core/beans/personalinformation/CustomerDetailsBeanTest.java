package com.brunswick.ecomm.merclink.core.beans.personalinformation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CustomerDetailsBeanTest {
       public CustomerDetailsBean fixture;
	   String test;
	
	@BeforeEach
	void setUp() throws Exception {
		 fixture=new CustomerDetailsBean();
	}

	@Test
	void testGetFirstname() {
		test="word";
		fixture.setFirstname(test);
		assertEquals(test,fixture.getFirstname());
	}

	

	@Test
	void testGetLastname() {
		test="word";
		fixture.setLastname(test);
		assertEquals(test,fixture.getLastname());
	}

	

	@Test
	void testGetEmail() {
		test="word";
		fixture.setEmail(test);
		assertEquals(test,fixture.getEmail());
	}

	

	@Test
	void testGetCompany_email() {
		test="word";
		fixture.setCompany_email(test);
		assertEquals(test,fixture.getCompany_email());
	}

	

	@Test
	void testGetCompany_name() {
		test="word";
		fixture.setCompany_name(test);
		assertEquals(test,fixture.getCompany_name());
	}

	

	@Test
	void testGetSuffix() {
		test="word";
		fixture.setSuffix(test);
		assertEquals(test,fixture.getSuffix());
	}

	

}
