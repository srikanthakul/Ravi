package com.brunswick.ecomm.merclink.core.beans;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ProductPricesBeanTest {
	
	ProductPricesBean fixture ;
	CustomerQuotedPriceBean CusQuotedPrice;
	PriceAdjustmentsBean price;
	@BeforeEach
	void setUpBeforeClass()  {
		fixture = new ProductPricesBean();
	}

	@Test
	void testGetTierPrices() {
		List<TierPriceBean> expData = new ArrayList<TierPriceBean>();
		TierPriceBean data = new TierPriceBean();
		expData.add(data);
		fixture.setTierPrices(expData);
		assertEquals(expData, fixture.getTierPrices());
	}

	@Test
	void testGetSalePrice() {
		Float expData = 0.1f;
		fixture.setSalePrice(expData);
		assertEquals(expData, fixture.getSalePrice());
	}

	/*@Test
	void testGetCustomerQuotedPrice() {
		price = new PriceAdjustmentsBean();
		CusQuotedPrice = new CustomerQuotedPriceBean();
		List<PriceAdjustmentsBean> listdata = new ArrayList<PriceAdjustmentsBean>();
		PriceAdjustmentsBean data = new PriceAdjustmentsBean();
		listdata.add(data);
		CusQuotedPrice.setListingPrice(.1f);
		CusQuotedPrice.setSellingPrice(.1f);
		CusQuotedPrice.setAdjustments(listdata);
		price.se
		fixture.
	}*/

}
