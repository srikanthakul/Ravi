package com.brunswick.ecomm.merclink.core.models.retriever;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

class AbstractProductsAvailabilityRetrieverTest {
	private AbstractProductsAvailabilityRetriever retriever;
	private MagentoGraphqlClient mockClient;
	Customer customer;
	private static final Logger LOG = LoggerFactory.getLogger(AbstractProductsAvailabilityRetriever.class);
	GraphqlResponse<Mutation, Error> response= mock(GraphqlResponse.class);
	Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	Mutation mutation= mock(Mutation.class);
	
	@BeforeEach
	void setUp() {
		 mockClient = mock(MagentoGraphqlClient.class);
	       
	     GraphqlResponse mockResponse = mock(GraphqlResponse.class);
	     when(mockClient.execute(any())).thenReturn(mockResponse);
	     when(mockClient.executeMutation(any())).thenReturn(response);
	     when(response.getData()).thenReturn(mutation);
	     when(mockResponse.getData()).thenReturn(mockQuery);
	     when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());
	     retriever = new AbstractProductsAvailabilityRetriever(mockClient);
	}


	@Test
	void testGetProductsAvaliability() {
		 String sampleQuery = "{{ \r\n" + 
	                           "products(filter: { sku: { eq : \"My item number\"} }) {\r\n"+
	                           "items { \r\n"+
	                           "__typename  \r\n"+
	                            "sku \r\n"+
	                           "name \r\n"+
	                            "bu_ss_to_part \r\n"+
	                            " }}}";
		
		
		
		try {
			if (retriever != null ) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the AbstractProductsAvailabilityRetrieverTest {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.getProductsAvaliability(sampleQuery);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the AbstractProductsAvailabilityRetrieverTest {}", e.getMessage());
		}
        
        
		
	}

}
