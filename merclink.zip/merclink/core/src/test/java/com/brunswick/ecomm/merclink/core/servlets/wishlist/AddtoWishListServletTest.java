package com.brunswick.ecomm.merclink.core.servlets.wishlist;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;

import org.apache.http.client.HttpClient;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.scripting.SlingBindings;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.caconfig.ConfigurationBuilder;
import org.apache.sling.servlethelpers.MockRequestPathInfo;
import org.apache.sling.servlethelpers.MockSlingHttpServletRequest;
import org.apache.sling.servlethelpers.MockSlingHttpServletResponse;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.core.components.internal.services.UrlProviderImpl;
import com.adobe.cq.commerce.core.components.services.ComponentsConfiguration;
import com.adobe.cq.commerce.graphql.client.GraphqlClientConfiguration;
import com.adobe.cq.commerce.graphql.client.HttpMethod;
import com.adobe.cq.commerce.graphql.client.impl.GraphqlClientImpl;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.WishlistItemInput;
import com.adobe.cq.commerce.magento.graphql.gson.MutationDeserializer;
import com.brunswick.ecomm.merclink.core.components.testing.MockExternalizer;
//import com.brunswick.ecomm.merclink.core.components.testing.MockUrlProviderConfiguration;
import com.brunswick.ecomm.merclink.core.components.testing.Utils;
import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.scripting.WCMBindingsConstants;
import com.google.common.collect.ImmutableMap;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

public class AddtoWishListServletTest {

	@Rule
	public final AemContext context = createContext("/context/jcr-content-wishlist.json");
	private static final Logger LOG = LoggerFactory.getLogger(AddtoWishListServletTest.class);
	private static final ValueMap MOCK_CONFIGURATION = new ValueMapDecorator(
			ImmutableMap.of("cq:graphqlClient", "default", "magentoStore", "my-store"));

	private static final ComponentsConfiguration MOCK_CONFIGURATION_OBJECT = new ComponentsConfiguration(
			MOCK_CONFIGURATION);

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");

			UrlProviderImpl urlProvider = new UrlProviderImpl();

			context.registerService(Externalizer.class, new MockExternalizer());

			ConfigurationBuilder mockConfigBuilder = Utils.getDataLayerConfig(true);
			context.registerAdapter(Resource.class, ConfigurationBuilder.class, mockConfigBuilder);
		}, ResourceResolverType.JCR_MOCK);
	}
	private AddtoWishListServlet addtoWishlist;
	private MockSlingHttpServletRequest request;
	private MockSlingHttpServletResponse response;
	private static final String PAGE = "/content/pageA";
	private static final String WISHLIST_RES = "/content/pageA/jcr:content/root/responsivegrid_1/mywishlists";
	private Resource pageResource;
	private Resource productResource;
	private List<WishlistItemInput> wishlistItems;
	private GraphqlClientImpl graphqlClient;
	private HttpClient httpClient;
	private String customerToken;
	
	@Before
	public void setUp() throws Exception {
		addtoWishlist = new AddtoWishListServlet();
		addtoWishlist.init();
		prepareModel(WISHLIST_RES, PAGE);
	}
	@Test
	public void testDoPost() throws IOException {
		request = context.request();
		response = context.response();
		String type = "parameters";
		Cookie[] cookies = request.getCookies();
		String data = "{ \"quantity\": \"2\",\"id\": \"ABC\",\"skuid\": \"132\",\"wishlistname\": \"wishlistname\",\"listtype\": \"type\",\"type\": \"ABC\",\"wishlisttype\": \"newwish1\",\"cartobj\": \"newcartobj\",\"resourcePath\": \"/content/pageA\",\"token\": \"r7ccftt50cguuu55wgvny13dxzlm5bum\" }";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		params.put("type", type);
		request.setParameterMap(params);
		request.setHeader("pageManager", "resourcePath " + customerToken);
		addtoWishlist.doPost(request, response);
	}

	private void prepareModel(String resourcePath, String currentPage) throws IOException {
		Page page = Mockito.spy(context.currentPage(currentPage));
		pageResource = Mockito.spy(page.adaptTo(Resource.class));
		when(page.adaptTo(Resource.class)).thenReturn(pageResource);

		httpClient = mock(HttpClient.class);

		context.currentResource(resourcePath);
		productResource = Mockito.spy(context.resourceResolver().getResource(resourcePath));
		try {
			if (context != null) {
				Mutation rootMutation = Utils
						.getMutationFromResource("graphql/magento-graphql-addtowishlist-result.json");
				rootMutation.getAddProductsToWishlist();
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the prepareModel {}", e.getMessage());
		}
		GraphqlClientConfiguration graphqlClientConfiguration = mock(GraphqlClientConfiguration.class);
		when(graphqlClientConfiguration.httpMethod()).thenReturn(HttpMethod.POST);

		graphqlClient = Mockito.spy(new GraphqlClientImpl());
		try {
			graphqlClient.activate(graphqlClientConfiguration);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Whitebox.setInternalState(graphqlClient, "gson", MutationDeserializer.getGson());
		Whitebox.setInternalState(graphqlClient, "client", httpClient);
		Utils.setupHttpResponse("graphql/magento-graphql-addtowishlist-result.json", httpClient, 200);

		MockRequestPathInfo requestPathInfo = (MockRequestPathInfo) context.request().getRequestPathInfo();
		requestPathInfo.setSelectorString("beaumont-summit-kit");
		context.request().setServletPath(PAGE + ".beaumont-summit-kit.html"); // used by
																				// context.request().getRequestURI();
		// This sets the page attribute injected in the models with @Inject or
		// @ScriptVariable
		SlingBindings slingBindings = (SlingBindings) context.request().getAttribute(SlingBindings.class.getName());
		slingBindings.setResource(productResource);
		slingBindings.put(WCMBindingsConstants.NAME_CURRENT_PAGE, page);
		slingBindings.put(WCMBindingsConstants.NAME_PROPERTIES, productResource.getValueMap());
	}

}
