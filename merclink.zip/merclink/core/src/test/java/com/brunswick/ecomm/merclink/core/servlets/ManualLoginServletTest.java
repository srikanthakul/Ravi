package com.brunswick.ecomm.merclink.core.servlets;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.apache.http.client.HttpClient;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.scripting.SlingBindings;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.caconfig.ConfigurationBuilder;
import org.apache.sling.servlethelpers.MockRequestPathInfo;
import org.apache.sling.servlethelpers.MockSlingHttpServletRequest;
import org.apache.sling.servlethelpers.MockSlingHttpServletResponse;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.core.components.internal.services.UrlProviderImpl;
import com.adobe.cq.commerce.core.components.services.ComponentsConfiguration;
import com.adobe.cq.commerce.core.components.services.urls.UrlProvider;
import com.adobe.cq.commerce.graphql.client.GraphqlClient;
import com.adobe.cq.commerce.graphql.client.GraphqlClientConfiguration;
import com.adobe.cq.commerce.graphql.client.HttpMethod;
import com.adobe.cq.commerce.graphql.client.impl.GraphqlClientImpl;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.gson.MutationDeserializer;
import com.brunswick.ecomm.merclink.core.components.testing.MockExternalizer;
import com.brunswick.ecomm.merclink.core.components.testing.Utils;
import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.scripting.WCMBindingsConstants;
//import com.google.common.base.Function;
import com.google.common.collect.ImmutableMap;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

public class ManualLoginServletTest {

	@Rule
	public final AemContext context = createContext("/context/jcr-content-manuallogin.json");

	private static final Logger LOG = LoggerFactory.getLogger(ManualLoginServlet.class);
	
	private static final ValueMap MOCK_CONFIGURATION = new ValueMapDecorator(
			ImmutableMap.of("cq:graphqlClient", "default", "magentoStore", "my-store"));

	private static final ComponentsConfiguration MOCK_CONFIGURATION_OBJECT = new ComponentsConfiguration(
			MOCK_CONFIGURATION);

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");

			UrlProviderImpl urlProvider = new UrlProviderImpl();
			//urlProvider.activate(new MockUrlProviderConfiguration());
			context.registerService(UrlProvider.class, urlProvider);

			context.registerAdapter(Resource.class, ComponentsConfiguration.class,
					(Function) input -> !((Resource) input).getPath().contains("pageB")
							? MOCK_CONFIGURATION_OBJECT
							: ComponentsConfiguration.EMPTY);

			context.registerService(Externalizer.class, new MockExternalizer());

			ConfigurationBuilder mockConfigBuilder = Utils.getDataLayerConfig(true);
			context.registerAdapter(Resource.class, ConfigurationBuilder.class, mockConfigBuilder);
		}, ResourceResolverType.JCR_MOCK);
	}

	private ManualLoginServlet login;
	private MockSlingHttpServletRequest request;
	private MockSlingHttpServletResponse response;
	private static final String PAGE = "/content/pageA";
	private static final String MANUAL_LOGIN = "/content/pageA/jcr:content/root/responsivegrid_1/manuallogin";
	private Resource pageResource;
	private Resource productResource;
	private String customerEmail;
	private GraphqlClient graphqlClient;
	private HttpClient httpClient;
	private String customerToken;

	@Before
	public void setUp() throws Exception {
		login = new ManualLoginServlet();
		login.init();
		
		try {
			if (login != null) {
				prepareModel(MANUAL_LOGIN, PAGE);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the ManualLoginServletTest {}", e.getMessage());
		}
	}

	@Test
	public void testDoPost() throws IOException {

		request = context.request();
		response = context.response();
		String data = "{ \"customerEmail\":\"xyz@gmail.com\",\"visibility\": \"PUBLIC\",\"resourcePath\": \"/content/pageA\",\"adminToken\": \"r7ccftt50cguuu55wgvny13dxzlm5bum\" }";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		request.setParameterMap(params);
		request.setHeader("Authorization", "Bearer " + customerToken);
		login.doPost(request, response);
		String op = response.getOutputAsString();

		
		try {
			if (op != null) {
				Assert.assertEquals(null, customerEmail);
				return; 
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the ManualLoginServletTest {}", e.getMessage());
		}
	}

	private void prepareModel(String resourcePath, String currentPage) throws IOException {
		Page page = Mockito.spy(context.currentPage(currentPage));
		pageResource = Mockito.spy(page.adaptTo(Resource.class));
		when(page.adaptTo(Resource.class)).thenReturn(pageResource);

		httpClient = mock(HttpClient.class);

		context.currentResource(resourcePath);
		productResource = Mockito.spy(context.resourceResolver().getResource(resourcePath));

		/*
		 * Mutation rootQuery =
		 * Utils.getMutationFromResource("graphql/magento-graphql-customer-token.json");
		 * customerToken = rootQuery.getGenerateCustomerToken().getToken();
		 */

		Mutation rootMutation = Utils.getMutationFromResource("graphql/magento-graphql-createwishlist-result.json");
		customerEmail = rootMutation.getCreateWishlist().getWishlist().getId().toString();
		

		GraphqlClientConfiguration graphqlClientConfiguration = mock(GraphqlClientConfiguration.class);
		when(graphqlClientConfiguration.httpMethod()).thenReturn(HttpMethod.POST);

		graphqlClient = Mockito.spy(new GraphqlClientImpl());
		Whitebox.setInternalState(graphqlClient, "gson", MutationDeserializer.getGson());
		Whitebox.setInternalState(graphqlClient, "client", httpClient);
		Whitebox.setInternalState(graphqlClient, "configuration", graphqlClientConfiguration);

		// Utils.setupHttpResponse("graphql/magento-graphql-customer-token.json",
		// httpClient, 200);
		Utils.setupHttpResponse("graphql/magento-graphql-createwishlist-result.json", httpClient, 200);

		context.registerAdapter(Resource.class, GraphqlClient.class, (Function<Resource, GraphqlClient>) input -> input
				.getValueMap().get("cq:graphqlClient", String.class) != null ? graphqlClient : null);

		MockRequestPathInfo requestPathInfo = (MockRequestPathInfo) context.request().getRequestPathInfo();
		requestPathInfo.setSelectorString("beaumont-summit-kit");
		context.request().setServletPath(PAGE + ".beaumont-summit-kit.html"); // used by
																				// context.request().getRequestURI();
		// This sets the page attribute injected in the models with @Inject or
		// @ScriptVariable
		SlingBindings slingBindings = (SlingBindings) context.request().getAttribute(SlingBindings.class.getName());
		slingBindings.setResource(productResource);
		slingBindings.put(WCMBindingsConstants.NAME_CURRENT_PAGE, page);
		slingBindings.put(WCMBindingsConstants.NAME_PROPERTIES, productResource.getValueMap());
	}
}
