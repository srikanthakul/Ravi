package com.brunswick.ecomm.merclink.core.models.impl;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.brunswick.ecomm.merclink.core.helper.MultifieldHelper;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith(AemContextExtension.class)
class CurrentNewsSectionImplTest {

	public AemContext context = new AemContext();
	public final String path = "/content/ecommerce/merclink/au/en/home/news/current-news/jcr:content/root/container/container/allnews";
	@BeforeEach
	void setUp() throws Exception {
		context.addModelsForPackage("com.brunswick.ecomm.merclink.core.models.impl");
		context.addModelsForClasses(CurrentNewsSectionImpl.class);
		context.load().json("/context/newsSection.json", path);
	}

	@Test
	void testGetCurrentNewsDetails() {
		Resource resource = context.resourceResolver().getResource(path);
		assertNotNull(resource);
		CurrentNewsSectionImpl currentNewsSection = resource.adaptTo(CurrentNewsSectionImpl.class);
		List<MultifieldHelper> currentNewsDetailsList = new ArrayList<>();
		Resource currentNewsDetails = resource.getChild("currentnews");
		if(currentNewsDetails != null) {
		for (Resource currentNewss : currentNewsDetails.getChildren()) {
		currentNewsDetailsList.add(new MultifieldHelper(currentNewss));
		assertNotNull(currentNewsDetailsList);
			}
		}
		assertNotNull(currentNewsSection.getCurrentNewsDetails());
	}

	@Test
	void testGetCurrentNewsHeading() {
		Resource resource = context.resourceResolver().getResource(path);
		assertNotNull(resource);
		CurrentNewsSectionImpl currentNewsSection = resource.adaptTo(CurrentNewsSectionImpl.class);
		assertNotNull(currentNewsSection.getCurrentNewsHeading());
		//assertEquals("Current News", currentNewsSection.getCurrentNewsHeading());
	}

}
