package com.brunswick.ecomm.merclink.core.beans.productdetailsrecommendations;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;



	public class RelatedProductsBeanTest {
		RelatedProductsBean fixture;
		@BeforeEach
		public void setup() {
			fixture = new RelatedProductsBean();
		}
		
		@Test
		public void getSkuTest() {
			String expecteddata="city";
			fixture.setSku(expecteddata);
			fixture.getSku();
		}
		
		@Test
		public void getNameTest() {
			String expecteddata="city";
			fixture.setName(expecteddata);
			fixture.getName();
		}
		
		@Test
		public void getPrice_rangeTest() {
			PriceRange expecteddata = new PriceRange();
			fixture.setPrice_range(expecteddata );
			assertEquals(expecteddata,fixture.getPrice_range());
		}

		@Test
		public void getImage_data_custom_Test() {
			imageBean expecteddata = new imageBean();
			fixture.setImage_data_custom_(expecteddata );
			assertEquals(expecteddata,fixture.getImage_data_custom_());
		}
	}