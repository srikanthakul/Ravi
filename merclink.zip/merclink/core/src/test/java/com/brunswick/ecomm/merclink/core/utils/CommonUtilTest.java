package com.brunswick.ecomm.merclink.core.utils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.adobe.cq.wcm.core.components.models.Page;
import com.adobe.xfa.ut.StringUtils;
import com.brunswick.ecomm.core.util.PathLinkUtil;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.PageManager;

import acscommons.com.jcraft.jsch.Logger;

class CommonUtilTest {
	 private final String COOKIE_NAME = "test_cookie";
	    private final String COOKIE_VALUE = "test_token";
	  
	    
	    private SlingHttpServletRequest request;
	   
	    @Mock
	    private Logger LOGGER;

	    @BeforeEach
	    void setUp() {
	        MockitoAnnotations.openMocks(this);
	        request = mock(SlingHttpServletRequest.class);
	        Cookie cookie = mock(Cookie.class);
	        when(cookie.getName()).thenReturn(COOKIE_NAME);
	        when(cookie.getValue()).thenReturn(COOKIE_VALUE);
	        when(request.getCookies()).thenReturn(new Cookie[] { cookie });
	    }

	@Test
	  void testGetTokenFromCookie() {
        // Call the method to be tested
        String token = getTokenFromCookie(COOKIE_NAME, request);

        // Verify the result
        assertEquals(token, token);

        // Verify that the logger was called with the expected message
        
        //((logger) verify(LOGGER)).error("Cookie value {}", COOKIE_VALUE);
    }
	 @Test
	    void testGetTokenFromCookieWithInvalidCookieName() {
	        // Call the method to be tested with an invalid cookie name
	        String token = getTokenFromCookie("invalid_cookie", request);

	        // Verify the result
	        assertEquals(token, token);

	        // Verify that the logger was not called with an error message
	        verifyNoInteractions(LOGGER);
	    }
	 private String getTokenFromCookie(String string, SlingHttpServletRequest request2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Test
	    void testGetTokenFromCookieWithNullCookies() {
	        // Set up the test with null cookies
	        when(request.getCookies()).thenReturn(null);

	        // Call the method to be tested with null cookies
	        String token = getTokenFromCookie(COOKIE_NAME, request);

	        // Verify the result
	        assertEquals(token, token);

	        // Verify that the logger was not called with an error message
	        verifyNoInteractions(LOGGER);
	    }
	 @Mock
	    private SlingHttpServletResponse response;

	    @BeforeEach
	    void getUp() {
	        MockitoAnnotations.openMocks(this);
	    }
	    @Test
	    void testSetCookie() {
	        // Call the method to be tested
	        getCookie(COOKIE_NAME, COOKIE_VALUE, response);

	        
	    }

		private void getCookie(String cOOKIE_NAME2, String cOOKIE_VALUE2, SlingHttpServletResponse response2) {
			// TODO Auto-generated method stub
			
		}
		 
		
}
