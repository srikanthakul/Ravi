package com.brunswick.ecomm.merclink.core.models;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.brunswick.ecomm.merclink.core.beans.PrivilegeMultiFieldBean;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith(AemContextExtension.class)
class TouchMultiFieldComponentModelTest {
	
	private final AemContext context = new AemContext();
	private final String path = "/content/ecommerce/merclink/au/en/contactusermanagement/createnewcontact/jcr:content/root/container/container/createnewcontact";
	private List<PrivilegeMultiFieldBean> privilegesBean;
	
	@InjectMocks
	SlingHttpServletRequest response;
	
	@InjectMocks
	TouchMultiFieldComponentModel touch;
	
	@BeforeEach
	void setUp() throws Exception {
		context.addModelsForPackage("com.brunswick.ecomm.merclink.core.models");
		context.addModelsForClasses(TouchMultiFieldComponentModel.class);
		context.load().json("/context/TouchMultiFieldComponentModel.json", path);
		
	}

	@Test
	void testGetPrivilegeDetailsWithBean() {
		Resource resource = context.resourceResolver().getResource(path);
		privilegesBean =new ArrayList<PrivilegeMultiFieldBean>();
		TouchMultiFieldComponentModel touchMultiField = resource.adaptTo(TouchMultiFieldComponentModel.class);
//		TouchMultiFieldComponentModel touchMultiField = mock(TouchMultiFieldComponentModel.class);
		response = mock(SlingHttpServletRequest.class);
		
		//assertNotNull(touchMultiField.getPrivilegeDetailsWithBean());
        //String privileges = response.getCookie("privileges").getValue().toString();
       
        ArrayList<String> privilegeList = new ArrayList<>();
        
        
            Resource privilegeDetailBean=resource.getChild("privilegedetailswithbean");
            Resource privilegeDetailBeanItem = privilegeDetailBean.getChild("item0");
            if(privilegeDetailBeanItem!=null){
                for (Resource privilegeBean : privilegeDetailBeanItem.getChildren()) {
                	ValueMap vm = privilegeBean.getValueMap();
                	String code = getPropertyValue(vm, "privilegecode");
                	if(privilegeList.contains(code)) {
                		PrivilegeMultiFieldBean menuItem = new PrivilegeMultiFieldBean();
                		String name = getPropertyValue(vm, "privilegename");
                		String tooltip = getPropertyValue(vm, "privilegetooltip");
                		menuItem.setName(name);
                		menuItem.setPrivilegeCode(code);
                		menuItem.setTooltip(tooltip);
                		privilegesBean.add(menuItem);
                		
                		assertNull(privilegesBean);
                		//when(touchMultiField.getPrivilegeDetailsWithBean()).thenReturn(privilegesBean);
                		
                	}
                	
                	assertNotNull(touchMultiField.getPrivilegeDetailsWithBean());

                }
            }
            
       
        
        
        
        
	}
	 private String getPropertyValue(final ValueMap properties, final String propertyName) {
	        return properties.containsKey(propertyName) ? properties.get(propertyName, String.class) : StringUtils.EMPTY;
	    }

}
