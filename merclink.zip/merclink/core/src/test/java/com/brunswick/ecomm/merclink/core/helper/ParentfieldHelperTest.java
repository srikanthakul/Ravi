package com.brunswick.ecomm.merclink.core.helper;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class ParentfieldHelperTest {
	private static final Logger LOG = LoggerFactory.getLogger(ParentfieldHelperTest.class);
	private String orderTitle;
	private List<subNastedHelper> permissionCode;
	private ParentfieldHelper fixture;
	@BeforeEach
	void setUp() throws Exception {
		fixture = new ParentfieldHelper(null);
	}
	@Test
	void getBuyPriceTest() {
		orderTitle = "orderTitle";
		try {
			if (fixture != null) {
				fixture.setSubMenu(null);
				assertEquals(orderTitle, fixture.getOrderTitle());
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the prepareModel {}", e.getMessage());
		}
	}

	@Test
	void getPermissionCode() {
		try {
			if (fixture != null) {
				fixture.setSubMenu(permissionCode);
				assertEquals(permissionCode, fixture.getPermissionCode());
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the prepareModel {}", e.getMessage());
		}
	}


}
