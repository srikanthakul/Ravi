package com.brunswick.ecomm.merclink.core.beans.product;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ProductDataResultBeanTest {
	ProductDataResultBean fixture;
	@BeforeEach
	public void setUp() throws Exception {
		fixture = new ProductDataResultBean();
	}

	@Test
	void testGetData() {
		ProductDataBean expectedData = new ProductDataBean();
		fixture.setData(expectedData);
		assertEquals(expectedData,fixture.getData());
	}

}
