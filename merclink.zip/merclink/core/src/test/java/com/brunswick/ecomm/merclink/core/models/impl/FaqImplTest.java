package com.brunswick.ecomm.merclink.core.models.impl;

import static org.junit.jupiter.api.Assertions.*;

import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.brunswick.ecomm.merclink.core.models.MultifieldModel;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith(AemContextExtension.class)
class FaqImplTest {

	public AemContext context = new AemContext();
	public final String path = "/content/ecommerce/merclink/au/en/faq/jcr:content/root/container/container/faq";
	
	@BeforeEach
	void setUp() throws Exception {
		context.addModelsForPackage("com.brunswick.ecomm.merclink.core.models.impl");
		context.addModelsForClasses(FaqImpl.class);
		context.load().json("/context/multifaq.json", path);
	}

	@Test
	void testGetFaqHeader() {
		  Resource resource = context.resourceResolver().getResource(path); 
		  assertNotNull(resource);
		  FaqImpl faqImpl = resource.adaptTo(FaqImpl.class);
		  assertNotNull(faqImpl.getFaqHeader()); 
	}

	@Test
	void testGetFaqDetails() {
		  Resource resource = context.resourceResolver().getResource(path +"/multifaq/item0"); 
		  assertNotNull(resource);
		  FaqImpl faqImpl = resource.adaptTo(FaqImpl.class);
		  assertNotNull(faqImpl.getFaqDetails());
	}

}
