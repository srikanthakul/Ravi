package com.brunswick.ecomm.merclink.core.beans.product;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.brunswick.ecomm.core.beans.product.InventoryBean;
import com.brunswick.ecomm.core.beans.product.InventoryStatusBean;
import com.brunswick.ecomm.core.beans.product.ProductDataBean;

class ProductDataBeanTest {
	private InventoryBean inventory;
	private String itemNumber;
	private String alternateItemNumber;
	private String superseededForItem;
	private String description;
	private String itemType;
	private String itemStatus;
	private String totalQuantity;
	private String date;
	private ProductDataBean fixture;
	
	@BeforeEach
	public void setup() {
		fixture=new ProductDataBean();
	}
	
	@Test
	public void getAlternateItemNumberTest() {
		alternateItemNumber="alternateItemNumber";
		fixture.setAlternateItemNumber(alternateItemNumber);
		assertEquals(alternateItemNumber,fixture.getAlternateItemNumber());
		
	}
	@Test
	public void getDateTest() {
		date="12/12/2020";
		fixture.setDate(date);
		assertEquals(date,fixture.getDate());
		
	}
	@Test
	public void getDescriptionTest() {
		description="description";
		fixture.setDescription(description);
		assertEquals(description,fixture.getDescription());
		
	}
	@Test
	public void getInventoryTest() {
		inventory=new InventoryBean();
		InventoryStatusBean status = new InventoryStatusBean();
		status.setId("itemid");
		status.setMessage("string msg");
		inventory.setStatus(status);
		fixture.setInventory(inventory);
		assertEquals(inventory,fixture.getInventory());
		
	}
	@Test
	public void getItemNumberTest() {
		itemNumber="itemno";
		fixture.setItemNumber(itemNumber);
		assertEquals(itemNumber,fixture.getItemNumber());
	}
	@Test
	public void getItemStatusTest() {
		itemStatus="instock";
		fixture.setItemStatus(itemStatus);
		assertEquals(itemStatus,fixture.getItemStatus());
	}
	@Test
	public void getItemTypeTest() {
		itemType="itemtype";
		fixture.setItemType(itemType);
		assertEquals(itemType,fixture.getItemType());
		
	}
	@Test
	public void getSuperseededForItemTest() {
		superseededForItem="superseed";
		fixture.setSuperseededForItem(superseededForItem);
		assertEquals(superseededForItem,fixture.getSuperseededForItem());
		
	}
	@Test
	public void getTotalQuantityTest() {
		totalQuantity="20";
		fixture.setTotalQuantity(totalQuantity);
		assertEquals(totalQuantity,fixture.getTotalQuantity());
	}
	

}
