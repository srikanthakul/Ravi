package com.brunswick.ecomm.merclink.core.beans.personalinformation;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CustomerBillingAddressBeanTest {
	public CustomerBillingAddressBean fixture;
	String test;
	Integer digits;
	int a;
	Boolean value;
	

	@BeforeEach
	void setUp() throws Exception {
		fixture=new CustomerBillingAddressBean();
	}

	@Test
	void testGetRegion_code() {
		test="word";
		fixture.setRegion_code(test);
		assertEquals(test,fixture.getRegion_code());	
	}

	

	@Test
	void testGetFirstname() {
		test="word";
		fixture.setFirstname(test);
		assertEquals(test,fixture.getFirstname());
	}

	
	@Test
	void testGetLastname() {
		test="word";
		fixture.setLastname(test);
		assertEquals(test,fixture.getLastname());
	}

	

	@Test
	void testGetStreet() {
		List<String> name = new ArrayList<String>();
		String somename = new String();
		name.add(somename);
		fixture.setStreet(name);
		assertEquals(name,fixture.getStreet());
	}

	

	@Test
	void testGetCity() {
		test="word";
		fixture.setCity(test);
		assertEquals(test,fixture.getCity());
	}

	

	@Test
	void testGetPrimary_flag() {
		test="word";
		fixture.setPrimary_flag(test);
		assertEquals(test,fixture.getPrimary_flag());
	}

	
	@Test
	void testGetCountry_code() {
		test="word";
		fixture.setCountry_code(test);
		assertEquals(test,fixture.getCountry_code());
	}

	

	@Test
	void testGetPostcode() {
		test="word";
		fixture.setPostcode(test);
		assertEquals(test,fixture.getPostcode());
	}

	

	@Test
	void testGetCountry_id() {
		test="word";
		fixture.setCountry_id(test);
		assertEquals(test,fixture.getCountry_id());
	}

	

	@Test
	void testGetId() {
		digits=12345;
		fixture.setId(digits);
		assertEquals(digits,fixture.getId());
	}

	

	@Test
	void testGetCustomer_id() {
		digits=12345;
		fixture.setCustomer_id(digits);
		assertEquals(digits,fixture.getCustomer_id());
	}

	

	@Test
	void testGetRegion_id() {
		digits=12345;
		fixture.setRegion_id(digits);
		assertEquals(digits,fixture.getRegion_id());
		a=1;
		fixture.setRegion_id(a);
		assertEquals(a,fixture.getRegion_id());
	}

	

	

	@Test
	void testGetDefault_shipping() {
		value=true;
		fixture.setDefault_shipping(value);
		assertEquals(value,fixture.getDefault_shipping());
	}

	

	@Test
	void testGetDefault_billing() {
		value=true;
		fixture.setDefault_billing(value);
		assertEquals(value,fixture.getDefault_billing());
	}

	

	@Test
	void testGetRegion() {
		test="word";
		fixture.setRegion(test);
		assertEquals(test,fixture.getRegion());
	}

	

	@Test
	void testGetCountry_name() {
		test="word";
		fixture.setCountry_name(test);
		assertEquals(test,fixture.getCountry_name());
	}

	

}
