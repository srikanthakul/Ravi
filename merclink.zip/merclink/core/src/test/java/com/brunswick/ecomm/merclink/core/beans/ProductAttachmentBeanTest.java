package com.brunswick.ecomm.merclink.core.beans;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ProductAttachmentBeanTest {

	ProductAttachmentBean fixture;

	@BeforeEach
	public void setup() {
		fixture = new ProductAttachmentBean();
	}

	@Test
	public void getlabelNameTest() {
		String expecteddata = "city";
		fixture.setLabelName(expecteddata);
		fixture.getLabelName();
	}

	@Test
	public void getdescriptionTest() {
		String expecteddata = "city";
		fixture.setDescription(expecteddata);
		fixture.getDescription();
	}

	@Test
	public void getattachment() {
		String expecteddata = "city";
		fixture.setAttachment(expecteddata);
		fixture.getAttachment();
	}
}
