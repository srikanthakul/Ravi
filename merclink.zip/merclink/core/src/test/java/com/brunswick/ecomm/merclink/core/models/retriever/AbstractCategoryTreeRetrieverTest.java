package com.brunswick.ecomm.merclink.core.models.retriever;

import static org.mockito.ArgumentMatchers.any;

import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.CategoryTree;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

class AbstractCategoryTreeRetrieverTest {

	private AbstractCategoryTreeRetriever categoryTreeRetriever;
	private MagentoGraphqlClient mockClient;
	CategoryTree categoryTree;
	private static final Logger LOG = LoggerFactory.getLogger(AbstractCategoryTreeRetriever.class);
	 GraphqlResponse<Mutation, Error> response= mock(GraphqlResponse.class);
	    Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	    Mutation mutation= mock(Mutation.class);
	    @BeforeEach
	    public void setUp() {
	        mockClient = mock(MagentoGraphqlClient.class);
	       
	       
	        GraphqlResponse mockResponse = mock(GraphqlResponse.class);
	        when(mockClient.execute(any())).thenReturn(mockResponse);
	        when(mockClient.executeMutation(any())).thenReturn(response);
	        when(response.getData()).thenReturn(mutation);
	        when(mockResponse.getData()).thenReturn(mockQuery);
	        when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());

	        categoryTreeRetriever = new AbstractCategoryTreeRetriever(mockClient);
	    }
	    
	    @Test
	    public void getCategoryTree(){
	    	String sampleQuery="{\r\n" + 
	    			"categoryList{\r\n" + 
//	    			"children_count\r\n" + 
	    			"children {\r\n" + 
	    			//"companyNumber:\r\n"+
	    			"level\r\n" + 
	    			"name\r\n" + 
	    			"path\r\n" + 
	    			"url_path\r\n" + 
	    			"url_key\r\n" + 
	    			"children {\r\n" + 
	    			"level\r\n" + 
	    			"name\r\n" + 
	    			"path\r\n" + 
	    			"url_path\r\n" + 
	    			"url_key\r\n" + 
	    			"}\r\n" + 
	    			"}\r\n" + 
	    			"}\r\n" + 
	    			"}";
	    	//categoryTreeRetriever.setQuery(queryString);
	    	try {
				if (categoryTreeRetriever != null) {
					categoryTreeRetriever.setQuery(sampleQuery);
					mockClient.execute(sampleQuery);
					 
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractCategoryTreeRetrieverTest {}", e.getMessage());
			}

	    	try {
				if (categoryTreeRetriever != null) {
					categoryTreeRetriever.getCategoryTree(null);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractCategoryTreeRetrieverTest {}", e.getMessage());
			}
	    	//mockClient.execute(queryString);
	    	//categoryTreeRetriever.getCategoryTree(null);
	    }
}
