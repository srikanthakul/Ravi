package com.brunswick.ecomm.merclink.core.beans;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PrivilegeMultiFieldBeanTest {
	PrivilegeMultiFieldBean fixture;
	String expectedOutput;

	@BeforeEach
	void setUp() throws Exception {
		fixture = new PrivilegeMultiFieldBean();
	}

	@Test
	void testGetTooltip() {
		expectedOutput = "Tooltip";
		fixture.setTooltip(expectedOutput);
		assertEquals(expectedOutput, fixture.getTooltip());
	}

	@Test
	void testGetName() {
		expectedOutput = "Name";
		fixture.setName(expectedOutput);
		assertEquals(expectedOutput, fixture.getName());

	}

	@Test
	void testGetPrivilegeCode() {
		expectedOutput = "Code";
		fixture.setPrivilegeCode(expectedOutput);
		assertEquals(expectedOutput, fixture.getPrivilegeCode());
	}

}
