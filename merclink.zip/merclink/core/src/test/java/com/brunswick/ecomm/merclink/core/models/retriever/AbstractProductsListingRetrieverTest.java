package com.brunswick.ecomm.merclink.core.models.retriever;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

class AbstractProductsListingRetrieverTest {
	private AbstractProductsListingRetriever retriever;
	private MagentoGraphqlClient mockClient;
	Customer customer;
	private static final Logger LOG = LoggerFactory.getLogger(AbstractProductsListingRetriever.class);
	GraphqlResponse<Mutation, Error> response = mock(GraphqlResponse.class);
	Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	Mutation mutation = mock(Mutation.class);

	@BeforeEach
	public void setUp() {
		mockClient = mock(MagentoGraphqlClient.class);

		GraphqlResponse mockResponse = mock(GraphqlResponse.class);
		when(mockClient.execute(any())).thenReturn(mockResponse);
		when(response.getData()).thenReturn(mutation);
		when(mockResponse.getData()).thenReturn(mockQuery);
		when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());

		retriever = new AbstractProductsListingRetriever(mockClient);
	}
	
	@Test
    public void getProductsList(){
    	String sampleQuery="{\r\n" + 
    			"products(\r\n" + 
    			"currentPage:\r\n" + 
    			"pageSize:\r\n" + 
    			"filter: { category_id: { eq:\r\n" + 
    			"}, company_customer_number: { eq:\r\n" + 
    			"}\r\n" + 
    			"sort: {\r\n" + 
    			") {\r\n" + 
    			
    			"total_count\r\n" + 
    			"items {\r\n" + 
    			"__typename\r\n" + 
    			"id\r\n" + 
    			"sku\r\n" + 
    			"name\r\n" + 
    			"image_data_custom_ : image_data { \r\n" + 
    			"image_set_custom_: image_set\r\n" + 
    			
    			"product_thumbnail_custom_: product_thumbnail\r\n" + 
    			"productattachment_custom_: productattachment\r\n" + 
    			"attach_identifer_custom_: attach_identifer\r\n" + 
    			"label_name_custom_: label_name\r\n" + 
    			"description_custom_: description\r\n" + 
    			"attachment_custom_: attachment\r\n" + 
    			"visible_custom_: visible\r\n" + 
    			"}\r\n" + 
    			"}\r\n" + 
    			
    			"masterpartlowestsellinguomqty_custom_: masterpartlowestsellinguomqty \r\n" + 
    			"small_image {\r\n" + 
    			"url\r\n" + 
    			"} \r\n" + 
    			"color\r\n" + 
    			"stock_status\r\n" + 
    			"type_id\r\n" + 
    			"masterpartprop65code_custom_: masterpartprop65code \r\n" + 
    			"mp_hazardous_material_custom_: mp_hazardous_material \r\n" + 
    			
    			"url_key\r\n" + 
    			"price_range { \r\n" + 
    			"minimum_price { \r\n" + 
    			"regular_price {\r\n" + 
    			"value\r\n" + 
    			"currency\r\n" + 
    			"}\r\n" + 
    			
    			"final_price { \r\n" + 
    			"value\r\n" + 
    			"currency\r\n" + 
    			"} \r\n" + 
    			"discount {\r\n" + 
    			"amount_off\r\n" + 
    			"percent_off\r\n" + 
    			"} \r\n" + 
    			"}\r\n" + 
    			
    			"maximum_price { \r\n" + 
    			"regular_price { \r\n" + 
    			"value\r\n" + 
    			"currency\r\n" + 
    			"} \r\n" + 
    			
    			"final_price { \r\n" + 
    			"value\r\n" + 
    			"currency\r\n" + 
    			"} \r\n" + 
    			"discount {\r\n" + 
    			"amount_off\r\n" + 
    			"percent_off\r\n" + 
    			"} \r\n" + 
    			"} \r\n" + 
    			"}\r\n" + 
    			
    			"... on ConfigurableProduct { \r\n" + 
    			
    			"maximum_price { \r\n" + 
    			"regular_price { \r\n" + 
    			"value\r\n" + 
    			"currency\r\n" + 
    			"} \r\n" +
    			
    			"final_price { \r\n" + 
    			"value\r\n" + 
    			"currency\r\n" + 
    			"} \r\n" + 
    			"discount {\r\n" + 
    			"amount_off\r\n" + 
    			"percent_off\r\n" + 
    			"} \r\n" + 
    			"} \r\n" + 
    			"}\r\n" +
    			
    			"configurable_options {  \r\n" + 
    			"label\r\n" + 
    			"attribute_code\r\n" + 
    			"values\r\n" + 
    			"value_index {\r\n" + 
    			"label\r\n" + 
    			"} \r\n" + 
    			"}\r\n" +
    			
    			"variants {\r\n" + 
    			"attributes {\r\n" + 
    			"code\r\n" + 
    			"value_index \r\n" + 
    			"discount {\r\n" + 
    			"} \r\n" + 
    			"} \r\n" + 
    			"}\r\n" +
    			
    			"... on BundleProduct {\r\n" + 
    			"price_range {\r\n" +
    			"maximum_price { \r\n" + 
    			"regular_price { \r\n" + 
    			"value\r\n" + 
    			"currency\r\n" + 
    			"} \r\n" +
    			
    			"final_price {\r\n" + 
    			"value\r\n" + 
    			"currency\r\n" + 
    			"} \r\n" + 
    			"discount {\r\n" + 
    			"amount_off \r\n" + 
    			"percent_off\r\n" + 
    			"}\r\n" +
    			"}\r\n" +
    			"}\r\n" +
    			"}\r\n" +
    			"}\r\n" +
    			
    			"aggregations {\r\n" + 
    			"options { \r\n" + 
    			"currency\r\n" + 
    			"count\r\n" + 
    			"label\r\n" + 
    			"value \r\n" + 
    			"level_custom_: level\r\n" + 
    			"name_custom_: name\r\n" +
    			"path_custom_: path\r\n" +
    			"path_name_custom_: path_name\r\n" +
    			"url_key_custom_: url_key\r\n" +
    			"url_path_custom_: url_path \r\n" +
    			"}\r\n" + 
    			"attribute_code \r\n" + 
    			"count\r\n" + 
    			"label\r\n" + 
    			"} \r\n" + 
    			"} \r\n" + 
    			"category(id:\r\n" +
    			"id\r\n" + 
    			"description\r\n" + 
    			
    			"name\r\n" + 
    			"image \r\n" + 
    			"product_count\r\n" + 
    			"meta_description\r\n" + 
    			"meta_keywords\r\n" + 
    			"meta_title\r\n" +
    			"url_path \r\n" +
    			"}\r\n" +
    			"}";
    	try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the AbstractProductsListingRetrieverTest {}", e.getMessage());
		}
    	try {
			if (retriever != null) {
				retriever.getProductsList(null);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the AbstractProductsListingRetrieverTest {}", e.getMessage());
		}
	}
}
