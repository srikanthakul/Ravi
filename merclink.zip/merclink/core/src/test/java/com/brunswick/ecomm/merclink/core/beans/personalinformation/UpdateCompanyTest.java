package com.brunswick.ecomm.merclink.core.beans.personalinformation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UpdateCompanyTest {

	UpdateCompany fixture;
	
	@BeforeEach
	 void setUpBeforeClass()  {
		fixture = new UpdateCompany();
	}

	@Test
	void testGetCompany() {
		Company expdata = new Company();
		fixture.setCompany(expdata);
		assertEquals(expdata, fixture.getCompany());
	}

}
