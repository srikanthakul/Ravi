package com.brunswick.ecomm.merclink.core.models.internal.productlist;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;



import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.AddConfigurableProductsToCartOutput;
import com.adobe.cq.commerce.magento.graphql.AddSimpleProductsToCartOutput;
import com.adobe.cq.commerce.magento.graphql.CartItemInput;
import com.adobe.cq.commerce.magento.graphql.ConfigurableProductCartItemInput;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.SimpleProductCartItemInput;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;



public class AbstractCartRetrieverV2Test {
	 private AbstractCartRetrieverV2 retriever;
	    private  MagentoGraphqlClient mockClient;
	    Customer customer;
		AddConfigurableProductsToCartOutput mockCartOutput;
		AddSimpleProductsToCartOutput addCartOutput;
	    GraphqlResponse<Mutation, Error> response= mock(GraphqlResponse.class);
	    Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	    Mutation queryResponse  = mock(Mutation.class);;
	    Mutation mutation= mock(Mutation.class);
	    @BeforeEach
	    public void setUp() {
	         mockClient = mock(MagentoGraphqlClient.class);
	         addCartOutput=mock(AddSimpleProductsToCartOutput.class);
	       mockCartOutput=mock(AddConfigurableProductsToCartOutput.class);
	        GraphqlResponse mockResponse = mock(GraphqlResponse.class);
	        when(mockClient.execute(any())).thenReturn(mockResponse);
	        when(mockClient.executeMutation(any())).thenReturn(response);
	        when(response.getData()).thenReturn(mutation);
	        when(mockResponse.getData()).thenReturn(queryResponse);
	        when(queryResponse.getAddConfigurableProductsToCart()).thenReturn(mockCartOutput);
	        when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());
	        when(mockQuery.getCart().getItems()).thenReturn(Collections.EMPTY_LIST);
	        
	        retriever = new CartRetriever(mockClient);
	        when(retriever.executeMutation()).thenReturn(mockResponse);

	    }
	    
	    
	    @Test
	    public void createEmptyCartTest() {
	    	String sampleQuery="{\r\n" + 
	    			"  customerCart{\r\n" + 
	    			"    id\r\n" + 
	    			"  }\r\n" + 
	    			"}";
	    	String cartId="CYmiiQRjPVc2gJUc5r7IsBmwegVIFO43";
	    	retriever.setQuery(sampleQuery);
	    	mockClient.execute(sampleQuery);
	        mockClient.executeMutation(sampleQuery);
	    	retriever.createEmptyCart(cartId);
	    	}
	    
	    @Test
	    public void addConfigurableProductsToCartTest() {
	    	String typeName = "ConfigurableProduct";                              
			String cartId = "CYmiiQRjPVc2gJUc5r7IsBmwegVIFO43";                                 
			List<ConfigurableProductCartItemInput> cartItems = new ArrayList<>();
			CartItemInput data = new CartItemInput(12, "ABC");
			ConfigurableProductCartItemInput configurableitems=new ConfigurableProductCartItemInput(data);
			cartItems.add(configurableitems);
			String sampleQuery="";                                 
			retriever.setQuery(sampleQuery);
	        mockClient.executeMutation(sampleQuery);
//			retriever.addConfigurableProductsToCart(typeName, cartId, cartItems);
//			retriever.generateconfigurableaddtoCartArgsQuery(cartId, cartItems);
	    }
	   
	    @Test
	    public void addSimpleProductsToCartTest() {
	    	
			when(queryResponse.getAddSimpleProductsToCart()).thenReturn(addCartOutput);
	    	String typeName = "SimpleProduct";  							
			String cartId = "CYmiiQRjPVc2gJUc5r7IsBmwegVIFO43";    							
			List<SimpleProductCartItemInput> cartItems = new ArrayList<>();   
			CartItemInput data = new CartItemInput(12, "50-85510");
			SimpleProductCartItemInput items = new SimpleProductCartItemInput(data );
			cartItems.add(items );
			String sampleQuery="";   								
			retriever.setQuery(sampleQuery);
	        mockClient.executeMutation(sampleQuery);
//			retriever.addSimpleProductsToCart(typeName, cartId, cartItems);
//			retriever.generateaddtoCartArgsQuery(cartId, cartItems);
//			retriever.generateCartArgsQuery(cartId);
			
	    }
	    
	    @Test
	    public void populateTest() {
	    	String typeName = "SimpleProduct";  							
			String cartId = "CYmiiQRjPVc2gJUc5r7IsBmwegVIFO43";    							
			List<SimpleProductCartItemInput> cartItems = null;   
			String sampleQuery="";
			mockClient.executeMutation(sampleQuery);
	    	retriever.populate();
	    }
	  
}

