package com.brunswick.ecomm.merclink.core.models.internal.product;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class VariantValueImplTest {
	  VariantValueImpl fixture;
	  String test;
	  Integer value;

	@BeforeEach
	void setUp() throws Exception {
		fixture = new VariantValueImpl();
	}

	@Test
	void testGetLabel() {
		test="123";
		fixture.setLabel(test);
		assertEquals(test,fixture.getLabel());
		
	}
	
	@Test
	void testGetId() {
		value=12345;
		fixture.setId(value);
		assertEquals(value,fixture.getId());
		
	}

	
}
