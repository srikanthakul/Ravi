package com.brunswick.ecomm.merclink.core.models.internal.productlist;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.AddConfigurableProductsToCartOutput;
import com.adobe.cq.commerce.magento.graphql.CartItemInput;
import com.adobe.cq.commerce.magento.graphql.ConfigurableProductCartItemInput;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.SimpleProductCartItemInput;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

public class CartRetrieverTest {
		 private CartRetriever retriever;
		    private  MagentoGraphqlClient mockClient;
		    Customer customer;
			AddConfigurableProductsToCartOutput mockCartOutput;
		    GraphqlResponse<Mutation, Error> response= mock(GraphqlResponse.class);
		    Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
		    Mutation mutation= mock(Mutation.class);
		    Mutation queryResponse  = mock(Mutation.class);;
		    @BeforeEach
		    public void setUp() {
		         mockClient = mock(MagentoGraphqlClient.class);
		         GraphqlResponse mockResponse = mock(GraphqlResponse.class);
			        when(mockClient.execute(any())).thenReturn(mockResponse);
			        when(mockClient.executeMutation(any())).thenReturn(response);
			        when(response.getData()).thenReturn(mutation);
			        when(mockResponse.getData()).thenReturn(queryResponse);
			        when(queryResponse.getAddConfigurableProductsToCart()).thenReturn(mockCartOutput);
			        when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());
			        when(mockQuery.getCart().getItems()).thenReturn(Collections.EMPTY_LIST);
			        retriever = new CartRetriever(mockClient);
			        when(retriever.executeMutation()).thenReturn(mockResponse);
		       

		        retriever = new CartRetriever(mockClient);
		    }
		    
		    
		@Test
		public void generateaddtoCartArgsQueryTest() {
			String typeName = "ConfigurableProduct";
			String cartId = "CYmiiQRjPVc2gJUc5r7IsBmwegVIFO43";
			List<SimpleProductCartItemInput> cartItems = new ArrayList<SimpleProductCartItemInput>();
			CartItemInput data = new CartItemInput(1, "DEL0334670006");
			SimpleProductCartItemInput items = new SimpleProductCartItemInput(data);
			cartItems.add(items );
			retriever.generateaddtoCartArgsQuery(cartId, cartItems);
		}
		
		
		@Test
		public void createEmptyCartTest() {
			String sampleQuery="{\r\n" + 
	    			"  customerCart{\r\n" + 
	    			"    id\r\n" + 
	    			"  }\r\n" + 
	    			"}";
	    	String cartId="CYmiiQRjPVc2gJUc5r7IsBmwegVIFO43";
	    	retriever.setQuery(sampleQuery);
	    	mockClient.execute(sampleQuery);
	        mockClient.executeMutation(sampleQuery);
	    	retriever.createEmptyCart(cartId);
		}
		
		@Test
		public void generateconfigurableaddtoCartArgsQueryTest() {
			String cartId="CYmiiQRjPVc2gJUc5r7IsBmwegVIFO43";
			List<ConfigurableProductCartItemInput> cartItems = new ArrayList<>();
			CartItemInput data = new CartItemInput(12, "DEL0334670006");
			ConfigurableProductCartItemInput items=new ConfigurableProductCartItemInput(data );
			cartItems.add(items);
			
			retriever.generateconfigurableaddtoCartArgsQuery(cartId, cartItems);
		}

		@Test
		public void populateTest() {
	        String sampleQuery = "query {\r\n" + 
	        		"  cart(cart_id: \"v7jYJUjvPeHbdMJRcOfZIeQhs2Xc2ZKT\"){\r\n" + 
	        		"    items {\r\n" + 
	        		"      uid\r\n" + 
	        		"      quantity\r\n" + 
	        		"      product{\r\n" + 
	        		"        name\r\n" + 
	        		"        sku\r\n" + 
	        		"        price_tiers {\r\n" + 
	        		"          quantity\r\n" + 
	        		"          final_price {\r\n" + 
	        		"            value\r\n" + 
	        		"          }\r\n" + 
	        		"          discount {\r\n" + 
	        		"            amount_off\r\n" + 
	        		"            percent_off\r\n" + 
	        		"          }\r\n" + 
	        		"        }\r\n" + 
	        		"      }\r\n" + 
	        		"      prices{\r\n" + 
	        		"        price{\r\n" + 
	        		"          value\r\n" + 
	        		"        }\r\n" + 
	        		"      }\r\n" + 
	        		"    }\r\n" + 
	        		"    prices {\r\n" + 
	        		"      discounts {\r\n" + 
	        		"        label\r\n" + 
	        		"        amount {\r\n" + 
	        		"          value\r\n" + 
	        		"        }\r\n" + 
	        		"      }\r\n" + 
	        		"      subtotal_excluding_tax {\r\n" + 
	        		"        value\r\n" + 
	        		"      }\r\n" + 
	        		"      applied_taxes {\r\n" + 
	        		"        label\r\n" + 
	        		"        amount {\r\n" + 
	        		"          value\r\n" + 
	        		"        }\r\n" + 
	        		"      }\r\n" + 
	        		"    }\r\n" + 
	        		"  }\r\n" + 
	        		"}\r\n" + 
	        		"";
	        retriever.setQuery(sampleQuery);
	        mockClient.execute(sampleQuery);
	        retriever.populate();
		}
		@Test
		public void generateCartArgsQueryTest() {
			String cartId="v7jYJUjvPeHbdMJRcOfZIeQhs2Xc2ZKT";
			retriever.generateCartArgsQuery(cartId);
		}


}

