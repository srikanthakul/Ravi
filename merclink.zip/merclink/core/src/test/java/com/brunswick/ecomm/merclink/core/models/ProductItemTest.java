package com.brunswick.ecomm.merclink.core.models;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ProductItemTest {
	ProductItem fixture;
	String expData;

	@BeforeEach
	void setUpBeforeClass() {
		fixture = new ProductItem();
	}

	@Test
	void testSetItemId() {
		expData = "itemId";
		fixture.setItemId(expData);
		assertEquals(expData, fixture.getItemId());
	}

	@Test
	void testSetSku() {
		expData = "Sku";
		fixture.setSku(expData);
		assertEquals(expData, fixture.getSku());
	}

	@Test
	void testSetName() {
		expData = "Name";
		fixture.setName(expData);
		assertEquals(expData, fixture.getName());
	}

	@Test
	void testSetQuantity() {
		expData = "Quantity";
		fixture.setQuantity(expData);
		assertEquals(expData, fixture.getQuantity());
	}

	@Test
	void testSetImageUrl() {
		expData = "ImageUrl";
		fixture.setImageUrl(expData);
		assertEquals(expData, fixture.getImageUrl());
	}

	@Test
	void testSetBuyPrice() {
		expData = "BuyPrice";
		fixture.setBuyPrice(expData);
		assertEquals(expData, fixture.getBuyPrice());
	}

	@Test
	void testSetListPrice() {
		expData = "ListPrice";
		fixture.setListPrice(expData);
		assertEquals(expData, fixture.getListPrice());
	}

	@Test
	void testSetSymbol() {
		expData = "Symbol";
		fixture.setSymbol(expData);
		assertEquals(expData, fixture.getSymbol());
	}

	@Test
	void testSetAvailability() {
		expData = "Availability";
		fixture.setAvailability(expData);
		assertEquals(expData, fixture.getAvailability());
	}

	@Test
	void testSetProp65() {
		expData = "Prop65";
		fixture.setProp65(expData);
		assertEquals(expData, fixture.getProp65());
	}

	@Test
	void testSetAvailableDate() {
		expData = "AvailableDate";
		fixture.setAvailableDate(expData);
		assertEquals(expData, fixture.getAvailableDate());
	}

	@Test
	void testSetHazardousCode() {
		expData = "HazardousCode";
		fixture.setHazardousCode(expData);
		assertEquals(expData, fixture.getHazardousCode());
	}

}
