package com.brunswick.ecomm.merclink.core.models;

import org.apache.sling.api.resource.Resource;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.junit.Assert;

import io.wcm.testing.mock.aem.junit.AemContext;

public class HomePageHeaderModelTest {	
	@Rule
	public final AemContext context = new AemContext();
	private static final Logger LOG = LoggerFactory.getLogger(HomePageHeaderModelTest.class);
	
	@Before
	public void setup() throws Exception {
		context.addModelsForPackage("com.brunswick.ecomm.decity.core.models");
		context.addModelsForClasses(MultifieldModel.class);
		context.load().json("/context/jcr-homepage-header-model.json", "/content");
	}

	@Test
	public void testGetMultilanguage() {
		Resource resource = context.resourceResolver().getResource("/content/jcr:content/root/header/topnav");
		try {	   
	    HomePageHeaderModel homePageHeader = resource.adaptTo(HomePageHeaderModel.class);
	   System.out.println( homePageHeader.getMultilanguage()); }
		catch (NullPointerException e) {
			LOG.error("NullPointerException inside the populate {}", e.getMessage());
		}
	   Assert.assertNotNull(resource);
	}

	@Test
	public void testGetLoginmultitopnav() {		
	    Resource resource = context.resourceResolver().getResource("/content/jcr:content/root/header/topnav");
	    try {
	    HomePageHeaderModel homePageHeader = resource.adaptTo(HomePageHeaderModel.class);
	    homePageHeader.getLoginmultitopnav();
	    }
		catch (NullPointerException e) {
			LOG.error("NullPointerException inside the populate {}", e.getMessage());
		}
	    Assert.assertNotNull(resource);
	}

	@Test
	public void testGetMultitopnav() {
	    Resource resource = context.resourceResolver().getResource("/content/jcr:content/root/header/topnav");
	    try {
	    HomePageHeaderModel homePageHeader = resource.adaptTo(HomePageHeaderModel.class);
	    homePageHeader.getMultitopnav();
	    }
	    catch (NullPointerException e) {
			LOG.error("NullPointerException inside the populate {}", e.getMessage());
	}
	    Assert.assertNotNull(resource);
	    
	}
}
