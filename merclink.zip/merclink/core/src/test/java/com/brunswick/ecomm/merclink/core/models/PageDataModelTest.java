package com.brunswick.ecomm.merclink.core.models;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.brunswick.ecomm.core.beans.common.NewRelicDataBean;
import com.brunswick.ecomm.core.services.EcommNewRelic;
import com.brunswick.ecomm.merclink.core.beans.MetaDataBean;

class PageDataModelTest {
	
	@Mock
	PageDataModel pageDataModel;
	
	@Mock
	EcommNewRelic ecommNewRelicService;
	
	@Mock
	MetaDataBean metaDataBean;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		
	}

	@Test
	void testGetMetaDataBean() {
		when(pageDataModel.getMetaDataBean()).thenReturn(metaDataBean);
		assertNotNull(pageDataModel.getMetaDataBean());
	}

	@Test
	void testGetCurrentPagePath() {
		when(pageDataModel.getCurrentPagePath()).thenReturn("path");
		assertEquals("path", pageDataModel.getCurrentPagePath());
	}

	@Test
	void testGetPageTitle() {
		when(pageDataModel.getPageTitle()).thenReturn("title");
		assertEquals("title", pageDataModel.getPageTitle());
	}

	@Test
	void testGetNewRelic() {
		NewRelicDataBean newRelicData = mock(NewRelicDataBean.class);
		pageDataModel.setNewRelic(newRelicData);
		when(pageDataModel.getNewRelic()).thenReturn(newRelicData);
		assertNotNull(pageDataModel.getNewRelic());
	}

}
