package com.brunswick.ecomm.merclink.core.models;

import static org.junit.jupiter.api.Assertions.assertEquals;


import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
public class ProductListResponseTest {
	ProductListResponse fixture;
	@BeforeEach
	public void setup() {
		fixture = new ProductListResponse();
	}

	
	@Test
	public void getFacetListTest() {
		List<FacetObj> expecteddata = new ArrayList<FacetObj>();
		FacetObj data = new FacetObj();
		expecteddata.add(data );
		fixture.setFacetList(expecteddata);
		assertEquals(expecteddata,fixture.getFacetList());
	}
	@Test
	public void getprodListTest() {
		List<ProductItem> expecteddata = new ArrayList<ProductItem>();
		ProductItem data = new ProductItem();
		expecteddata.add(data );
		fixture.setProdList(expecteddata);
		assertEquals(expecteddata,fixture.getProdList());
	}
}