package com.brunswick.ecomm.merclink.core.models.impl;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith(AemContextExtension.class)
class CustomBreadcrumbImplTest {

	public AemContext context = new AemContext();
	public final String path = "/content/ecommerce/merclink/nz/en/home/news/jcr:content/root/container/container/cstmbreadcrumb/";
	
	@BeforeEach
	void setUp() throws Exception {
		context.addModelsForPackage("com.brunswick.ecomm.merclink.core.models.impl");
		context.addModelsForClasses(CustomBreadcrumbImpl.class);
		context.load().json("/context/customBreadCrumb.json", path);
	}

	@Test
	void testGetNavDetails() {
		Resource resource = context.resourceResolver().getResource(path +"/navItemList");
		assertNotNull(resource);
		CustomBreadcrumbImpl cstmBreadCrumb = resource.adaptTo(CustomBreadcrumbImpl.class);
		List<Map<String, String>> navDetails=new ArrayList<>();
		Resource navDetail = resource.getChild("navItemList");
		if(navDetail!=null){
            for (Resource nav : navDetail.getChildren()) {
                Map<String,String> navMap=new HashMap<>();
                navMap.put("pagelabel",nav.getValueMap().get("pagelabel",String.class));
                navMap.put("pagelink",nav.getValueMap().get("pagelink",String.class));
                navDetails.add(navMap);
            }
            assertNotNull(navDetails);
        }
		
		assertNotNull(cstmBreadCrumb.getNavDetails());
		
	}

}
