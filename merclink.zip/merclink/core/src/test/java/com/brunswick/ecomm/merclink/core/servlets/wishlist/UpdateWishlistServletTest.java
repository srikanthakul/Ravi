package com.brunswick.ecomm.merclink.core.servlets.wishlist;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.apache.http.client.HttpClient;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.scripting.SlingBindings;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.caconfig.ConfigurationBuilder;
import org.apache.sling.servlethelpers.MockRequestPathInfo;
import org.apache.sling.servlethelpers.MockSlingHttpServletRequest;
import org.apache.sling.servlethelpers.MockSlingHttpServletResponse;
import org.apache.sling.servlets.post.JSONResponse;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.assertj.core.internal.bytebuddy.description.modifier.Visibility;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;

import com.adobe.cq.commerce.core.components.internal.services.UrlProviderImpl;
import com.adobe.cq.commerce.core.components.services.ComponentsConfiguration;
import com.adobe.cq.commerce.core.components.services.urls.UrlProvider;
import com.adobe.cq.commerce.graphql.client.GraphqlClient;
import com.adobe.cq.commerce.graphql.client.GraphqlClientConfiguration;
import com.adobe.cq.commerce.graphql.client.HttpMethod;
import com.adobe.cq.commerce.graphql.client.impl.GraphqlClientImpl;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.UpdateWishlistOutput;
import com.adobe.cq.commerce.magento.graphql.WishlistVisibilityEnum;
import com.adobe.cq.commerce.magento.graphql.gson.MutationDeserializer;
import com.brunswick.ecomm.merclink.core.components.testing.MockExternalizer;
import com.brunswick.ecomm.merclink.core.components.testing.Utils;
import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.scripting.WCMBindingsConstants;
//import com.google.common.base.Function;
import com.google.common.collect.ImmutableMap;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

public class UpdateWishlistServletTest {
	@Rule
	public final AemContext context = createContext("/context/jcr-content-wishlist.json");

	private static final ValueMap MOCK_CONFIGURATION = new ValueMapDecorator(
			ImmutableMap.of("cq:graphqlClient", "default", "magentoStore", "my-store"));

	private static final ComponentsConfiguration MOCK_CONFIGURATION_OBJECT = new ComponentsConfiguration(
			MOCK_CONFIGURATION);

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");

			UrlProviderImpl urlProvider = new UrlProviderImpl();
			//urlProvider.activate(new MockUrlProviderConfiguration());
			context.registerService(UrlProvider.class, urlProvider);

			context.registerAdapter(Resource.class, ComponentsConfiguration.class,
					(Function<Resource, ComponentsConfiguration>) input -> !input.getPath().contains("pageB")
							? MOCK_CONFIGURATION_OBJECT
							: ComponentsConfiguration.EMPTY);

			context.registerService(Externalizer.class, new MockExternalizer());

			ConfigurationBuilder mockConfigBuilder = Utils.getDataLayerConfig(true);
			context.registerAdapter(Resource.class, ConfigurationBuilder.class, mockConfigBuilder);
		}, ResourceResolverType.JCR_MOCK);
	}

	public UpdateWishlistServlet updateWishlistServlet;
	private MockSlingHttpServletRequest request;
	private MockSlingHttpServletResponse response;
	private static final String PAGE = "/content/pageA";
	private static final String WISHLIST_RES = "/content/pageA/jcr:content/root/responsivegrid_1/mywishlists";
	private Resource pageResource;
	private Resource productResource;
	private JSONObject jsonResponse;
	private GraphqlClientImpl graphqlClient;
	private HttpClient httpClient;
	private String customerToken;

	@Before
	public void setUp() throws Exception {
		updateWishlistServlet = new UpdateWishlistServlet();
		updateWishlistServlet.init();
		prepareModel(WISHLIST_RES, PAGE);
	}

	@Test
	public void testDoPost() throws IOException {

		request = context.request();
		response = context.response();
		String data = "{ \"wishlistId\": 169, \"wishlistName\": \"mywishlist\",\"visibility\": \"PUBLIC\",\"resourcePath\": \"/content/pageA\",\"token\": \"r7ccftt50cguuu55wgvny13dxzlm5bum\" }";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		request.setParameterMap(params);
		request.setHeader("Authorization", "Bearer " + customerToken);
		try {
		    if(updateWishlistServlet != null) {
		        updateWishlistServlet.doPost(request, response);
		        return;
		    }
		}catch(NullPointerException e) {
		   e.getMessage();
		    
		}
        /*
         * try {
         * if (updateWishlistServlet != null) {
         * updateWishlistServlet.doPost(request, response);
         * return;           
         * }       
         * }
         * catch (NullPointerException e)
         * {
         * LOG.error("NullPointerException inside the GetId() {}", e.getMessage());
         * }
         */
		String op= response.getOutputAsString();
//
		Assert.assertEquals(op, jsonResponse.toString());

	}

	private void prepareModel(String resourcePath, String currentPage) throws IOException, JSONException {
		Page page = Mockito.spy(context.currentPage(currentPage));
		pageResource = Mockito.spy(page.adaptTo(Resource.class));
		when(page.adaptTo(Resource.class)).thenReturn(pageResource);

		httpClient = mock(HttpClient.class);

		context.currentResource(resourcePath);
		productResource = Mockito.spy(context.resourceResolver().getResource(resourcePath));

		/*
		 * Mutation rootQuery =
		 * Utils.getMutationFromResource("graphql/magento-graphql-customer-token.json");
		 * customerToken = rootQuery.getGenerateCustomerToken().getToken();
		 */
		

		Mutation rootMutation = Utils.getMutationFromResource("graphql/magento-graphql-updatewishlist-result.json");
		jsonResponse=new JSONObject();
		jsonResponse.put("wishlistName", rootMutation.getUpdateWishlist().getName());
		jsonResponse.put("visibility", rootMutation.getUpdateWishlist().getVisibility());
		GraphqlClientConfiguration graphqlClientConfiguration = mock(GraphqlClientConfiguration.class);
		when(graphqlClientConfiguration.httpMethod()).thenReturn(HttpMethod.POST);

		graphqlClient = Mockito.spy(new GraphqlClientImpl());
		try {
            graphqlClient.activate(graphqlClientConfiguration);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
		Whitebox.setInternalState(graphqlClient, "gson", MutationDeserializer.getGson());
		Whitebox.setInternalState(graphqlClient, "client", httpClient);
		//Whitebox.setInternalState(graphqlClient, "configuration", graphqlClientConfiguration);

		// Utils.setupHttpResponse("graphql/magento-graphql-customer-token.json",
		// httpClient, 200);
		Utils.setupHttpResponse("graphql/magento-graphql-updatewishlist-result.json", httpClient, 200);

		context.registerAdapter(Resource.class, GraphqlClient.class, (Function<Resource, GraphqlClient>) input -> input
				.getValueMap().get("cq:graphqlClient", String.class) != null ? graphqlClient : null);

		MockRequestPathInfo requestPathInfo = (MockRequestPathInfo) context.request().getRequestPathInfo();
		requestPathInfo.setSelectorString("beaumont-summit-kit");
		context.request().setServletPath(PAGE + ".beaumont-summit-kit.html"); // used by
																				// context.request().getRequestURI();
		// This sets the page attribute injected in the models with @Inject or
		// @ScriptVariable
		SlingBindings slingBindings = (SlingBindings) context.request().getAttribute(SlingBindings.class.getName());
		slingBindings.setResource(productResource);
		slingBindings.put(WCMBindingsConstants.NAME_CURRENT_PAGE, page);
		slingBindings.put(WCMBindingsConstants.NAME_PROPERTIES, productResource.getValueMap());
	}
}
