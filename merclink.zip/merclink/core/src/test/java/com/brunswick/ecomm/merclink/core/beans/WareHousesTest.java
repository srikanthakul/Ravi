package com.brunswick.ecomm.merclink.core.beans;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class WareHousesTest {
	WareHouses fixture;

	@BeforeEach
	 void setUpBeforeClass()  {
		fixture = new WareHouses();
	}

	@Test
	void testGetQuantity() {
		int expdata = 12;
		fixture.setQuantity(expdata);
		assertEquals(expdata, fixture.getQuantity());
	}

	@Test
	void testGetWarehouse() {
		WareHouse expdata = new WareHouse();
		//expdata.setName("name");
		fixture.setWarehouse(expdata);
		assertEquals(expdata, fixture.getWarehouse());
	}

}
