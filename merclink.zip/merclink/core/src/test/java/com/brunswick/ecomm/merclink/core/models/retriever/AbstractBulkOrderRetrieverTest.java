package com.brunswick.ecomm.merclink.core.models.retriever;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

public class AbstractBulkOrderRetrieverTest {
	private AbstractBulkOrderRetriever retriever;
	private MagentoGraphqlClient mockClient;
	Customer customer;
	private static final Logger LOG = LoggerFactory.getLogger(AbstractBulkOrderRetriever.class);
	GraphqlResponse<Mutation, Error> response = mock(GraphqlResponse.class);
	Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	Mutation mutation = mock(Mutation.class);

	
	@BeforeEach
	public void setUp() {
		mockClient = mock(MagentoGraphqlClient.class);

		GraphqlResponse mockResponse = mock(GraphqlResponse.class);
		when(mockClient.execute(any())).thenReturn(mockResponse);
		when(response.getData()).thenReturn(mutation);
		when(mockResponse.getData()).thenReturn(mockQuery);
		when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());

		retriever = new AbstractBulkOrderRetriever(mockClient);
	}

	@Test
    public void generatecreateBulkCartQuery(){
    	String sampleQuery="{\r\n" + 
    			"customerCart{\r\n" + 
    			"id {\r\n" + 
    			"erp_errors{\r\n" + 
    			"message\r\n" + 
    			"code\r\n" + 
    			"}\r\n" + 
    			"}\r\n" + 
    			"}";
    	try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				
				//mockClient.execute(sampleQuery);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the AbstractBulkOrderRetrieverTest {}", e.getMessage());
		}
    	try {
			if (retriever != null) {
				retriever.createBulkCart(null);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the AbstractBulkOrderRetrieverTest {}", e.getMessage());
		}
	}


    	@Test
        public void generateplaceBulkOrderSingleItemQuery(){
        	String sampleQuery="mutation\r\n" + 
        			"{{\r\n" + 
        			"placeBulkOrder( \r\n" + 
        			"input:{{\r\n" + 
        			"cart_id\r\n" + 
        			"po_number\r\n" + 
        			"order_comment\r\n" + 
        			"requested_ship_date\r\n" + 
        			"payment_method\r\n" + 
        			"shipping_method\r\n" +
        			"shipping_cost\r\n" + 
        			"attribute19\r\n" + 
        			"items_data\r\n" + 
        			"}\r\n" + 
        			")\r\n" + 
        			"status\r\n" + 
        			"message\r\n" + 
        			"data{\r\n" + 
        			"order_numer\r\n" + 
        			"created\r\n" + 
        			"}\r\n" + 
        			"errors{\r\n" + 
        			"message{\r\n" +
        			"}\r\n" + 
        			"}\r\n" + 
        			"}";
        	try {
    			if (retriever != null) {
    				retriever.setQuery(sampleQuery);
    				mockClient.execute(sampleQuery);
    				//retriever.placeBulkOrderSingleItem(sampleQuery, sampleQuery, sampleQuery, sampleQuery, sampleQuery, sampleQuery, sampleQuery, sampleQuery, sampleQuery, sampleQuery);
    				//mockClient.execute(sampleQuery);
    				return;
    			}
    		} catch (NullPointerException e) {
    			LOG.error("NullPointerException inside the generateplaceBulkOrderSingleItemQuery {}");
    		}
        	try {
    			if (retriever != null) {
    				retriever.placeBulkOrderSingleItem(sampleQuery, sampleQuery, sampleQuery, sampleQuery, sampleQuery, sampleQuery, sampleQuery, sampleQuery, sampleQuery, sampleQuery);
    				return;
    			}
    		} catch (NullPointerException e) {
    			LOG.error("NullPointerException inside the generateplaceBulkOrderSingleItemQuery {}", e.getMessage());
    		}
}
}
