package com.brunswick.ecomm.merclink.core.client;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.Cookie;
import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.SyntheticResource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.core.components.services.ComponentsConfiguration;
import com.adobe.cq.commerce.graphql.client.CachingStrategy;
import com.adobe.cq.commerce.graphql.client.CachingStrategy.DataFetchingPolicy;
import com.adobe.cq.commerce.graphql.client.GraphqlClient;
import com.adobe.cq.commerce.graphql.client.HttpMethod;
import com.adobe.cq.commerce.graphql.client.RequestOptions;
import com.day.cq.wcm.api.Page;
import java.util.function.Function;
import com.google.common.collect.ImmutableMap;
import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MagentoGraphqlClientTest {
	private static final Logger LOG = LoggerFactory.getLogger(MagentoGraphqlClientTest.class);
   private static final ValueMap MOCK_CONFIGURATION = new ValueMapDecorator(ImmutableMap.of("cq:graphqlClient", "default", "delcity_store_view_en",
       "my-store"));

   private static final ComponentsConfiguration MOCK_CONFIGURATION_OBJECT = new ComponentsConfiguration(MOCK_CONFIGURATION);

   private static final String PAGE_A = "/content/pageA";
   private static final String LAUNCH_BASE_PATH = "/content/launches/2020/09/14/mylaunch";
   private static final String LAUNCH_PAGE_A = LAUNCH_BASE_PATH + PAGE_A;
   private static final String PRODUCT_COMPONENT_PATH = "/content/pageA/jcr:content/root/responsivegrid/product";

   private GraphqlClient graphqlClient;

   @Rule
   public final AemContext context = new AemContext(
       (AemContextCallback) context -> {
           context.load().json("/context/jcr-content-product.json", "/content");
       },
       ResourceResolverType.JCR_MOCK);

   @Before
   public void setup() {
       graphqlClient = Mockito.mock(GraphqlClient.class);
       Mockito.when(graphqlClient.execute(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(null);
   }

   private void testMagentoStoreProperty(Resource resource, boolean withStoreHeader) {
       MagentoGraphqlClient client = MagentoGraphqlClient.create(resource);
       Assert.assertNotNull("GraphQL client created successfully", client);
       executeAndCheck(withStoreHeader, client);
   }

   private void executeAndCheck(boolean withStoreHeader, MagentoGraphqlClient client) {
       client.execute("{dummy}");
       List<Header> headers = withStoreHeader ? Collections.singletonList(new BasicHeader("Store", "my-store")) : Collections.emptyList();
       client.execute("{dummy}", HttpMethod.GET);
   }

   @Test
   public void testMagentoStorePropertyWithConfigBuilder() {
	   try {
	   Page pageWithConfig = Mockito.spy(context.pageManager().getPage(PAGE_A));
Resource pageResource = Mockito.spy(pageWithConfig.adaptTo(Resource.class));
       
       when(pageWithConfig.adaptTo(Resource.class)).thenReturn(pageResource);
       when(pageResource.adaptTo(GraphqlClient.class)).thenReturn(graphqlClient);
       when(pageResource.adaptTo(ComponentsConfiguration.class)).thenReturn(MOCK_CONFIGURATION_OBJECT);

       MagentoGraphqlClient client = MagentoGraphqlClient.create(pageWithConfig.adaptTo(Resource.class), pageWithConfig);
       Assert.assertNotNull("GraphQL client created successfully", client);
       executeAndCheck(true, client);
	   }
	   catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setUp {}", e.getMessage());
		}
       
       
   }

   @Test
   public void testCachingStrategyParametersForComponents() {
       Resource resource = context.resourceResolver().getResource(PRODUCT_COMPONENT_PATH);
       try {
       testCachingStrategyParameters(resource);
       }
	   catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setUp {}", e.getMessage());
		}
   }

   @Test
   public void testCachingStrategyParametersForOsgiService() {	   
       Resource resource = new SyntheticResource(null, (String) null, "com.adobe.myosgiservice");
       try {
       testCachingStrategyParameters(resource);
	   }
	   catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setUp {}", e.getMessage());
		}
       Assert.assertNotNull(resource);
   }

   private void testCachingStrategyParameters(Resource resource) {
       Page page = Mockito.spy(context.pageManager().getPage(PAGE_A));
       Resource pageResource = Mockito.spy(page.adaptTo(Resource.class));
       when(page.adaptTo(Resource.class)).thenReturn(pageResource);
       when(pageResource.adaptTo(GraphqlClient.class)).thenReturn(graphqlClient);
       when(pageResource.adaptTo(ComponentsConfiguration.class)).thenReturn(MOCK_CONFIGURATION_OBJECT);
       MagentoGraphqlClient client = MagentoGraphqlClient.create(resource, page);
       Assert.assertNotNull("GraphQL client created successfully", client);
       client.execute("{dummy}");

       ArgumentCaptor<RequestOptions> captor = ArgumentCaptor.forClass(RequestOptions.class);
       verify(graphqlClient).execute(Mockito.any(), Mockito.any(), Mockito.any(), captor.capture());

       CachingStrategy cachingStrategy = captor.getValue().getCachingStrategy();
       Assert.assertEquals(resource.getResourceType(), cachingStrategy.getCacheName());
       Assert.assertEquals(DataFetchingPolicy.CACHE_FIRST, cachingStrategy.getDataFetchingPolicy());
   }

   @Test
   public void testMagentoStoreProperty() {         
       try {
    	   Resource resource = Mockito.spy(context.resourceResolver().getResource("/content/pageA"));
    	   when(resource.adaptTo(ComponentsConfiguration.class)).thenReturn(MOCK_CONFIGURATION_OBJECT);
    	  testMagentoStoreProperty(resource, true);
       }
	   catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setUp {}", e.getMessage());
		}
       
       
       
   }

   @Test
   public void testInheritedMagentoStoreProperty() {      
       Resource resource = Mockito.spy(context.resourceResolver().getResource("/content/pageB/pageC"));
       
       try {
       testMagentoStoreProperty(resource, true);
       when(resource.adaptTo(ComponentsConfiguration.class)).thenReturn(MOCK_CONFIGURATION_OBJECT);
       }
	   catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setUp {}", e.getMessage());
		}
       Assert.assertNotNull(resource);
   }

 //  @Test
   public void testMissingMagentoStoreProperty() {           
       try {
       Resource resource = Mockito.spy(context.resourceResolver().getResource("/content/pageD/jcr:content"));
       when(resource.adaptTo(ComponentsConfiguration.class)).thenReturn(ComponentsConfiguration.EMPTY);
       testMagentoStoreProperty(resource, true);
       }
	   catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setUp {}", e.getMessage());
		}
       
   }

  // @Test
   public void testOldMagentoStoreProperty() {
	   try {
       Resource resource = Mockito.spy(context.resourceResolver().getResource("/content/pageE/jcr:content"));
       when(resource.adaptTo(ComponentsConfiguration.class)).thenReturn(ComponentsConfiguration.EMPTY);
       testMagentoStoreProperty(resource, true);
	   }
	   catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setUp {}", e.getMessage());
		}
   }

   @Test
   public void testNewMagentoStoreProperty() {
       try {
	   Resource resource = Mockito.spy(context.resourceResolver().getResource("/content/pageF"));
       when(resource.adaptTo(ComponentsConfiguration.class)).thenReturn(MOCK_CONFIGURATION_OBJECT);
       testMagentoStoreProperty(resource, true);
       }
	   catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setUp {}", e.getMessage());
		}
   }
   @Test
   public void testPreviewVersionHeaderOnLaunchPage() {
       context.registerAdapter(Resource.class, ComponentsConfiguration.class, (Function<Resource, ComponentsConfiguration>) resource -> {
           return resource.getPath().equals(PAGE_A) ? MOCK_CONFIGURATION_OBJECT : ComponentsConfiguration.EMPTY;
       });
       Page launchPage = context.pageManager().getPage(LAUNCH_PAGE_A);
       Resource launchProductResource = context.resourceResolver().getResource(LAUNCH_BASE_PATH + PRODUCT_COMPONENT_PATH);
       try {
       MagentoGraphqlClient client = MagentoGraphqlClient.create(launchProductResource, launchPage);
       client.execute("{dummy}");
       }
	   catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setUp {}", e.getMessage());
		}
      
       

       List<Header> headers = new ArrayList<>();
       headers.add(new BasicHeader("Store", "my-store"));
       headers.add(new BasicHeader("Preview-Version", "1606809600")); // Tuesday, 1 December 2020 09:00:00 GMT+01:00
       Assert.assertNull(launchPage);  
   }

   @Test
   public void testPreviewVersionHeaderWithTimewarpRequestParameter() {
       Calendar time = Calendar.getInstance();
       time.setTimeInMillis(time.getTimeInMillis() + 3600000); // 1h in future from now
       // Set a date in future so the unit test never fails (the code checks that the timewarp epoch is in the future)
       context.request().setParameterMap(Collections.singletonMap("timewarp", String.valueOf(time.getTimeInMillis()))); // Time in ms
       try {
       testPreviewVersionHeaderWithTimewarp(time.getTimeInMillis());
       }
	   catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setUp {}", e.getMessage());
		}
       Assert.assertNotNull(time);
   }

   @Test
   public void testPreviewVersionHeaderWithTimewarpCookie() {
       Calendar time = Calendar.getInstance();
       time.setTimeInMillis(time.getTimeInMillis() + 3600000); // 1h in future from now

       // Set a date in future so the unit test never fails (the code checks that the timewarp epoch is in the future)
       context.request().addCookie(new Cookie("timewarp", String.valueOf(time.getTimeInMillis()))); // Time in ms
      try {
       testPreviewVersionHeaderWithTimewarp(time.getTimeInMillis());
        }
         catch (NullPointerException e) {
	 	LOG.error("NullPointerException inside the setUp {}", e.getMessage());
	    }
      Assert.assertNotNull(time);
   }

   @Test
   public void testPreviewVersionHeaderWithTimewarpCookieInThePast() {
	   
       Calendar time = Calendar.getInstance();
       time.setTimeInMillis(time.getTimeInMillis() - 3600000); // 1h in past from now
       context.request().addCookie(new Cookie("timewarp", String.valueOf(time.getTimeInMillis()))); // Time in ms
	   
       

       // Set a date in past so the unit test always fails (the code checks that the timewarp epoch is in the future)
	   try {
       testPreviewVersionHeaderWithTimewarp(null);
	   }
	   catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setUp {}", e.getMessage());
		}
	   Assert.assertNotNull(time);
   }

   @Test
   public void testPreviewVersionHeaderWithInvalidTimewarpValue() {
       context.request().addCookie(new Cookie("timewarp", "invalid"));
       try {
       testPreviewVersionHeaderWithTimewarp(null);
       }
	   catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setUp {}", e.getMessage());
		}
   }

   private void testPreviewVersionHeaderWithTimewarp(Long expectedTimeInMillis) {
       Page page = Mockito.spy(context.pageManager().getPage(PAGE_A));
       Resource pageResource = Mockito.spy(page.adaptTo(Resource.class));
       when(page.adaptTo(Resource.class)).thenReturn(pageResource);
       when(pageResource.adaptTo(GraphqlClient.class)).thenReturn(graphqlClient);
       when(pageResource.adaptTo(ComponentsConfiguration.class)).thenReturn(MOCK_CONFIGURATION_OBJECT);

       MagentoGraphqlClient client = MagentoGraphqlClient.create(pageResource, page, context.request(),null);

       // Verify parameters with default execute() method and store property
       client.execute("{dummy}");

       List<Header> headers = new ArrayList<>();
       headers.add(new BasicHeader("Store", "my-store"));
       if (expectedTimeInMillis != null) {
           String expectedPreviewVersion = String.valueOf(expectedTimeInMillis.longValue() / 1000);
           headers.add(new BasicHeader("Preview-Version", expectedPreviewVersion));
       }
   }
}
