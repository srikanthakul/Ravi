package com.brunswick.ecomm.merclink.core.servlets;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.apache.http.client.HttpClient;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.scripting.SlingBindings;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.caconfig.ConfigurationBuilder;
import org.apache.sling.servlethelpers.MockRequestPathInfo;
import org.apache.sling.servlethelpers.MockSlingHttpServletRequest;
import org.apache.sling.servlethelpers.MockSlingHttpServletResponse;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.core.components.internal.services.UrlProviderImpl;
import com.adobe.cq.commerce.core.components.services.ComponentsConfiguration;
import com.adobe.cq.commerce.core.components.services.urls.UrlProvider;
import com.adobe.cq.commerce.graphql.client.GraphqlClient;
import com.adobe.cq.commerce.graphql.client.GraphqlClientConfiguration;
import com.adobe.cq.commerce.graphql.client.HttpMethod;
import com.adobe.cq.commerce.graphql.client.impl.GraphqlClientImpl;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.gson.MutationDeserializer;
import com.brunswick.ecomm.merclink.core.components.testing.MockExternalizer;
import com.brunswick.ecomm.merclink.core.components.testing.Utils;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractCategoryTreeRetriever;
import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.scripting.WCMBindingsConstants;
//import com.google.common.base.Function;
import com.google.common.collect.ImmutableMap;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

public class CategoryTreeTest {

	@Rule
	public final AemContext context = createContext("/context/categoryTree.json");

	private static final Logger LOG = LoggerFactory.getLogger(CategoryTree.class);

	private static final ValueMap MOCK_CONFIGURATION = new ValueMapDecorator(
			ImmutableMap.of("cq:graphqlClient", "default", "magentoStore", "my-store"));

	private static final ComponentsConfiguration MOCK_CONFIGURATION_OBJECT = new ComponentsConfiguration(
			MOCK_CONFIGURATION);

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");

			UrlProviderImpl urlProvider = new UrlProviderImpl();
			// urlProvider.activate(new MockUrlProviderConfiguration());
			context.registerService(UrlProvider.class, urlProvider);

			context.registerAdapter(Resource.class, ComponentsConfiguration.class,
					(Function) input -> !((Resource) input).getPath().contains("pageB") ? MOCK_CONFIGURATION_OBJECT
							: ComponentsConfiguration.EMPTY);

			context.registerService(Externalizer.class, new MockExternalizer());

			ConfigurationBuilder mockConfigBuilder = Utils.getDataLayerConfig(true);
			context.registerAdapter(Resource.class, ConfigurationBuilder.class, mockConfigBuilder);
		}, ResourceResolverType.JCR_MOCK);
	}

	private CategoryTree login;
	private MockSlingHttpServletRequest request;
	private MockSlingHttpServletResponse response;
	private static final String PAGE = "/content/";
	private static final String CATEGORY_TREE = "/content/";
	private Resource pageResource;
	private Resource productResource;
	private GraphqlClient graphqlClient;
	private HttpClient httpClient;
	private String customerToken;
	AbstractCategoryTreeRetriever abstractCategoryTree;

	@Before
	public void setUp() throws Exception {
		login = new CategoryTree();
		login.init();

		try {
			if (login != null) {
				prepareModel(CATEGORY_TREE, PAGE);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the CategoryTreeTest {}", e.getMessage());
		}
	}

	@Test
	public void testDoPost() throws IOException, RuntimeException {

		request = context.request();
		response = context.response();
		String data = "{ \"wishlistName\": \"mywishlist\",\"visibility\": \"PUBLIC\",\"resourcePath\": \"/content/pageA\",\"token\": \"r7ccftt50cguuu55wgvny13dxzlm5bum\" }";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		request.setParameterMap(params);
		request.setHeader("Authorization", "Bearer " + customerToken);
		login.doPost(request, response);
		String op = response.getOutputAsString();

		try {
			if (op != null) {

				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the CategoryTreeTest {}", e.getMessage());
		}
	}

	private void prepareModel(String resourcePath, String currentPage) throws IOException {
		Page page = Mockito.spy(context.currentPage(currentPage));
		pageResource = Mockito.spy(page.adaptTo(Resource.class));
		when(page.adaptTo(Resource.class)).thenReturn(pageResource);

		httpClient = mock(HttpClient.class);

		context.currentResource(resourcePath);
		productResource = Mockito.spy(context.resourceResolver().getResource(resourcePath));

		Mutation rootMutation = Utils.getMutationFromResource("graphql/magento-graphql-createwishlist-result.json");

		GraphqlClientConfiguration graphqlClientConfiguration = mock(GraphqlClientConfiguration.class);
		when(graphqlClientConfiguration.httpMethod()).thenReturn(HttpMethod.POST);

		graphqlClient = Mockito.spy(new GraphqlClientImpl());
		Whitebox.setInternalState(graphqlClient, "gson", MutationDeserializer.getGson());
		Whitebox.setInternalState(graphqlClient, "client", httpClient);
		Whitebox.setInternalState(graphqlClient, "configuration", graphqlClientConfiguration);

		Utils.setupHttpResponse("graphql/magento-graphql-createwishlist-result.json", httpClient, 200);

		context.registerAdapter(Resource.class, GraphqlClient.class, (Function<Resource, GraphqlClient>) input -> input
				.getValueMap().get("cq:graphqlClient", String.class) != null ? graphqlClient : null);

		MockRequestPathInfo requestPathInfo = (MockRequestPathInfo) context.request().getRequestPathInfo();
		requestPathInfo.setSelectorString("beaumont-summit-kit");
		context.request().setServletPath(PAGE + ".beaumont-summit-kit.html"); // used by
																				// context.request().getRequestURI();
		// This sets the page attribute injected in the models with @Inject or
		// @ScriptVariable
		SlingBindings slingBindings = (SlingBindings) context.request().getAttribute(SlingBindings.class.getName());
		slingBindings.setResource(productResource);
		slingBindings.put(WCMBindingsConstants.NAME_CURRENT_PAGE, page);
		slingBindings.put(WCMBindingsConstants.NAME_PROPERTIES, productResource.getValueMap());
	}
}
