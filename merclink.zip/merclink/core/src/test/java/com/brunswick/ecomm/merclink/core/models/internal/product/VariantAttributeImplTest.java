package com.brunswick.ecomm.merclink.core.models.internal.product;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


class VariantAttributeImplTest {
	VariantAttributeImpl fixture;
	String test;
	

	@BeforeEach
	void setUp() throws Exception {
		fixture=new VariantAttributeImpl();
	}

	@Test
	void testGetLabel() {
		test="word";
	    fixture.setLabel(test);
	    assertEquals(test,fixture.getLabel());
		
	}
	
	@Test
	void testGetId() {
		test ="word";
		fixture.setId(test);
		assertEquals(test,fixture.getId());
	}

	

}
