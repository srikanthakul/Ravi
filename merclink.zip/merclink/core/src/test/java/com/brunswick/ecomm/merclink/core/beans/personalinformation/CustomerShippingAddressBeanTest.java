package com.brunswick.ecomm.merclink.core.beans.personalinformation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CustomerShippingAddressBeanTest {

	CustomerShippingAddressBean fixture;
	Integer expData;
	String expdata;
	@BeforeEach
	 void setUpBeforeClass()  {
		fixture = new CustomerShippingAddressBean();
	}

	@Test
	void testGetRegion_code() {
		expdata = "region_code";
		fixture.setRegion_code(expdata);
		assertEquals(expdata, fixture.getRegion_code());
	}

	@Test
	void testGetFirstname() {
		expdata = "firstname";
		fixture.setFirstname(expdata);
		assertEquals(expdata, fixture.getFirstname());
	}

	@Test
	void testGetLastname() {
		expdata = "lastname";
		fixture.setLastname(expdata);
		assertEquals(expdata, fixture.getLastname());
	}

	//@Test
	//void testGetStreet() {
	//	fail("Not yet implemented");
	//}

	@Test
	void testGetCity() {
		expdata = "city";
		fixture.setCity(expdata);
		assertEquals(expdata, fixture.getCity());
	}

	@Test
	void testGetCountry_id() {
		expdata = "country_id";
		fixture.setCountry_id(expdata);
		assertEquals(expdata, fixture.getCountry_id());
	}

	@Test
	void testGetCountry_code() {
		expdata = "country_code";
		fixture.setCountry_code(expdata);
		assertEquals(expdata, fixture.getCountry_code());
	}

	@Test
	void testGetPostcode() {
		expdata = "postcode";
		fixture.setPostcode(expdata);
		assertEquals(expdata, fixture.getPostcode());
	}

	@Test
	void testGetPrimary_flag() {
		expdata = "primary_flag";
		fixture.setPrimary_flag(expdata);
		assertEquals(expdata, fixture.getPrimary_flag());
	}

	@Test
	void testGetId() {
		expData = 12;
		fixture.setId(expData);
		assertEquals(expData, fixture.getId());
	}

	@Test
	void testGetCustomer_id() {
		expData = 12;
		fixture.setCustomer_id(expData);
		assertEquals(expData, fixture.getCustomer_id());
	}

}
