package com.brunswick.ecomm.merclink.core.models.retriever;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

class CompanyRegistrationRetrieverTest {

	private CompanyRegistrationRetriever retriever;
	private MagentoGraphqlClient mockClient;
	Customer customer;
	private static final Logger LOG = LoggerFactory.getLogger(CompanyRegistrationRetriever.class);
	GraphqlResponse<Mutation, Error> response = mock(GraphqlResponse.class);
	Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	Mutation mutation = mock(Mutation.class);

	@BeforeEach
	public void setUp() {
		mockClient = mock(MagentoGraphqlClient.class);

		GraphqlResponse mockResponse = mock(GraphqlResponse.class);
		when(mockClient.execute(any())).thenReturn(mockResponse);
		when(response.getData()).thenReturn(mutation);
		when(mockResponse.getData()).thenReturn(mockQuery);
		when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());

		retriever = new CompanyRegistrationRetriever(mockClient);
	}
	
	@Test
    public void createCompany(){
    	String sampleQuery="mutation {createCompany(input: {\r\n" + 
    			"company_name:\r\n" + 
    			"company_email:\r\n" + 
    			"company_admin:\r\n" + 
    			"firstname:\r\n" + 
    			"lastname:\r\n" + 
    			"} telephone:\r\n" + 
    			"customer_type:\r\n" + 
    			"billing_address:\r\n" + 
    			"lastname:\r\n" + 
    			"city:\r\n" + 
    			"region:\r\n" + 
    			"region_code:\r\n" + 
    			"} country_code:\r\n" + 
    			"street:\r\n" + 
    			"postcode:\r\n" + 
    			"address_type:\r\n" + 
    			"firstname:\r\n" + 
    			"lastname:r\n" + 
    			"region:\r\n" + 
    			"region_code:\r\n" + 
    			"} country_code:\r\n" + 
    			"address_type\r\n"+
    			"street:\r\n" + 
    			"postcode:\r\n" +
    			"primary_flag:\r\n" + 
    			"city:\r\n" + 
    			"legal_name:\r\n" + 
    			"legal_address: {\r\n" + 
    			"city:\r\n" + 
    			"region:\r\n" + 
    			"postcode:\r\n" + 
    			"telephone: \r\n" + 
    			"country_id:\r\n" +
    			"primary_flag:\\\"Y\\\"}}){ company { id name company_admin { email firstname lastname } }}}";
    	try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the CompanyRegistrationRetrieverTest {}", e.getMessage());
		}
    	try {
			if (retriever != null) {
				retriever.createCompany(null);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the CompanyRegistrationRetrieverTest {}", e.getMessage());
		}
	}
	@Test
    public void getRegionList(){
		String sampleQuery="Region List Query==";
		
		try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the CompanyRegistrationRetrieverTest {}", e.getMessage());
		}
    	try {
			if (retriever != null) {
				retriever.getCountryList();
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the CompanyRegistrationRetrieverTest {}", e.getMessage());
		}
	}
	@Test
    public void getCountryList(){
		String sampleQuery="Country List Query==";
		
		try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the CompanyRegistrationRetrieverTest {}", e.getMessage());
		}
    	try {
			if (retriever != null) {
				retriever.getCountryList();
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the CompanyRegistrationRetrieverTest {}", e.getMessage());
		}
	}
	
}
