package com.brunswick.ecomm.merclink.core.utils;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

class ValidateContactUsServletTest {

	@Test
	void testValidate() {
        // Initialize test data
        Map<String, String> jsondata = new HashMap<>();
        jsondata.put("fname", "John");
        jsondata.put("lname", "Doe");
        jsondata.put("phone", "1234567890");
        jsondata.put("email", "johndoe@example.com");

        // Create the instance of the ValidateContactUsServlet
        ValidateContactUsServlet servlet = new ValidateContactUsServlet();

        // Call the validate method with test data
        Map<String, String> errormessages = servlet.validate(jsondata);

        // Assert the expected error messages
        assertEquals(0, errormessages.size(), "No error message expected");

        // Update the test data to have invalid data
        jsondata.put("fname", "John123");
        jsondata.put("lname", "");
        jsondata.put("phone", "123");
        jsondata.put("email", "johndoe@example");

        errormessages = servlet.validate(jsondata);

        
        assertEquals(3, errormessages.size(), "3 error messages expected");
        assertEquals("Invalid First Name", errormessages.get("fnameError"));
        assertEquals("Invalid Last Name", errormessages.get("lnameError"));
        assertEquals("Invalid Phone Number", errormessages.get("phonenoError"));
      
    }
	@Test
	void testValidEmail() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertTrue(validator.isValidEmail("john.doe@example.com"));
	}

	@Test
	void testInvalidEmail() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertFalse(validator.isValidEmail("not_a_valid_email"));
	}

	@Test
	void testEmptyEmail() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertTrue(validator.isValidEmail(""));
	}
	
	@Test
	void testValidPhone() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertTrue(validator.isValidPhone("1234567890"));
	}

	@Test
	void testInvalidPhone() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertFalse(validator.isValidPhone("not_a_valid_phone"));
	}

	@Test
	void testEmptyPhone() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertTrue(validator.isValidPhone(""));
	}
	@Test
	void testValidName() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertTrue(validator.isValidName("John Doe"));
	}

	@Test
	void testInvalidName() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertFalse(validator.isValidName("123"));
	}

	@Test
	void testEmptyName() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertFalse(validator.isValidName(""));
	}

	@Test
	void testValidAddress() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertTrue(validator.isValidAddress("123 Main St, Apt 4"));
	}

	@Test
	void testInvalidAddress() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertFalse(validator.isValidAddress("!!!"));
	}

	@Test
	void testEmptyAddress() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertTrue(validator.isValidAddress(""));
	}
	@Test
	void testValidCity() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertTrue(validator.isValidCity("New York"));
	}

	@Test
	void testInvalidCity() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertFalse(validator.isValidCity("123"));
	}

	@Test
	void testEmptyCity() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertFalse(validator.isValidCity(""));
	}
	@Test
	void testValidZipcode() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertTrue(validator.isValidZipcode("12345"));
	}

	@Test
	void testInvalidZipcode() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertFalse(validator.isValidZipcode("not_a_valid_zipcode"));
	}

	@Test
	void testEmptyZipcode() {
		ValidateContactUsServlet validator = new ValidateContactUsServlet();
		assertFalse(validator.isValidZipcode(""));
	}
}
