package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;
import org.json.JSONException;


public class QuickorderCheckStockServletTest {
	
	@Rule
	public final AemContext context = createContext("/context/jcr-content-quickorder.json");
	private EcommSessionService adminService;
	private QuickorderCheckStockServlet fixture = new QuickorderCheckStockServlet();
	private APIGEEService apigee;
	
	

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");
		}, ResourceResolverType.JCR_MOCK);
	}
	@Before
	public void setup() throws IOException, JSONException {
		fixture = new QuickorderCheckStockServlet();
		apigee = Mockito.mock(APIGEEService.class);
		APIGEEService apigee = Mockito.mock(APIGEEService.class);
		adminService = Mockito.mock(EcommSessionService.class);
		context.registerService(EcommSessionService.class, adminService);
		context.registerService(APIGEEService.class,apigee);
		context.registerInjectActivateService(fixture);
	}
	
	@Test
	public void doPostTest() throws IOException, LoginException {
		ResourceResolver resolver = mock(ResourceResolver.class);
		when(adminService.getWriteServiceResourceResolver()).thenReturn(resolver);
		String data = "{\"itemno\":\"ABC\",\"currentPage\":\"/content/ecommerce/delcity/us/en/home/quick-order\",\"token\":\"23pjbqgrhwict6xjzvg2tdr9vfjmkhja\",\"operatingUnit\":\"DC\"}}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		fixture.doPost(context.request(), context.response());
	}
	@Test
	public void doPostBulkTest() throws IOException, LoginException {
		ResourceResolver resolver = mock(ResourceResolver.class);
		when(adminService.getWriteServiceResourceResolver()).thenReturn(resolver);
		String data = "{\"itemno\":\"ABC,123,234\",\"currentPage\":\"/content/ecommerce/delcity/us/en/home/quick-order\",\"token\":\"23pjbqgrhwict6xjzvg2tdr9vfjmkhja\",\"operatingUnit\":\"DC\"}}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		fixture.doPost(context.request(), context.response());
	}
	@Test
	public void setstatus() throws IOException {
		fixture.setResponseData(context.response());
}
	
}
