package com.brunswick.ecomm.merclink.core.models.internal.quickorderform;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Collections;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.ProductInterfaceQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class AbstractItemNoSearchRetrieverTest {

    private AbstractItemNoSearchRetriever retriever;
    private MagentoGraphqlClient mockClient;

    @BeforeEach
    public void setUp() {
        mockClient = mock(MagentoGraphqlClient.class);
        GraphqlResponse mockResponse = mock(GraphqlResponse.class);
        Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
        when(mockClient.execute(any())).thenReturn(mockResponse);
        when(mockResponse.getData()).thenReturn(mockQuery);
        when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());
        when(mockQuery.getStoreConfig().getSecureBaseMediaUrl()).thenReturn("");
        retriever = new ItemNoSearchRetriever(mockClient);
    }
    
    @Test
    public void testQueryOverride() {
        String sampleQuery = "{ my_sample_query }";
        retriever.setQuery(sampleQuery);
        retriever.fetchProduct();
        verify(mockClient, times(1)).execute(sampleQuery);
    }
    
    @Test
    public void testsetInput() {
        String input = "AS123";
        retriever.setInput(input);
        assertNotNull(input);
    }
    
    @Test
    public void testProductInterfaceQueryDefinition() {
        assertNotNull(retriever.generateProductQuery());
    }
    
}
