package com.brunswick.ecomm.merclink.core.models.retriever;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.CreateWishlistOutput;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.CustomerToken;
import com.adobe.cq.commerce.magento.graphql.DeleteWishlistOutput;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.RemoveProductsFromWishlistOutput;
import com.adobe.cq.commerce.magento.graphql.UpdateProductsInWishlistOutput;
import com.adobe.cq.commerce.magento.graphql.UpdateWishlistOutput;
import com.adobe.cq.commerce.magento.graphql.Wishlist;
import com.adobe.cq.commerce.magento.graphql.WishlistItemInput;
import com.adobe.cq.commerce.magento.graphql.WishlistItemInterface;
import com.adobe.cq.commerce.magento.graphql.WishlistItems;
import com.adobe.cq.commerce.magento.graphql.WishlistVisibilityEnum;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.shopify.graphql.support.ID;

class AbstractWishlistDetailsRetrieverTest {

	 private AbstractWishlistDetailsRetriever retriever;
	    private MagentoGraphqlClient mockClient;
	    Customer customer;
	    private static final Logger LOG = LoggerFactory.getLogger(AbstractWishlistDetailsRetriever.class);
	    
	    GraphqlResponse<Mutation, Error> response= mock(GraphqlResponse.class);
	    Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	    Mutation mutation= mock(Mutation.class);
	    @BeforeEach
	    public void setUp() {
	        mockClient = mock(MagentoGraphqlClient.class);
	       
	       
	        GraphqlResponse mockResponse = mock(GraphqlResponse.class);
	        when(mockClient.execute(any())).thenReturn(mockResponse);
	        when(mockClient.executeMutation(any())).thenReturn(response);
	        when(response.getData()).thenReturn(mutation);
	        when(mockResponse.getData()).thenReturn(mockQuery);
	        when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());

	        retriever = new AbstractWishlistDetailsRetriever(mockClient);
//	        retriever.setIdentifier(CategoryIdentifierType.ID, "5");
	    }
	    
	    @Test
	    public void getCustomerWishlist() {
	        String sampleQuery = "{ \r\n" + 
	        		" customer {\r\n" + 
	        		" wishlists {\r\n" + 
	        		" id\r\n" + 
	        		" items_count\r\n" + 
	        		" items_v2 {\r\n" + 
	        		" items {\r\n" + 
	        		" id\r\n" + 
	        		" product {\r\n" + 
	        		" id\r\n" + 
	        		" name\r\n" + 
	        		" sku\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		"}y }";
//	        retriever.setQuery(sampleQuery);
	        try {
				if (retriever != null) {
					 retriever.setQuery(sampleQuery);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}
	        //mockClient.executeMutation(sampleQuery);
	        try {
				if (mockClient != null) {
					mockClient.executeMutation(sampleQuery);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}
//	        retriever.getCustomerWishlist(null, null, null);
	        try {
				if (retriever != null) {
					retriever.getCustomerWishlist(null, null, null);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}

	       // verify(mockClient, times(1)).execute(sampleQuery);
	    	
	    }
	    
	    @Test
	    public void getgenerateCustomerToken() {
	        String sampleQuery = "{mutation {\r\n" + 
	        		" generateCustomerToken(\r\n" + 
	        		" email: \"raj.mohanrajendran@infosys.com\"\r\n" + 
	        		" password: \"Admin@123\"\r\n" + 
	        		" ) {\r\n" + 
	        		" token\r\n" + 
	        		" }\r\n" + 
	        		"}\r\n" + 
	        		" }";
	        //retriever.setQuery(sampleQuery);
	        try {
				if (retriever != null) {
					 retriever.setQuery(sampleQuery);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}
	       // mockClient.executeMutation(sampleQuery);
	        CustomerToken token =mock(CustomerToken.class);
	        when(mutation.getGenerateCustomerToken()).thenReturn(token);
	        when( token.getToken()).thenReturn("12345");
	        //retriever.generateCustomerToken("raj.mohanrajendran@infosys.com", "Admin@123");
	        try {
				if (retriever != null) {
					retriever.generateCustomerToken("raj.mohanrajendran@infosys.com", "Admin@123");
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}
	        
	       // verify(mockClient, times(1)).execute(sampleQuery);
	    	
	    }
	    
	    @Test
	    public void getdeleteWishlist() {
	        String sampleQuery = "{mutation{\r\n" + 
	        		" deleteWishlist(wishlistId: 3){\r\n" + 
	        		" status\r\n" + 
	        		" wishlists {\r\n" + 
	        		" id\r\n" + 
	        		" name\r\n" + 
	        		" items_count\r\n" + 
	        		" }\r\n" + 
	        		" }}";
	        //retriever.setQuery(sampleQuery);
	        try {
				if (retriever != null) {
					retriever.setQuery(sampleQuery);
					response=mockClient.executeMutation(sampleQuery);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}
	        //response=mockClient.executeMutation(sampleQuery);
	        
	       DeleteWishlistOutput value= mock(DeleteWishlistOutput.class);
	       when(mutation.getDeleteWishlist()).thenReturn(value);
	       when(value.getStatus()).thenReturn(true);
	        ID id=new ID("171");
	        //retriever.deleteWishlist(id);
	        try {
				if (retriever != null) {
					retriever.deleteWishlist(id);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}
	       // verify(mockClient, times(1)).execute(sampleQuery);
	    	
	    }

	    
	    @Test
	    public void getremoveWishlistItem() {
	        String sampleQuery = "{mutation {\r\n" + 
	        		" removeProductsFromWishlist(\r\n" + 
	        		" wishlistId: 169\r\n" + 
	        		" wishlistItemsIds: [\r\n" + 
	        		" 127,\r\n" + 
	        		" 128,\r\n" + 
	        		" 129\r\n" + 
	        		" ]){\r\n" + 
	        		" wishlist {\r\n" + 
	        		" id\r\n" + 
	        		" items_count\r\n" + 
	        		" items_v2 {\r\n" + 
	        		" items {\r\n" + 
	        		" id\r\n" + 
	        		" quantity\r\n" + 
	        		" product {\r\n" + 
	        		" id\r\n" + 
	        		" name\r\n" + 
	        		" sku\r\n" + 
	        		" price_range {\r\n" + 
	        		" minimum_price {\r\n" + 
	        		" regular_price {\r\n" + 
	        		" currency\r\n" + 
	        		" value\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" maximum_price {\r\n" + 
	        		" regular_price {\r\n" + 
	        		" currency\r\n" + 
	        		" value\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" user_errors {\r\n" + 
	        		" code\r\n" + 
	        		" message\r\n" + 
	        		" }\r\n" + 
	        		" }}}";
	        //retriever.setQuery(sampleQuery);
	        try {
				if (retriever != null) {
					 retriever.setQuery(sampleQuery);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}
	       // response=mockClient.executeMutation(sampleQuery);
	        RemoveProductsFromWishlistOutput value= mock(RemoveProductsFromWishlistOutput.class);
	       when(mutation.getRemoveProductsFromWishlist()).thenReturn(value);
	       Wishlist wishlist =mock(Wishlist.class);
	       when(value.getWishlist()).thenReturn(wishlist);
	       ID id=new ID("171");
	       when( wishlist.getId()).thenReturn(id);
	       
	        List<ID> wishlistItemIds= new ArrayList<>();
	        //retriever.removeWishlistItem(id, wishlistItemIds);
	        try {
				if (retriever != null) {
					retriever.removeWishlistItem(id, wishlistItemIds);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}
	       // verify(mockClient, times(1)).execute(sampleQuery);
	    	
	    }
	    @Test
	    public void getcreateWishlist() {
	        String sampleQuery = "{mutation {\r\n" + 
	        		" createWishlist(input: {\r\n" + 
	        		" name: \"My Wishlist1\"\r\n" + 
	        		" visibility: PUBLIC\r\n" + 
	        		" }\r\n" + 
	        		" ) {\r\n" + 
	        		" wishlist {\r\n" + 
	        		" id\r\n" + 
	        		" name\r\n" + 
	        		" visibility\r\n" + 
	        		" }\r\n" + 
	        		" }}}";
	        //retriever.setQuery(sampleQuery);
	        try {
				if (retriever != null) {
					 retriever.setQuery(sampleQuery);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}
	       // response=mockClient.executeMutation(sampleQuery);
	       CreateWishlistOutput value= mock(CreateWishlistOutput.class);
	       Wishlist wishlist =mock(Wishlist.class);
	       when(mutation.getCreateWishlist()).thenReturn(value);
	       ID id=new ID("171");
	       when(value.getWishlist()).thenReturn(wishlist);
	       when( wishlist.getId()).thenReturn(id);
	        List<ID> wishlistItemIds= new ArrayList<>();
	        //retriever.createWishlist("NEWWISHLIST", "PUBLIC", null);
	        try {
				if (retriever != null) {
					retriever.createWishlist("NEWWISHLIST", "PUBLIC", null);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}
	       // verify(mockClient, times(1)).execute(sampleQuery);
	    	
	    }

	    
	    @Test
	    public void getaddWishlistItems() {
	        String sampleQuery = "{customer {\r\n" + 
	        		" wishlists {\r\n" + 
	        		" id\r\n" + 
	        		" items_count\r\n" + 
	        		" items_v2 {\r\n" + 
	        		" items {\r\n" + 
	        		" id\r\n" + 
	        		" product {\r\n" + 
	        		" id\r\n" + 
	        		" name\r\n" + 
	        		" sku\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" }}\r\n" + 
	        		"";
	       
	        try {
				if (retriever != null) {
					 retriever.setQuery(sampleQuery);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}
			
	       // response=mockClient.executeMutation(sampleQuery);
	        try {
				if (response != null) {
					response=mockClient.executeMutation(sampleQuery);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}
	        Mutation mutation= mock(Mutation.class);
	      /* when(mockResponse.getData()).thenReturn(mutation);
	       DeleteWishlistOutput value= mock(DeleteWishlistOutput.class);
	       when(mutation.getDeleteWishlist()).thenReturn(value);
	       when(value.getStatus()).thenReturn(true);*/
	        ID id=new ID("171");
	        List<WishlistItemInput>  wishlistItemIds= new ArrayList<>();
	        //retriever.addWishlistItems(id, wishlistItemIds);
	        try {
				if (retriever != null) {
					retriever.addWishlistItems(id, wishlistItemIds);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}
	        

	       // verify(mockClient, times(1)).execute(sampleQuery);
	    	
	    }

	    @Test
	    public void getaddComment() {
	        String sampleQuery = "{mutation {\r\n" + 
	        		" updateProductsInWishlist(\r\n" + 
	        		" wishlistId: 169\r\n" + 
	        		" wishlistItems: [\r\n" + 
	        		" {\r\n" + 
	        		" wishlist_item_id: 130\r\n" + 
	        		" quantity: 12\r\n" + 
	        		" }\r\n" + 
	        		" ]){\r\n" + 
	        		" wishlist {\r\n" + 
	        		" id\r\n" + 
	        		" items_count\r\n" + 
	        		" items_v2 {\r\n" + 
	        		" items {\r\n" + 
	        		" id\r\n" + 
	        		" quantity\r\n" + 
	        		" product {\r\n" + 
	        		" name\r\n" + 
	        		" sku\r\n" + 
	        		" id\r\n" + 
	        		" price_range {\r\n" + 
	        		" minimum_price {\r\n" + 
	        		" regular_price {\r\n" + 
	        		" currency\r\n" + 
	        		" value\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" maximum_price {\r\n" + 
	        		" regular_price {\r\n" + 
	        		" currency\r\n" + 
	        		" value\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" }\r\n" + 
	        		" user_errors {\r\n" + 
	        		" code\r\n" + 
	        		" message\r\n" + 
	        		" }\r\n" + 
	        		" }}";
	        //retriever.setQuery(sampleQuery);
	        try {
				if (retriever != null) {
					retriever.setQuery(sampleQuery);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}
	      //  response=mockClient.executeMutation(sampleQuery);
	        Wishlist wishlist =mock(Wishlist.class);
	        WishlistItems item= mock(WishlistItems.class);
	        List<WishlistItemInterface> wishlistiteminterface= new ArrayList<>();
	        UpdateProductsInWishlistOutput value= mock(UpdateProductsInWishlistOutput.class);
	       when(mutation.getUpdateProductsInWishlist()).thenReturn(value);
					 when(value.getWishlist()).thenReturn(wishlist);
					 when(wishlist.getItemsV2()).thenReturn(item);
			
					 when( item.getItems()).thenReturn(wishlistiteminterface);
	        ID id=new ID("171");
	        List<WishlistItemInput>  wishlistItemIds= new ArrayList<>();
	       // retriever.addComment(id, id, "this is good");
	       // verify(mockClient, times(1)).execute(sampleQuery);
	    	
	    }
	    
	    @Test
	    public void getupdateWishlist() {
	        String sampleQuery = "{mutation {\r\n" + 
	        		" updateWishlist(\r\n" + 
	        		" wishlistId: 4\r\n" + 
	        		" name: \"My Wishlis1Updated\"\r\n" + 
	        		" visibility: PUBLIC\r\n" + 
	        		" ) {\r\n" + 
	        		" name\r\n" + 
	        		" uid\r\n" + 
	        		" visibility\r\n" + 
	        		" }}";
//	        retriever.setQuery(sampleQuery);
	        try {
				if (retriever != null) {
					retriever.setQuery(sampleQuery);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}
	       // response=mockClient.executeMutation(sampleQuery);
	        UpdateWishlistOutput value= mock(UpdateWishlistOutput.class);
	       when(mutation.getUpdateWishlist()).thenReturn(value);
	       when(value.getName()).thenReturn("mywishlist");
	       when(value.getVisibility()).thenReturn( WishlistVisibilityEnum.valueOf("PUBLIC"));
			
	        ID id=new ID("171");
	        List<WishlistItemInput>  wishlistItemIds= new ArrayList<>();
//	        retriever.updateWishlist(id, "NEWWISHLIST", "PUBLIC");
	        try {
				if (retriever != null) {
					retriever.updateWishlist(id, "NEWWISHLIST", "PUBLIC");
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractWishlistDetailsRetriever {}", e.getMessage());
			}
	       // verify(mockClient, times(1)).execute(sampleQuery);
	    	
	    }


}
