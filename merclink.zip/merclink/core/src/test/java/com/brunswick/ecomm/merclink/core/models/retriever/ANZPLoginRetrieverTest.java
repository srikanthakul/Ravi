package com.brunswick.ecomm.merclink.core.models.retriever;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.CustomerToken;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

class ANZPLoginRetrieverTest {
	
	private ANZPLoginRetriever retriever;
    private MagentoGraphqlClient mockClient;
    Customer customer;
    
    private static final Logger LOGGER = LoggerFactory.getLogger(ANZPLoginRetriever.class);
    
    GraphqlResponse<Mutation, Error> response= mock(GraphqlResponse.class);
    Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
    Mutation mutation= mock(Mutation.class);
    @BeforeEach
    public void setUp() {
        mockClient = mock(MagentoGraphqlClient.class);
       
       
        GraphqlResponse mockResponse = mock(GraphqlResponse.class);
        when(mockClient.execute(any())).thenReturn(mockResponse);
        when(mockClient.executeMutation(any())).thenReturn(response);
        when(response.getData()).thenReturn(mutation);
        when(mockResponse.getData()).thenReturn(mockQuery);
        when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());

        retriever = new ANZPLoginRetriever(mockClient);
//        retriever.setIdentifier(CategoryIdentifierType.ID, "5");
    }
	@Test
	 void testPopulate() {							  
    	retriever.populate();
	}
	

	@Test
	void testGenerateCustomerToken() {
		String sampleQuery = "{mutation {\r\n" + 
        		" generateCustomerToken(\r\n" + 
        		" email: \"raj.mohanrajendran@infosys.com\"\r\n" + 
        		" ) {\r\n" + 
        		" token\r\n" + 
        		" }\r\n" + 
        		"}\r\n" + 
        		" }";
        retriever.setQuery(sampleQuery);
       // mockClient.executeMutation(sampleQuery);
        CustomerToken token =mock(CustomerToken.class);
        when(mutation.getGenerateCustomerToken()).thenReturn(token);
        when( token.getToken()).thenReturn("12345");
        retriever.generateCustomerToken("raj.mohanrajendran@infosys.com");
	}

	
	@Test
	void testRevokeCustomerToken() {
		
		
	}

	@Test
	void testGetCustomerCart() {
		String sampleQuery="{SimpleProduct\r\n"+
	            "12345\r\n"+
				"803456\r\n"+
                "CYmiiQRjPVc2gJUc5r7IsBmwegVIFO43\r\n"+
	            "}";   								
		retriever.setQuery(sampleQuery);
		mockClient.execute(sampleQuery);
		mockClient.executeQuery(sampleQuery);
		retriever.getCustomerCart();
	}

	@Test
	void testMergeCartsString() {
		String sampleQuery="{12345\r\n"+
				"803456\r\n"+
                "CYmiiQRjPVc2gJUc5r7IsBmwegVIFO43\r\n"+
	            "}";   								
		retriever.setQuery(sampleQuery);
		mockClient.execute(sampleQuery);
		mockClient.executeMutation(sampleQuery);
		retriever.mergeCarts(sampleQuery, sampleQuery);

	}

	@Test
	void testGetCustomerRecentOrder() {
		String sampleQuery = "{ \r\n" + 
                 " salesRecentOrder{ \r\n"+
                 "increment_id\"\r\n"+
                 " customer_name \r\n"+
                 " items { \r\n"+
                 " title \r\n"+
                 " sku\r\n"+
                 " price\r\n"+
                 " image \r\n"+
                  " }}}";
		try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
	           //assertNotNull(retriever.getCustomerRecentOrder());
	           //assertEquals(retriever.getProductsAvaliability(sampleQuery),sampleQuery);
	           }
			} catch (NullPointerException e) {
				LOGGER.error("NullPointerException inside the AbstractQuickOrderRetriever {}", e.getMessage());
			}
		try {
			if (retriever != null) {
				
	           assertNotNull(retriever.getCustomerRecentOrder());
	           //assertEquals(retriever.getProductsAvaliability(sampleQuery),sampleQuery);
	           }
			} catch (NullPointerException e) {
				LOGGER.error("NullPointerException inside the AbstractQuickOrderRetriever {}", e.getMessage());
			}
		
	}

}

	 
