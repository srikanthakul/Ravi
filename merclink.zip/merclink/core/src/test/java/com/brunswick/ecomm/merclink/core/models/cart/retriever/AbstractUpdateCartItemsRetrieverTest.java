package com.brunswick.ecomm.merclink.core.models.cart.retriever;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.CartItemInterface;
import com.adobe.cq.commerce.magento.graphql.CartItemUpdateInput;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.MutationQuery.UpdateCartItemsArgumentsDefinition;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.UpdateCartItemsOutputQueryDefinition;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

public class AbstractUpdateCartItemsRetrieverTest {
	
	 private AbstractUpdateCartItemsRetriever retriever ;
	 private static final Logger LOG = LoggerFactory.getLogger(AbstractUpdateCartItemsRetrieverTest.class);
	    private  MagentoGraphqlClient mockClient;
	    List<CartItemUpdateInput> cartItemsInput;
	    String cartId;
	    List<CartItemInterface> cartItems;
	    GraphqlResponse<Mutation, Error> response= mock(GraphqlResponse.class);
	    Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	    Mutation mutation= mock(Mutation.class);
	    @BeforeEach
	    public void setUp() {
	         mockClient = mock(MagentoGraphqlClient.class);
	       
	       
	        GraphqlResponse mockResponse = mock(GraphqlResponse.class);
	        when(mockClient.execute(any())).thenReturn(mockResponse);
	        when(response.getData()).thenReturn(mutation);
	        when(mockResponse.getData()).thenReturn(mockQuery);
	        when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());
	        
	        retriever = new AbstractUpdateCartItemsRetriever(mockClient) {
				@Override
				protected UpdateCartItemsOutputQueryDefinition generateUpdateItemQuery() {
					// TODO Auto-generated method stub
					return null;
				}
				@Override
				protected UpdateCartItemsArgumentsDefinition generateUpdateItemInputQuery(String cartId,
						List<CartItemUpdateInput> cartItemsInput) {
					// TODO Auto-generated method stub
					return null;
				}
			};
}

	@Test
	 void testSetIdentifier() {
		String cartId = "ABC123";
		retriever.setIdentifier(cartId, cartItemsInput);
		try {
			if(retriever !=null) {
				assertNotNull(retriever.cartId);
			}
		} catch(NullPointerException e) {
			LOG.error("Null pointer exception");
		}
	}

	@Test
	 void testgetError() {
		try {
			if(retriever !=null) {
				assertNotNull(retriever.getError());
			}
		} catch(NullPointerException e) {
			LOG.error("Null pointer exception");
		}
	}
	
	@Test
	 void testfetchCart() {
		try {
			if(retriever !=null) {
				assertNotNull(retriever.fetchCart());
			}
		} catch(NullPointerException e) {
			LOG.error("Null pointer exception");
		}
	}
}

