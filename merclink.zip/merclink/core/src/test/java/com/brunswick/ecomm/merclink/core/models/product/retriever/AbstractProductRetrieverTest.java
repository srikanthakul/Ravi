package com.brunswick.ecomm.merclink.core.models.product.retriever;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.core.components.client.MagentoGraphqlClient;
import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.brunswick.ecomm.core.models.internal.quickorderform.ItemNoSearchRetriever;

class AbstractProductRetrieverTest {

	private ItemNoSearchRetriever retriever;
	private MagentoGraphqlClient mockClient;
	private static final Logger LOG = LoggerFactory.getLogger(AbstractProductRetrieverTest.class);
	GraphqlResponse<Mutation, Error> response = mock(GraphqlResponse.class);
	Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	Mutation mutation = mock(Mutation.class);

	@BeforeEach
	public void setUp() {
		mockClient = mock(MagentoGraphqlClient.class);
		GraphqlResponse mockResponse = mock(GraphqlResponse.class);
		when(response.getData()).thenReturn(mutation);
		when(mockResponse.getData()).thenReturn(mockQuery);
		when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());
		try {
			if (retriever != null) {
				retriever = new ItemNoSearchRetriever(null);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the setUp {}", e.getMessage());
		}
	}

	@Test
	void generateQuery() {
		String queryString = "query{\r\n" + "category_url_path \r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateQuery {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.fetchProduct();
				retriever.generateQuery(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateQuery {}", e.getMessage());
		}
		assertNotNull(queryString);
	}

	@Test
	void generatePriceQuery() {
		String queryString = "query{\r\n" + "regularPrice\r\n" + "value() \r\n" + "currency() \r\n" + "finalPrice \r\n"
				+ "value() \r\n" + "currency() \r\n" + "discount \r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generatePriceQuery {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.fetchProduct();
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generatePriceQuery {}", e.getMessage());
		}
		assertNotNull(queryString);
	}

	@Test
	void populate() {
		String queryString = "query{\r\n" + "regularPrice\r\n" + "value() \r\n" + "currency() \r\n" + "finalPrice \r\n"
				+ "value() \r\n" + "currency() \r\n" + "discount \r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the populate {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.fetchProduct();
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the populate {}", e.getMessage());
		}
		assertNotNull(queryString);
	}
	

}

