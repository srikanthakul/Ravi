package com.brunswick.ecomm.merclink.core.beans.productdetailsrecommendations;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;



	public class FinalPriceBeanTest {

		FinalPriceBean fixture;
		@BeforeEach
		public void setup() {
			fixture = new FinalPriceBean();
		}
		
		@Test
		public void getCurrencyTest() {
			String expecteddata="city";
			fixture.setCurrency(expecteddata);
			fixture.getCurrency();
		}
		
		@Test
		public void getValueTest() {
			Integer expecteddata=1;
			fixture.setValue(expecteddata);
			fixture.getValue();
		}

	}
