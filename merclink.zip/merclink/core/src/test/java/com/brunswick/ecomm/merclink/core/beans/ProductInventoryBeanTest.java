package com.brunswick.ecomm.merclink.core.beans;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ProductInventoryBeanTest {
	ProductInventoryBean fixture;
	InventoryStatus inventory;

	@BeforeEach
	void setUp() throws Exception {
		fixture = new ProductInventoryBean();
	}

	@Test
	void testGetStatus() {
		inventory = new InventoryStatus();
		String message = "message";
		inventory.setId(0);
		inventory.setMessage(message);
		fixture.setStatus(inventory);
		assertEquals(inventory, fixture.getStatus());
		
		
	}

	@Test
	void testGetWarehouses() {
		List<WareHouses> expectedOutput = new ArrayList<WareHouses>();
		WareHouses data = new WareHouses();
		expectedOutput.add(data);
		fixture.setWarehouses(expectedOutput);
		assertEquals(expectedOutput, fixture.getWarehouses());
		
		
	}

	@Test
	void testGetTotal_quantity() {
		int expectedOutput = 0;
		fixture.setTotal_quantity(expectedOutput);
		assertEquals(expectedOutput, fixture.getTotal_quantity());
	}

	@Test
	void testGetDate() {
		String expectedOutput = "Date";
		fixture.setDate(expectedOutput);
		assertEquals(expectedOutput, fixture.getDate());
	}

}
