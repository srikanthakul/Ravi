package com.brunswick.ecomm.merclink.core.models;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import javax.servlet.http.Cookie;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.webservicesupport.ConfigurationManagerFactory;

class DatalayerModelTest {
	
	private static final String COOKIE_NAME = "customerNumber";
    private static final String COOKIE_VALUE = "12345";
    
    @Mock
    private Resource resource;
    
    @Mock
    private SlingHttpServletRequest request;
    
    @Mock
    private Cookie cookie;
    
    @Mock
    private DatalayerModel datalayerModel;
    
    @InjectMocks
    private DatalayerModel dataLayer;
    
    private Logger logger;
    private String primaryCategory;
    private String pageName;
    private String countryCode;
    private String languageCode;
    private String customerNumber;
    private String brandName;
    private String queryString;
    private String newsTitle;
    private ConfigurationManagerFactory configManagerFctry;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
        //logger = mock(Logger.class);
        customerNumber = StringUtils.EMPTY;
        primaryCategory = StringUtils.EMPTY;
        pageName = StringUtils.EMPTY;
        countryCode = "US";
        languageCode = "en";
        brandName = StringUtils.EMPTY;
        queryString = StringUtils.EMPTY;
        newsTitle = StringUtils.EMPTY;
        //configManagerFctry = mock(ConfigurationManagerFactory.class);
        datalayerModel.setCustomerNumber(customerNumber);
        
	}

	@Test
	void testGetCustomerFromCookie() {
		when(request.getCookies()).thenReturn(new Cookie[] {cookie});
        when(cookie.getName()).thenReturn(COOKIE_NAME);
        when(cookie.getValue()).thenReturn(COOKIE_VALUE);
        Assertions.assertEquals(COOKIE_VALUE, DatalayerModel.getCustomerFromCookie(COOKIE_NAME, request));
	}

	@Test
	void testGetUserLoginStatus() {
		dataLayer.setUserLoginStatus("test");
		assertEquals("test", dataLayer.getUserLoginStatus());
	}

	@Test
	void testGetPageName() {
		when(datalayerModel.getPageName()).thenReturn(pageName);
		assertEquals("", datalayerModel.getPageName());
	}

	@Test
	void testGetPrimaryCategory() {
		when(datalayerModel.getPrimaryCategory()).thenReturn(primaryCategory);
		assertEquals("", datalayerModel.getPrimaryCategory());
	}

	@Test
	void testGetCountryCode() {
		when(datalayerModel.getCountryCode()).thenReturn(countryCode);
		assertEquals("US", datalayerModel.getCountryCode());
	}

	@Test
	void testGetLanguageCode() {
		when(datalayerModel.getLanguageCode()).thenReturn(languageCode);
		assertEquals("en", datalayerModel.getLanguageCode());
	}

	@Test
	void testGetCurrentPagePath() {
		when(datalayerModel.getCurrentPagePath()).thenReturn("path");
		assertEquals("path", datalayerModel.getCurrentPagePath());
		
	}

	@Test
	void testGetCustomerNumber() {
		dataLayer.setCustomerNumber(customerNumber);
		assertEquals("", dataLayer.getCustomerNumber());
	}

	@Test
	void testGetBrandName() {
		when(datalayerModel.getBrandName()).thenReturn(brandName);
		assertEquals("", datalayerModel.getBrandName());
	}

	@Test
	void testGetQueryString() {
		when(datalayerModel.getQueryString()).thenReturn(queryString);
		assertEquals("", datalayerModel.getQueryString());
	}

	@Test
	void testGetNewsTitle() {
		when(datalayerModel.getNewsTitle()).thenReturn(newsTitle);
		assertEquals("", datalayerModel.getNewsTitle());
	}

}
