package com.brunswick.ecomm.merclink.core.beans.checkout;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SubmitOrderBeanTest {
	public SubmitOrderBean fixture;
	String test;
	boolean value;

	@BeforeEach
	void setUp() throws Exception {
		fixture = new SubmitOrderBean();
	}

	@Test
	void testIsIs_dropship() {
		value = true;
		 fixture.setIs_dropship(value);
		 assertEquals(value,fixture.isIs_dropship());
	}

	

	@Test
	void testGetAttribute19() {
		test = "word";
		 fixture.setAttribute19(test);
		 assertEquals(test,fixture.getAttribute19());
	}

	

	@Test
	void testGetCartId() {
		test = "word";
		 fixture.setCartId(test);
		 assertEquals(test,fixture.getCartId());
	}

	

	@Test
	void testGetPonumber() {
		test = "word";
		 fixture.setPonumber(test);
		 assertEquals(test,fixture.getPonumber());
	}

	

	@Test
	void testGetOrdercomment() {
		test = "word";
		 fixture.setOrdercomment(test);
		 assertEquals(test,fixture.getOrdercomment());
	}

	

	@Test
	void testGetRequestedshipdate() {
		test = "word";
		 fixture.setRequestedshipdate(test);
		 assertEquals(test,fixture.getRequestedshipdate());
	}

	

	@Test
	void testGetPayment_method() {
		test = "word";
		 fixture.setPayment_method(test);
		 assertEquals(test,fixture.getPayment_method());
	}

	

	@Test
	void testGetShipping_method() {
		test = "word";
		 fixture.setShipping_method(test);
		 assertEquals(test,fixture.getShipping_method());
	}

	

	@Test
	void testGetShipping_cost() {
		test = "word";
		 fixture.setShipping_cost(test);
		 assertEquals(test,fixture.getShipping_cost());
	}

	

}
