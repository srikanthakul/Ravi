package com.brunswick.ecomm.merclink.core.beans;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class WareHouseTest {
	WareHouse fixture;

	@BeforeEach
	 void setUpBeforeClass()  {
		fixture = new WareHouse();
	}

	@Test
	void testGetName() {
		String expData = "name";
		fixture.setName(expData);
		assertEquals(expData, fixture.getName());
	}

}
