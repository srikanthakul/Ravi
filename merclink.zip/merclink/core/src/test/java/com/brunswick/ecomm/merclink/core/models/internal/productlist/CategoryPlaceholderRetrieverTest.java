package com.brunswick.ecomm.merclink.core.models.internal.productlist;



import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.Collections;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

public class CategoryPlaceholderRetrieverTest {
	private CategoryPlaceholderRetriever retriever;
	private MagentoGraphqlClient mockClient;
    Customer customer;
    private static final String PATH="what_is_the_path"; //**************************************
    GraphqlResponse<Mutation, Error> response= mock(GraphqlResponse.class);
    Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
    Mutation mutation= mock(Mutation.class);
    @BeforeEach
    public void setUp() throws IOException {
        mockClient = mock(MagentoGraphqlClient.class);
       
       
        GraphqlResponse mockResponse = mock(GraphqlResponse.class);
        when(mockClient.execute(any())).thenReturn(mockResponse);
        when(mockClient.executeMutation(any())).thenReturn(response);
        when(response.getData()).thenReturn(mutation);
        when(mockResponse.getData()).thenReturn(mockQuery);
        when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());

//        retriever = new CategoryPlaceholderRetriever(mockClient,PATH);
//        retriever.setIdentifier(CategoryIdentifierType.ID, "5");
    }
    
	@Test
	public void generateCategoryQueryTest() {
		String sampleQuery = ""; 
//		retriever.setQuery(sampleQuery);
//	    mockClient.execute(sampleQuery);
//		retriever.generateCategoryQuery();
	}
	

}

