package com.brunswick.ecomm.merclink.core.beans.checkout;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CustomerAddressBeanTest {
	public CustomerAddressBean fixture;
	String test;
	Boolean value;
	Integer digit;

	@BeforeEach
	void setUp() throws Exception {
		fixture = new CustomerAddressBean();
	}

	@Test
	void testGetSameasshipping() {
		 test = "word";
		 fixture.setSameasshipping(test);
		 assertEquals(test,fixture.getSameasshipping());
	}

	

	@Test
	void testGetCartId() {
		test = "word";
		 fixture.setCartId(test);
		assertEquals(test,fixture.getCartId());
	}

	

	@Test
	void testGetCustomerId() {
		 test = "word";
		 fixture.setCustomerId(test);
		 assertEquals(test,fixture.getCustomerId());
	}

	
	@Test
	void testGetFirstname() {
		test = "word";
		 fixture.setFirstname(test);
		 assertEquals(test,fixture.getFirstname());
	}

	

	@Test
	void testGetLastname() {
		test = "word";
		 fixture.setLastname(test);
		 assertEquals(test,fixture.getLastname());
	}

	

	@Test
	void testGetCompany() {
		test = "word";
		 fixture.setCompany(test);
		 assertEquals(test,fixture.getCompany());
	}

	

	@Test
	void testGetAddress1() {
		test = "word";
		 fixture.setAddress1(test);
		 assertEquals(test,fixture.getAddress1());
	}

	

	@Test
	void testGetAddress2() {
		test = "word";
		 fixture.setAddress2(test);
		 assertEquals(test,fixture.getAddress2());
	}

	

	@Test
	void testGetCity() {
		test = "word";
		 fixture.setCity(test);
		 assertEquals(test,fixture.getCity());
	}

	

	@Test
	void testGetState() {
		test = "word";
		 fixture.setState(test);
		 assertEquals(test,fixture.getState());
	}

	
	@Test
	void testGetRegioncode() {
		test = "word";
		 fixture.setRegioncode(test);
		 assertEquals(test,fixture.getRegioncode());
	}

	

	@Test
	void testGetCountry() {
		test = "word";
		 fixture.setCountry(test);
		 assertEquals(test,fixture.getCountry());
	}

	

	@Test
	void testGetPostalcode() {
		test = "word";
		 fixture.setPostalcode(test);
		 assertEquals(test,fixture.getPostalcode());
	}

	

	@Test
	void testGetAddresstype() {
		test = "word";
		 fixture.setAddresstype(test);
		 assertEquals(test,fixture.getAddresstype());
	}

	

	@Test
	void testGetCustomertype() {
		test = "word";
		 fixture.setCustomertype(test);
		 assertEquals(test,fixture.getCustomertype());
	}

	

	@Test
	void testGetAddressbook() {
		value = true;
		 fixture.setAddressbook(value);
		 assertEquals(value,fixture.getAddressbook());
	}

	

	@Test
	void testGetTelephone() {
		test = "word";
		 fixture.setTelephone(test);
		 assertEquals(test,fixture.getTelephone());
	}

	

	@Test
	void testGetCompanyAddrId() {
		digit = 1;
		 fixture.setCompanyAddrId(digit);
		 assertEquals(digit,fixture.getCompanyAddrId());
	}

	

}
