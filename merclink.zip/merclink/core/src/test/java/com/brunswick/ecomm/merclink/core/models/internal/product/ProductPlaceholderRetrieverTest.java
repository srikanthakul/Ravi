package com.brunswick.ecomm.merclink.core.models.internal.product;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

class ProductPlaceholderRetrieverTest {
	private ProductPlaceholderRetriever retriever;
	private MagentoGraphqlClient mockClient;
	private static final Logger LOG = LoggerFactory.getLogger(ProductPlaceholderRetrieverTest.class);
	GraphqlResponse<Mutation, Error> response = mock(GraphqlResponse.class);
	Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	Mutation mutation = mock(Mutation.class);

	@BeforeEach
	public void setUp() {
		mockClient = mock(MagentoGraphqlClient.class);

		GraphqlResponse mockResponse = mock(GraphqlResponse.class);
		when(mockClient.execute(any())).thenReturn(mockResponse);
		when(response.getData()).thenReturn(mutation);
		when(mockResponse.getData()).thenReturn(mockQuery);
		when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());

	}

	@Test
	public void generateProductQuery() {
		try {
			if (retriever != null) {
				retriever.setQuery(null);
				mockClient.execute(null);
				retriever.extendProductQueryWith(null);
				retriever.extendVariantQueryWith(null);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateProductQuery {}", e.getMessage());
		}

	}

}
