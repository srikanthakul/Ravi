package com.brunswick.ecomm.merclink.core.beans.personalinformation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RegionTest {

	Region fixture;
	
	@BeforeEach
	void setUpBeforeClass()  {
		fixture = new Region();
	}

	@Test
	void testGetRegion() {
		String expdata = "region";
		fixture.setRegion(expdata);
		assertEquals(expdata, fixture.getRegion());
	}

	@Test
	void testGetRegion_code() {
		String expData = "region_code";
		fixture.setRegion_code(expData);
		assertEquals(expData, fixture.getRegion_code());
	}

	@Test
	void testGetRegion_id() {
		Integer expdata = 12;
		fixture.setRegion_id(expdata);
		assertEquals(expdata, fixture.getRegion_id());
	}

}
