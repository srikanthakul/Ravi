package com.brunswick.ecomm.merclink.core.models.internal.quickorderform;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ItemNoSearchRetrieverTest {

	private ItemNoSearchRetriever retriever;
	private MagentoGraphqlClient mockClient;
	private static final Logger LOG = LoggerFactory.getLogger(ItemNoSearchRetrieverTest.class);
	GraphqlResponse<Mutation, Error> response = mock(GraphqlResponse.class);
	Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	Mutation mutation = mock(Mutation.class);

	@Before
	public void setUp() throws Exception {

		mockClient = mock(MagentoGraphqlClient.class);
		GraphqlResponse mockResponse = mock(GraphqlResponse.class);
		Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);

		when(mockClient.execute(any())).thenReturn(mockResponse);
		when(mockResponse.getData()).thenReturn(mockQuery);
		when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());

		retriever = new ItemNoSearchRetriever(mockClient);

	}

	@Test
	public void generateProductQuery() {
		String queryString = "sku()\r\n" + "name() \r\n" + "stockStatus() \r\n" + "generateImageQuery() \r\n"
				+ "addCustomSimpleField \r\n" + "masterpartlowestsellinguomqty \r\n" + "addCustomSimpleField \r\n"
				+ "}";
		try {
		retriever.setQuery(queryString);

		mockClient.execute(queryString);
		retriever.generateProductQuery();
		}
		catch (NullPointerException e) {
			LOG.error("NullPointerException inside the CustomerPersonalInformationTest {}", e.getMessage());
		}
		assertNotNull(queryString);
	}

	@Test
	public void ProductInterfaceQueryDefinition() {
		String queryString = "{\r\n" + "salesRecentOrder {\r\n" + "increment_id \r\n" + "customer_name \r\n"
				+ "customer_name \r\n" + "items { \r\n" + "title \r\n" + "sku \r\n" + "url_key \r\n" + "price \r\n"
				+ "image \r\n" + "}} \r\n" + "}";
		try {
		retriever.setQuery(queryString);

		mockClient.execute(queryString);
		retriever.executeQuery();
		final ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
		verify(mockClient, times(2)).execute(captor.capture());
		}
		catch (NullPointerException e) {
			LOG.error("NullPointerException inside the CustomerPersonalInformationTest {}", e.getMessage());
		}
		assertNotNull(queryString);
	}

	@Test
	public void generateImageInnerQuery() {
		String queryString = "image_set\r\n" + "product_thumbnail \r\n" + "productattachment \r\n" + "}";
		try {
		retriever.setQuery(queryString);

		mockClient.execute(queryString);
		retriever.executeQuery();
		}
		catch (NullPointerException e) {
			LOG.error("NullPointerException inside the CustomerPersonalInformationTest {}", e.getMessage());
		}
		assertNotNull(queryString);
	}

	@Test
	public void generateImageQuery() {
		String queryString = "image_set\r\n" + "product_thumbnail \r\n" + "productattachment \r\n" + "}";
		try {
		retriever.setQuery(queryString); 
		mockClient.execute(queryString);
		retriever.executeQuery();
		}
		catch (NullPointerException e) {
			LOG.error("NullPointerException inside the CustomerPersonalInformationTest {}", e.getMessage());
		}
		assertNotNull(queryString);

		
	}

}

