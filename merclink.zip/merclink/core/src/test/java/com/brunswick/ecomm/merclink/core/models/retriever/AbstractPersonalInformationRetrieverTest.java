package com.brunswick.ecomm.merclink.core.models.retriever;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

class AbstractPersonalInformationRetrieverTest {

	private AbstractPersonalInformationRetriever retriever;
	private MagentoGraphqlClient mockClient;
	Customer customer;
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractPersonalInformationRetriever.class);
	GraphqlResponse<Mutation, Error> response = mock(GraphqlResponse.class);
	Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	Mutation mutation = mock(Mutation.class);
	@BeforeEach
	public void setUp() {
		mockClient = mock(MagentoGraphqlClient.class);

		GraphqlResponse mockResponse = mock(GraphqlResponse.class);
		when(mockClient.execute(any())).thenReturn(mockResponse);
		when(response.getData()).thenReturn(mutation);
		when(mockResponse.getData()).thenReturn(mockQuery);
		when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());

		retriever = new AbstractPersonalInformationRetriever(mockClient);
	}
	
   	@Test
    public void getCustomerPersonalInformation(){
    	String sampleQuery="{\r\n" + 
    			"getCustomerPersonalInformation {\r\n" + 
    			"firstname( \r\n" + 
    			"lastname:{{\r\n" + 
    			"email\r\n" + 
    			"company_email\r\n" + 
    			"company_name\r\n" + 
    			"customer_number\r\n" + 
    			"company_currency\r\n" + 
    			"warehouse_name\r\n" +
    			"shipping_method\r\n" + 
    			"dropship\r\n" + 
    			"is_wells_fargo\r\n" + 
    			"tax_group\r\n" + 
    			"blog_news\r\n" + 
    			"roles_permission\r\n" + 
    			"company_name\r\n" + 
    			"company_number\r\n" + 
    			"customer_group\r\n" + 
    			"customer_roles\r\n" + 
    			"customer_permission\r\n" + 
    			"}\r\n" + 
    			"account_list{\r\n" +
    			"company_number\r\n" + 
    			"company_name\r\n" + 
    			
    			"is_admin\r\n" + 
    			"is_default\r\n" + 
    			"}\r\n" +
    			"telephone\r\n" + 
    			"billing_address {\r\n" + 
    			"id\r\n" + 
    			"customer_id\r\n" + 
    			"firstname\r\n" + 
    			"lastname\r\n" + 
    			"street\r\n" + 
    			"city\r\n" + 
    			"primary_flag\r\n" + 
    			"country_code\r\n" + 
    			"postcode\r\n" + 
    			"region_id\r\n" + 
    			"primary_flag\r\n" +
    			"default_shipping\r\n" + 
    			"default_billing\r\n"+
    			"}\r\n" + 
    			"}\r\n"+
    			"}";
    	try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractPersonalInformationRetrieverTest {}", e.getMessage());
		}
    	try {
			if (retriever != null) {
				retriever.getCustomerPersonalInformation();
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractPersonalInformationRetrieverTest {}", e.getMessage());
		}
}

   	@Test
    public void updateCustomerAddress(){
   		String sampleQuery="mutation {\r\n" + 
    			"updateCompanyAddress\r\n" + 
    			"firstname:( \r\n" + 
    			"lastname }\r\n" + 
    			") {\r\n" + 
    			"id\r\n" + 
    			"city\r\n" + 
    			"postcode\r\n" + 
    			"street\r\n" + 
    			"firstname\r\n" +
    			"lastname\r\n" + 
    			"email\r\n" + 
    			"}\r\n" + 
    			"}";
   		try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractPersonalInformationRetrieverTest {}", e.getMessage());
		}
   		try {
			if (retriever != null) {
				retriever.updateCustomerAddress(sampleQuery, sampleQuery, sampleQuery, sampleQuery, sampleQuery);
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractPersonalInformationRetrieverTest {}", e.getMessage());
		}
   	}
   	@Test
    public void deleteAddress(){
   		String sampleQuery="mutation {\r\n" + 
    			"deleteCompanyAddress(\r\n" + 
    			"id:( \r\n" + 
    			"addressid\r\n" + 
    			")\r\n" + 
    			"}";
   		try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractPersonalInformationRetrieverTest {}", e.getMessage());
		}
   		try {
			if (retriever != null) {
				retriever.deleteAddress(sampleQuery);
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractPersonalInformationRetrieverTest {}", e.getMessage());
		}
   	}
   	@Test
    public void updateCustomerPersonalInformation(){
   		String sampleQuery="mutation {\r\n" + 
    			"updateCompany(\r\n" + 
    			"input: { \r\n" + 
    			"company_name :\r\n" + 
    			"company_email:\r\n" + 
    			"firstname:\r\n" + 
    			"lastname:\r\n" + 
    			"customer_type:\r\n" + 
    			"telephone:\r\n" + 
    			" }) {\r\n" + 
    			"company {\r\n" + 
    			"id\r\n" + 
    			"email\r\n" + 
    			"name\r\n" + 
    			"company_admin { \r\n" + 
    			
				"firstname\r\n" + 
				"lastname\r\n" + 
				"email \r\n" + 
				"telephone\r\n" + 
				"customer_type \r\n" + 
				"orig_system_reference \r\n" + 
				"azure_object_id\r\n" + 
				" erp_customer_id \r\n" + 
				"}\r\n" + 
				"default_shipping\r\n" + 
				"default_billing\r\n" + 
				"}\r\n" + 
				"}\r\n" +
    			"}";
   		try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractPersonalInformationRetrieverTest {}", e.getMessage());
		}
   		try {
			if (retriever != null) {
				retriever.updateCustomerPersonalInformation(sampleQuery, sampleQuery, sampleQuery, sampleQuery, sampleQuery, sampleQuery, sampleQuery);
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractPersonalInformationRetrieverTest {}", e.getMessage());
		}
   	}
}
