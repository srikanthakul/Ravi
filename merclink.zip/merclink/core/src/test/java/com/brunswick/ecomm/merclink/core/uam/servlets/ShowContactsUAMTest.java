package com.brunswick.ecomm.merclink.core.uam.servlets;


import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.servlethelpers.MockSlingHttpServletRequest;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;

import com.brunswick.ecomm.core.beans.UamRelationShipsBean;
import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractUamRetriever;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;


public class ShowContactsUAMTest {
	
	MockSlingHttpServletRequest request;
	@Rule
	public final AemContext context = createContext("/context/jcr-content-quickorder.json");
	private EcommSessionService adminService;
	private ShowContactsUAM fixture;
	private APIGEEService apigee;
	private transient UamRelationShipsBean relation;
	
	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");
		}, ResourceResolverType.JCR_MOCK);
	}

	@Before
	public void setup() throws IOException, JSONException {
		fixture = new ShowContactsUAM();
		request = context.request();
		apigee = Mockito.mock(APIGEEService.class);
		APIGEEService apigee = Mockito.mock(APIGEEService.class);
		adminService = Mockito.mock(EcommSessionService.class);
		context.registerService(EcommSessionService.class, adminService);
		context.registerService(APIGEEService.class, apigee);
		 context.registerInjectActivateService(fixture);
	}

	@Test
	public void doPostTest() throws IOException, LoginException {
		Gson gson = new Gson();
		ResourceResolver resolver = mock(ResourceResolver.class);
		when(adminService.getWriteServiceResourceResolver()).thenReturn(resolver);
		String data="{\"resourcePath\":\"test\",\"customerid\":\"test\",\"companyNumber\":\"test\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		String customerToken = "23pjbqgrhwict6xjzvg2tdr9vfjmkhja";
		request.setHeader("Authorization", "Bearer " + customerToken);
		JsonObject jsondata = new JsonObject();
		jsondata = gson.fromJson(data, JsonObject.class);
		try {
			if (context != null) {
				fixture.doGet(context.request(), context.response());
				return;
			}
		} catch (NullPointerException e) {
			
		}
	}

}

