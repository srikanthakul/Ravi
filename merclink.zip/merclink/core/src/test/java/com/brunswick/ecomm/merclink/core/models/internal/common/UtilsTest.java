package com.brunswick.ecomm.merclink.core.models.internal.common;

import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

class UtilsTest {

	private Utils retriever;
	private MagentoGraphqlClient mockClient;
	private static final Logger LOG = LoggerFactory.getLogger(UtilsTest.class);

	@BeforeEach
	public void setUp() {
		mockClient = mock(MagentoGraphqlClient.class);
		GraphqlResponse mockResponse = mock(GraphqlResponse.class);
		retriever = new Utils();
	}

	@Test
	public void buildPriceFormatter() {
		try {
			if (retriever != null) {
				mockClient.execute(toString());
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the buildPriceFormatter {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				Utils.buildPriceFormatter(null, toString());
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the buildPriceFormatter {}", e.getMessage());
		}
	}
}
