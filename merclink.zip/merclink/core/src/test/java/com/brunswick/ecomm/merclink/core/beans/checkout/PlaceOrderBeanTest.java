package com.brunswick.ecomm.merclink.core.beans.checkout;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PlaceOrderBeanTest {
	public PlaceOrderBean fixture;
	String test;

	@BeforeEach
	void setUp() throws Exception {
		fixture = new PlaceOrderBean();
	}

	@Test
	void testGetCollectAccNumber() {
		test = "word";
		 fixture.setCollectAccNumber(test);
		 assertEquals(test,fixture.getCollectAccNumber());
	}

	

	@Test
	void testGetCsRequestId() {
		test = "word";
		 fixture.setCsRequestId(test);
		 assertEquals(test,fixture.getCsRequestId());
	}

	

	@Test
	void testGetCredit_card_approval_code() {
		test = "word";
		 fixture.setCredit_card_approval_code(test);
		 assertEquals(test,fixture.getCredit_card_approval_code());
	}

	

	@Test
	void testGetCredit_card_approval_date() {
		test = "word";
		 fixture.setCredit_card_approval_date(test);
		 assertEquals(test,fixture.getCredit_card_approval_date());
	}

	

	@Test
	void testGetCredit_card_token() {
		test = "word";
		 fixture.setCredit_card_token(test);
		 assertEquals(test,fixture.getCredit_card_token());
	}

	

	@Test
	void testGetCredit_card_holder_name() {
		test = "word";
		 fixture.setCredit_card_holder_name(test);
		 assertEquals(test,fixture.getCredit_card_holder_name());
	}

	

	@Test
	void testGetCredit_card_expiration_date() {
		test = "word";
		 fixture.setCredit_card_expiration_date(test);
		 assertEquals(test,fixture.getCredit_card_expiration_date());
	}

	

	@Test
	void testGetPayment_method() {
		test = "word";
		 fixture.setPayment_method(test);
		 assertEquals(test,fixture.getPayment_method());
	}

	

	@Test
	void testGetShipping_method() {
		test = "word";
		 fixture.setShipping_method(test);
		 assertEquals(test,fixture.getShipping_method());
	}

	

	@Test
	void testGetShipping_cost() {
		test = "word";
		 fixture.setShipping_cost(test);
		 assertEquals(test,fixture.getShipping_cost());
	}

	

	@Test
	void testGetShipping_discount_amount() {
		test = "word";
		 fixture.setShipping_discount_amount(test);
		 assertEquals(test,fixture.getShipping_discount_amount());
	}

	

	@Test
	void testGetShipping_tax_amount() {
		test = "word";
		 fixture.setShipping_tax_amount(test);
		 assertEquals(test,fixture.getShipping_tax_amount());
	}

	

	@Test
	void testGetCartId() {
		test = "word";
		 fixture.setCartId(test);
		 assertEquals(test,fixture.getCartId());
	}

	

	@Test
	void testGetPonumber() {
		test = "word";
		 fixture.setPonumber(test);
		 assertEquals(test,fixture.getPonumber());
	}

	

	@Test
	void testGetOrdercomment() {
		test = "word";
		 fixture.setOrdercomment(test);
		 assertEquals(test,fixture.getOrdercomment());
	}

	

	@Test
	void testGetRequestedshipdate() {
		test = "word";
		 fixture.setRequestedshipdate(test);
		 assertEquals(test,fixture.getRequestedshipdate());
	}


}
