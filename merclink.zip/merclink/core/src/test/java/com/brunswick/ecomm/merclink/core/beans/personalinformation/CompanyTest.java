package com.brunswick.ecomm.merclink.core.beans.personalinformation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CompanyTest {
	public Company fixture;
	String test;
	Integer digits;

	@BeforeEach
	void setUp() throws Exception {
		fixture = new Company();
	}

	@Test
	void testGetId() {
		test="word";
		fixture.setId(test);
		assertEquals(test,fixture.getId());
	}


	@Test
	void testGetName() {
		test="word";
		fixture.setName(test);
		assertEquals(test,fixture.getName());
	}

	

	@Test
	void testGetFirstname() {
		test="word";
		fixture.setFirstname(test);
		assertEquals(test,fixture.getFirstname());
	}

	

	@Test
	void testGetLastname() {
		test="word";
		fixture.setLastname(test);
		assertEquals(test,fixture.getLastname());
	}

	

	@Test
	void testGetCustomer_number() {
		digits =12345;
		fixture.setCustomer_number(digits);
		assertEquals(digits,fixture.getCustomer_number());
	}

	

	@Test
	void testGetCustomer_type() {
		test="word";
		fixture.setCustomer_type(test);
		assertEquals(test,fixture.getCustomer_type());
	}

	

	@Test
	void testGetTelephone() {
		digits=12345;
		fixture.setTelephone(digits);
		assertEquals(digits,fixture.getTelephone());
	}

	

	@Test
	void testGetEmail() {
		test="word";
		fixture.setEmail(test);
		assertEquals(test,fixture.getEmail());
	}

	

}
