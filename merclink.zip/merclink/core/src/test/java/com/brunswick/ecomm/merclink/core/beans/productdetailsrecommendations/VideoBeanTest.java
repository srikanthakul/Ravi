package com.brunswick.ecomm.merclink.core.beans.productdetailsrecommendations;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.brunswick.ecomm.core.beans.productdetailsrecommendations.VideoBean;

class VideoBeanTest {
	VideoBean fixture;
	
	@BeforeEach
	public void setup() {
		fixture = new VideoBean();
	}

	@Test
	public void getAttach_identifer_custom_Test() {
		String expecteddata="city";
		fixture.setAttach_identifer_custom_(expecteddata);
		fixture.getAttach_identifer_custom_();
	}
	
	@Test
	public void getLabel_name_custom_Test() {
		String expecteddata="city";
		fixture.setLabel_name_custom_(expecteddata);
		fixture.getLabel_name_custom_();
	}
	
	@Test
	public void getDescription_custom_Test() {
		String expecteddata="city";
		fixture.setDescription_custom_(expecteddata);
		fixture.getDescription_custom_();
	}
	
	@Test
	public void getAttachment_custom_Test() {
		String expecteddata="city";
		fixture.setAttachment_custom_(expecteddata);
		fixture.getAttachment_custom_();
	}
	
	@Test
	public void getVisible_custom_Test() {
		String expecteddata="city";
		fixture.setVisible_custom_(expecteddata);
		fixture.getVisible_custom_();
	}
}
