package com.brunswick.ecomm.merclink.core.models;

import static org.junit.jupiter.api.Assertions.assertEquals;


import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

public class FacetObjTest {
	FacetObj fixture;
	@BeforeEach
	public void setup() {
		fixture = new FacetObj();
	}

	@Test
	public void getAttrCodeTest() {
		String expecteddata = "city";
		fixture.setAttrCode(expecteddata);
		fixture.getAttrCode();
	}
	@Test
	public void getFacetlabelTest() {
		String expecteddata = "city";
		fixture.setFacetLabel(expecteddata);
		fixture.getFacetLabel();
	}
	@Test
	public void getFacetListTest() {
		List<FacetOption> expecteddata = new ArrayList<FacetOption>();
		FacetOption data = new FacetOption();
		expecteddata.add(data );
		fixture.setFacetList(expecteddata);
		assertEquals(expecteddata,fixture.getFacetList());
	}
}