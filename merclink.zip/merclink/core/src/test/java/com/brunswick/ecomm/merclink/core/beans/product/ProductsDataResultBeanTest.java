package com.brunswick.ecomm.merclink.core.beans.product;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ProductsDataResultBeanTest {
    ProductsDataResultBean fixture;
	@BeforeEach
	void setUp() throws Exception {
		fixture = new ProductsDataResultBean();
	}

	@Test
	void testGetData() {
		List<ProductDataBean> expectedOutput = new ArrayList<ProductDataBean>();
		ProductDataBean data = new ProductDataBean();
		expectedOutput.add(data);
		fixture.setData(expectedOutput);
		assertEquals(expectedOutput, fixture.getData());
		
	}

}
