package com.brunswick.ecomm.merclink.core.servlets;


import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import javax.servlet.ServletException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.caconfig.ConfigurationBuilder;
import org.apache.sling.servlethelpers.MockSlingHttpServletRequest;
import org.apache.sling.servlethelpers.MockSlingHttpServletResponse;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.json.JSONArray;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.adobe.cq.commerce.core.components.internal.services.UrlProviderImpl;
import com.adobe.cq.commerce.core.components.services.ComponentsConfiguration;
import com.adobe.cq.commerce.core.components.services.urls.UrlProvider;
import com.brunswick.ecomm.merclink.core.components.testing.MockExternalizer;
import com.brunswick.ecomm.merclink.core.components.testing.Utils;
import com.day.cq.commons.Externalizer;
import com.day.cq.dam.api.Asset;
import com.google.common.collect.ImmutableMap;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;


public class ContactUsDropdownServletTest {         

	  @Mock
	  private transient ResourceResolverFactory resolverFactory;
	  @Mock
	  private transient ResourceResolver resolver;
	  @Mock
	  private transient Resource resource;
	  //private final AemContext context = new AemContext();
	  @InjectMocks
	  ContactUsDropdownServlet contactUsDropdownServlet;
	  Resource original;
	  JSONArray jsonObj = null;
	  Map<String,String> countryList = null;
	  Map<String,String> stateList = null;

	  @Rule
		public final AemContext context = createContext("/context/categoryTree.json");
	  
	  private static final ValueMap MOCK_CONFIGURATION = new ValueMapDecorator(
				ImmutableMap.of("cq:graphqlClient", "default", "magentoStore", "my-store"));

		private static final ComponentsConfiguration MOCK_CONFIGURATION_OBJECT = new ComponentsConfiguration(
				MOCK_CONFIGURATION);
	  private static AemContext createContext(String contentPath) {
			return new AemContext((AemContextCallback) context -> {
				// Load page structure
				context.load().json(contentPath, "/content");

				UrlProviderImpl urlProvider = new UrlProviderImpl();
				// urlProvider.activate(new MockUrlProviderConfiguration());
				context.registerService(UrlProvider.class, urlProvider);

				context.registerAdapter(Resource.class, ComponentsConfiguration.class,
						(Function) input -> !((Resource) input).getPath().contains("pageB") ? MOCK_CONFIGURATION_OBJECT
								: ComponentsConfiguration.EMPTY);

				context.registerService(Externalizer.class, new MockExternalizer());

				ConfigurationBuilder mockConfigBuilder = Utils.getDataLayerConfig(true);
				context.registerAdapter(Resource.class, ConfigurationBuilder.class, mockConfigBuilder);
			}, ResourceResolverType.JCR_MOCK);
		}
      @Before
      public void setUp() {
       //   MockitoAnnotations.initMocks(this);
    	contactUsDropdownServlet = new ContactUsDropdownServlet() ;
    	//contactUsDropdownServlet.init();
      }
  
      private ContactUsDropdownServlet fixture;
  	private MockSlingHttpServletRequest request;
  	private MockSlingHttpServletResponse response;
  	private static final String PAGE = "/content/";
  	private static final String CATEGORY_TREE = "/content/";
  	private String customerToken;
	  
     
     @Test
 	public void testdoGet() throws IOException, RuntimeException {

 		request = context.request();
 		response = context.response();
 		String data = "{ \"wishlistName\": \"mywishlist\",\"visibility\": \"PUBLIC\",\"resourcePath\": \"/content/pageA\",\"token\": \"r7ccftt50cguuu55wgvny13dxzlm5bum\" }";
 		Map<String, Object> params = new HashMap<>();
 		params.put("data", data);
 		request.setParameterMap(params);
 		request.setHeader("Authorization", "Bearer " + customerToken);
 		try {
			fixture.doGet(request, response);
		} catch (NullPointerException | ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
// 		String op = response.getOutputAsString();

 	}

	  
	  @Test
	 public void getCountryList() throws JSONException {
		  String jsonArray = "[{\"name\":\"Afghanistan\",\"subregion\":\"Southern Asia\",\"states\":[{\"id\":3898,\"name\":\"Urozgan\",\"state_code\":\"URU\"},{\"id\":3874,\"name\":\"Zabul\",\"state_code\":\"ZAB\"}]},{\"name\":\"India\",\"subregion\":\"Southern Asia\",\"states\":[{\"id\":3898,\"name\":\"Delhi\",\"state_code\":\"Del\"},{\"id\":3874,\"name\":\"Goa\",\"state_code\":\"Goa\"}]}]";
		  JSONArray json = new JSONArray(jsonArray); 
		  Map<String,String> map = contactUsDropdownServlet.getCountryList(json);
		  assertEquals("Afghanistan",map.get("country-1"));
		  assertEquals("India",map.get("country-2"));
	  }
	  
	  @Test
	 public void getStateList() throws JSONException {
		  String jsonArray = "[{\"name\":\"Afghanistan\",\"subregion\":\"Southern Asia\",\"states\":[{\"id\":3898,\"name\":\"Urozgan\",\"state_code\":\"URU\"},{\"id\":3874,\"name\":\"Zabul\",\"state_code\":\"ZAB\"}]},{\"name\":\"India\",\"subregion\":\"Southern Asia\",\"states\":[{\"id\":3898,\"name\":\"Delhi\",\"state_code\":\"Del\"},{\"id\":3874,\"name\":\"Goa\",\"state_code\":\"Goa\"}]}]";
		  JSONArray json = new JSONArray(jsonArray); 
		  Map<String,String> map = contactUsDropdownServlet.getStateList(json,"India");
		  assertEquals("Delhi",map.get("state-1"));
		  assertEquals("Goa",map.get("state-2"));
	  }
	  
 
       
}  
    
    

