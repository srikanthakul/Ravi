package com.brunswick.ecomm.merclink.core.models.internal.product;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AssetImplTest {
	
	AssetImpl fixture ;
	String test;
	Integer digits;

	@BeforeEach
	void setUp() throws Exception {
		fixture = new AssetImpl();
	}

	@Test
	void testGetLabel() {
		test = "word";
		fixture.setLabel(test);
		assertEquals(test,fixture.getLabel());
		
		
	}

	

	@Test
	void testGetPosition() {
		digits=1234;
		fixture.setPosition(digits);
		assertEquals(digits,fixture.getPosition());
		
	}

	

	@Test
	void testGetType() {
		test="word";
		fixture.setType(test);
		assertEquals(test,fixture.getType());
	}

	

	@Test
	void testGetPath() {
		test="word";
		fixture.setPath(test);
		assertEquals(test,fixture.getPath());
	}

	

	

}
