package com.brunswick.ecomm.merclink.core.beans.personalinformation;

import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CreateCompanyAddressTest {
	 
	public CreateCompanyAddress fixture;
	String test;
	Region regname;
	Integer digits;
	Boolean value;
	

	@BeforeEach
	void setUp() throws Exception {
		fixture = new CreateCompanyAddress();
	}

	@Test
	void testGetCity() {
		test="word";
		fixture.setCity(test);
		assertEquals(test,fixture.getCity());
	}

	

	@Test
	void testGetRegion() {
		regname=new Region();
		fixture.setRegion(regname);
		assertEquals(regname,fixture.getRegion());
	}

	

	@Test
	void testGetCountry_code() {
		test="word";
		fixture.setCountry_code(test);
		assertEquals(test,fixture.getCountry_code());
	}

	

	@Test
	void testGetStreet() {
		List<String> name = new ArrayList<String>();
		String someName = new String();
		name.add(someName);
		fixture.setStreet(name);
		assertEquals(name,fixture.getStreet());
	}

	

	@Test
	void testGetPostcode() {
		digits=12345;
		fixture.setPostcode(digits);
		assertEquals(digits,fixture.getPostcode());
	}

	

	@Test
	void testGetCompany_id() {
		test="word";
		fixture.setCompany_id(test);
		assertEquals(test,fixture.getCompany_id());
	}

	

	@Test
	void testGetAddress_type() {
		digits=12345;
		fixture.setAddress_type(digits);
		assertEquals(digits,fixture.getAddress_type());
	}

	

	@Test
	void testGetCustomer_type() {
		test="word";
		fixture.setCustomer_type(test);
		assertEquals(test,fixture.getCustomer_type());
	}

	

	@Test
	void testGetPrimary_flag() {
		test="word";
		fixture.setPrimary_flag(test);
		assertEquals(test,fixture.getPrimary_flag());
	}

	

	@Test
	void testGetFirstname() {
		test="word";
		fixture.setFirstname(test);
		assertEquals(test,fixture.getFirstname());
	}

	

	@Test
	void testGetLastname() {
		test="word";
		fixture.setLastname(test);
		assertEquals(test,fixture.getLastname());
	}

	

	@Test
	void testGetDefault_shipping() {
		test="word";
		fixture.setPrimary_flag(test);
		assertEquals(test,fixture.getPrimary_flag());
	}

	

	@Test
	void testGetDefault_billing() {
		value=true;
		fixture.setDefault_billing(value);
		assertEquals(value,fixture.getDefault_billing());
	}

	

}
