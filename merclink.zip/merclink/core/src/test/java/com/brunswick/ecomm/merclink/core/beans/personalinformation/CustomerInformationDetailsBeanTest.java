package com.brunswick.ecomm.merclink.core.beans.personalinformation;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CustomerInformationDetailsBeanTest {
	public CustomerInformationDetailsBean fixture;
    String test;
    CustomerBillingAddressBean name;
    
	@BeforeEach
	void setUp() throws Exception {
		fixture = new CustomerInformationDetailsBean();
	}

	@Test
	void testGetFirstname() {
		test="word";
		fixture.setFirstname(test);
		assertEquals(test,fixture.getFirstname());
	}

	

	@Test
	void testGetLastname() {
		test="word";
		fixture.setLastname(test);
		assertEquals(test,fixture.getLastname());
	}

	

	@Test
	void testGetEmail() {
		test="word";
		fixture.setEmail(test);
		assertEquals(test,fixture.getEmail());
	}

	

	@Test
	void testGetCompany_email() {
		test="word";
		fixture.setCompany_email(test);
		assertEquals(test,fixture.getCompany_email());
	}

	

	@Test
	void testGetCompany_name() {
		test="word";
		fixture.setCompany_name(test);
		assertEquals(test,fixture.getCompany_name());
	}

	

	@Test
	void testGetTelephone() {
		test="word";
		fixture.setTelephone(test);
		assertEquals(test,fixture.getTelephone());
	}

	

	@Test
	void testGetBilling_address() {
		name = new CustomerBillingAddressBean();
		fixture.setBilling_address(name);
		assertEquals(name,fixture.getBilling_address());
	}

	

	@Test
	void testGetShipping_addresses() {
		List<CustomerShippingAddressBean> someValue = new ArrayList<CustomerShippingAddressBean>();
		CustomerShippingAddressBean specificValue = new CustomerShippingAddressBean();
		someValue.add(specificValue);
		fixture.setShipping_addresses(someValue);
		assertEquals(someValue,fixture.getShipping_addresses());
	}

	

}
