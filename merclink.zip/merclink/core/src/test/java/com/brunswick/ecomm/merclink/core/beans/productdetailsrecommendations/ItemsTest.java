package com.brunswick.ecomm.merclink.core.beans.productdetailsrecommendations;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.brunswick.ecomm.core.beans.productdetailsrecommendations.RecommendationsBean;

class ItemsTest {
	Items fixture;

	@BeforeEach
	void setUp() throws Exception {
		fixture = new Items();
	}

	@Test
	void testGetItems() {
		List<RecommendationsBean> orderResults = new ArrayList<RecommendationsBean>();
		RecommendationsBean orderbean = new RecommendationsBean();
		orderResults.add(orderbean);
		fixture.setItems(orderResults);
		assertEquals(orderResults,fixture.getItems());
	}

}
