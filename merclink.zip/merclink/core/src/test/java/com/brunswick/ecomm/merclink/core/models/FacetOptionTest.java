package com.brunswick.ecomm.merclink.core.models;

import static org.junit.jupiter.api.Assertions.assertEquals;


import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

public class FacetOptionTest {
	FacetOption fixture;
	@BeforeEach
	public void setup() {
		fixture = new FacetOption();
	}

	@Test
	public void getAttrCodeTest() {
		String expecteddata = "city";
		fixture.setAttrCode(expecteddata);
		fixture.getAttrCode();
	}
	@Test
	public void getAttrlabelTest() {
		String expecteddata = "city";
		fixture.setAttrLabel(expecteddata);
		fixture.getAttrLabel();
	}
	@Test
	public void getAttrcountTest() {
		String expecteddata = "city";
		fixture.setAttrCount(expecteddata);
		fixture.getAttrCount();
	}
}
