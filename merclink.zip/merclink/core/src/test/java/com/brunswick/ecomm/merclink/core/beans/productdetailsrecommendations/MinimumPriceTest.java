package com.brunswick.ecomm.merclink.core.beans.productdetailsrecommendations;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MinimumPriceTest {

	MinimumPrice fixture;
	@BeforeEach
	public void setup() {
		fixture = new MinimumPrice();
	}
	
	@Test
	public void getFinal_priceTest() {
		FinalPriceBean expecteddata = new FinalPriceBean();
		fixture.setFinal_price(expecteddata );
		assertEquals(expecteddata,fixture.getFinal_price());
	}

}
