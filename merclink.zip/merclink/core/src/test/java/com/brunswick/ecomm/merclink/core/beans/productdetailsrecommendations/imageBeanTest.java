package com.brunswick.ecomm.merclink.core.beans.productdetailsrecommendations;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class imageBeanTest {

	imageBean fixture;
	@BeforeEach
	public void setup() {
		fixture = new imageBean();
	}
	
	@Test
	public void getImage_set_custom_Test() {
		String expecteddata="city";
		fixture.setImage_set_custom_(expecteddata);
		fixture.getImage_set_custom_();
	}
	
	@Test
	public void getProduct_thumbnail_custom_Test() {
		String expecteddata="city";
		fixture.setProduct_thumbnail_custom_(expecteddata);
		fixture.getProduct_thumbnail_custom_();
	}
	
	@Test
	public void getVideos_custom_Test() {
		String expecteddata="city";
		fixture.setVideos_custom_(expecteddata);
		fixture.getVideos_custom_();
	}

	@Test
	public void getProductattachment_custom_Test() {
		List<VideoBean> orderResults = new ArrayList<VideoBean>();
		VideoBean orderbean = new VideoBean();
		orderResults.add(orderbean );
		fixture.setProductattachment_custom_(orderResults);
		assertEquals(orderResults,fixture.getProductattachment_custom_());
	}
}

