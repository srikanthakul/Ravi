package com.brunswick.ecomm.merclink.core.utils;

import static org.mockito.Mockito.*;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.security.auth.Subject;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.abdera.model.DateTime;
import org.apache.oltu.oauth2.as.validator.AssertionValidator;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.opensaml.core.config.InitializationException;
import org.opensaml.core.config.InitializationService;
import org.opensaml.core.xml.io.UnmarshallingException;
import org.opensaml.saml1.core.Assertion;
import org.opensaml.saml1.core.SubjectStatement;
import org.opensaml.xmlsec.signature.support.SignatureException;
import org.slf4j.Logger;
import org.xml.sax.SAXException;

import com.adobe.cq.social.tally.client.api.Response;
import com.adobe.granite.workflow.model.ValidationException;
import com.day.cq.mcm.campaign.ConfigurationException;

import acscommons.io.jsonwebtoken.JwtException;

import static org.junit.jupiter.api.Assertions.*;


	 class SAMLResponseDataUtilTest {

	    private static final String SAML_RESPONSE = "SAMLResponse";

	    private AssertionValidator assertionValidator;

	    @Mock
	    private SlingHttpServletRequest request;

	    @Mock
	    private SlingHttpServletResponse response;

	    @Mock
	    private Response decodedResponse;

	    @Mock
	    private List<Assertion> assertions;

	    @Mock
	    private Assertion assertion;

	    @Mock
	    private List<SubjectStatement> subject;

	    @Mock
	    private DateTime onOrAfterTime;

	    @Mock
	    private Date todate;

	    @BeforeEach
	    void setUp() {
	        MockitoAnnotations.initMocks(this);
	        assertionValidator = new AssertionValidator();
	    }

	    @Test
	    void testValidateAssertionWithValidSamlResponse() throws UnsupportedEncodingException, ConfigurationException,
	            SAXException, IOException, UnmarshallingException, ParserConfigurationException, ValidationException,
	            SignatureException, ParseException, JwtException {

	        final String samlResponseString = "SAML Response";
	        final String username = "user";
	        final String sessionIndex = "session";
	        final String assertionId = "assertionId";


	        final SimpleDateFormat dateFormat = new SimpleDateFormat("yy-MM-dd'T'HH:mm:ss");
	        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));

	        final Date currentDate = dateFormat.parse("23-02-16T13:00:00");
	        final Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
	        cal.setTime(currentDate);

	        when(todate.getTime()).thenReturn(currentDate.getTime());

	    }
	    @Test
		void testGetDateInGMT() throws ParseException {
			// Arrange
			String date = "2023-02-16T10:30:00";
			String timeDiff = "0";
			Calendar expected = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
			expected.set(2023, 1, 16, 10, 30, 0);
			expected.set(Calendar.MILLISECOND, 0);	
		}
	    @Test
		void testGetAssertionsFromFederation() throws ConfigurationException, SAXException, IOException, 
					UnmarshallingException, ParserConfigurationException, InitializationException {
			
			
			final String responseString = "<saml2p:Response xmlns:saml2p=\"urn:oasis:names:tc:SAML:2.0:protocol\" "
					+ "xmlns:saml2=\"urn:oasis:names:tc:SAML:2.0:assertion\" ID=\"someid\" "
					+ "Version=\"2.0\" IssueInstant=\"2023-02-16T15:30:00Z\"> "
					+ "<saml2:Assertion>...</saml2:Assertion></saml2p:Response>";

			
			assertNotNull(response);

			
		}
	    }

