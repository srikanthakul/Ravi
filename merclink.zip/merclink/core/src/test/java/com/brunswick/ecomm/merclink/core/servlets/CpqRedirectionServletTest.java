package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.scripting.SlingBindings;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.apache.sling.testing.resourceresolver.MockResourceResolverFactory;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;

import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import com.brunswick.ecomm.core.services.apigee.impl.APIGEEServiceImpl;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

public class CpqRedirectionServletTest {

		@Rule
		public final AemContext context = createContext("/context/jcr-content-wishlist.json");
		
//		private static final ValueMap MOCK_CONFIGURATION = new ValueMapDecorator(
//				ImmutableMap.of("cq:graphqlClient", "default", "magentoStore", "anzpau_store_view_en"));
		
		private EcommSessionService adminService;
		private ResourceResolver resolver;
		private CpqRedirectionServlet fixture = new CpqRedirectionServlet();
		private APIGEEService apigee;
		private APIGEEServiceImpl mockServiceImpl;
		private static final String PAGE = "/content";
		private Resource pageResource;
		private Resource productResource;

		private static AemContext createContext(String contentPath) {
			return new AemContext((AemContextCallback) context -> {
				// Load page structure
				context.load().json(contentPath, "/content/ecommerce/merclink/au/en/mywishlists");
			}, ResourceResolverType.JCR_MOCK);
		}
		@Before
		public void setup() throws IOException, LoginException {
			fixture = new CpqRedirectionServlet();
			apigee = Mockito.mock(APIGEEService.class);
			APIGEEService apigee = Mockito.mock(APIGEEService.class);
			resolver = context.resourceResolver();
			adminService = Mockito.mock(EcommSessionService.class);
			MockResourceResolverFactory factory = new MockResourceResolverFactory();
			resolver = factory.getResourceResolver(null);
			
			//Page page = Mockito.spy(context.currentPage(PAGE));
			//pageResource = Mockito.spy(page.adaptTo(Resource.class));
			//when(page.adaptTo(Resource.class)).thenReturn(pageResource);
			String resourcePath ="/content/ecommerce/merclink/au/en/mywishlists";
			context.currentResource(resourcePath);
			productResource = Mockito.spy(context.resourceResolver().getResource(resourcePath));
			
			context.registerService(EcommSessionService.class, adminService);
			context.registerService(APIGEEService.class,apigee);
			context.registerService(ResourceResolver.class,resolver);
			context.registerInjectActivateService(fixture);
			
			SlingBindings slingBindings = (SlingBindings) context.request().getAttribute(SlingBindings.class.getName());
	        slingBindings.setResource(productResource);
	        //slingBindings.put(WCMBindingsConstants.NAME_CURRENT_PAGE, page);
	       // slingBindings.put(WCMBindingsConstants.NAME_PROPERTIES, productResource.getValueMap());
			
			
		}
		@Test
		public void orderNoSearchTest() throws IOException {
			String data = "{\"resourcePath\":\"/content/ecommerce/merclink/au/en/mywishlists\", \"orderInLast\":\"\",\"creditHold\":\"on\",\"startDate\":\"\",\"endDate\":\"\",\"currentPage\":\"/content/ecommerce/delcity/language-masters/en/open-order\",\"customerNumber\":\"590271\",\"orderNumber\":\"\",\"customerEmail\":\"test@infosys.com\",\"poNumber\":\"\"}";
			Map<String, Object> params = new HashMap<>();
			params.put("data", data);
			context.request().setParameterMap(params);
			try {
			if(fixture != null) {
				fixture.doPost(context.request(), context.response());
				}
			}catch(Exception e) {
				e.getMessage();
			}
		}
	}

