package com.brunswick.ecomm.merclink.core.models.retriever;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
import com.google.gson.JsonObject;

class AbstractReturntoAddressRetrieverTest {
	private AbstractReturntoAddressRetriever retriever;
	private MagentoGraphqlClient mockClient;
	Customer customer;
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractReturntoAddressRetriever.class);
	
	Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	JsonObject mutation = new JsonObject();

	@BeforeEach
	public void setUp() {
		mockClient = mock(MagentoGraphqlClient.class);

		GraphqlResponse<JsonObject, Error> mockResponse = mock(GraphqlResponse.class);
		when(mockClient.executeQuery(any())).thenReturn(mockResponse);
		when(mockClient.executeJsonMutation(any())).thenReturn(mockResponse);
		when(mockResponse.getData()).thenReturn(mutation);

		retriever = new AbstractReturntoAddressRetriever(mockClient);
		
	}

	@Test
	public void getReturntoAddressDetailstest() {
		String sampleQuery = "query{\r\n" + "warehouse\r\n" + "(name:\"DWC Del City West Coast Distribution\")\r\n"
				+ "{type \r\n" + "name \r\n" + "address}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractReturntoAddressRetrieverTest {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.getReturntoAddressDetails();
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractReturntoAddressRetrieverTest {}", e.getMessage());
		}
	}

}
