package com.brunswick.ecomm.merclink.core.models.internal.cart;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

class AbstractCartRetrieverTest {
	private AbstractCartRetriever retriever;
	private MagentoGraphqlClient mockClient;
	Customer customer;
	private static final Logger LOG = LoggerFactory.getLogger(AbstractCartRetrieverTest.class);
	GraphqlResponse<Mutation, Error> response = mock(GraphqlResponse.class);
	Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	Mutation mutation = mock(Mutation.class);

	@BeforeEach
	public void setUp() {
		mockClient = mock(MagentoGraphqlClient.class);

		GraphqlResponse mockResponse = mock(GraphqlResponse.class);
		when(mockClient.execute(any())).thenReturn(mockResponse);
		when(response.getData()).thenReturn(mutation);
		when(mockResponse.getData()).thenReturn(mockQuery);
		when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());

		retriever = new AbstractCartRetriever(mockClient);
	}

	@Test
	public void generateCartPageQuery() {
		String queryString = "{\r\n" + "cart(cart_id: \\r\n" + "email \r\n" + "items { \r\n" + "id \r\n"
				+ "item_attributes{  \r\n" + "availability_date" + "backorder_qty \r\n" + "customer_adjustments\r\n"
				+ "tier_price\r\n" + "customer_price\r\n" + "availability\r\n" + "}\r\n" + "product {\r\n" + "cart"
				+ "sku \r\n" + "masterpartprop65code\r\n" + "product_data {\r\n" + "weight\r\n" + "weight_unit\r\n"
				+ "masterpartlowestsellinguomqty\r\n" + "warning_message\r\n" + "}\r\n" + "}\r\n" + "quantity\r\n"
				+ "cpq_session\r\n" + "}\r\n" + "}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateCartPageQuery {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.cartPageQuery(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateCartPageQuery {}", e.getMessage());
		}
	}

	@Test
	public void generatecartQuery() {
		String queryString = "{\r\n" + "cart(cart_id: \\\r\n" + "email\r\n" + "is_dropship\r\n" + "billing_address{\r\n"
				+ "city{\r\n" + "country{\r\n" + "code\r\n" + "label\r\n" + "}\r\n" + "firstname\r\n" + "lastname\r\n"
				+ "company_address_id \r\n" + "postcode{\r\n" + "region {\r\n" + "code\r\n" + "label\r\n" + "}\r\n"
				+ "street\r\n" + "telephone\r\n" + "}\r\n" + "shipping_addresses { \r\n" + "firstname\r\n"
				+ "lastname\r\n" + "company_address_id \r\n" + "street\r\n" + "city\r\n" + "region { \r\n" + "code\r\n"
				+ "label\r\n" + "}\r\n" + "telephone\r\n" + "pickup_location_code\r\n"
				+ "available_shipping_methods { \r\n" + "amount {\r\n" + "currency\r\n" + "value \r\n" + "}\r\n"
				+ "available\r\n" + "company_address_id \r\n" + "carrier_code\r\n" + "carrier_title \r\n"
				+ "error_message\r\n" + "method_code \r\n" + "method_title\r\n" + "price_excl_tax { \r\n" + "value\r\n"
				+ "currency \r\n" + "}\r\n" + "price_incl_tax {  \r\n" + "value\r\n" + "currency \r\n" + "}\r\n"
				+ "} \r\n" + "selected_shipping_method {\r\n" + "amount { \r\n" + "value\r\n" + "currency \r\n"
				+ "}\r\n" + "carrier_title \r\n" + "error_message\r\n" + "method_code \r\n" + "method_title\r\n"
				+ "} \r\n" + "} \r\n" + "items { \r\n" + "id\r\n" + "item_attributes{  \r\n" + "availability_date\r\n"
				+ "backorder_qty \r\n" + "customer_adjustments\r\n" + "tier_price \r\n" + "customer_price\r\n"
				+ "availability \r\n" + "}\r\n" + " product {  \r\n" + "name\r\n" + "sku \r\n"
				+ "masterpartprop65code\r\n" + "product_data { \r\n" + "method_title\r\n" + "weight \r\n"
				+ "weight_unit\r\n" + "masterpartlowestsellinguomqty \r\n" + "warning_message\r\n" + "}\r\n" + "}\r\n"
				+ "quantity \r\n" + "}\r\n" + "available_payment_methods { \r\n" + "code\r\n" + "title \r\n" + "}\r\n"
				+ "applied_coupons \r\n" + "code\r\n" + "}\r\n" + "prices { \r\n" + "minimum_charge{ \r\n"
				+ "chargecode\r\n" + "minimum \r\n" + "message\r\n" + "}\r\n" + "grand_total {  \r\n" + "value\r\n"
				+ "currency \r\n" + "}\r\n" + "quantity \r\n" + "}\r\n" + "applied_taxes { \r\n" + "label\r\n"
				+ "amount{ \r\n" + "}\r\n" + "value \r\n" + "}\r\n" + "}\r\n" + "}\r\n" + "}\r\n" + "}";

		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generatecartQuery {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.cartQuery(queryString, true);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generatecartQuery {}", e.getMessage());
		}
	}

	@Test
	public void generatebulkcartQuery() {
		String queryString = "{\r\n" + "cart(cart_id: \\\r\n" + "email\r\n" + "billing_address {\r\n" + "city{\r\n"
				+ "country{\r\n" + "code\r\n" + "label\r\n" + "}\r\n" + "firstname\r\n" + "lastname\r\n"
				+ "company_address_id \r\n" + "postcode{\r\n" + "region {\r\n" + "code\r\n" + "label\r\n" + "}\r\n"
				+ "firstname\r\n" + "lastname\r\n" + "company_address_id \r\n" + "street {{\r\n" + "city \r\n"
				+ "region {\r\n" + "code\r\n" + "label\r\n" + "}\r\n" + "country  {\r\n" + "code\r\n" + "label\r\n"
				+ "}\r\n" + "telephone \r\n" + "pickup_location_code\r\n" + "available_shipping_methods { \r\n"
				+ "amount {\r\n" + "currency \r\n" + "value\r\n" + "}\r\n" + " available  \r\n" + "carrier_code \r\n"
				+ "carrier_title\r\n" + "error_message  \r\n" + "method_code\r\n" + "method_title \r\n" + "}\r\n"
				+ "selected_shipping_method { \r\n" + "amount {\r\n" + "value\r\n" + "currency \r\n" + "}\r\n"
				+ "carrier_code \r\n" + "carrier_title\r\n" + "method_code\r\n" + "method_title \r\n" + "quantity \r\n"
				+ "}\r\n" + "}\r\n" + "available_payment_methods { \r\n" + "code\r\n" + "title \r\n" + "}\r\n" + "}";

		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generatebulkcartQuery {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.bulkcartQuery(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generatebulkcartQuery {}", e.getMessage());
		}
	}

	@Test
	public void generatecartPrice() {
		String queryString = "{\r\n" + "cart(cart_id: \\\r\n" + "prices {\r\n" + "minimum_charge {\r\n"
				+ "chargecode \r\n" + "minimum \r\n" + "message \r\n" + "}\r\n" + "shipping_priority {\r\n" + "code\r\n"
				+ "title\r\n" + "value\r\n" + "} \r\n" + "grand_total {\r\n" + "value\r\n" + "currency\r\n" + "}\r\n"
				+ "applied_taxes {  \r\n" + "label\r\n" + "amount { \r\n" + "value\r\n" + "}\r\n" + "}\r\n" + "}\r\n"
				+ "}\r\n" + "}";

		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generatecartPrice {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.cartPrice(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generatecartPrice {}", e.getMessage());
		}
	}

	@Test
	public void generateshippingMethodCartQuery() {
		String queryString = "{\r\n" + "cart(cart_id: \\\r\n" + "prices {\r\n" + "minimum_charge {\r\n"
				+ "chargecode{\r\n" + "minimum \r\n" + "message \r\n" + "}\r\n" + " shipping_priority {\r\n"
				+ "code\r\n" + "title\r\n" + "value\r\n" + "} \r\n" + "grand_total {\r\n" + "value\r\n" + "currency\r\n"
				+ "}\r\n" + "applied_taxes {  \r\n" + "label\r\n" + "amount { \r\n" + "value\r\n" + "}\r\n" + "}\r\n"
				+ "}\r\n" + "}\r\n" + "shipping_addresses {{\r\n" + "firstname\r\n" + "lastname\r\n"
				+ "company_address_id \r\n" + "street {{\r\n" + "city \r\n" + "region {\r\n" + "code\r\n" + "label\r\n"
				+ "}\r\n" + "country {\r\n" + "code\r\n" + "label\r\n" + "telephone \r\n" + "pickup_location_code\r\n"
				+ "selected_shipping_method { \r\n" + "amount {\r\n" + "value \r\n" + "currency\r\n" + "}\r\n"
				+ " carrier_code \r\n" + "carrier_title \r\n" + "method_code\r\n" + "method_title \r\n" + "}\r\n"
				+ "}\r\n" + "}\r\n" + "}";

		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateshippingMethodCartQuery {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.shippingMethodCartQuery(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateshippingMethodCartQuery {}", e.getMessage());
		}
	}

	@Test
	public void generateRemoveCartItemPriceQuery() {
		String queryString = "{\r\n" + "cart(cart_id: \\\r\n" + "prices {\r\n" + "minimum_charge {\r\n"
				+ "chargecode \r\n" + "minimum \r\n" + "message \r\n" + "}\r\n" + "shipping_priority {\r\n" + "code\r\n"
				+ "title\r\n" + "value\r\n" + "} \r\n" + "grand_total {\r\n" + "value\r\n" + "currency\r\n" + "}\r\n"
				+ "applied_taxes {  \r\n" + "label\r\n" + "amount { \r\n" + "value\r\n" + "}\r\n" + "}\r\n" + "}\r\n"
				+ "}\r\n" + "}";

		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateRemoveCartItemPriceQuery {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.RemoveCartItemPriceQuery(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateRemoveCartItemPriceQuery {}", e.getMessage());
		}
	}

	@Test
	public void generateCartId() {
		String queryString = "{\r\n" + "customerCart(company_customer_number: \\\r\n" + "id\r\n" + "erp_errors {\r\n"
				+ "message\r\n" + "code\r\n" + "}\r\n" + "}\r\n" + "}";

		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateCartId {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.createCartId(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateCartId {}", e.getMessage());
		}
	}

	@Test
	public void generateAddToCart() {
		String queryString = "mutation{\r\n" + "addProductsToCart(\r\n" + "cartId:  \\\r\n" + "cartItems: [\r\n"
				+ "listSeperator1\r\n" + "]\r\n" + "){\r\n" + "cart {\r\n" + "items {\r\n" + "product {\r\n"
				+ "name\r\n" + "sku\r\n" + "} \r\n" + "quantity\r\n" + "}\r\n" + "erp_errors {\r\n" + "message\r\n"
				+ "code \r\n" + "}\r\n" + "} \r\n" + "user_errors {\r\n" + "message \r\n" + "code\r\n" + "}\r\n"
				+ "}\r\n" + "}";

		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateAddToCart {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.addToCartQuery(queryString, null);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateAddToCart {}", e.getMessage());
		}
	}

	@Test
	public void generatUpdateCart() {
		String queryString = "{\r\n" + "updateCartItems(\r\n" + "input: { \r\n" + " cart_id: \\\r\n"
				+ "cart_items: [\r\n" + "]\r\n" + "}\r\n" + ")}\r\n" + "cart {\r\n" + "items {\r\n" + "uid\r\n"
				+ " product { \r\n" + "name \r\n" + "}\r\n" + "quantity \r\n" + "}\r\n" + "prices { \r\n"
				+ " grand_total{ \r\n" + "value\r\n" + "currency \r\n" + "}\r\n" + "}\r\n" + "}\r\n" + "}\r\n" + "}";

		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generatUpdateCart {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.updateCartQuery(queryString, null);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generatUpdateCart {}", e.getMessage());
		}
	}

	@Test
	public void generateCartSummary() {
		String queryString = "mutation\r\n" + "cartCount(input: {\r\n" + " cart_id:  \\\r\n" + "}\r\n" + "){\r\n"
				+ "item_count\r\n" + "cart_updatedat\r\n" + "errors{\r\n" + "message\r\n" + "}\r\n" + "}\r\n" + "}";

		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateCartSummary {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.cartSummary(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateCartSummary {}", e.getMessage());
		}
	}

	@Test
	public void generateValidateCart() {
		String queryString = "{\r\n" + " ValidateUserCompany(cartId:\\\r\n" + "companyCustomerNumber:\\\r\n"
				+ "status\r\n" + "errortype \r\n" + "message\r\n" + "cartCompany\r\n" + "}\r\n" + "}";

		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateValidateCart {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.validateCart(queryString, queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateValidateCart {}", e.getMessage());
		}
	}

}
