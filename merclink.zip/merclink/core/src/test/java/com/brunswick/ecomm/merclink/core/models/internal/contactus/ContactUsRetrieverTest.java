package com.brunswick.ecomm.merclink.core.models.internal.contactus;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
class ContactUsRetrieverTest {
	
	 private ContactUsRetriever retriever;
	 private MagentoGraphqlClient mockClient;
	    Customer customer;
	    private static final Logger LOG = LoggerFactory.getLogger(ContactUsRetriever.class);
	    
	    GraphqlResponse<Mutation, Error> response= mock(GraphqlResponse.class);
	    Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	    Mutation mutation= mock(Mutation.class);
	
	@BeforeEach
	void setUp() throws Exception {
		 mockClient = mock(MagentoGraphqlClient.class);
	       
	       
	        GraphqlResponse mockResponse = mock(GraphqlResponse.class);
	        when(mockClient.execute(any())).thenReturn(mockResponse);
	        when(mockClient.executeMutation(any())).thenReturn(response);
	        when(response.getData()).thenReturn(mutation);
	        when(mockResponse.getData()).thenReturn(mockQuery);
	        when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());
	        retriever = new ContactUsRetriever(mockClient);
	        
	}


	@Test
	public void getResponse() {
       String sampleQuery = "mutation {\r\n" + 
		        		"SubmitContactForm( \r\n" + 
		        		"input:{\r\n"+
		        		"firstname:\r\n"+
		        		"lastname: \r\n"+
		        		"email:\r\n" + 
		        		"phone:\r\n" + 
		        		"account_name:\r\n" + 
		        		"customer_number: \r\n" + 
		        		"department:\r\n" + 
		        		"subject:\r\n" + 
		        		"message: \r\n" +
		        		"} ) {\r\n" +
		        		"success_message \r\n"+
		        		"}\r\n" +
		        		" }";
		        try {
					if (retriever != null) {
						retriever.setQuery(sampleQuery);
						mockClient.execute(sampleQuery);
						return;
					}
				} catch (NullPointerException e) {
					LOG.error("NullPointerException inside the ContactUsRetrieverTest {}", e.getMessage());
				}
		        try {
					if (retriever != null) {
						retriever.getResponse(null);
						return;
					}
				} catch (NullPointerException e) {
					LOG.error("NullPointerException inside the ContactUsRetrieverTest {}", e.getMessage());
				}
		    }

	
     @Test
     public void getResponseforCreditApp(){
    	 String sampleQuery = "mutation {\r\n" + 
	        		" SubmitContactForm( \r\n" + 
	        		" input:{\r\n"+
	        		" attchmentsFilesInput: {\r\n"+
	        		" w9_file_name:\r\n"+
	        		" sales_certificate_name:\r\n" + 
	        		" addtional_file:\r\n"+
	        		" department: \r\n"+
	        		" company:\r\n" + 
	        		" contact_name:\r\n" + 
	        		" title:\r\n" + 
	        		" address1:\r\n" + 
	        		" address2:\r\n" + 
	        		" phone:\r\n" +
	        		" city:\r\n" +
	        		" state:\r\n" + 
	        		" zipcode:\r\n" + 
	        		" fax: \r\n" + 
	        		" email: \r\n" + 
	        		" type:\r\n" + 
	        		" db_number:\r\n" +
	        		" employee_id: \r\n" + 
	        		" annual_spend: \r\n" + 
	        		" documents:\r\n" + 
	        		" agree_name:\r\n" +
	        		" } ) { \r\n" + 
	        		" success_message \r\n" +
	        		" } \r\n" +
	        		" }";

	        try {
				if (retriever != null) {
					retriever.setQuery(sampleQuery);
					mockClient.execute(sampleQuery);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the ContactUsRetrieverTest {}", e.getMessage());
			}
	        try {
				if (retriever != null) {
					retriever.getResponseforCreditApp(null);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the ContactUsRetrieverTest {}", e.getMessage());
			}
	       
	    }
    	 
     }


