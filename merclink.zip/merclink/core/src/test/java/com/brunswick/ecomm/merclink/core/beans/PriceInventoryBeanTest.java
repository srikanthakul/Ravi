package com.brunswick.ecomm.merclink.core.beans;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class PriceInventoryBeanTest {
	PriceInventoryBean fixture;

	@BeforeEach
	public void setup() {
		fixture = new PriceInventoryBean();
	}

	@Test
	public void getitem_numberTest() {
		String expecteddata = "city";
		fixture.setItem_number(expecteddata);
		fixture.getItem_number();
	}

}
