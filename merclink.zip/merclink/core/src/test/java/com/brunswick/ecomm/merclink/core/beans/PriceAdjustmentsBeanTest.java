package com.brunswick.ecomm.merclink.core.beans;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class PriceAdjustmentsBeanTest {

	PriceAdjustmentsBean fixture;

	@BeforeEach
	public void setup() {
		fixture = new PriceAdjustmentsBean();
	}

	@Test
	public void getNameTest() {
		String expecteddata = "city";
		fixture.setName(expecteddata);
		fixture.getName();
	}

	@Test
	public void getvalueTest() {
		String expecteddata = "city";
		fixture.setValue(expecteddata);
		fixture.getValue();
	}

}
