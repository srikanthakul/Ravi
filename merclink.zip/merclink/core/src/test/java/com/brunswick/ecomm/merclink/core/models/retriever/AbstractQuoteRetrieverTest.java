package com.brunswick.ecomm.merclink.core.models.retriever;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.json.JSONException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

class AbstractQuoteRetrieverTest {
	private AbstractQuoteRetriever retriever;
	private MagentoGraphqlClient mockClient;
	Customer customer;
	private static final Logger LOG = LoggerFactory.getLogger(AbstractQuoteRetrieverTest.class);
	GraphqlResponse<Mutation, Error> response = mock(GraphqlResponse.class);
	Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	Mutation mutation = mock(Mutation.class);

	@BeforeEach
	public void setUp() {
		mockClient = mock(MagentoGraphqlClient.class);

		GraphqlResponse mockResponse = mock(GraphqlResponse.class);
		when(mockClient.execute(any())).thenReturn(mockResponse);
		when(response.getData()).thenReturn(mutation);
		when(mockResponse.getData()).thenReturn(mockQuery);
		when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());

		retriever = new AbstractQuoteRetriever(mockClient);
	}

	@Test
	public void generateCloseQuote() {
		String queryString = "mutation{\r\n" + "closeNegotiableQuotes(\r\n" + "placeBulkOrder( \r\n"
				+ "input: {quote_uids: [\r\n" + "\\r\n" + "[\r\n" + "quote_close_reason\r\n" + "\\r\n" + "}\r\n"
				+ ") {\r\n" + "closed_quotes {\r\n" + "uid\r\n" + "name\r\n" + "status\r\n" + "}\r\n"
				+ "negotiable_quotes {\r\n" + "total_count\r\n" + "items {\r\n" + "uid\r\n" + "name\r\n" + "status\r\n"
				+ "}\r\n" + "}\r\n" + "}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateCloseQuote {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.createCloseQuote(queryString, queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateCloseQuote {}", e.getMessage());
		}
	}

	@Test
	public void generateChildUserDetailQuery() {
		String queryString = "query{\r\n" + "ChildUsers(companyNumber:\r\n" + "){\r\n" + "customerid\r\n"
				+ "firstname\r\n" + "middlename\r\n" + "lastname\r\n" + "email\r\n" + "telephone\r\n"
				+ "permissions\r\n" + "start_date\r\n" + "end_date\r\n" + "}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateChildUserDetailQuery {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.childUserDetails(null);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateCloseQuote {}", e.getMessage());
		}
	}

	@Test
	public void updateNegotiableQuoteQuantities() {
		String queryString = "mutation{\r\n" + "updateNegotiableQuoteQuantities(input: {\r\n" + "quote_uid: \\ \r\n"
				+ "comment: \\\r\n" + "items: [\r\n" + "{ quote_item_uid: \\\r\n" + "quantity: \r\n" + "]\r\n" + "}\r\n"
				+ ") {\r\n" + "quote {\r\n" + "uid\r\n" + "name\r\n" + "updated_at\r\n" + "items {\r\n" + "uid {\r\n"
				+ "product {\r\n" + "uid\r\n" + "sku\r\n" + "name\r\n" + "}\r\n" + "quantity\r\n" + "prices {\r\n"
				+ "price {\r\n" + "value\r\n" + "}\r\n" + "}\r\n" + "}\r\n" + "}\r\n" + "}\r\n" + "}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the updateNegotiableQuoteQuantities {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.createUpdateQuote(queryString, queryString, null);
				return;
			}
		} catch (JSONException e) {
			LOG.error("JSONException inside the generateCloseQuote {}", e.getMessage());
		}
	}

	@Test
	public void generateCreateQuotesQueryDefinition() {
		String queryString = "{ item_sku: \\\r\n" + "order_quantity:\r\n" + "estimated_annual_usage: \\ \r\n"
				+ "target_price: \\\r\n" + "mutation { requestNegotiableQuote( input: { \r\n" + "quote_name: \\\r\n"
				+ "customer_number: \\\r\n" + "firstname: \\\r\n" + "lastname: \\\r\n" + "account_name: \\\r\n"
				+ "email: \\\r\n" + "phone_number: \\" + "company_name: \\name\r\n" + "items: [\r\n" + "comment: {\r\n"
				+ "comment: \\\r\n" + "} }  ) { quote { uid }}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateCloseQuote {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.createQuote(null);
				return;
			}
		} catch (JSONException e) {
			LOG.error("JSONException inside the generateCloseQuote {}", e.getMessage());
		}
	}

	@Test
	public void generateCustomerToken() {
		String queryString = "mutation{\r\n" + "generateCustomerTokenAsAdmin(input: {\r\n" + "customer_email: \\ \r\n"
				+ "}){\r\n" + "customer_token \r\n" + "}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateCloseQuote {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.createManualLogin(queryString);
				return;
			}
		} catch (JSONException e) {
			LOG.error("JSONException inside the generateCloseQuote {}", e.getMessage());
		}
	}

	@Test
	public void getNegotiableQuotesDefinition() {
		String queryString = "query {\r\n" + "negotiableQuotes(filter: {\r\n" + "name: {\r\n" + "match:\r\n"
				+ "items {\\r\n" + "uid\r\n" + "name\r\n" + "buyer {\r\n" + "firstname\r\n" + "lastname\r\n" + "}\r\n"
				+ "salesRep\r\n" + "created_at \r\n" + "expiration_date\r\n" + "status\r\n" + "}\r\n"
				+ "total_count\r\n" + "}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the getNegotiableQuotesDefinition {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.getNegotiableQuotes();
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the getNegotiableQuotesDefinition {}", e.getMessage());
		}
	}

	@Test
	public void generatecreateCompanyUserQuery() {
		String queryString = "mutation {\r\n" + "createCompanyUser(\r\n" + "input: {\r\n" + "email: \\\r\n"
				+ "firstname: \\ \\r\n" + "lastname: \\\r\n" + "middlename: \\\r\n" + "job_title: \\ \r\n"
				+ "status:\r\n" + "telephone:\r\n" + "start_date:\r\n" + "end_date:\r\n" + "permissions: \\\r\n"
				+ "} ){\r\n" + "user {\r\n" + "created_at\r\n" + "email\r\n" + "}\r\n" + "}\r\n" + "}";
		try {
			if (retriever != null) {
				retriever.setQuery(queryString);
				mockClient.execute(queryString);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateChildUserDetailQuery {}", e.getMessage());
		}
		try {
			if (retriever != null) {
				retriever.createCompanyUser(null);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the generateChildUserDetailQuery {}", e.getMessage());
		}
	}
}
