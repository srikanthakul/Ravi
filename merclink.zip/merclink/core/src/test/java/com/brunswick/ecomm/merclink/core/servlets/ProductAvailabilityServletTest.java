package com.brunswick.ecomm.merclink.core.servlets;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.apache.sling.testing.resourceresolver.MockResourceResolverFactory;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;
import com.brunswick.ecomm.core.services.EcommSessionService;
import com.brunswick.ecomm.core.services.apigee.APIGEEService;
import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;

public class ProductAvailabilityServletTest {
	@Rule
	public final AemContext context = createContext("/context/jcr-content-productavailability.json");
	private EcommSessionService adminService;
	private APIGEEService apigee;
	private ResourceResolver resolver;
	private ProductAvailabilityServlet fixture = new ProductAvailabilityServlet();
	
	private AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");
		}, ResourceResolverType.JCR_MOCK);
	}
	
	@Before
	public void setup() throws IOException, LoginException {
		fixture = new ProductAvailabilityServlet();
		apigee = Mockito.mock(APIGEEService.class);
		APIGEEService apigee = Mockito.mock(APIGEEService.class);
		resolver = context.resourceResolver();
		adminService = Mockito.mock(EcommSessionService.class);
		MockResourceResolverFactory factory = new MockResourceResolverFactory();
		resolver = factory.getResourceResolver(null);
		context.registerService(EcommSessionService.class, adminService);
		context.registerService(APIGEEService.class,apigee);
		context.registerService(ResourceResolver.class,resolver);
		context.registerInjectActivateService(fixture);
	}
	
	@Test
	public void productAvailabilityServletDoPostTest() throws IOException{
		String data = "{\"itemNumber\":\"12345\",\"resourcePath\":\"/content/ecommerce/merclink/language-masters/en/product-listing\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		try {
			if(fixture != null) {
		fixture.doPost(context.request(), context.response());
			}
		}catch(Exception e) {
			e.getMessage();		}
	}

}
