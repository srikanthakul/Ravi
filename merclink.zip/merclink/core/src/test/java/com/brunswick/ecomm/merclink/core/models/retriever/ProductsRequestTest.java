package com.brunswick.ecomm.merclink.core.models.retriever;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.brunswick.ecomm.merclink.core.models.FacetObj;

class ProductsRequestTest {
	
	private String categoryId;
	private String categoryPath;
	private String currentPageNo;
	private String pageSize;
	private String sort;
	private String customerNumber;
	private ProductsRequest fixture;

	@BeforeEach
	void setUp() throws Exception {
		fixture = new ProductsRequest();
	}

	@Test
	void testGetCategoryId() {
		 categoryId="categoryId";
		 fixture.setCategoryId(categoryId);
		 assertEquals(categoryId, fixture.getCategoryId());
	}

	@Test
	void testGetCategoryPath() {
		categoryPath="categoryPath";
		fixture.setCategoryPath(categoryPath);
		assertEquals(categoryPath, fixture.categoryPath);
	}
	@Test
	void testGetCurrentPageNo() {
		currentPageNo="currentPageNo";
		fixture.setCurrentPageNo(currentPageNo);
		assertEquals(currentPageNo, fixture.currentPageNo);
	}

	@Test
	void testGetPageSize() {
		pageSize="pageSize";
		fixture.setPageSize(pageSize);
		assertEquals(pageSize, fixture.pageSize);
	}

	@Test
	void testGetSort() {
		sort="sort";
		fixture.setSort(sort);;
		assertEquals(sort, fixture.sort);
	}

	@Test
	void testGetFilterMap() {
		List<FacetObj> expectedData = new ArrayList<FacetObj>();
		FacetObj filterMap = new FacetObj();
		expectedData.add(filterMap);
		fixture.setFilterMap(expectedData);
		assertEquals(expectedData, fixture.getFilterMap());
	}

	@Test
	void testGetCustomerNumber() {
		customerNumber="customerNumber";
		fixture.setCustomerNumber(customerNumber);;
		assertEquals(customerNumber, fixture.customerNumber);
	}


}
