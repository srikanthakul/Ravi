package com.brunswick.ecomm.merclink.core.models.retriever;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.Error;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;
class AbstractQuickOrderRetrieverTest {
	
	 private AbstractQuickOrderRetriever retriever;
	 private MagentoGraphqlClient mockClient;
	    Customer customer;
	    private static final Logger LOG = LoggerFactory.getLogger(AbstractQuickOrderRetriever.class);
	    
	    GraphqlResponse<Mutation, Error> response= mock(GraphqlResponse.class);
	    Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	    Mutation mutation= mock(Mutation.class);
	
	@BeforeEach
	void setUp() throws Exception {
		 mockClient = mock(MagentoGraphqlClient.class);
	       
	       
	        GraphqlResponse mockResponse = mock(GraphqlResponse.class);
	        when(mockClient.execute(any())).thenReturn(mockResponse);
	        when(mockClient.executeMutation(any())).thenReturn(response);
	        when(response.getData()).thenReturn(mutation);
	        when(mockResponse.getData()).thenReturn(mockQuery);
	        when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());
	        retriever = new AbstractQuickOrderRetriever(mockClient);
	        
	}


	@Test
	public void QuickOrderSingleItem() {
       String sampleQuery = "{{ \r\n" + 
		        		" quickOrderProductsAnzp( \r\n" + 
		        		" filter: { sku: { in: [\"My item\"]}}\r\n"+
		        		" pageSize: 999 \r\n"+
		        		" erpData: { \r\n"+
		        		" customer_number :\"Cust number\"\r\n" + 
		        		" }\r\n" + 
		        		" ) {\r\n" + 
		        		" items {\r\n" + 
		        		" id\r\n" + 
		        		" sku\r\n" + 
		        		" stock_status \r\n" +
		        		" masterpartlowestsellinguomqty\r\n" +
		        		" item_number \r\n"+
		        		" ss_item_number\r\n" +
		        		" description\r\n" +
		        		" availability \r\n" + 
		        		" warehouse_total \r\n" +
		        		" estimated_availability_date \r\n" +
		        		" }\r\n" + 
		        		" user_errors { \r\n" +
		        		" message \r\n" + 
		        		" }}}";
		        try {
					if (retriever != null) {
						retriever.setQuery(sampleQuery);
						mockClient.execute(sampleQuery);
						return;
					}
				} catch (NullPointerException e) {
					LOG.error("NullPointerException inside the AbstractQuickOrderRetriever {}", e.getMessage());
				}
		        try {
					if (retriever != null) {
						retriever.quickOrderSingleItem(sampleQuery, sampleQuery);
						return;
					}
				} catch (NullPointerException e) {
					LOG.error("NullPointerException inside the AbstractQuickOrderRetriever {}", e.getMessage());
				}
		    }

	
     @Test
     public void generatebulkItemSearchQuery(){
    	 String sampleQuery = "{{ \r\n" + 
	        		" quickOrderProductsAnzp( \r\n" + 
	        		" filter: { sku: { in: [\"My item\"]}}\r\n"+
	        		" pageSize: 999 \r\n"+
	        		" erpData: { \r\n"+
	        		" customer_number :\"Cust number\"\r\n" + 
	        		" name: \"My Wishlist1\"\r\n"+
	        		" is_bulk_order:true \r\n"+
	        		" }\r\n" + 
	        		" ) {\r\n" + 
	        		" items {\r\n" + 
	        		" id\r\n" + 
	        		" sku\r\n" + 
	        		" item_number\r\n" +
	        		" ss_item_number\r\n" +
	        		" description\r\n" + 
	        		" masterpartlowestsellinguomqty\r\n" + 
	        		" mp_pkg_ea_weight_uom_metric \r\n" + 
	        		" mp_pkg_ea_weight_metrics \r\n" + 
	        		" }\r\n" + 
	        		" user_errors { \r\n" +
	        		" message \r\n" + 
	        		" }}}";

	        try {
				if (retriever != null) {
					retriever.setQuery(sampleQuery);
					mockClient.execute(sampleQuery);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractQuickOrderRetriever {}", e.getMessage());
			}
	        try {
				if (retriever != null) {
					retriever.setQuery(sampleQuery);
					return;
				}
			} catch (NullPointerException e) {
				LOG.error("NullPointerException inside the AbstractQuickOrderRetriever {}", e.getMessage());
			}
	       
	    }
    	 
     }


