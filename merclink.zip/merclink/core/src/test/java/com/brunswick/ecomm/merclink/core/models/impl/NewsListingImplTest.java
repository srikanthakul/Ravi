package com.brunswick.ecomm.merclink.core.models.impl;

import static org.junit.jupiter.api.Assertions.*;

import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith(AemContextExtension.class)
class NewsListingImplTest {
	public AemContext context = new AemContext();
	public String newsHeadingPath = "/apps/merclink/components/content/newslisting/cq:dialog/content/items/tabs/items/newslisting/items/well/items/newstitle";
	public String newsDetailsPath = "/apps/merclink/components/content/news/cq:dialog/content/items/tabs/items/news/items/well/items";

	@BeforeEach
	void setUp() throws Exception {
		context.addModelsForPackage("com.brunswick.ecomm.merclink.core.models.impl");
		context.addModelsForClasses(NewsListingImpl.class);
		
		
	}

	@Test
	void testGetNewsDetails() {
		context.load().json("/context/newsListing_newsDetails.json", newsDetailsPath);
		Resource resource = context.resourceResolver().getResource(newsDetailsPath );
		assertNotNull(resource);
		NewsListingImpl newsListing = new NewsListingImpl();
		assertNotNull(newsListing.getNewsDetails());
	}

	@Test
	void testGetNewsHeading() {
		context.load().json("/context/newsListing_currentNewsHeading.json", newsHeadingPath);
		Resource resource = context.resourceResolver().getResource(newsHeadingPath);
		assertNotNull(resource);
		NewsListingImpl newsListing = new NewsListingImpl();
		assertNull(newsListing.getNewsHeading());
	}

}
