package com.brunswick.ecomm.merclink.core.models;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.brunswick.ecomm.merclink.core.helper.MultifieldHelper;

public class LoginDetailsTest {
    @Test
    public void testGetAuthorName() {
        LoginDetails logindetails = new LoginDetailsImplogin();
        String authorname = logindetails.getAuthorName();
        assertEquals("Test Annotation", authorname);
    }


@Test
public void testGetMyProfile() {
    LoginDetails logindetails = new LoginDetailsImplogin();
    List<Map<String, String>> myprofile = logindetails.getMyProfile();
    assertNull(myprofile);
   
}
@Test
public void testGetLoginDetailsWithNestedMultifield() {
    LoginDetails logindetails = new LoginDetailsImplogin();
    List<MultifieldHelper> logindetailsWithNestedMultifield = logindetails.getLoginDetailsWithNestedMultifield();
    assertNull(logindetailsWithNestedMultifield);

}
class LoginDetailsImplogin implements LoginDetails {
    @Override
    public String getAuthorName() {
        return "Test Annotation";
    }

	@Override
	public List<Map<String, String>> getMyProfile() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<MultifieldHelper> getLoginDetailsWithNestedMultifield() {
		// TODO Auto-generated method stub
		return null;
	}

    
}
}