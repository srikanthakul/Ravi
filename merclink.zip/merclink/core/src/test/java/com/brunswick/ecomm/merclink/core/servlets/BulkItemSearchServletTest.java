package com.brunswick.ecomm.merclink.core.servlets;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.apache.http.client.HttpClient;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.scripting.SlingBindings;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.caconfig.ConfigurationBuilder;
import org.apache.sling.servlethelpers.MockRequestPathInfo;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.apache.sling.testing.mock.sling.servlet.MockSlingHttpServletRequest;
import org.apache.sling.testing.mock.sling.servlet.MockSlingHttpServletResponse;
import org.junit.Before;
import org.junit.Rule;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;

import com.adobe.cq.commerce.core.components.internal.services.UrlProviderImpl;
import com.adobe.cq.commerce.core.components.services.ComponentsConfiguration;
import com.adobe.cq.commerce.core.components.services.urls.UrlProvider;
import com.adobe.cq.commerce.graphql.client.GraphqlClient;
import com.adobe.cq.commerce.graphql.client.GraphqlClientConfiguration;
import com.adobe.cq.commerce.graphql.client.HttpMethod;
import com.adobe.cq.commerce.graphql.client.impl.GraphqlClientImpl;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.adobe.cq.commerce.magento.graphql.gson.MutationDeserializer;
import com.brunswick.ecomm.merclink.core.components.testing.MockExternalizer;
import com.brunswick.ecomm.merclink.core.components.testing.Utils;
import com.brunswick.ecomm.merclink.core.models.retriever.AbstractQuickOrderRetriever;
import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.scripting.WCMBindingsConstants;
import com.google.common.collect.ImmutableMap;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextCallback;

class BulkItemSearchServletTest {

	@InjectMocks
	BulkItemSearchServlet fixture = new BulkItemSearchServlet();

	MockSlingHttpServletRequest request;
	MockSlingHttpServletResponse response;
	private GraphqlClientImpl graphqlClient;
	private HttpClient httpClient;
	private Resource pageResource;
	private Resource productResource;
	private AbstractQuickOrderRetriever retriever;

	private static final ValueMap MOCK_CONFIGURATION = new ValueMapDecorator(
			ImmutableMap.of("cq:graphqlClient", "default", "magentoStore", "anzpau_store_view_en"));
	private static final ComponentsConfiguration MOCK_CONFIGURATION_OBJECT = new ComponentsConfiguration(
			MOCK_CONFIGURATION);

	@Rule
	public final AemContext context = createContext("/context/jcr-content-wishlist.json");

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			context.load().json(contentPath, "/content");

			UrlProviderImpl urlProvider = new UrlProviderImpl();
			context.registerService(UrlProvider.class, urlProvider);

			context.registerAdapter(Resource.class, ComponentsConfiguration.class,
					(Function<Resource, ComponentsConfiguration>) input -> !input.getPath().contains("pageB")
							? MOCK_CONFIGURATION_OBJECT
							: ComponentsConfiguration.EMPTY);

			context.registerService(Externalizer.class, new MockExternalizer());

			ConfigurationBuilder mockConfigBuilder = Utils.getDataLayerConfig(true);
			context.registerAdapter(Resource.class, ConfigurationBuilder.class, mockConfigBuilder);
		}, ResourceResolverType.JCR_MOCK);

	}

	@Before
	public void SetUp() throws IOException {
		request = context.request();
		response = context.response();
		context.registerService(AbstractQuickOrderRetriever.class, retriever);
		context.registerInjectActivateService(fixture);
		prepareModel();

	}

	@Test
	void testDoPostSlingHttpServletRequestSlingHttpServletResponse() {

		String data = "{\"companyNumber\":\"1426525\",\"sku\":\"123456789\",\"componentPath\":\"/content/ecommerce/merclink/us/en/home/bulkorder\",\"token\":\"23pjbqgrhwict6xjzvg2tdr9vfjmkhja\",\"operatingUnit\":\"DC\"}}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", data);
		context.request().setParameterMap(params);
		context.registerAdapter(Resource.class, ComponentsConfiguration.class,
				(Function) input -> !((Resource) input).getPath().contains("pageB") ? MOCK_CONFIGURATION_OBJECT
						: ComponentsConfiguration.EMPTY);
		try {
			fixture.doPost(context.request(), context.response());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void prepareModel() throws IOException {

		httpClient = mock(HttpClient.class);

		Query rootMutation = Utils.getQueryFromResource("graphql/magento-graphql-regionlist-result.json");

		GraphqlClientConfiguration graphqlClientConfiguration = mock(GraphqlClientConfiguration.class);
		when(graphqlClientConfiguration.httpMethod()).thenReturn(HttpMethod.POST);

		graphqlClient = Mockito.spy(new GraphqlClientImpl());
		Whitebox.setInternalState(graphqlClient, "gson", MutationDeserializer.getGson());
		Whitebox.setInternalState(graphqlClient, "client", httpClient);
		Whitebox.setInternalState(graphqlClient, "configuration", graphqlClientConfiguration);
		Utils.setupHttpResponse("graphql/magento-graphql-quickorder-result.json", httpClient, 200);

		context.registerAdapter(Resource.class, GraphqlClient.class, (Function<Resource, GraphqlClient>) input -> input
				.getValueMap().get("cq:graphqlClient", String.class) != null ? graphqlClient : null);

		MockRequestPathInfo requestPathInfo = (MockRequestPathInfo) context.request().getRequestPathInfo();
		requestPathInfo.setSelectorString("beaumont-summit-kit");
		// This sets the page attribute injected in the models with @Inject or
		// @ScriptVariable
		SlingBindings slingBindings = (SlingBindings) context.request().getAttribute(SlingBindings.class.getName());
		slingBindings.setResource(productResource);
		slingBindings.put(WCMBindingsConstants.NAME_PROPERTIES, productResource.getValueMap());
	}

}
