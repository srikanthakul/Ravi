package com.brunswick.ecomm.merclink.core.beans;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.brunswick.ecomm.core.beans.RecentOrderItem;
import com.brunswick.ecomm.core.beans.product.InventoryStatusBean;




public class InventoryStatusTest {
	InventoryStatus fixture;
	@BeforeEach
	 void setup() {
		fixture = new InventoryStatus();
	}
	
	@Test
	public void getIdTest() {
		int id = 20;
		fixture.setId(id);
		assertEquals(id, fixture.getId());
	}
	
	@Test
	public void getMessageTest() {
		String expectedmessage = "message";
		fixture.setMessage(expectedmessage );
		assertEquals(expectedmessage, fixture.getMessage());
	}
	

}
