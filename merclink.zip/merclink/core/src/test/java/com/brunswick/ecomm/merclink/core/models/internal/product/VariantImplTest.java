package com.brunswick.ecomm.merclink.core.models.internal.product;

import static org.junit.jupiter.api.Assertions.*;



import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.brunswick.ecomm.merclink.core.models.product.common.Price;
class VariantImplTest {
	VariantImpl fixture;
	String test;
	Double digit;
	Price value;
	Boolean result;
	Integer digits;

	@BeforeEach
	void setUp() throws Exception {
		fixture = new VariantImpl();
		
	}

	@Test
	void testGetName() {
		test="word";
		fixture.setName(test);
		assertEquals(test,fixture.getName());
		
	}	

	@Test
	void testGetDescription() {
		test="word";
		fixture.setDescription(test);
		assertEquals(test,fixture.getDescription());
	}

	@Test
	void testGetSku() {
		test="word";
		fixture.setSku(test);
		assertEquals(test,fixture.getSku());
	}

	@Test
	void testGetInStock() {
		result=true;
		fixture.setInStock(result);
		assertEquals(result,fixture.getInStock());
	}

	@Test
	void testGetColor() {
		digits=123;
		fixture.setColor(digits);
		assertEquals(digits,fixture.getColor());
	}
}
