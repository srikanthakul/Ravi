package com.brunswick.ecomm.merclink.core.helper;

import static org.junit.jupiter.api.Assertions.assertEquals;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NastedHelperTest {
	private static final Logger LOG = LoggerFactory.getLogger(NastedHelperTest.class);
	 private String childUserTxt;
     private String childUserPath;
	private NastedHelper fixture;
	@BeforeEach
	void setUp() throws Exception {
		try {
			if (fixture != null) {
				fixture = new NastedHelper(null);
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the prepareModel {}", e.getMessage());
		}
	}
	@Test
	void getChildUserTxtTest() {
		childUserTxt = "childUserTxt";
		try {
			if (fixture != null) {
				fixture.getChildUserTxt();
				assertEquals(childUserTxt, fixture.getChildUserTxt());
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the prepareModel {}", e.getMessage());
		}
	}

	@Test
	void childUserPathTest() {
		try {
			if (fixture != null) {
				fixture.getChildUserPath();
				assertEquals(childUserPath, fixture.getChildUserPath());
				return;
			}
		} catch (NullPointerException e) {
			LOG.error("NullPointerException inside the getChildUserPath {}", e.getMessage());
		}
	}
}
