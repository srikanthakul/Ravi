package com.brunswick.ecomm.merclink.core.beans;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TierPriceBeanTest {
	TierPriceBean fixture;
	String test;
	@BeforeEach
	 void setUpBeforeClass() throws Exception {
		fixture = new TierPriceBean();
	}

	@Test
	void testGetName() {
		test = "name";
		fixture.setName(test);
		assertEquals(test, fixture.getName());
	}

	@Test
	void testGetPrice() {
		test = "price";
		fixture.setPrice(test);
		assertEquals(test, fixture.getPrice());
	}

}
