package com.brunswick.ecomm.merclink.core.models.retriever;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.json.JSONException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Customer;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

class AbstractUamRetrieverTest {
	private AbstractUamRetriever retriever;
	private MagentoGraphqlClient mockClient;
	Customer customer;
	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractUamRetriever.class);
	
	GraphqlResponse<Mutation, Error> response = mock(GraphqlResponse.class);
	Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);
	Mutation mutation = mock(Mutation.class);
	@BeforeEach
	public void setUp() {
		mockClient = mock(MagentoGraphqlClient.class);

		GraphqlResponse mockResponse = mock(GraphqlResponse.class);
		when(mockClient.execute(any())).thenReturn(mockResponse);
		when(response.getData()).thenReturn(mutation);
		when(mockResponse.getData()).thenReturn(mockQuery);
		when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());

		retriever = new AbstractUamRetriever(mockClient);
	}

	@Test
    public void createManualLogin() throws JSONException{
   		String sampleQuery="mutation {\r\n" + 
    			"generateCustomerTokenAsAdmin(input: {\r\n" + 
    			"customer_email: \r\n" + 
    			" }\r\n" + 
    			") {\r\n" + 
    			"customer_token\r\n" + 
    			"}\r\n" + 
    			"}";
   		try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractUamRetrieverTest {}", e.getMessage());
		}
   		try {
			if (retriever != null) {
				retriever.createManualLogin(sampleQuery);
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractUamRetrieverTest {}", e.getMessage());
		}
   	}
	
	@Test
    public void childUserDetails() {
   		String sampleQuery="query{\r\n" + 
    			"GetChildUsers(status:\r\n" + 
    			"){ \r\n" + 
    			"customerid\r\n" + 
    			"firstname\r\n" + 
    			"middlename\r\n" + 
    			"lastname\r\n" + 
    			"email\r\n" + 
    			"telephone\r\n" + 
    			"start_date\r\n" + 
    			"end_date\r\n" + 
    			"status\r\n" + 
    			"}\r\n" + 
    			"}";
   		try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractUamRetrieverTest {}", e.getMessage());
		}
   		try {
			if (retriever != null) {
				retriever.childUserDetails(null, null);
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractUamRetrieverTest {}", e.getMessage());
		}
   	}
	
	@Test
    public void childSecondaryUserDetails() {
   		String sampleQuery="query{\r\n" + 
    			"ChildUserDetail\r\n" + 
    			"){ \r\n" + 
    			"customerid\r\n" + 
    			"firstname\r\n" + 
    			"middlename\r\n" + 
    			"lastname\r\n" + 
    			"email\r\n" + 
    			"telephone\r\n" + 
    			"permissions\r\n"+
    			"roles\r\n"+
    			"start_date\r\n" + 
    			"end_date\r\n" + 
    			"}\r\n" + 
    			"}";
   		try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractUamRetrieverTest {}", e.getMessage());
		}
   		try {
			if (retriever != null) {
				retriever.childSecondaryUserDetails(null, null);
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractUamRetrieverTest {}", e.getMessage());
		}
   	}
	
	@Test
    public void setDefaultAccount() {
   		String sampleQuery="mutation {\r\n" + 
    			"setAnzpDefaultCompany(\r\n" + 
    			"input: { \r\n" + 
    			"companynumber :\r\n" + 
    			"}\r\n" + 
    			") {\r\n" + 
    			"message\r\n" + 
    			"}\r\n" + 
    			"}";
   		try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractUamRetrieverTest {}", e.getMessage());
		}
   		try {
			if (retriever != null) {
				retriever.setDefaultAccount(sampleQuery);
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractUamRetrieverTest {}", e.getMessage());
		}
   	}
	
	@Test
    public void getEditChildUserDetail() {
   		String sampleQuery="query{\r\n" + 
    			"ChildUserDetail(customerId:\r\n" + 
    			"){\r\n" + 
    			"customerid\r\n" + 
    			"firstname\r\n" + 
    			"middlename\r\n" + 
    			"lastname\r\n" + 
    			"email\r\n" + 
    			"telephone\r\n" + 
    			"permissions\r\n" + 
    			"start_date\r\n" + 
    			"end_date\r\n" +
    			"}\r\n" + 
    			"}";
   		try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractUamRetrieverTest {}", e.getMessage());
		}
   		try {
			if (retriever != null) {
				retriever.getEditChildUserDetail(null, null);
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractUamRetrieverTest {}", e.getMessage());
		}
   	}
	
	@Test
    public void changeUserEmail() {
   		String sampleQuery="mutation {\r\n" + 
    			"changeAnzpEmail (\r\n" + 
    			"input:\r\n" + 
    			"email :\r\n" + 
    			"}\r\n" + 
    			") {\r\n" + 
    			"message\r\n" + 
    			"}\r\n" + 
    			"}";
   		try {
			if (retriever != null) {
				retriever.setQuery(sampleQuery);
				mockClient.execute(sampleQuery);
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractUamRetrieverTest {}", e.getMessage());
		}
   		try {
			if (retriever != null) {
				retriever.changeUserEmail(sampleQuery);
				return;
			}
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException inside the AbstractUamRetrieverTest {}", e.getMessage());
		}
   	}
}
