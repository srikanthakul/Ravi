package com.brunswick.ecomm.merclink.core.models;

import static org.junit.jupiter.api.Assertions.*;

import org.apache.sling.api.resource.Resource;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;



@ExtendWith(AemContextExtension.class)
 class MultifieldModelTest {

	public final AemContext context = new AemContext();
	
	public String path;
	
	@BeforeEach
	 void setUp() throws Exception {
		context.addModelsForPackage("com.brunswick.ecomm.merclink.core.models");
		context.addModelsForClasses(MultifieldModel.class);
		
		
	}

	
	 @Test 
	  void testGetNewsItems() { 
		 path = "/content/ecommerce/merclink/au/en/ContactUS/jcr:content/root/container/container/contactpage/newsItems";
		 context.load().json("/context/newsItems.json", path);
		 Resource resource = context.resourceResolver().getResource(path);
		 assertNotNull(resource);
		 MultifieldModel multifieldModel = resource.adaptTo(MultifieldModel.class);
		 assertNotNull(multifieldModel.getNewsItems());
		 }
	 
	  @Test 
	  	void testGetNewsItems1() { 
		  path = "/content/ecommerce/merclink/au/en/home/jcr:content/root/container/container/newssection1";
		  context.load().json("/context/newsItems1-3.json", path);
		  Resource resource = context.resourceResolver().getResource(path);
		  assertNotNull(resource);
		  MultifieldModel multifieldModel = resource.adaptTo(MultifieldModel.class);
		  assertNotNull(multifieldModel.getNewsItems1());
	  }
	  
	 @Test 
	 	void testGetNewsItems2() { 
		  path = "/content/ecommerce/merclink/au/en/home/jcr:content/root/container/container/newssection1";
		  context.load().json("/context/newsItems1-3.json", path);
		  Resource resource = context.resourceResolver().getResource(path);
		  assertNotNull(resource);
		  MultifieldModel multifieldModel = resource.adaptTo(MultifieldModel.class);
		  assertNotNull(multifieldModel.getNewsItems2());
	 }
	 
	 @Test 
	 	void testGetNewsItems3() { 
		  path = "/content/ecommerce/merclink/au/en/home/jcr:content/root/container/container/newssection1";
		  context.load().json("/context/newsItems1-3.json", path);
		  Resource resource = context.resourceResolver().getResource(path);
		  assertNotNull(resource);
		  MultifieldModel multifieldModel = resource.adaptTo(MultifieldModel.class);
		  assertNotNull(multifieldModel.getNewsItems3()); 
		 
	 }
	 
	 
	 @Test 
	 	void testGetPageLink() { 
		  path = "/content/experience-fragments/merclink/us/en/site/footer/master/jcr:content/root/footer/pageTitle";
		 context.load().json("/context/pageTitle.json", path); 
		  Resource resource = context.resourceResolver().getResource(path +"/item0"); 
		  assertNotNull(resource);
		  MultifieldModel multifieldModel = resource.adaptTo(MultifieldModel.class);
		  assertNotNull(multifieldModel.getPageLink());
		 
	 }
	 

	
	  @Test 
	   	void testGetPageTitle() {
		  path = "/content/experience-fragments/merclink/us/en/site/footer/master/jcr:content/root/footer/pageTitle";
		  context.load().json("/context/pageTitle.json", path); 
		  Resource resource = context.resourceResolver().getResource(path +"/item0");  
		  assertNotNull(resource);
		  MultifieldModel multifieldModel = resource.adaptTo(MultifieldModel.class);
		  assertNotNull(multifieldModel.getPageTitle()); 
	  	}
	 

	@Test
	 void testGetItemsPerPageSelectionWishlist() {
		  path = "/apps/merclink/components/commerce/searchresults/cq:dialog/content/items/columns/items";
		  context.load().json("/context/itemsPerPageSelection.json", path); 
		  Resource resource = context.resourceResolver().getResource(path +"/itemsperpageselection/field/items/column/items/itemsperpage");  
		  assertNotNull(resource);
		  MultifieldModel multifieldModel = resource.adaptTo(MultifieldModel.class);
		  assertNull(multifieldModel.getItemsPerPageSelectionWishlist());
	}

	/*
	@Test
	void testGetMultiIconsBar() {
		fail("Not yet implemented");
	}*/

	@Test
	 void testGetMultifaq() {
		path  = "/content/ecommerce/merclink/au/en/faq/jcr:content/root/container/container/faq";
		context.load().json("/context/multifaq.json", path);
		Resource resource = context.resourceResolver().getResource(path +"/multifaq/item0");
		assertNotNull(resource);
		MultifieldModel multifieldModel = resource.adaptTo(MultifieldModel.class);
		assertNull(multifieldModel.getMultifaq());
	}

	@Test
	void testGetItemsPerPageSelection() {
		  path = "/apps/merclink/components/commerce/searchresults/cq:dialog/content/items/columns/items/itemsperpageselection";
		  context.load().json("/context/itemsPerPageSelection.json", path); 
		  Resource resource = context.resourceResolver().getResource(path);  
		  assertNotNull(resource);
		  MultifieldModel multifieldModel = resource.adaptTo(MultifieldModel.class);
		  assertNull(multifieldModel.getItemsPerPageSelection());
	} 

}
