package com.brunswick.ecomm.merclink.core.servlets;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;

import org.apache.http.client.HttpClient;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.scripting.SlingBindings;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.caconfig.ConfigurationBuilder;
import org.apache.sling.servlethelpers.MockRequestPathInfo;
import org.apache.sling.servlethelpers.MockSlingHttpServletRequest;
import org.apache.sling.servlethelpers.MockSlingHttpServletResponse;
import org.apache.sling.testing.mock.sling.ResourceResolverType;
import org.apache.sling.xss.XSSAPI;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.adobe.cq.commerce.core.components.internal.services.UrlProviderImpl;
import com.adobe.cq.commerce.core.components.services.ComponentsConfiguration;
import com.adobe.cq.commerce.core.components.services.urls.UrlProvider;
import com.adobe.cq.commerce.graphql.client.GraphqlClient;
import com.adobe.cq.commerce.graphql.client.GraphqlClientConfiguration;
import com.adobe.cq.commerce.graphql.client.HttpMethod;
import com.adobe.cq.commerce.graphql.client.impl.GraphqlClientImpl;
import com.adobe.cq.commerce.magento.graphql.Mutation;
import com.adobe.cq.commerce.magento.graphql.gson.MutationDeserializer;
import com.brunswick.ecomm.merclink.core.components.testing.MockExternalizer;
import com.brunswick.ecomm.merclink.core.components.testing.Utils;
import com.brunswick.ecomm.merclink.core.utils.ValidateContactUsServlet;
import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.scripting.WCMBindingsConstants;
import java.util.function.*;
import com.google.common.collect.ImmutableMap;

import io.wcm.testing.mock.aem.junit.AemContext;
import io.wcm.testing.mock.aem.junit.AemContextCallback;


public class ContactUsServletTest { 
	
	@Rule
	public final AemContext context = createContext("/context/jcr-content-contactus.json");

	private static final ValueMap MOCK_CONFIGURATION = new ValueMapDecorator(
			ImmutableMap.of("cq:graphqlClient", "default", "magentoStore", "anzpau_store_view_en"));

	private static final ComponentsConfiguration MOCK_CONFIGURATION_OBJECT = new ComponentsConfiguration(
			MOCK_CONFIGURATION);

	private static AemContext createContext(String contentPath) {
		return new AemContext((AemContextCallback) context -> {
			// Load page structure
			context.load().json(contentPath, "/content");

			UrlProviderImpl urlProvider = new UrlProviderImpl();
			//urlProvider.activate(new MockUrlProviderConfiguration());
			context.registerService(UrlProvider.class, urlProvider);

			context.registerAdapter(Resource.class, ComponentsConfiguration.class,
					(Function<Resource, ComponentsConfiguration>) input -> !input.getPath().contains("pageB")
							? MOCK_CONFIGURATION_OBJECT
							: ComponentsConfiguration.EMPTY);

			context.registerService(Externalizer.class, new MockExternalizer());

			ConfigurationBuilder mockConfigBuilder = Utils.getDataLayerConfig(true);
			context.registerAdapter(Resource.class, ConfigurationBuilder.class, mockConfigBuilder);
		}, ResourceResolverType.JCR_MOCK);
	}
	@InjectMocks
	private ContactUsServlet fixture;
	ValidateContactUsServlet validate;
	private MockSlingHttpServletRequest request;
	private MockSlingHttpServletResponse response;
	private static final String PAGE = "/content/pageA";
	private static final String RES = "/content/pageA/jcr:content/root/responsivegrid_1812104790/contactus";
	private Resource pageResource;
	private Resource productResource;
	private GraphqlClient graphqlClient;
	private String customerToken;
	private HttpClient httpClient; 
		XSSAPI xssAPI = mock(XSSAPI.class);
        Map<String, String> map;
        HashMap<String,String> errormessages=new HashMap<String, String>();
        PrintWriter pw = mock(PrintWriter.class);  

        @Before
        public void setUp() throws IOException {
        	fixture = new ContactUsServlet();
    		//addCommentToWishlist.init();
    		prepareModel(RES, PAGE);
            MockitoAnnotations.initMocks(this);
            validate = new ValidateContactUsServlet();
            
        } 
 
       
    
    @Test
     public void doPost() throws ServletException, IOException, JSONException{
    	request = context.request();
		response = context.response();
		String requestdata ="{\"fname\":\"Ravi\",\"lname\":\"Developer\",\"email\":\"ravi.chomal01@infosys.com\",\"companyname\":\"RaviCompany\",\"customerno\":\"123\",\"dept\":\"Credit\",\"phone\":\"\",\"subject\":\"\",\"message\":\"\",\"resourcePath\":\"/content/pageA/jcr:content/root/responsivegrid_1812104790/contactus\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", requestdata);
		params.put("formtype", "Sales");
		request.setParameterMap(params);
		request.setHeader("Authorization", "Bearer "+customerToken);
		Map<String,String> data= new HashMap<>();
           data.put("fname", "Ravi");
           data.put("lname", "Developer");
           data.put("email", "ravi.chomal01@infosys.com");
           data.put("companyname", "RaviCompany");
           data.put("dept", "Sales");
           data.put("phone", "9234111111");
           data.put("resourcePath", RES);
           data.put("customerno","123");
           data.put("comment", "This is to test comment area");

        when(xssAPI.filterHTML(Mockito.anyString())).thenAnswer(new Answer() {
            public Object answer(InvocationOnMock invocation) {
                return invocation.getArguments()[0];
            }
        });
        
        assertEquals(200, fixture.sendStatus(errormessages, 200, response));
        assertEquals(400, fixture.sendStatus(errormessages, 400, response));
        
        try{
        	if(fixture != null){
        		fixture.doPost(request, response);
        	}
        }
        catch(Exception e) {
        	e.getMessage();
        }
    }
    
    @Test
    public void doPostCreditApplication() throws ServletException, IOException, JSONException{
   	request = context.request();
		response = context.response();
		String requestdata ="{\"contact_name\":\"Ravi\",\"agree_name\":\"Ravi\",\"annual_spend\":\"120000\",\"documents\":\"doc.pdf\",\"title\":\"Mr\",\"employee_id\":\"123\",\"email\":\"ravi.chomal01@infosys.com\",\"customerno\":\"123\",\"company\":\"RaviCompany\",\"address1\":\"addr2\",\"address2\":\"addr1\",\"city\":\"city\",\"state\":\"state\",\"zipcode\":\"111\",\"department\":\"Credit\",\"phone\":\"\",\"fax\":\"\",\"type\":\"\",\"db_number\":\"123\",\"resourcePath\":\"/content/pageA/jcr:content/root/responsivegrid_1812104790/contactus\"}";
		Map<String, Object> params = new HashMap<>();
		params.put("data", requestdata);
		params.put("formtype", "Credit Application");
		request.setParameterMap(params);
		request.setHeader("Authorization", "Bearer "+customerToken);

       when(xssAPI.filterHTML(Mockito.anyString())).thenAnswer(new Answer() {
           public Object answer(InvocationOnMock invocation) {
               return invocation.getArguments()[0];
           }
       });
       
       assertEquals(200, fixture.sendStatus(errormessages, 200, response));
       assertEquals(400, fixture.sendStatus(errormessages, 400, response));
       fixture.doPost(request, response);
        

   }
    
  
       
       @Test
      public void getFilteredData() throws JSONException{   
    	   JSONObject jsondata= new JSONObject("{'companyname':'Brunswick','customerno':'123456','title':'Mr.','fname':'Ram','lname':'Roy','phone':'9999999999','resourcePath':'resource/path','message':'msg','subject':'','dept':'Credit Application','email':'test@xyz.com','comment':'This is to test comment area'}");
    	  Map<String,String> data = new HashMap<>();
    	  data.put("companyname", "Brunswick");
    	  when(xssAPI.filterHTML(Mockito.anyString())).thenAnswer(new Answer() {
              public Object answer(InvocationOnMock invocation) {
                  return invocation.getArguments()[0];
              }
          });
    	  Map<String,String> hashmap = fixture.getFilteredData(jsondata);    	   
    	  assertEquals("Brunswick",hashmap.get("companyname"));
    	  assertEquals("Ram",hashmap.get("fname"));
    	  assertEquals("Roy",hashmap.get("lname"));
    	  assertEquals("9999999999",hashmap.get("phone"));
    	  assertEquals("test@xyz.com",hashmap.get("email"));
    	  assertEquals("msg",hashmap.get("message"));
    	     	   
       }
       @Test
       public void getFilteredDataforCreditApp() throws JSONException{   
     	   JSONObject jsondata= new JSONObject("{'company':'Brunswick','employee_id':'empid','department':'Credit Application','customerno':'123456','title':'Mr.','contact_name':'XYZ','address1':'addr1','address2':'addr2','city':'','state':'','zipcode':'123321','fax':'','annual_spend':'120000','agree_name':'XYZ','type':'','db_number':'121','w9_file':'doc.pdf','sales_file':'doc.pdf','add_file':'doc.pdf','fname':'Ram','lname':'Roy','phone':'9999999999','resourcePath':'resource/path','message':'msg','subject':'','documents':'file1,file2','dept':'Credit Application','email':'test@xyz.com','comment':'This is to test comment area'}");
     	  Map<String,String> data = new HashMap<>();
     	  when(xssAPI.filterHTML(Mockito.anyString())).thenAnswer(new Answer() {
               public Object answer(InvocationOnMock invocation) {
                   return invocation.getArguments()[0];
               }
           });
     	  Map<String,String> hashmap = fixture.getFilteredDataforCreditApp(jsondata);    	   
     	     	   
        }
       
       @Test
       public void getFilteredText() throws JSONException, LoginException {  
    	   String userInput = "Brunswick";
    	   when(xssAPI.filterHTML(userInput)).thenReturn(userInput);
    	   assertEquals(userInput,fixture.getFilteredText(userInput));
   	   
       }
       
       

       private void prepareModel(String resourcePath, String currentPage) throws IOException {
   		Page page = Mockito.spy(context.currentPage(currentPage));
   		pageResource = Mockito.spy(page.adaptTo(Resource.class));
   		when(page.adaptTo(Resource.class)).thenReturn(pageResource);

   		httpClient = mock(HttpClient.class);

   		context.currentResource(resourcePath);
   		productResource = Mockito.spy(context.resourceResolver().getResource(resourcePath));
   		Mutation rootMutation = Utils.getMutationFromResource("graphql/magento-graphql-contactus-result.json");
   		//description=rootMutation.
   		
   		GraphqlClientConfiguration graphqlClientConfiguration = mock(GraphqlClientConfiguration.class);
   		when(graphqlClientConfiguration.httpMethod()).thenReturn(HttpMethod.POST);

   		graphqlClient = Mockito.spy(new GraphqlClientImpl());
   		Whitebox.setInternalState(graphqlClient, "gson", MutationDeserializer.getGson());
   		Whitebox.setInternalState(graphqlClient, "client", httpClient);
   		//Whitebox.setInternalState(graphqlClient, "configuration", graphqlClientConfiguration);

   		Utils.setupHttpResponse("graphql/magento-graphql-contactus-result.json", httpClient, 200);

   		context.registerAdapter(Resource.class, GraphqlClient.class, (Function<Resource, GraphqlClient>) input -> input
   				.getValueMap().get("cq:graphqlClient", String.class) != null ? graphqlClient : null);
   		
   		

   		MockRequestPathInfo requestPathInfo = (MockRequestPathInfo) context.request().getRequestPathInfo();
   		requestPathInfo.setSelectorString("beaumont-summit-kit");
   		context.request().setServletPath(PAGE + ".beaumont-summit-kit.html"); // used by
   																				// context.request().getRequestURI();
   		// This sets the page attribute injected in the models with @Inject or @ScriptVariable
           SlingBindings slingBindings = (SlingBindings) context.request().getAttribute(SlingBindings.class.getName());
           slingBindings.setResource(productResource);
           slingBindings.put(WCMBindingsConstants.NAME_CURRENT_PAGE, page);
           slingBindings.put(WCMBindingsConstants.NAME_PROPERTIES, productResource.getValueMap());
   	}


       
     	  
 
       
}  
    
    