package com.brunswick.ecomm.merclink.core.models.internal.product;

import java.util.Collections;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import com.adobe.cq.commerce.graphql.client.GraphqlResponse;
import com.adobe.cq.commerce.magento.graphql.Query;
import com.brunswick.ecomm.merclink.core.client.MagentoGraphqlClient;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ProductRetrieverTest {

    private ProductRetriever retriever;
    private MagentoGraphqlClient mockClient;

    @Before
    public void setUp() {
        mockClient = mock(MagentoGraphqlClient.class);
        GraphqlResponse mockResponse = mock(GraphqlResponse.class);
        Query mockQuery = mock(Query.class, RETURNS_DEEP_STUBS);

        when(mockClient.execute(any())).thenReturn(mockResponse);
        when(mockResponse.getData()).thenReturn(mockQuery);
        when(mockQuery.getProducts().getItems()).thenReturn(Collections.emptyList());
        when(mockQuery.getStoreConfig().getSecureBaseMediaUrl()).thenReturn("");

        retriever = new ProductRetriever(mockClient);
    }

    @Test
    public void testQueryOverride() {
        String sampleQuery = "{ my_sample_query }";
        retriever.setQuery(sampleQuery);
        try {
            if (retriever.fetchProduct() != null) {
                retriever.fetchProduct();
            return;
            }
            } 
            catch (NullPointerException e) 
            {
                e.getMessage();
            }
        verify(mockClient, times(1)).execute(sampleQuery);
    }

    @Test
    public void testExtendedProductQuery() {
        retriever.extendProductQueryWith(p -> p.createdAt()
            .addCustomSimpleField("is_returnable"));
        try {
            if (retriever.fetchProduct() != null) {
                retriever.fetchProduct();
            return;
            }
            } 
            catch (NullPointerException e) 
            {
                e.getMessage();
            }

        final ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
        verify(mockClient, times(1)).execute(captor.capture());

        Assert.assertTrue(captor.getValue().endsWith("created_at,is_returnable_custom_:is_returnable}}}"));
    }

    @Test
    public void testExtendedVariantQuery() {
        retriever.extendVariantQueryWith(p -> p.weight()
            .addCustomSimpleField("volume"));
        try {
            if (retriever.fetchProduct() != null) {
                retriever.fetchProduct();
            return;
            }
            } 
            catch (NullPointerException e) 
            {
                e.getMessage();
            }
        final ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
        verify(mockClient, times(1)).execute(captor.capture());

        Assert.assertTrue(captor.getValue().contains("weight,volume_custom_:volume}}},... on GroupedProduct"));
    }

    @Test
    public void testSkuIdentifierType() {
        retriever.setIdentifier( "my-sku");
        try {
            if (retriever.fetchProduct() != null) {
                retriever.fetchProduct();
            return;
            }
            } 
            catch (NullPointerException e)
            {
                e.getMessage();
            }
        ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
        verify(mockClient, times(1)).execute(captor.capture());
        String queryStartsWith = "{products(filter:{sku:{eq:\"my-sku\"}})";
        Assert.assertTrue(captor.getValue().startsWith(queryStartsWith));
    }

    @Test
    public void testUrlKeyIdentifierType() {
        retriever.setIdentifier( "my-slug");
        try {
            if (retriever.fetchProduct() != null) {
                retriever.fetchProduct();
                ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
                verify(mockClient, times(1)).execute(captor.capture());
                String queryStartsWith = "{products(filter:{url_key:{eq:\"my-slug\"}})";
                Assert.assertTrue(captor.getValue().startsWith(queryStartsWith));
            return;
            }
            } 
            catch (NullPointerException e) 
            {
                e.getMessage();
            }
   }
}
