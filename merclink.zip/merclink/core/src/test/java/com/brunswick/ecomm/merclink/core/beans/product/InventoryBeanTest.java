package com.brunswick.ecomm.merclink.core.beans.product;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.brunswick.ecomm.core.beans.product.InventoryBean;
import com.brunswick.ecomm.core.beans.product.InventoryStatusBean;

public class InventoryBeanTest {
	InventoryBean fixture;
	@BeforeEach
	public void setup() {
		fixture = new InventoryBean();
	}
	
	@Test
	public void getStatusTest() {
		InventoryStatusBean expectedstatus = new InventoryStatusBean();
		fixture.setStatus(expectedstatus);
		assertEquals(expectedstatus, fixture.getStatus());
	}

}
