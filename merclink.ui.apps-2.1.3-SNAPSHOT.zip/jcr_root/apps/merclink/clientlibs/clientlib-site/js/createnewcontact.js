
/*-------Tooltip----------------*/
$(".cum_info_remove_icon-inner").click(function(){
  $(".mm-remove-inner-tooltip").show();
});
$(".cum_info_remove_icon-close-btn").click(function(){
  $(".mm-remove-inner-tooltip").hide();
});
/*-------End of Tooltip----------------*/

var resourcePath = $('#componentPath').val()
//TO BE PROVIDED THROUGH Dialog properties usinf path browser.
function back(){
	location.href = "/content/ecommerce/mercnet/us/en/contactusermanagement.html";
}

function saveCreateNewContactDetails(){
  let cnc_firstName = document.getElementById('cnc_firstName').value;
    let cnc_middileName = document.getElementById('cnc_middileName').value;
    let cnc_lastName = document.getElementById('cnc_lastName').value;
    let cnc_email = document.getElementById('cnc_email').value;
    let cnc_phone = document.getElementById('cnc_phone').value;
    let cnc_startDate = document.getElementById('cnc_startDate').value;
    let cnc_endDate = document.getElementById('cnc_endDate').value;
    var date = cnc_startDate.split("-");
    console.log("start date :"+ cnc_startDate)
    var day = date[2];
    var month = date[1];
    var year = date[0];
    cnc_startDate = [day, month, year].join('-');
    console.log("final start date : "+cnc_startDate);
    
    date = cnc_endDate.split("-");
    console.log("end date : "+ cnc_endDate)
    var day = date[2];
    var month = date[1];
    var year = date[0];
    cnc_endDate = [day, month, year].join('-');
    console.log("final end date : "+cnc_endDate);
    
    let cnc_removeUser = document.getElementById('cnc_removeUser').value;

    var privilegesList="";
    $('.dynamicPrivileges  input[type=checkbox]:checked').each(function() {
    	privilegesList = privilegesList + $(this).attr("value") +",";
    });

    console.log("privilegesList : "+privilegesList);
    var data = {
    	       "componentPath": $('#componentPath').val(),
    	       "email" : cnc_email,
    	       "firstname" : cnc_firstName,
    	       "lastname" : cnc_lastName,
    	       "middlename" : cnc_middileName,
    	       "job_title" : "User",
    	       "telephone" : cnc_phone,
    	       "start_date" : cnc_startDate,
    	       "end_date" : cnc_endDate,
    	       //"permissions" : cnc_privileges1+","+cnc_privileges2
    	       "permissions" : privilegesList
    	   }
    	   $.ajax({
    	       type: "POST",
    	       url: "/bin/uam/createChildUserServlet",
    	       ContentType: 'application/json',
    	       async: false,
    	       data: {
    	           'data': JSON.stringify(data)
    	       },
    	       success: function (data) {
    	       	console.log("Data2 = " + JSON.stringify(data));
    	       	if(data != undefined && data.createCompanyUser != undefined && data.createCompanyUser != null){
    	       		localStorage.setItem("successIndicator", 'ON');
    	       		location.href = "/content/ecommerce/mercnet/us/en/contactusermanagement.html";
    	       	}
    	       },
    	       error: function (e) {
    	    	   console.log("Error = " + e);
    	       }
    	   	});
 	 return false;
}

function saveUpdateContactDetails(id){
  let cnc_firstName = document.getElementById('cnc_firstName').value;
    let cnc_middileName = document.getElementById('cnc_middileName').value;
    let cnc_lastName = document.getElementById('cnc_lastName').value;
    let cnc_email = document.getElementById('cnc_email').value;
    let cnc_phone = document.getElementById('cnc_phone').value;
    let cnc_startDate = document.getElementById('cnc_startDate').value;
    let cnc_endDate = document.getElementById('cnc_endDate').value;
    var date = cnc_startDate.split("-");
    console.log("start date :"+ cnc_startDate)
    var day = date[2];
    var month = date[1];
    var year = date[0];
    cnc_startDate = [day, month, year].join('-');
    console.log("final start date : "+cnc_startDate);
    
    date = cnc_endDate.split("-");
    console.log("end date : "+ cnc_endDate)
    var day = date[2];
    var month = date[1];
    var year = date[0];
    cnc_endDate = [day, month, year].join('-');
    console.log("final end date : "+cnc_endDate);
    
    let cnc_removeUser = document.getElementById('cnc_removeUser').value;

    var privilegesList="";
    $('.dynamicPrivileges  input[type=checkbox]:checked').each(function() {
    	privilegesList = privilegesList + $(this).attr("value") +",";
    });

    console.log("privilegesList : "+privilegesList);
    var data = {
    	       "componentPath": $('#componentPath').val(),
    	       "email" : cnc_email,
    	       "firstname" : cnc_firstName,
    	       "lastname" : cnc_lastName,
    	       "middlename" : cnc_middileName,
    	       "job_title" : "User",
    	       "telephone" : cnc_phone,
    	       "start_date" : cnc_startDate,
    	       "end_date" : cnc_endDate,
    	       "permissions" : privilegesList,
        		"company_number" : id
    	   }
    	   $.ajax({
    	       type: "POST",
    	       url: "/bin/uam/childUserUpdateServlet",
    	       ContentType: 'application/json',
    	       async: false,
    	       data: {
    	           'data': JSON.stringify(data)
    	       },
    	       success: function (data) {
    	       	console.log("Data2 = " + JSON.stringify(data));
    	       	if(data != undefined && data.updateCompanyUser != undefined && data.updateCompanyUser != null){
    	       		localStorage.setItem("successIndicator", 'ON');
					console.log("Child user updated successfully");
    	       		//location.href = "/content/ecommerce/mercnet/us/en/contactusermanagement.html";
    	       	}
    	       },
    	       error: function (e) {
    	    	   console.log("Error = " + e);
    	       }
    	   	});
 	 return false;
}
//Servlet call should be page specific
$(document).ready(function () {
if (null != resourcePath && resourcePath != "" && (resourcePath === "/content/ecommerce/mercnet/us/en/contactusermanagement/createnewcontact" || resourcePath === "/content/ecommerce/mercnet/us/en/contactusermanagement/createnewcontact/Edit-Contact") ) {
    console.log(" inside loadPersonalInformation ");
	loadPersonalInformation(resourcePath);
     console.log("Inside edit js");
        let urlParams = new URLSearchParams(window.location.search);
		var uid = urlParams.get('uid');
    	if(uid != undefined && uid != ""){
        	console.log("uid:::",uid)
        	editContact(uid);
    	}
    }

function loadPersonalInformation(resourcePath) {
    console.log(" inside loadPersonalInformation : "+resourcePath);
    var data = {
        "componentPath": resourcePath
    }
    $.ajax({
        type: "POST",
        url: "/bin/personalInformationML",
        ContentType: "application/json",
        dataType: "json",
        async: false,
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {

            console.log("Data = " + data);
            if (data != null) {
                if (data.getCustomerPersonalInformation === "Internal server error" || data.getCustomerPersonalInformation === "The current customer isn\u0027t authorized.") {
                    $(".nav-menu").hide();
                    $(".msg").html("");
                    $(".msg").fadeIn(100).append('<center>Internal server error.please try after sometime</center').css('color', 'red').fadeOut(3500);

                } else if (null != data) {

                    $('#companyname').text(data.company_name);
                    $('#personal-info-lastname').text(data.lastname);
                    $('#personal-info-firstname').text(data.firstname);
                    $("#customer_number").html(data.customer_number);
                    $("#street").html(data.billing_address.street[0].substring(20, 0) + "...");
                    $('#personal-info-customer_permission').text(data.roles_permission.customer_permission);
                    console.log("customer_permission" + data.roles_permission.customer_permission);

                    $(".nav-menu").hide();
                    $(".sub-nav-item").hide();

                    data.roles_permission.customer_permission.split(",").forEach(element => {
                        if (element != null && element != '') {
                            console.log(element);
                            $("li[data-permission='" + element + "']").show();
                        }
                    });

                }
            } else {
                console.log("Data = " + data);
            }

        },
        error: function(status, errorthrown) {
            console.log("function error" + errorthrown);
        }
    });
} 

function editContact(cid){
    // map update child user fucntion on save button
    document.getElementById("saveButtonFunction").setAttribute('onClick', "saveUpdateContactDetails("+cid+")");
 var data = {
        "componentPath": $('#componentPath').val(),
        "customerid" : parseInt(cid) 
    }
    $.ajax({
        type: "POST",
        url: "/bin/uam/editChildUserServlet",
        ContentType: 'application/json',
        async: false,
        data: {
            'data': JSON.stringify(data)
        },
        success: function (data) {
        	console.log("Data2 = " + data+" : "+JSON.stringify(data));
             $.each(data.UserDetail, function (index, result) {
				//$('#cnc_firstName').value=result.firstname;
                 document.getElementById('cnc_firstName').value = result.firstname
                 document.getElementById('cnc_middileName').value = result.middlename
                 document.getElementById('cnc_lastName').value = result.lastname
                 document.getElementById('cnc_email').value = result.email;
                 document.getElementById('cnc_phone').value=result.telephone;
                 console.log("result.start_date :"+result.start_date);
                 document.getElementById('cnc_startDate').value=formatResponseDate(result.start_date);
                 document.getElementById('cnc_endDate').value=formatResponseDate(result.end_date);
                 var permissions = result.permissions;

                 var myarray = permissions.split(',');
                 myarray.forEach(element => {

   					 $(`.form-check-input[value='${element}']`).attr('checked', true);;
 				 });
            });
        },
        error: function (e) {
        }
    	});
} 
// needs to be alloghed to display data in US format in the UI.
function formatResponseDate(date){
    var date = date.split("-");
    var day = date[0];
    var month = date[1];
    var year = date[2];
    return [ year,month,day].join('-');
}

});