/*contactlist-anzp.js*/
function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function setCookie(cname, cvalue, exdays) {
    const d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    let expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function pagination(itemNumer, pageNumber, tableId, pageNumberClass, pageIndex) {

    var showItem = parseInt(itemNumer);
    var itemCount = $("#" + tableId + " tr").length - 1;

    if ((itemCount % showItem) == 0) {
        totalPage = parseInt(itemCount / showItem);
    } else {
        totalPage = parseInt(itemCount / showItem) + 1;
    }

    if (pageNumber > totalPage) {
        pageNumber = totalPage;
    }

    var displayItemsTo = parseInt(pageNumber) * parseInt(showItem);
    var displayItemsFrom = parseInt(pageNumber) * parseInt(showItem) - parseInt(showItem);


    var option = "";
    for (var i = 1; i <= totalPage; i++) {
        var selected = "";
        if (i == pageNumber) {
            selected = "selected";
        }
        option += "<option value='" + i + "'" + selected + ">Page " + i + " of " + totalPage + "</option>";
    }



    $("." + pageNumberClass).empty();
    $("." + pageNumberClass).append(option);

    if (displayItemsTo < itemCount) {
        var index = displayItemsFrom + 1 + "-" + displayItemsTo + " of " + itemCount + " Results";
    } else {
        var index = displayItemsFrom + 1 + "-" + itemCount + " of " + itemCount + " Results";
    }
    $("." + pageIndex).html(index);

    $("#" + tableId + " tr").each((index, element) => {
        if (index != 0) {
            if (index > displayItemsFrom && index <= displayItemsTo) {
                $(element).show();
            } else {
                $(element).hide();
            }
        }
    });
}

function warning_pagination(itemNumer, pageNumber, tableId, pageNumberClass, pageIndex) {

    var showItem = parseInt(itemNumer) * 2;
    var itemCount = parseInt($("#" + tableId + " tr").length - 1) / 2;

    if ((itemCount % (showItem / 2)) == 0) {
        totalPage = parseInt(itemCount / (showItem / 2));
    } else {
        totalPage = parseInt(itemCount / (showItem / 2)) + 1;
    }

    if (pageNumber > totalPage) {
        pageNumber = totalPage;
    }

    var displayItemsTo = parseInt(pageNumber) * parseInt(showItem);
    var displayItemsFrom = parseInt(pageNumber) * parseInt(showItem) - parseInt(showItem);


    var option = "";
    for (var i = 1; i <= totalPage; i++) {
        var selected = "";
        if (i == pageNumber) {
            selected = "selected";
        }
        option += "<option value='" + i + "'" + selected + ">Page " + i + " of " + totalPage + "</option>";
    }



    $("." + pageNumberClass).empty();
    $("." + pageNumberClass).append(option);

    if ((displayItemsTo / 2) < itemCount) {
        var index = displayItemsFrom / 2 + 1 + "-" + displayItemsTo / 2 + " of " + itemCount + " Results";
    } else {
        var index = displayItemsFrom / 2 + 1 + "-" + itemCount + " of " + itemCount + " Results";
    }
    $("." + pageIndex).html(index);

    $("#" + tableId + " tr").each((index, element) => {
        if (index != 0) {
            if (index > displayItemsFrom && index <= displayItemsTo) {
                $(element).show();
            } else {
                $(element).hide();
            }
        }
    });
}

function sortTable(n, dir, tableName) {
    var table, rows, switching, i, x, y, shouldSwitch, switchcount = 0;
    table = document.getElementById(tableName);
    switching = true;
    //Set the sorting direction to ascending:
    /*Make a loop that will continue until
    no switching has been done:*/
    while (switching) {
        //start by saying: no switching is done:
        switching = false;
        rows = table.rows;
        /*Loop through all table rows (except the
        first, which contains table headers):*/
        for (i = 1; i < (rows.length - 1); i++) {
            //start by saying there should be no switching:
            shouldSwitch = false;
            /*Get the two elements you want to compare,
            one from current row and one from the next:*/
            x = rows[i].getElementsByTagName("TD")[n];
            y = rows[i + 1].getElementsByTagName("TD")[n];
            /*check if the two rows should switch place,
            based on the direction, asc or desc:*/
            if (dir == "asc") {
                if (isNaN(parseFloat(x.innerHTML)) == false && isNaN(parseFloat(y.innerHTML)) == false) {
                    if (parseFloat(x.innerHTML) > parseFloat(y.innerHTML)) {
                        //if so, mark as a switch and break the loop:
                        shouldSwitch = true;
                        break;
                    }
                } else {
                    if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                        //if so, mark as a switch and break the loop:
                        shouldSwitch = true;
                        break;
                    }
                }
            } else if (dir == "desc") {
                if (isNaN(parseFloat(x.innerHTML)) == false && isNaN(parseFloat(y.innerHTML)) == false) {
                    if (parseFloat(x.innerHTML) < parseFloat(y.innerHTML)) {
                        //if so, mark as a switch and break the loop:
                        shouldSwitch = true;
                        break;
                    }
                } else {
                    if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
                        //if so, mark as a switch and break the loop:
                        shouldSwitch = true;
                        break;
                    }
                }
            }
        }
        if (shouldSwitch) {
            /*If a switch has been marked, make the switch
            and mark that a switch has been done:*/
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            switching = true;
            //Each time a switch is done, increase this count by 1:
            switchcount++;
        }
    }
}


function currencyFormat(number) {
    return new Intl.NumberFormat('en-US', { minimumFractionDigits: 2 }).format(number);
}


function validateCompanyCartError(cartId, companyNumber) {
    var data = {
        "componentPath": $('#resourcePath').val(),
        "cartId": cartId,
        "companyNumber": companyNumber,
    }
    $.ajax({
        type: "POST",
        url: "/bin/cart/validateCartServlet",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            if (data) {
                if (data.ValidateUserCompany) {
                    if (data.ValidateUserCompany.status === "error") {
                        if (data.ValidateUserCompany.message) {
                            if (data.ValidateUserCompany.message.trim() !== "The current user cannot perform operations" && data.ValidateUserCompany.message.trim() !== "The current customer isn't authorized." && data.ValidateUserCompany.message.split("=")[0].trim() !== "No such entity with cartId") {
                                $(".logout").click();
                                alert("Error occured. Redirecting you to the login page.");
                            }
                        }
                    }
                }
            }
        },
        error: function(e) {}
    });
}

$(document).ready(function() {
    let customerEmail="";
    $(".logout").click(function(e) {
        setCookie("customerToken", null, 0);
        setCookie("isDifferentUser", true, 30);
        setCookie("selectedCustomer", null, 0);
        setCookie("customerNumber", null, 0);
        setCookie("customer_id", null, 0);
        setCookie("completeAccountDetails", null, 0);
        setCookie("merclinkCustomerPersonalInfo", null, 0);
        location.href = $("#loginpath").val();
    });

    if (getCookie("cartId") !== "" && getCookie("selectedCustomer") !== "") {
        validateCompanyCartError(getCookie("cartId"), getCookie("selectedCustomer"));
    }


    var pageUrl = window.location.href;
    var arr = pageUrl.split("/");
    var loginWebsite = arr[arr.length - 1];
    if (arr.indexOf("content") == -1 && loginWebsite != "login.html") {
        $(".nav-menu").hide();

        setInterval(function() {
            var customerTokenCheck = getCookie("customerToken");
            if (customerTokenCheck == null || customerTokenCheck == "" || customerTokenCheck == "null") {
                location.href = $("#loginpath").val();


            }
        }, 3000);

        var customerToken = getCookie("customerToken");
        if (customerToken !== null && customerToken != "" && customerToken != "null") {
            digitalData.page.pageInfo.customerID = getCookie("customerNumber");
            var personatInformation = getCookie("merclinkCustomerPersonalInfo");
            if (personatInformation !== null && personatInformation !== "" && personatInformation != "null") {
                setCookie("isDifferentUser", false, 30);
                setPersonalInformation(JSON.parse(personatInformation));
                if (localStorage.getItem("categoryTree") == "") {
                    shopByCategory();
                } else {
                    categorytree(localStorage.getItem("categoryTree") ? JSON.parse(localStorage.getItem("categoryTree")) : []);
                }
            } else {
                setCookie("isDifferentUser", true, 30);
                _satellite.track('Login completed', { formName: 'Login' });
                loadPersonalInformation();
                shopByCategory();
            }

        } else {
            setCookie("customerToken", null, 0);
            setCookie("cartId", null, 0);
            setCookie("isDifferentUser", true, 30);
            setCookie("selectedCustomer", null, 0);
            setCookie("customerNumber", null, 0);
            setCookie("customer_id", null, 0);
            setCookie("completeAccountDetails", null, 0);
            setCookie("merclinkCustomerPersonalInfo", null, 0);
            digitalData.page.pageInfo.customerID = "";
            location.href = $("#loginpath").val();

        }

        $(".nav-menu").click(function(e) {
            if ($(this).attr("data-permission") === "F-L") {
                setCookie("customerToken", null, 0);
                setCookie("isDifferentUser", true, 30);
                setCookie("selectedCustomer", null, 0);
                setCookie("customerNumber", null, 0);
                setCookie("customer_id", null, 0);
                setCookie("completeAccountDetails", null, 0);
                setCookie("merclinkCustomerPersonalInfo", null, 0);
                location.href = $("#loginpath").val();

            }
            if ($(this).attr("data-permission") === "M-H") {
                location.href = $('#homepage').val();
            }

            if ($(this).attr("data-permission") === "F-SW") {
                window.open($('#prntmnupath').val(), '_blank');
            }
        });

        if ($("li[data-permission='F-D']").length > 0) {
            $("li[data-permission='F-D']").children().children().each((index, element) => $(element).children().attr("target", "_blank"));
        }

        if ($("li[data-permission='F-I-EPC']").length > 0) {
            $("li[data-permission='F-I-EPC']").children().prop("target", "_blank")
        }

        $("li[data-permission='F-PO-EC']").click(function(e) {
            e.preventDefault();
            var data = {
		        "resourcePath": $('#resourcePath').val(),
				"customerEmail":JSON.parse(getCookie("merclinkCustomerPersonalInfo")).email
		    }
            $.ajax({
                type: "POST",
                url: "/bin/merclink/cpqRedirection",
                ContentType: "application/json",
                data: {
		            'data': JSON.stringify(data)
		        },
                success: function(data) {
                    if (data != null && data.data != null && data.data.url != null) {
                        var cpq_url_link =  new URL(data.data.url);
						var cpq_logout = cpq_url_link.protocol + '//' + cpq_url_link.host +'/logout.jsp?_bm_trail_refresh_=true';
						var wnd = window.open(cpq_logout,"cpqLogout", "height=200,width=200","_blank");
						setTimeout(function() {
						  wnd.close();
						}, 2000);
                        setTimeout(function() {
                        window.location.href = data.data.url;
						}, 2500);
                    } else if (data != null && data.detail != null) {
                        respErrorMsgDisplay(data.detail.replaceAll("%", ""))
                    } else {
                        respErrorMsgDisplay("Something went wrong. Please try again later")
                    }

                },
                error: function(e) {
                    respErrorMsgDisplay("Something went wrong. Please try again later")
                }
            });
        });

        $(".setPageCompany").click(function() {
            var company_number = $(this).attr("data-company");
            var selectedCustomer = getCookie("selectedCustomer");
            if (company_number != selectedCustomer) {
                setCompany(company_number);
            }
        });
        // Shop By Category flyout when user clicks outside the category list
        $(document).click(function(e) {
            if ($(e.target).closest('.shop-by-cat-dropdown-menu').length == 0) {
                $('.shop-by-cat-dropdown-menu').hide();
            }
        });
    }
});


function setCompany(companyNumber) {
    $("#customer_number").html(companyNumber);

    var selectedCustomer = getCookie("selectedCustomer");
    setCookie("selectedCustomer", companyNumber, 30);
    setCookie("customerNumber", companyNumber, 30);
    digitalData.page.pageInfo.customerID = getCookie("customerNumber"); // analytics
    var customerId = getCookie("customer_id");

    var completeAccountDetails = JSON.parse(getCookie("completeAccountDetails"));
    var blogIndex = completeAccountDetails.findIndex(element => parseInt(element.company_number) === parseInt(companyNumber));
    var defaultBlog = completeAccountDetails[blogIndex].blog_news;
    showBlogNews(defaultBlog);

    var data = JSON.parse(getCookie("merclinkCustomerPersonalInfo"));

    setPermission("");
    if (data.roles_permission.customer_group != undefined && data.roles_permission.customer_group != "Anzp Default Customer Group" && data.roles_permission.customer_permission != undefined) {
        setPermission(data.roles_permission.customer_permission);
    }
    if (selectedCustomer !== null && selectedCustomer !== "null" && selectedCustomer != companyNumber) {
        createCartId(companyNumber);
        location.reload()
    } else {
        cartItemCount(getCookie("cartId"));
    }

    epcLink(companyNumber);
}

function setPersonalInformation(data) {

    $('#main-nav-links-nav').removeClass("d-none");
    $('#mm-caqo').removeClass("d-none");

    $('#companyname').text(data.firstname);
    $('#personal-info-lastname').text(data.lastname);
    $('#personal-info-firstname').text(data.firstname);
    $("#street").html(data.billing_address.street[0].substring(20, 0) + "...");
    $('#personal-info-customer_permission').text(data.roles_permission.customer_permission);

    var blog_news = data.blog_news.split(",");
    var company_currency = data.company_currency.split(",");
    var company_name = data.company_name.split(",");
    var customer_number = data.customer_number.split(",");
    var dropship = data.dropship.split(",");
    var is_wells_fargo = data.is_wells_fargo.split(",");
    var tax_group = data.tax_group.split(",");
    var shipping_method = data.shipping_method.split(",");
    var warehouse_name = data.warehouse_name.split(",");
    var customer_id = data.billing_address.customer_id;
    setCookie("customer_id", customer_id, 30);


    var item = [];
    var list = "";
    customer_number.forEach((element, index) => {
        if (element !== null || element !== "" || element !== " ") {
            list += "<li class='dropend'><a class='dropdown-item setPageCompany' data-company = '" + element.trim() + "' id='profile-options' aria-expanded='false'> <span class='px-2'>" + element.trim() + "</span></a></li>";

            var newdata = {
                "company_name": company_name[index].trim(),
                "customer_number": element.trim(),
                "warehouse_name": warehouse_name[index].trim(),
                "company_currency": company_currency[index].trim(),
                "is_wells_fargo": parseInt(is_wells_fargo[index].trim()),
                "blog_news": parseInt(blog_news[index].trim()),
                "dropship": parseInt(dropship[index].trim()),
                "shipping_method": shipping_method[index].trim(),
                "tax_group": tax_group[index].trim(),
            }
            item.push(newdata);
        }
    });
    $(".home-my-profile-dropdown-details").empty();
    $(".home-my-profile-dropdown-details").append(list);

    var completeAccountDetails = [];
    completeAccountDetails = data.account_list;
    completeAccountDetails.forEach((elemet, index) => {
        var itemIndex = item.findIndex(element => element.customer_number === completeAccountDetails[index].company_number);
        if (itemIndex !== -1) {
            elemet.warehouse_name = item[itemIndex].warehouse_name;
            elemet.company_currency = item[itemIndex].company_currency;
            elemet.is_wells_fargo = item[itemIndex].is_wells_fargo;
            elemet.blog_news = item[itemIndex].blog_news;
            elemet.dropship = item[itemIndex].dropship;
            elemet.shipping_method = item[itemIndex].shipping_method;
            elemet.tax_group = item[itemIndex].tax_group;
        }
    });

    setCookie("completeAccountDetails", JSON.stringify(completeAccountDetails), 30);
    var isDifferentUser = getCookie("isDifferentUser");
    var selectedCustomer = getCookie("selectedCustomer");

    var defaultIndex = completeAccountDetails.findIndex(element => element.is_default === "Yes");

    if (selectedCustomer) {
        var filterCustomer = completeAccountDetails.filter(element => element.company_number === selectedCustomer);
    } else {
        selectedCustomer = "";
    }

    if (selectedCustomer && selectedCustomer !== "" && filterCustomer.length > 0 && isDifferentUser === "false") {
        setCompany(selectedCustomer);
    } else if (defaultIndex !== -1) {

        $("#customer_number").html(completeAccountDetails[defaultIndex].company_number);
        setCookie("selectedCustomer", completeAccountDetails[defaultIndex].company_number, 30);
        setCookie("customerNumber", completeAccountDetails[defaultIndex].company_number, 30);
        digitalData.page.pageInfo.customerID = getCookie("customerNumber"); // analytics
        var defaultBlog = completeAccountDetails[defaultIndex].blog_news;
        showBlogNews(defaultBlog);
        createCartId(completeAccountDetails[defaultIndex].company_number);

        if (data.roles_permission.customer_group != null || data.roles_permission.customer_group != undefined) {
            if (data.roles_permission.customer_group != "Anzp Default Customer Group") {
                if (data.roles_permission.customer_permission != "") {
                    setPermission(data.roles_permission.customer_permission);
                }
            } else {
                setPermission("");
            }
        }
    }

}

function showBlogNews(defaultBlog) {
    if (parseInt(defaultBlog) === 0) {
        $(".news-comp-mar-3").hide();
    } else {
        $(".news-comp-mar-3").show();
    }
}


function loadPersonalInformation() {
    var data = {
        "resourcePath": $('#resourcePath').val(),

    }
    $.ajax({
        type: "POST",
        url: "/bin/merclinkCustomerPersonalInfo",
        ContentType: "application/json",
        dataType: "json",
        async: false,
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {

            if (data != null) {
                customerEmail=data.company_email;
                var companyNumber= data.roles_permission.company_number;
                var completeAccountDetails = [];
                completeAccountDetails = data.account_list;
                setCookie("completeAccountDetails", JSON.stringify(completeAccountDetails), 30);
                if (data.getCustomerPersonalInformation === "Internal server error" || data.getCustomerPersonalInformation === "The current customer isn\u0027t authorized.") {
                    $(".nav-menu").hide();
                    $(".msg").html("");
                    $(".msg").fadeIn(100).append('<center>Internal server error.please try after sometime</center').css('color', 'red').fadeOut(3500);

                } else if (null != data) {

                    setCookie("merclinkCustomerPersonalInfo", JSON.stringify(data), 30);
                    setPersonalInformation(data);
	             epcLink(companyNumber);
                    
                }
            } else {
                // console.log("Data = " + data);
            }


        },
        error: function(status, errorthrown) {
            // console.log("function error" + errorthrown);
        }
    });
}

function childUserDetails(customerId, companyNumber) {
    var data = {
        "componentPath": $('#resourcePath').val(),
        "customer_Id": parseInt(customerId),
        "company_number": parseInt(companyNumber)
    }
    $.ajax({
        type: "POST",
        url: "/bin/uam/childSecondaryUserDetailsServlet",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            if (data != null) {
                setPermission(data.ChildUserDetail[0].permissions);
                var selectedCustomer = getCookie("selectedCustomer");
                if (selectedCustomer != companyNumber) {
                    createCartId(companyNumber);
                    location.reload();
                } else {
                    cartItemCount(getCookie("cartId"));
                }
            }
        },
        error: function(e) {}
    });
}

function setPermission(permission) {
    if (permission != "") {
        $(".nav-menu").hide();
        $(".sub-nav-item").hide();
        $('#mm-caqo').hide();
        $('#mm-banner').show();
        permission.split(",").forEach(element => {
            if (element != null && element != '') {
                if (element == "F-PO") {
                    $('#mm-caqo').show();
                    $('#mm-banner').hide();
                }
                $("li[data-permission='" + element + "']").show();
            }

        });
    } else {
        $('#mm-caqo').show();
        $('#mm-banner').hide();
        $(".nav-menu").show();
        $(".sub-nav-item").show();
    }
}


function shopByCategory() {
    var data = {
        "resourcePath": $('#resourcePath').val(),
    }
    $.ajax({
        type: "POST",
        url: "/bin/categorytree",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            if (data != null && data.categoryList != null) {
                if (data.categoryList.length > 0) {
                    localStorage.setItem("categoryTree", JSON.stringify(data.categoryList));
                    categorytree(data.categoryList);
                }
            }
        },
        error: function(e) {}
    });
}

function createCartId(conpanyNumber) {
    var data = {
        "componentPath": $('#resourcePath').val(),
        "conpanyNumber": conpanyNumber
    }
    $.ajax({
        type: "POST",
        url: "/bin/cart/createCartQuery",
        ContentType: 'application/json',
        async: false,
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            if (data != null && data.customerCart != null) {
                setCookie("cartId", data.customerCart.id, 30);
                cartItemCount(data.customerCart.id);
            }
        },
        error: function(e) {}
    });
}


function cartItemCount(cartId) {
    var data = {
        "componentPath": $('#resourcePath').val(),
        "cartId": cartId
    }
    $.ajax({
        type: "POST",
        url: "/bin/cart/cartSummary",
        ContentType: 'application/json',
        async: false,
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            if (data && data.cartCount) {
                $(".cart-item-display-number").html(parseInt(data.cartCount.item_count));
                if (data.cartCount.item_count) {
                    setCookie("cartCount", parseInt(data.cartCount.item_count), 30);
                }
                if (data.cartCount.cart_updatedat) {
                    setCookie("cartUpdatedAt", cartId + "^" + data.cartCount.cart_updatedat, 1);
                }
                if (data.cartCount.errors && data.cartCount.errors.message) {
                    if (data.cartCount.errors.message.trim() === "The current user is inactive") {
                        setTimeout(function() {
                            $("button").attr("disabled", true);
                            $("input").attr("disabled", true);
                            $("a").attr("disabled", true);
                            $("a").attr("href", "#");
                            var clickMessage = " Please <span class='text-decoration-underline inactive-logout' role='button'> Click Here </span> to Log Out."
                            $(".error-msg-header").html(data.cartCount.errors.message + clickMessage);
                            $(".mm-error-msg-header").removeClass("d-none");
                            $(".inactive-logout").click(function() {
                                $(".logout").click();
                            });
                        }, 0);
                    }

                    if (data.cartCount.errors.message.trim() === "The current user cannot perform operations") {
                        $(".error-msg-header").html(data.cartCount.errors.message);
                        $(".mm-error-msg-header").removeClass("d-none");
                        $(".logout").click();
                        alert('Your session has expired . Redirecting you to the login page .');
                    }
                }
            } else if (data && data.cartQuery && data.cartQuery.split("=")[0].trim() === "No such entity with cartId") {
                var selectedCustomer = getCookie("selectedCustomer");
                createCartId(selectedCustomer)
            }
        },
        error: function(e) {}
    });
}

function respErrorMsgDisplay(message) {
    $(".error-msg-header").html(message);
    $(".mm-error-msg-header").removeClass("d-none");
    $(".mm-error-msg-header").fadeIn(1000);
    $(".mm-error-msg-header").parent().parent()[0].scrollIntoView();
    setTimeout(function() {
        $(".mm-error-msg-header").fadeOut(5000);
    }, 10000);
}

function epcLink(selectedCustomer) {
    var merclinkCustomerPersonalInfo = JSON.parse(getCookie("merclinkCustomerPersonalInfo"));
    var completeAccountDetails = JSON.parse(getCookie("completeAccountDetails"));
    var filterItem = completeAccountDetails.filter(element => element.company_number == selectedCustomer)
    var tax_group = filterItem.length > 0 ? filterItem[0].tax_group : "";
    var country =digitalData.page.pageInfo.country;
    var url = "";
    if (country == "AU" && tax_group == "GST") {
        url = $("#epcgst").val() + merclinkCustomerPersonalInfo.company_email;
    } else {
        url = $("#epcnogst").val() + merclinkCustomerPersonalInfo.company_email;
    }
    if (country == "NZ") {
         url = $("#epcgst").val() + merclinkCustomerPersonalInfo.company_email;

    }
    $("li[data-permission='F-I-EPC']").children().prop("href", url);
}

function categorytree(items) {
    var data = items.filter(element => {
        var product_count = element.product_count ? element.product_count : 0;
        if (product_count != 0) {
            return element;
        }
    });
    if (data.length > 0) {
        var menu = '';
        data.forEach((element, index) => {
            var submenu = '';
            var plpPath = $("#plpPath").val() != null ? $("#plpPath").val() : "#";
            for (var i = 0; i < element.children.length; i++) {
                var product_count = element.children[i].product_count ? element.children[i].product_count : 0;
                if (product_count != 0) {
                    var url = plpPath + "?name=" + encodeURIComponent(element.children[i].name) + "&id=" + element.children[i].id;
                    if (i % 2 != 0) {
                        var url1 = plpPath + "?name=" + encodeURIComponent(element.children[i - 1].name) + "&id=" + element.children[i - 1].id;
                        submenu += '<div class="row"><div class="col-md-6 shop-by-cat-submenus"><a class="dropdown-item" href="' + url1 + '">' + element.children[i - 1].name + '</a></div><div class="col-md-6 shop-by-cat-submenus"><a class="dropdown-item" href="' + url + '">' + element.children[i].name + '</a></div></div><br>';
                    }
                    if (i == (element.children.length - 1)) {
                        if (i % 2 == 0) {
                            submenu += '<div class="row"><div class="col-md-6 shop-by-cat-submenus"><a class="dropdown-item" href="' + url + '">' + element.children[i].name + '</a></div></div><br>';
                        }
                    }
                }
            }
            if (submenu != '') {
                menu += '<div class="dropdown-submenu"><a id="shop-by-cat-item-' + index + '" class="dropdown-item shopbycategory-items" href="javascript:void(0)">' + element.name + ' <span class="subarrow"></span></a><div id="shop-by-cat-submenu-' + index + '" class="shop-by-category-submenu display-none ">' + submenu + '</div></div>';
            } else {
                menu += '<div class="dropdown-submenu"><a id="shop-by-cat-item-' + index + '" class="dropdown-item shopbycategory-items" href="javascript:void(0)">' + element.name + ' </a></div>';
            }
        });
        $(".shop-by-cat-dropdown-menu").html(menu);
        $("#shop-by-category-options").click(function(e) {
            $(".shop-by-cat-dropdown-menu").toggle();
            $(".shop-by-category-submenu").css("display", "none");
            e.stopImmediatePropagation();
        });

        $(".shopbycategory-items").click(function() {
            $(".shop-by-cat-dropdown-menu").css("display", "block");
            let get_id = $(this).attr("id");
            let split_id = get_id.substring(17);
            let new_id = "#shop-by-cat-submenu-" + split_id;
            $('.shop-by-category-submenu').not(new_id).hide();
            $(new_id).toggle();
        });
    } else {
        $(".shop-by-cat-dropdown-menu").empty();
    }
}

function getProp65(prop65) {
    var warnings = {
        "Cancer": "cancer",
        "Cancer and Reproductive Harm": "cancerandreproductiveharm",
        "Reproductive Harm": "reproductiveharm",
        "N": "reproductiveharm",
        "001": "cancer",
        "003": "cancerandreproductiveharm",
        "002": "reproductiveharm",
        "Yes": "cancerandreproductiveharm",
    };
    var prop65res = "";
    if (warnings[prop65]) {
        prop65res = '<i> <img src="/content/dam/merclinkimages/warning.svg" class="warning-img"> </i> <span><strong>WARNING</strong>: ' + warnings[prop65] + ' - <a href="www.P65Warnings.ca.gov" target="_blank">www.P65Warnings.ca.gov</a></span>';
    }
    return prop65res;
}