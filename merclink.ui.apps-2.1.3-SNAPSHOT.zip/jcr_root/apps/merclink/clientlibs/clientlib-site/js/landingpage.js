$(document).ready(function () {
	$('.dropdown-submenu a.arrowclick').on("click", function (e) {
		$(this).next('div').toggle();
		e.stopPropagation();
		e.preventDefault();
		if (window.matchMedia("(orientation: portrait)").matches) {
			$('.tabporthide').hide();
			$('.portmenu').toggle();
		}
		if (window.innerHeight >= 320 && window.innerWidth <= 740) {
			$('.tabporthide').hide();
			$('.portmenu').toggle();
		}

	});
});
window.addEventListener("orientationchange", function (event) {
	if (event.target.screen.orientation.angle == 0) {
		$('.tabporthide').hide();
		$('.portmenu').hide();
	} else {
		$('.tabporthide').hide();
		$('.portmenu').hide();
	}
});


