//global ajax call
$(document).ready(function () {
    if (!$(".mm-error-msg")[0]) {
        $(".header").append("<div class='mm-error-msg  mb-3 d-none'><img src='/content/dam/merclink/images/Error.svg' class='me-1'> <span class='error-msg'>Please select at least one product to add to wish list</span></div>");
    }
    if (!$(".lds-dual-ring")[0]) {
        $(".header").append("<div id='loader' class='lds-dual-ring overlay hidden'></div>");
    } else {
        $(".lds-dual-ring").addClass("hidden");
    }

    $.ajaxSetup({
        beforeSend: function () {
            $(".lds-dual-ring").removeClass("hidden");
            $("body").addClass("backDisabled");
        },
        complete: function () {
            $(".lds-dual-ring").addClass("hidden");
            $('body').removeClass("backDisabled");
        },
        error: function (jqXHR, exception) {
            $('.modal').modal('hide');
            var msg = '';
            if (jqXHR.status === 0) {
                msg = 'Not connect.\n Verify Network.';
            } else if (jqXHR.status == 404) {
                msg = 'Requested page not found. [404]';
            } else if (jqXHR.status == 500) {
                msg = 'Internal Server Error [500].';
            } else if (exception === 'parsererror') {
                msg = 'Requested JSON parse failed.';
            } else if (exception === 'timeout') {
                msg = 'Time out error.';
            } else if (exception === 'abort') {
                msg = 'Ajax request aborted.';
            } else {
                msg = 'Uncaught Error.\n' + jqXHR.responseText;
            }
            $(".mm-error-msg span").empty();
            $(".mm-error-msg span").text("" + msg + "");
            $(".mm-error-msg").removeClass("d-none");
            $(".mm-error-msg").fadeIn("slow");
            $('html,body').animate({
                scrollTop: $(".mm-error-msg").offset().top
            }, 'slow');
            setTimeout(function () {
                $(".mm-error-msg").fadeOut("slow");
            }, 10000);
            $("body").removeClass("backDisabled");
        }
    });

});
