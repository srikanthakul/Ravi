$(document).ready(function() {

    $(".resultperpage").change(function() {
        var showItem = $(this).val();
        var pageNumber = $(".curpage").val();
        $(".resultperpage").val(showItem);
        $(".curpage").val(pageNumber);
        pagination(showItem, pageNumber, "order_details_table", "curpage", "total-value");
        pagination(showItem, pageNumber, "shipping_table", "curpage", "total-value");
    });

    $(".curpage").change(function() {
        var showItem = $(".resultperpage").val();
        var pageNumber = $(this).val();
        $(".resultperpage").val(showItem);
        $(".curpage").val(pageNumber);
        pagination(showItem, pageNumber, "order_details_table", "curpage", "total-value");
        pagination(showItem, pageNumber, "shipping_table", "curpage", "total-value");
    });


    $("table").after("<div class='mm-table-filter' style='text-align:center'>No data found</div>");
    $("#order-box-print").removeClass('d-none');


    $('.bi-chevron-left').click(()=> $(".curpage > option:selected").prev().val() && $(".curpage").val($(".curpage > option:selected").prev().val() ) && $(".curpage").change());
    $('.bi-chevron-right').click(()=>$(".curpage > option:selected").next().val() && $(".curpage").val($(".curpage > option:selected").next().val()) && $(".curpage").change());

    /* print page */
    $("a.Print-Page").click(function () {
        $(".noExport").addClass('d-none');
        $("#profile").addClass('d-none');
        $(".wish-reorder").addClass('d-none');
        $(".orderD-tab").addClass('d-none');
        $(".up-down-icon").addClass('d-none');
        $(".pagination-row").addClass('d-none');
        $("#home-tab").addClass('d-none');
        var cssLink = "";
        $("link[rel='stylesheet']").each(function () {
            cssLink +=
                "<link rel='stylesheet' href='" +
                $(this).prop("href") +
                "' type='text/css'>";
        });
        const element = document.getElementById("pdf-container");
        var divToPrint = element.cloneNode(true);
        var newWin = window.open("", "Print-Window");
        newWin.document.open();
        newWin.document.write(
            "<html><head>" +
            cssLink +
            '</head><body onload="window.print()">' +
            divToPrint.innerHTML +
            "</body></html>"
        );
        newWin.document.close();
        setTimeout(function () {
            newWin.close();
        }, 100);
        $(".noExport").removeClass('d-none');
        $("#profile").removeClass('d-none');
        $(".wish-reorder").removeClass('d-none');
        $(".orderD-tab").removeClass('d-none');
        $(".up-down-icon").removeClass('d-none');
        $(".pagination-row").removeClass('d-none');
        $("#home-tab").removeClass('d-none');
    });

    $(".accordion-header").click(() => {
        $("#panelsStayOpen-headingOne button").html("&nbsp &nbsp Hide Order Details");
        $("#panelsStayOpen-headingOne button.collapsed").html("&nbsp &nbsp Show Order Details");
        $("#panelsStayOpen-headingTwo button").html("&nbsp &nbsp Hide Address Details");
        $("#panelsStayOpen-headingTwo button.collapsed").html("&nbsp &nbsp Show Address Details");
        $("#panelsStayOpen-headingThree button").html("&nbsp &nbsp Hide Order Summary");
        $("#panelsStayOpen-headingThree button.collapsed").html("&nbsp &nbsp Show Order Summary");
    });


    var itemNumLink = $(".mm-item-num-link").text();

    let url = new URL(document.location);
    let params = url.searchParams;
    let orderNumber = params.get("order_number");
    var selectedCustomer = getCookie("selectedCustomer");

    var data = {
        headerId: orderNumber,
        resourcePath: $("#resourcePathOrderDetail").val(),
        customerNumber: parseInt(selectedCustomer)
    };

    $.ajax({
        type: "GET",
        url: "/bin/merclink/OrderDetailsServlet",
        ContentType: 'application/json',
        async:false,
        data: {
            'data': JSON.stringify(data)
        },
        beforeSend: function () {
            $('#loader').removeClass('hidden')
        },
        success: function (data) {

            if (data != null && data.data != null){
                var responseData = data.data;

                if (responseData.order_number.length != 0 && responseData.order_number != null && responseData.order_number != "null") {
                    var Ordertabletitle = $('#orderTableTitle').val();
                    if(Ordertabletitle.length > 0 && Ordertabletitle != null && params.get("order_number") != null){
                        $('#pageTitle').text(Ordertabletitle+" - Order "+params.get("order_number"));
                        $(".page-title").text($('#pageTitle').text().trim()); // for breadcrumbs
                    }
                }

                if (responseData.po_number.length != 0 && responseData.po_number != null && responseData.po_number != "null") {
                    $('#PoNumber').text(responseData.po_number);
                } else {
                    $('#PoNumber').html("NA");
                }

                if (responseData.shipping_preference.length != 0 && responseData.shipping_preference != null && responseData.shipping_preference != "null") {
                    $('#ShipmentPriority').text(responseData.shipping_preference);
                } else {
                    $('#ShipmentPriority').html("NA");
                }

                if (responseData.customer_name.length != 0 && responseData.customer_name != null && responseData.customer_name != "null") {
                    $('#AccountName').text(responseData.customer_name);
                } else {
                    $('#AccountName').html("NA");
                }

                if (responseData.shipping.method.length != 0 && responseData.shipping.method != null && responseData.shipping.method != "null") {
                    $('#ShippingMethod').text(responseData.shipping.method);
                } else {
                    $('#ShippingMethod').html("NA");
                }

                if (responseData.order_source.length != 0 && responseData.order_source != null && responseData.order_source != "null") {
                    $('#OrderSource').text(responseData.order_source);
                } else {
                    $('#OrderSource').html("NA");
                }

                if (responseData.request_date.length != 0 && responseData.request_date != null && responseData.request_date != "null") {
                    $('#OrderedDate').text(responseData.ordered_date.split("-").reverse().join("-"));
                } else {
                    $('#OrderedDate').html("NA");
                }

                if (responseData.packing_instructions.length != 0 && responseData.packing_instructions != null && responseData.packing_instructions != "null") {
                    $('#PackingInstructions').text(responseData.packing_instructions);
                } else {
                    $('#PackingInstructions').html("NA");
                }

                if (responseData.request_date.length != 0 && responseData.request_date != null && responseData.request_date != "null") {
                    $('#RequestedShipDate').text(responseData.request_date.split("-").reverse().join("-"));
                } else {
                    $('#RequestedShipDate').html("NA");
                }

                if (responseData.shipping.ship_to.name.length != 0 && responseData.shipping.ship_to.name != null && responseData.shipping.ship_to.name != "null") {
                    $('#ShipToName').text(responseData.shipping.ship_to.name);
                } else {
                    $('#ShipToName').html("NA");
                }

                if (responseData.shipping.ship_to.full_address.length != 0 && responseData.shipping.ship_to.full_address != null && responseData.shipping.ship_to.full_address != "null") {
                    $('#ShipToAddress').html(responseData.shipping.ship_to.full_address);
                } else {
                    $('#ShipToAddress').html("NA");
                }

                if (responseData.billing_address.name.length != 0 && responseData.billing_address.name != null && responseData.billing_address.name != "null") {
                    $('#BillToName').text(responseData.billing_address.name);
                } else {
                    $('#BillToName').html("NA");
                }

                if (responseData.billing_address.full_address.length != 0 && responseData.billing_address.full_address != null && responseData.billing_address.full_address != "null") {
                    $('#BillToAddress').html(responseData.billing_address.full_address);
                } else {
                    $('#BillToAddress').html("NA");
                }

                if (responseData.total_item_count != null) {
                    $('#TotalItems').text("(" + responseData.total_item_count + " items)");
                } else {
                    $('#TotalItems').html("NA");
                }

                if (responseData.charges_total != null) {
                    $('#totalCharge').text(parseFloat(responseData.charges_total).toLocaleString("en-US", {style: "currency", currency: "USD", minimumFractionDigits: 2}));
                } else {
                    $('#totalCharge').html("NA");
                }

                if (responseData.tax_amount != null) {
                    $('#TaxAmt').text(parseFloat(responseData.tax_amount).toLocaleString("en-US", {style: "currency", currency: "USD", minimumFractionDigits: 2}));
                } else {
                    $('#TaxAmt').html("NA");
                }

                if (responseData.subtotal != null) {
                    $('#subTotal').text(parseFloat(responseData.subtotal).toLocaleString("en-US", {style: "currency", currency: "USD", minimumFractionDigits: 2}));
                } else {
                    $('#subTotal').html("NA");
                }

                if (responseData.subtotal > 0 && responseData.grand_total == 0) {
                    if (responseData.grand_total != null) {
                        var grand_total = 0;
                        if (responseData.subtotal != null) {
                            grand_total += responseData.subtotal;
                        }
                        if (responseData.tax_amount != null) {
                            grand_total += responseData.tax_amount;
                        }
                        if (responseData.charges_total != null) {
                            grand_total += responseData.charges_total;
                        }

                        $('#TotalAmt').html("<strong>" + parseFloat(grand_total).toLocaleString("en-US", {style: "currency", currency: "USD", minimumFractionDigits: 2}) + "</strong>");
                    } else {
                        $('#TotalAmt').html("NA");
                    }

                } else if (responseData.grand_total != null && responseData.grand_total > 0 && responseData.subtotal > 0) {

                    $('#TotalAmt').html("<strong>" + parseFloat(responseData.grand_total).toLocaleString("en-US", {style: "currency", currency: "USD", minimumFractionDigits: 2}) + "</strong>");

                } else if (responseData.grand_total == 0 && responseData.subtotal == 0 && responseData.tax_amount == 0 && responseData.charges_total == 0) {

                    $('#TotalAmt').html("<strong>" + parseFloat(responseData.grand_total).toLocaleString("en-US", {style: "currency", currency: "USD", minimumFractionDigits: 2}) + "</strong>");
                } else {
                    $('#TotalAmt').html("NA");
                }

                var orderTable = responseData.items;
                if (typeof orderTable !== 'undefined' && orderTable.length > 0) {
                    $(orderTable).each(function (i, e) {
                        if (orderTable.length > 0) {
                            $(".mm-table-filter").remove();
                            $(".mm-table-filter-order").remove();

                            var order_elements = '<tr><td><input class="form-check-input ms-0 addtoCartCheckBox" itemid="' + orderTable[i].item_number + '" type="checkbox" value=""></td>';
                            order_elements += '<td class=""><a href="'+itemNumLink+'?sku=' + orderTable[i].item_number + '">' + orderTable[i].item_number + '</a></td>';
                            order_elements += '<td class="desc-' + orderTable[i].item_number + '" id="desc' + orderTable[i].item_number + '">' + orderTable[i].description + '</td>';

                            if (orderTable[i].ordered_quantity != null && orderTable[i].ordered_quantity != undefined) {
                                order_elements += '<td class="qty-' + orderTable[i].item_number + '" id="qty' + orderTable[i].item_number + '">' + orderTable[i].ordered_quantity + '</td>';
                            } else {
                                order_elements += '<td></td>';
                            }

                            order_elements += '<td>' + orderTable[i].availability_date.split("-").reverse().join("-") + '</td>';
                            order_elements += '<td>' + orderTable[i].warehouse_name + '</td>';
                            order_elements += '<td>' + orderTable[i].status + '</td>';

                            if (orderTable[i].selling_price != null && orderTable[i].selling_price != undefined) {
                                order_elements += '<td>' + parseFloat(orderTable[i].selling_price).toLocaleString("en-US", {style: "currency", currency: "USD", minimumFractionDigits: 2}) + '</td>';
                            } else {
                                order_elements += '<td></td>';
                            }

                            order_elements += '<td>' + responseData.credit_hold + '</td>';
                            order_elements += '<td>' + responseData.payment_term + '</td>';
                            order_elements += '</tr>';

                            $(".Order-Details-Table").append(order_elements);

                            pagination(20, 1, "order_details_table", "curpage", "total-value");
                        }
                    })

                } else {

                    $(".mm-table-filter").remove();
                    $(".mm-table-filter-order").remove();
                    $("#order_details_table").after("<div class='mm-table-filter-order' style='text-align:center'>No data found</div>");
                }

                var shippingTable = responseData.shipment_items;

                if (typeof shippingTable !== 'undefined' && shippingTable.length > 0) {
                    $(shippingTable).each(function (i, e) {

                        if (shippingTable.length > 0) {
                            $(".mm-table-filter").remove();

                            var table_elements = '<tr><td><input class="form-check-input ms-0 addtoCartShipCheckBox" shippingitemid="' + shippingTable[i].item_number + '" type="checkbox" value=""></td>';
                            table_elements += '<td class=""><a href="'+itemNumLink+'?sku=' + shippingTable[i].item_number + '">' + shippingTable[i].item_number + '</a></td>';
                            table_elements += '<td class="descship-' + shippingTable[i].item_number + '" id="descship' + shippingTable[i].item_number + '">' + shippingTable[i].description + '</td>';

                            if (shippingTable[i].ordered_quantity != null && shippingTable[i].ordered_quantity != undefined) {
                                table_elements += '<td class="qty-' + shippingTable[i].ordered_quantity + '" id="qtyship' + shippingTable[i].item_number + '">' + shippingTable[i].ordered_quantity + '</td>';
                            } else {
                                table_elements += '<td></td>';
                            }

                            table_elements += '<td>' + shippingTable[i].warehouse_name + '</td>';
                            table_elements += '<td>' + shippingTable[i].freight_terms + '</td>';
                            table_elements += '<td>' + responseData.shipping_preference + ' </td>';

                            if (typeof shippingTable[i].supplier_references !== undefined && shippingTable[i].supplier_references.length > 0 && shippingTable[i].tracking_numbers.length > 0 && shippingTable[i].delivery_numbers.length > 0) {
                                table_elements += '<td>Tracking #:<strong><a href="https://www.smartfreight.com/tracking/' + shippingTable[i].supplier_references + '" target="_blank">' + shippingTable[i].tracking_numbers + '</a></strong></br>Delivery #:' + shippingTable[i].delivery_numbers + '</td>';
                            } else if (shippingTable[i].tracking_numbers.length > 0 && shippingTable[i].delivery_numbers.length > 0) {
                                table_elements += '<td>Tracking #:<strong>' + shippingTable[i].tracking_numbers + '</strong></br>Delivery #:' + shippingTable[i].delivery_numbers + '</td>';
                            } else if (shippingTable[i].delivery_numbers.length > 0) {
                                table_elements += '<td>Tracking #:<strong></strong></br>Delivery #:' + shippingTable[i].delivery_numbers + '</td>';
                            } else if (shippingTable[i].tracking_numbers.length > 0) {
                                table_elements += '<td>Tracking #:' + shippingTable[i].tracking_numbers + '<strong></strong></br>Delivery #:</td>';
                            } else {
                                table_elements += '<td>Tracking #:<strong></strong></br>Delivery #:</td>';
                            }

                            if (shippingTable[i].serial_numbers.length > 1) {
                                 var serialnumber = "";
                                 shippingTable[i].serial_numbers[i].forEach((element,index)=>{
                                  serialnumber += element + "</br>";
                                });

                                table_elements += '<td>'+ shippingTable[i].serial_numbers[0] +'</br><a href="javascript:void(0)" class="tooltip-box">View More</a>';
                                table_elements += '<div class="mm-common-tooltip w-20"><div class="h6 d-flex justify-content-between align-items-center m-0 position-relative">';
                                table_elements += '<i class="tooltip-close position-absolute end-0 w-auto view-more">x</i></div>';
                                table_elements += '<div class="mm-tooltiptext p-3"><p id="serial-'+ i +'" class="mt-2 mb-0 serial'+i+'">'+serialnumber+'</p></div></div>';
                                table_elements += '</td>';
                            }else if(shippingTable[i].serial_numbers.length == 1){
							    table_elements += '<td>' + shippingTable[i].serial_numbers[0] + '</td>';
                            } else {
                                table_elements += '<td></td>';
                            }

                            table_elements += '</tr>'

                            $(".Shipping-Details-Table").append(table_elements);

                            pagination(20, 1, "shipping_table", "curpage", "total-value");
                        }
                    })

                } else {
                    $(".mm-table-filter").remove();
                    $("#shipping_table").after("<div class='mm-table-filter' style='text-align:center'>No data found</div>");
                }


            } else {

                console.log(data);
                $("#order-box-print").addClass('d-none');
                $("#order-box-print").after("<div class='mm-table-filter' style='text-align:center'>No data found</div>");

                if (data != null && data.detail != null) {
                    var errmsg = data.detail;
                    respMsgDisplay(503, errmsg);
                }

            }


        },
        complete: function () {
            $('#loader').addClass('hidden')
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            console.log("Status: " + textStatus);
            console.log("Error: " + errorThrown);
        }
    });

   // tootltip hide show

    $(".tooltip-box").click(function() {
        $(this).parent().addClass("tooltip-open");
    });

    $(".tooltip-close").click(function() {
        $(this).parents().removeClass("tooltip-open");
    });


    $(".add-to-wishlist").click(function () {
        var count = 0;
        $('.Order-Details-Table input[type=checkbox]:checked').each(function () {
            count = count + 1;
        });
        var shipcount = 0;
        $('.Shipping-Details-Table input[type=checkbox]:checked').each(function () {
            shipcount = shipcount + 1;
        });

        if (count > 0 || shipcount > 0) {
            getWishlistModal()
        } else {
            var msg = "Please select at least one product to copy to other wish list";
            respMsgDisplay(202, msg);
        }


    });

    /* select all checkbox*/
    $('.selectall').click(function (e) {
        $(this).closest('table').find('td input:checkbox').prop('checked', this.checked);
    });

    /* uncheck all selected boxes*/
    $('#profile-tab').click(function () {
        $('.selectall').prop('checked', false);
        $('tbody tr td input[type="checkbox"]').each(function () {
            $(this).prop('checked', false);
        });
        $('#page-break').addClass('noExport');
    });

    $('#home-tab').click(function () {
        $('.selectall').prop('checked', false);
        $('tbody tr td input[type="checkbox"]').each(function () {
            $(this).prop('checked', false);
        });
        $('#page-break').removeClass('noExport');
    });
    
    /*  title change */
    $('#profile-tab').click(function () {
		var pagetitle = $('#shippingTableTitle').val();
        if(pagetitle.length > 0 && pagetitle != null && params.get("order_number") != null){
			$('#pageTitle').text(pagetitle+" - Order "+params.get("order_number"));
            $(".page-title").text($('#pageTitle').text().trim()); // for breadcrumbs
		}else if(pagetitle.length > 0 && pagetitle != null){
			$('#pageTitle').text(pagetitle);
            $(".page-title").text($('#pageTitle').text().trim()); // for breadcrumbs
		}else{
			$('#pageTitle').text("NA");
		}
    }); 
    $('#home-tab').click(function () {
		var pagetitle = $('#orderTableTitle').val();
		if(pagetitle.length > 0 && pagetitle != null && params.get("order_number") != null){
			$('#pageTitle').text(pagetitle+" - Order "+params.get("order_number"));
            $(".page-title").text($('#pageTitle').text().trim()); // for breadcrumbs
		}else if(pagetitle.length > 0 && pagetitle != null){
			$('#pageTitle').text(pagetitle);
            $(".page-title").text($('#pageTitle').text().trim()); // for breadcrumbs
		}else{
			$('#pageTitle').text("NA");
		}
    });



    /* Table Sorting */

    $('#shipping_table .img-down-icon').click(function () {

        var tableId = "shipping_table";

        var rowIndex = $(this).parent().parent().parent().parent().index('#' + tableId + ' tr');

        var thIndex = $(this).parent().parent().parent().index('#' + tableId + ' tr:eq(' + rowIndex + ') th');

        sortTable(parseInt(thIndex), 'asc', tableId);

        var showItem = $(".resultperpage").val();

        var pageNumber = $(".curpage").val();

        pagination(showItem, pageNumber, "shipping_table", "curpage", "total-value");

    });



    $('#shipping_table .img-up-icon').click(function () {

        var tableId = "shipping_table";

        var rowIndex = $(this).parent().parent().parent().parent().index('#' + tableId + ' tr');

        var thIndex = $(this).parent().parent().parent().index('#' + tableId + ' tr:eq(' + rowIndex + ') th');

        sortTable(parseInt(thIndex), 'desc', tableId);

        var showItem = $(".resultperpage").val();

        var pageNumber = $(".curpage").val();

        pagination(showItem, pageNumber, "shipping_table", "curpage", "total-value");

    });




    $('#order_details_table .img-down-icon').click(function () {

        var tableId = "order_details_table";

        var rowIndex = $(this).parent().parent().parent().parent().index('#' + tableId + ' tr');

        var thIndex = $(this).parent().parent().parent().index('#' + tableId + ' tr:eq(' + rowIndex + ') th');

        sortTable(parseInt(thIndex), 'asc', tableId);

        var showItem = $(".resultperpage").val();

        var pageNumber = $(".curpage").val();

        pagination(showItem, pageNumber, "order_details_table", "curpage", "total-value");

    });



    $('#order_details_table .img-up-icon').click(function () {

        var tableId = "order_details_table";

        var rowIndex = $(this).parent().parent().parent().parent().index('#' + tableId + ' tr');

        var thIndex = $(this).parent().parent().parent().index('#' + tableId + ' tr:eq(' + rowIndex + ') th');

        sortTable(parseInt(thIndex), 'desc', tableId);

        var showItem = $(".resultperpage").val();

        var pageNumber = $(".curpage").val();

        pagination(showItem, pageNumber, "order_details_table", "curpage", "total-value");

    });




    /* save as pdf*/
    $(document).on("click", "#order-conf-pdf", function () {
        getPDForderConfirmation();
    });
    //PDF Download //
    function getPDForderConfirmation() {
        var d = jQuery.Deferred(),
            p = d.promise();
        p.pipe(generatePdforderConfirmation);
        d.resolve();
    }

    function generatePdforderConfirmation() {

        $('#shipping_table').addClass('d-none');
        $('.pagination-row').addClass('d-none');
        $('.total-value').addClass('d-none');
        $('.total-value').addClass('d-none');
        $('.bi-chevron-left').addClass('d-none');
        $('.curpage').addClass('d-none');
        $('.bi-chevron-right').addClass('d-none');
        $('.mm-total-result').addClass('d-none');
        $('.resultperpage').addClass('d-none');
        $('.add-to-wishlist').addClass('d-none');
        $('.reorder').addClass('d-none');
        if($('#profile-tab').hasClass('active')){
            $('#page-break').addClass('d-none');
            $('#ship-page-break').removeClass('page-break');
        }

        kendo.drawing.drawDOM($('#pdf-container'), {
            paperSize: "A4",
            margin: {
                left: "0.5cm",
                top: "0.5cm",
                right: "0.5cm",
                bottom: "1cm"
            },
            scale: 0.6,
            multiPage: true,
            landscape: true,
            repeatHeaders: true,
            template: $("#orderDetail_page").html(),
            forcePageBreak: ".page-break",
            height: 500,
            KeepTogether: true

        }).then(function (group) {
            if(orderNumber != null){
                kendo.drawing.pdf.saveAs(group, orderNumber+".pdf");
            }else{
                kendo.drawing.pdf.saveAs(group, "order-details.pdf");
            }
        }).then(function () {
            $('#shipping_table').removeClass('d-none');
            $('.pagination-row').removeClass('d-none');
            $('.total-value').removeClass('d-none');
            $('.total-value').removeClass('d-none');
            $('.bi-chevron-left').removeClass('d-none');
            $('.curpage').removeClass('d-none');
            $('.bi-chevron-right').removeClass('d-none');
            $('.mm-total-result').removeClass('d-none');
            $('.resultperpage').removeClass('d-none');
            $('.add-to-wishlist').removeClass('d-none');
            $('.reorder').removeClass('d-none');
            $('#page-break').removeClass('d-none');
            $('#ship-page-break').addClass('page-break');
        });


    }
    
    $(document).on("click",".addtoCartCheckBox",function(){
        var numberChecked = $(".addtoCartCheckBox:checked").length;
        var totalRows= $('.addtoCartCheckBox').length;
        if(numberChecked == totalRows){
         $('.order-all').prop("checked",true);
        }else{
         $('.order-all').prop("checked",false);
        }
      });
 
      $(document).on("click",".addtoCartShipCheckBox",function(){
         var numberChecked = $(".addtoCartShipCheckBox:checked").length;
         var totalRows = $('.addtoCartShipCheckBox').length
         if(numberChecked == totalRows){
             $('.shipping-all').prop("checked",true);
         }else{
             $('.shipping-all').prop("checked",false);
         }
       });

});

function addtoWishListItem() {
    var c = [];
    var count = 0;
    var countshippingtable = 0;
    $('.Order-Details-Table input[type=checkbox]:checked').each(function () {
        count = count + 1;
        var b = $(".qty-" + $(this).attr("itemid")).html();

        var products = {
            skuid: $(this).attr("itemid"),
            quantity: b
        }
        c.push(products);


    });

    $('.Shipping-Details-Table input[type=checkbox]:checked').each(function () {

        countshippingtable = countshippingtable + 1;

        var shipqty = $(".qty-" + $(this).attr("shippingitemid")).html();
        var products = {
            skuid: $(this).attr("shippingitemid"),
            quantity: shipqty
        }
        c.push(products);


    });

    if (count > 0) {

        AddProductToWishL(c, "addfromcart", "", "available", "").success(function (b) {
            $(".Order-Details-Table .form-check-input:checked").each(function () {
                this.checked = !1
            });
      
            if(b.alreadyExists){
                $("#add-to-wishlist-modal").modal("hide");
                    var existmsg = b.alreadyExists;
                    respMsgDisplay(202, existmsg);
            }else if(b.wishlisttype){
                if(b.wishlisttype == "newwish" || b.wishlisttype == "existwish"){
                    $("#add-to-wishlist-modal").modal("hide");
                    var newwish = "Item(s) have been added to your wish list : " + b.wishlistname;
                    respMsgDisplay(200, newwish);
                }
            }
            $('.selectall').attr('checked', false);

            //analytics
            if(b!=null && b.wishlisttype != null){
                var productDetailsArray = [];
                b.cartobj.forEach((element, index) => {

                    description = $("#desc" + element.skuid).html();
                    var productDetails = {
                        "productQuantity": element.quantity > 0 ? element.quantity : 0,
                        "productInfo": {
                            "productID": element.skuid,
                            "productName": description,
                        }
                    };
                    
                    productDetailsArray.push(productDetails);
                    
                });    

                addToWishlist = {};
                addToWishlist['product'] = productDetailsArray;
                digitalData["addtoWishlist"] = addToWishlist;
                _satellite.track('Add to wishlist', { linkName: $(".add-to-wishlist").html() });
            }

        });

    } else if (count == 0 && countshippingtable == 0) {
        var msg = "Please select at least one product to copy to other wish list";
        respMsgDisplay(202, msg);
        $('.selectall').attr('checked', false);
    }

    if (countshippingtable > 0) {
        AddProductToWishL(c, "addfromcart", "", "available", "").success(function (shipqty) {
            $(".Shipping-Details-Table .form-check-input:checked").each(function () {
                this.checked = !1
            });

            if(shipqty.alreadyExists){
                $("#add-to-wishlist-modal").modal("hide");
                    var existmsg = shipqty.alreadyExists;
                    respMsgDisplay(202, existmsg);
            }else if(shipqty.wishlisttype){
                if(shipqty.wishlisttype == "newwish" || shipqty.wishlisttype == "existwish"){
                    $("#add-to-wishlist-modal").modal("hide");
                    var newwish = "Item(s) have been added to your wish list : " + shipqty.wishlistname;
                    respMsgDisplay(200, newwish);
                }
            }
            $('.selectall').attr('checked', false);
            
            //analytics
            if(shipqty!=null && shipqty.wishlisttype != null){
                var productDetailsArray = [];
                shipqty.cartobj.forEach((element, index) => {

                    description = $("#descship" + element.skuid).html();
                    var productDetails = {
                        "productQuantity": element.quantity > 0 ? element.quantity : 0,
                        "productInfo": {
                            "productID": element.skuid,
                            "productName": description,
                        }
                    };
                    
                    productDetailsArray.push(productDetails);
                    
                });    
                addToWishlist = {};
                addToWishlist['product'] = productDetailsArray;
                digitalData["addtoWishlist"] = addToWishlist;
                _satellite.track('Add to wishlist', { linkName: $(".add-to-wishlist").html() });
            }
        });
        $('.selectall').attr('checked', false);

    } else if (count == 0 && countshippingtable == 0) {
        var shipmsg = "Please select at least one product to copy to other wish list";
        respMsgDisplay(202, shipmsg);

        $('.selectall').attr('checked', false);
    }


}

function respMsgDisplay(statusCode, message, ) {
    if (statusCode == 200) {
        $(".mm-success-msg span").empty();
        $(".mm-success-msg span").text("" + message + "");
        $(".mm-success-msg").removeClass("d-none");
        $(".mm-success-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-success-msg").offset().top
        }, 'slow');
        setTimeout(function () {
            $(".mm-success-msg").fadeOut("slow");
        }, 20000);



    } else if (statusCode == 202) {
        $(".mm-error-msg span").empty();
        $(".mm-error-msg span").text("" + message + "");
        $(".mm-error-msg").removeClass("d-none");
        $(".mm-error-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-error-msg").offset().top
        }, 'slow');
        setTimeout(function () {
            $(".mm-error-msg").fadeOut("slow");
        }, 20000);

    } else if (statusCode == 503) {
        $(".mm-error-msg span").empty();
        $(".mm-error-msg span").text("" + message + "");
        $(".mm-error-msg").removeClass("d-none");
        $(".mm-error-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-error-msg").offset().top
        }, 'slow');
        setTimeout(function () {
            $(".mm-error-msg").fadeOut("slow");
        }, 20000);
    }

}

/* reorder */
$(document).on("click", ".reorder", function () {
    var cartArray = [];
    if ($("#order_details_table input:checkbox:checked").length > 0) {
        $(".addtoCartCheckBox").each(function () {
            if ($(this).is(":checked")) {
                var itemNumber = $(this).attr("itemid");
                var qty = $("#qty" + itemNumber).html();
                if (itemNumber != "" && itemNumber != null && qty != "" && qty != "0" && qty != null) {
                    var cartobj = {
                        "skuid": itemNumber,
                        "quantity": qty.toString()
                    }
                    cartArray.push(cartobj);
                }
            }
        });
    }else if($("#shipping_table input:checkbox:checked").length > 0){
        $(".addtoCartShipCheckBox").each(function () {
            if ($(this).is(":checked")) {
                var itemNumber = $(this).attr("shippingitemid");
                var qty = $("#qtyship" + itemNumber).html();
                if (itemNumber != "" && itemNumber != null && qty != "" && qty != "0" && qty != null) {
                    var cartobj = {
                        "skuid": itemNumber,
                        "quantity": qty.toString()
                    }
                    cartArray.push(cartobj);
                }
            }
        });
    }else {
        if($('#profile-tab').hasClass('active')){           
            $('.shipping-all').prop("checked",true);
            $('.addtoCartShipCheckBox').prop("checked",true);
            $(".addtoCartShipCheckBox").each(function () {
                if ($(this).is(":checked")) {
                    var itemNumber = $(this).attr("shippingitemid");
                    var qty = $("#qtyship" + itemNumber).html();
                    if (itemNumber != "" && itemNumber != null && qty != "" && qty != "0" && qty != null) {
                        var cartobj = {
                            "skuid": itemNumber,
                            "quantity": qty.toString()
                        }
                        cartArray.push(cartobj);
                    }
                }
            });

        }else if($('#home-tab').hasClass('active')){
              $('.order-all').prop("checked",true);
              $('.addtoCartCheckBox').prop("checked",true);
              $(".addtoCartCheckBox").each(function () {
                var itemNumber = $(this).attr("itemid");
                var qty = $("#qty" + itemNumber).html();
                if (itemNumber != "" && itemNumber != null && qty != "" && qty != "0" && qty != null) {
                    var cartobj = {
                        "skuid": itemNumber,
                        "quantity": qty.toString()
                    }
                    cartArray.push(cartobj);
                }
            });
        }else{
            
            $(".addtoCartCheckBox").each(function () {
                var itemNumber = $(this).attr("itemid");
                var qty = $("#qty" + itemNumber).html();
                if (itemNumber != "" && itemNumber != null && qty != "" && qty != "0" && qty != null) {
                    var cartobj = {
                        "skuid": itemNumber,
                        "quantity": qty.toString()
                    }
                    cartArray.push(cartobj);
                }
            });
        }
    } 
    
    if (cartArray.length > 0) {
        var data = {
            "componentPath": $("#resourcePathOrderDetail").val(),
            cartId: getCookie("cartId"),
            cartobj: cartArray
        }
        
        $.ajax({
            type: "POST",
            url: "/bin/cart/addToCartQuery",
            ContentType: "application/json",
            dataType: "json",
            data: {
                'data': JSON.stringify(data)
            },
            beforeSend: function () {
                $('#loader').removeClass('hidden');
                $('body').addClass("backDisabled");

            },
            complete: function () {
                $('#loader').addClass('hidden');
                $('body').removeClass("backDisabled");
            },
            success: function(data) {
                if (data && data.addProductsToCart) {
                    if (data.addProductsToCart.cart && data.addProductsToCart.cart.items && data.addProductsToCart.cart.items.length > 0) {
                        $(".cart-item-display-number").html(data.addProductsToCart.cart.items.length);
                        setCookie("cartCount", data.addProductsToCart.cart.items.length, 30);

                        var sendSkuId = cartArray.map(element => element.skuid);
                        var matchedCartItemArray = data.addProductsToCart.cart.items.filter(element => sendSkuId.indexOf(element.product.sku) != -1);
                        var matchedCartItem = matchedCartItemArray.map(element => element.product.sku);
                        if (matchedCartItem.length > 0) {
                            var msg = 'Item(s) have been added/updated to Cart: ' + matchedCartItem.join().toString();
                            var productDetailsArray = [];
                            matchedCartItemArray.forEach((element, indexe) => {
                                var quantityFilter = cartArray.filter(cartElement => cartElement.skuid == element.product.sku);
                                var productDetails = {
                                    "productQuantity": quantityFilter.length > 0 ? quantityFilter[0].quantity : 0,
                                    "productInfo": {
                                        "productID": element.product.sku,
                                        "productName": element.product.name,
                                    }
                                };
                                productDetailsArray.push(productDetails);
                            });

                            addToCartlist = {};
                            addToCartlist['product'] = productDetailsArray;
                            digitalData["addtoCart"] = addToCartlist;
                            _satellite.track('Add to cart', { linkName: $(".reorder").html() });
                            respMsgDisplay(200, msg);
                        }
                    }

                    if (data.addProductsToCart.cart && data.addProductsToCart.cart.erp_errors && data.addProductsToCart.cart.erp_errors.length > 0) {
                        var errMsg = "";
                        data.addProductsToCart.cart.erp_errors.forEach((element) => {
                            errMsg += element.message + ", "
                        });
                        if (errMsg.length > 0) {
                            respMsgDisplay(202, errMsg);
                            window.scrollTo(0, 0);
                        }
                    }

                    if (data.addProductsToCart.user_errors != null && data.addProductsToCart.user_errors.length > 0) {
                        var errorHtml = "";
                        data.addProductsToCart.user_errors.forEach((element, i) => {
                            if (data.addProductsToCart.user_errors.length - 1 != i) {
                                errorHtml = errorHtml + element.message + ", ";
                            } else {
                                errorHtml = errorHtml + element.message;
                            }
                        });
                        if (errorHtml.length > 0) {
                            respMsgDisplay(202, errorHtml);
                            window.scrollTo(0, 0);
                        }
                    }

                } else if (data && data.createCartId) {
                    respMsgDisplay(202, data.createCartId);
                }
            },
            error: function (status, errorthrown) {
                console.log("function error" + errorthrown);
            }
        });
    }else{
        var emtyitmsg = "Please select at least one item from the list";
        respMsgDisplay(202, emtyitmsg);
    }
});