$(document).ready(function() {

    $(document).on("click", ".invoice_checkbox", function() {
        if ($('.invoice_checkbox:checked').length == $('.invoice_checkbox').length) {
            $('.selectall').prop('checked', true);
        } else {
            $('.selectall').prop('checked', false);
        }
    });
	
	$(".datepicker").datepicker({
        autoclose: true,
        dateFormat: 'dd/mm/yyyy',
        todayHighlight: true
    });
    
    pagination(20, 1, "invoice_merclink_table", "curpage", "total-value");
    $(".resultperpage").change(function() {
        var showItem = $(this).val();
        var pageNumber = $(".curpage").val();
        $(".resultperpage").val(showItem);
        $(".curpage").val(pageNumber);
        pagination(showItem, pageNumber, "invoice_merclink_table", "curpage", "total-value");
    });
    $(".curpage").change(function() {
        var showItem = $(".resultperpage").val();
        var pageNumber = $(this).val();
        $(".resultperpage").val(showItem);
        $(".curpage").val(pageNumber);
        pagination(showItem, pageNumber, "invoice_merclink_table", "curpage", "total-value");
    });
    $('#reset').click(function(ev) {
        ev.preventDefault();
        if (($("#invc_startDate").val() != '') || ($("#invc_endDate").val() != '') || ($(".order-invoice-text").val() != '')) {
            $(".order-invoice-text").val('');
            $('.order-invoice').prop('selectedIndex', 0);
            $(".order-invoice-text").attr("placeholder", "" + $('.order-invoice').val());
            $("#wf-inv").prop("checked" , false);
            $("#wf-inv").change();
            $("#invc-error-msg").addClass("d-none");
            last30DaysRecords();
            loadsearch();
        }
        return false;
    });
    //invoice order dropdown textbox 
    $(".order-invoice").on('change', function() {
        $("#invc_startDate").val('');
        $("#invc_endDate").val('');
        $(".order-invoice-text").val('');
        $('.order-invoice').val($(this).val());
        $(".order-invoice-text").attr("placeholder", "" + $(this).val());

    });
    //validation for date
    $("#invc_endDate").change(function() {
        var startDate = document.getElementById("invc_startDate").value.split("-").reverse().join("-");
        var endDate = document.getElementById("invc_endDate").value.split("-").reverse().join("-");

        if (Date.parse(endDate) < Date.parse(startDate)) {
            document.getElementById("invc_endDate").value = "";
            $(".mm-error-msg").removeClass("d-none");
            $("#invc-error-msg").html('<img src="/content/dam/merclink/images/Error.svg" width="25" class="me-1" /> End date should be greater than Start date');
            setTimeout(function(){
				$("#invc-error-msg").html("");
				$("#invc-error-msg").addClass("d-none");
			},5000)

        }
    });
    $("#invc_startDate").change(function() {

        var startDate = document.getElementById("invc_startDate").value.split("-").reverse().join("-");
        var endDate = document.getElementById("invc_endDate").value.split("-").reverse().join("-");
        if (Date.parse(endDate) < Date.parse(startDate)) {
            document.getElementById("invc_startDate").value = "";
            $("#invc-error-msg").html('<img src="/content/dam/merclink/images/Error.svg" width="25" class="me-1" /> Start date should be lesser than End date').removeClass("d-none");
            setTimeout(function(){
				$("#invc-error-msg").html("");
				$("#invc-error-msg").addClass("d-none");
			},5000)
        }
    });
    last30DaysRecords();
    
        function last30DaysRecords() {
            var date = new Date();
            date.setDate(date.getDate() - 30);
            var dateString = date.toISOString().split('T')[0];
            dateString = dateString.split("-").reverse().join("-");
            $("#invc_startDate").val(dateString);
            var todayDate = new Date();
            todayDate = todayDate.toISOString().split('T')[0];
            todayDate = todayDate.split("-").reverse().join("-");
            $("#invc_endDate").val(todayDate);
        }
    
    var currentURL = window.location.href;
	
	if(currentURL.includes("?wf=true")) {
	    $("#wf-inv").prop("checked",true);
	    $("#wf-inv").change();
	    loadsearch();
	}
	else {
		loadsearch();
	}
    

    $('#invoice_merclink_table .img-down-icon').click(function() {

        var tableId = "invoice_merclink_table";

        var rowIndex = $(this).parent().parent().parent().parent().index('#' + tableId + ' tr');


        var thIndex = $(this).parent().parent().parent().index('#' + tableId + ' tr:eq(' + rowIndex + ') th');

        sortTable(parseInt(thIndex), 'asc', tableId);

        var showItem = $(".resultperpage").val();

        var pageNumber = $(".curpage").val();

        pagination(showItem, pageNumber, "invoice_merclink_table", "curpage", "total-value");

    });

    $('#invoice_merclink_table .img-up-icon').click(function() {

        var tableId = "invoice_merclink_table";

        var rowIndex = $(this).parent().parent().parent().parent().index('#' + tableId + ' tr');

        var thIndex = $(this).parent().parent().parent().index('#' + tableId + ' tr:eq(' + rowIndex + ') th');

        sortTable(parseInt(thIndex), 'desc', tableId);


        var showItem = $(".resultperpage").val();

        var pageNumber = $(".curpage").val();

        pagination(showItem, pageNumber, "invoice_merclink_table", "curpage", "total-value");

    });

    $('.bi-chevron-left').click(() => $(".curpage > option:selected").prev().val() && $(".curpage").val($(".curpage > option:selected").prev().val()) && $(".curpage").change());

    $('.bi-chevron-right').click(() => $(".curpage > option:selected").next().val() && $(".curpage").val($(".curpage > option:selected").next().val()) && $(".curpage").change());
    /* export file */

    function download_table_as_csv(invoice_merclink_table, separator = ',') {
        var rows = document.querySelectorAll('table#' + invoice_merclink_table + ' tr');
        var csv = [];
        for (var i = 0; i < rows.length; i++) {
            var row = [],
                row1 = [],
                cols = rows[i].querySelectorAll('td, th');
            for (var j = 0; j < cols.length; j++) {
                if (i >= 1 && cols[0].children.length > 0 && cols[0].children[0].checked) {
                    var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
                    data = data.replace(/"/g, '""');
                    row.push('"' + data + '"');
                } else if (i == 0) {
                    var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
                    data = data.replace(/"/g, '""');
                    row.push('"' + data + '"');
                }

            }

            if (typeof row !== 'undefined' && row.length > 0) {
                csv.push(row.join(separator));
            }

        }

        var csv_string = csv.join('\n');
        var filename = 'export_' + invoice_merclink_table + '_' + new Date().toLocaleDateString() + '.csv';
        var link = document.createElement('a');
        link.style.display = 'none';
        link.setAttribute('target', '_blank');
        link.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv_string));
        link.setAttribute('download', filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    /* select all checkbox*/
    $('.selectall').click(function(e) {
        $(this).closest('table').find('td input:checkbox').prop('checked', this.checked);
    });

    $(".mm-invoice-csv").click(function() {
        if ($('.invoice_checkbox:checkbox:checked').length > 0) {
            download_table_as_csv("invoice_merclink_table", separator = ',');
        } else {
            $(".mm-error-msg").html(`<img src="/content/dam/merclink/images/Error.svg" width="25" class="me-1" /> Please select rows you want to export`);
            $(".mm-error-msg").removeClass("d-none");
            $(window).scrollTop(0);
            setTimeout(function(){
				$(".mm-error-msg").html("");
				$(".mm-error-msg").addClass("d-none");
			},3000);
        }

    });


});


function testfun(pdfValue) {

    var url = pdfValue;

    $(".pdf_hidden_value").val(url);
    $("#pdf_form").submit();
}

function loadsearch() {
	
	var invAccountVal = $(".mm-invoice-acc-val").text();

    var selectedCustomer = getCookie("customerNumber");
    let invc_startDate = document.getElementById('invc_startDate').value;
    let invc_endDate = document.getElementById('invc_endDate').value;

    var data = {

        "currentPage": $("#resourcePathPage").val(),
        "customerNumber": selectedCustomer,
        "start_date": invc_startDate.split("-").reverse().join("-"),
        "end_date": invc_endDate.split("-").reverse().join("-"),
        "orderNumber": "",
        "invoiceNumber": "",
        "invoiceAccount": ""
    }
    $('.order-invoice :selected').val() == "Enter MM Order Number" ? data["orderNumber"] = $(".order-invoice-text").val().trim() : data["orderNumber"] = '';
    $('.order-invoice :selected').val() == "Enter MM Invoice Number" ? data["invoiceNumber"] = $(".order-invoice-text").val().trim() : data["invoiceNumber"] ='';
    
    if($("#wf-inv").is(":checked")) {
		data["invoiceAccount"] = invAccountVal; 
	}
	else {
		data["invoiceAccount"] = "";
	}

    if ((data["orderNumber"] != "") || (data["invoiceNumber"] != "") || (data["start_date"] != "") || (data["end_date"] != "")) {
        $.ajax({
            type: "GET",
            url: "/bin/merclink/invoiceMerclink",
            ContentType: "application/json",
            data: {
                'data': JSON.stringify(data)
            },
            beforeSend: function() {
                $('#loader').removeClass('hidden')
            },
            success: function(data) {
                console.log(data);
                if (data != null) {
                    var invoices_det = data;
                    var tableContent = "";
                    var invoicesList = invoices_det.data.reverse();

                    if (invoicesList.length > 0) {

                        for (var i = 0; i < invoicesList.length; i++) {
                            var pdfcurvalue = "" + invoicesList[i].file_name + "";
							var invoiceDate =invoicesList[i].invoice_date;
                    		invoiceDate= invoiceDate.split("-").reverse().join("-");
                            if (pdfcurvalue != 'null') {
                                var PDF_tag = '<td onclick="testfun(\'' + pdfcurvalue + '\')" class="text-decoration-underline pdf_value invc-td-data" style="font-weight: bold;cursor:pointer;">' +
                                    invoicesList[i].invoice_number + '</td>'; 

                            } else {
                                var PDF_tag = '<td class="invc-td-data">' +
                                    invoicesList[i].invoice_number + '</td>';
                            }
                            tableContent += '<tr class="mm-csv-row"><td><input class="form-check-input invoice_checkbox" type="checkbox" value="invoice_check' + i + '"  /></td>'
                            + PDF_tag 
                            +'<td>' + invoiceDate + '</td>'
                            +'<td>' + invoicesList[i].order_number + '</td>'
                            +'<td>' + invoicesList[i].warehouse_name + '</td></tr>';



                        }
                    } else {
                        tableContent += '<tr class="mm-no-data"><td>No results found</td></tr>';
                        
                    }

                    $(".invoiceTable").html(tableContent);
                    pagination(20, 1, "invoice_merclink_table", "curpage", "total-value");
                    if($(".mm-no-data").length != 0) {
						$(".total-value").html("0 of 0 Results");
						$(".curpage option").remove();
						$(".curpage").append(`<option value="1" selected="">Page 1 of 1</option>`);
					}
                } else {
                    console.log("servlet data null");
                }

            },
            complete: function() { // Set our complete callback, adding the .hidden class and hiding the spinner.
                $('#loader').addClass('hidden')
            },
            error: function(data) {
                console.log(data);
            }
        });
    }
}