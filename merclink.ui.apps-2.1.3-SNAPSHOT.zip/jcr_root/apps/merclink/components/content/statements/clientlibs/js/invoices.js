$(document).ready(function(){
	
	var linkText = $(".mm-st-link-text").text();
			
	getStatementsData();

	 
    function getStatementsData() {
		
		var selectedCustomer = getCookie("selectedCustomer");
   		var data = {
				"resourcePath": $("#resourcePathPage").val(),
				"customerNumber": parseInt(selectedCustomer)
				};
	
		$.ajax({
	        type: "GET",
	        url: "/bin/merclink/statements",
	        ContentType: "application/json",
	        data: {
	            'data': JSON.stringify(data)
	        },
	        beforeSend: function () { 
                $('#loader').removeClass('hidden')
            },
	        success: function(data) {

				if(data != null) {
					if(data.data != null) {
						for(i in data.data) {
							var reportRunDate = data.data[i].reportrun_date.split("-").reverse().join("-"); 
							var statementDate = data.data[i].statement_date;
							var fileName = data.data[i].file_name;

							if(statementDate){
								var statementDateIndex =  statementDate.trim().toLowerCase().split("t");
								var stmtDate = statementDateIndex[0].split("-").reverse().join("-");
							}else{
								var stmtDate = "";
							}
							let pdfcurvalue = fileName;
                            let indexNum = i;


							$(".tableData").append(`<tr>
														<td>${reportRunDate}</td> 
														<td>${stmtDate}</td>
														<td>
															<a id=pdfValue-${i} class="text-decoration-underline text-0C4C6B mm-limited-text" style="cursor:pointer">${linkText}</a>
														</td>
													</tr>`);



                                                   $('#pdfValue-' + indexNum).click(function(){
														testfun(pdfcurvalue);
													});
												
						} 
						
					}
				}
				if (data == null || data.data.length == 0) {
					$(".tableData").append(`<tr>
												<td>No data found</td>
											</tr>`);
				}
				
	        },
	        complete: function () {
                $('#loader').addClass('hidden')
            },
	    });
	}

	function testfun(pdfValue){
        var url=pdfValue;
        $(".pdf_hidden_value").val(url);
        $("#pdf_form").submit();
    } 
	

 
});
