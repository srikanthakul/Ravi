$(document).ready(function(){ 
	
				
	getAccountSumamry();
	
	$(".mm-csv-btn").click(function(){
		tableToCSV();
	});
	
    
    function getAccountSumamry() {
		
		var selectedCustomer = getCookie("selectedCustomer");
   		var data = {
				"resourcePath": $("#resourcePathPage").val(),
				"customerNumber": parseInt(selectedCustomer)
				};
	
		$.ajax({
	        type: "GET",
	        url: "/bin/merclink/accountsummary",
	        ContentType: "application/json",
	        data: {
	            'data': JSON.stringify(data)
	        },
	        beforeSend: function () { 
                $('#loader').removeClass('hidden')
            },
	        success: function(data) {
				if(data != null) {
					if(data.data != null) {
						for(i in data.data) {
							var description = data.data[i].description;
							var value = data.data[i].value;
							valueCSV = value.split(",").join("");
							valueCSV = valueCSV.toString();
							$(".mm-account-data").append(`
															<div class="d-flex justify-content-between mm-csv-row">
	                            								<p>${description}</p>
	                            								<span>$${value} <csv style="display:none">$${valueCSV}</csv></span>
                        									</div>`);
							
						}
						
						
						
					}
				}
				if(data == null || data.data.length == 0) {
					
					$(".mm-account-data").append(`<div class="d-flex justify-content-between mm-csv-row">
	                    								<p>No data found</p>
	            									</div>`);
				}
				
	        },
	        complete: function () {
                $('#loader').addClass('hidden')
            },
	        error: function () {
	            console.log("error");
	        } 
	    });
	}
	
	function tableToCSV() {
		var tableTitle = $(".order-summary .head-title").text();
		var csv_data = [];
		var rows = $(".mm-csv-row");
		for (var i = 0; i < rows.length; i++) {
			
			var cols = rows[i].querySelectorAll('p,span csv');
			var csvrow = [];
			for (var j = 0; j < cols.length; j++) {
				csvrow.push(cols[j].innerHTML);
			}
			csv_data.push(csvrow.join(","));
			
		}
		csv_data.unshift(tableTitle);
		csv_data = csv_data.join('\n');
		
		downloadCSVFile(csv_data);
	}
	
	function downloadCSVFile(csv_data) {
 
	    CSVFile = new Blob([csv_data], { type: "text/csv" });
	    
	    var temp_link = document.createElement('a');
	 
	    temp_link.download = "account_summary.csv";
	    var url = window.URL.createObjectURL(CSVFile);
	    temp_link.href = url;
	 
	    temp_link.style.display = "none";
	    document.body.appendChild(temp_link);
	 
	    temp_link.click();
	    document.body.removeChild(temp_link);
	}
	
	
 
});