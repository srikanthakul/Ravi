// contactUserManager.js

$(document).ready(function() {

    $("th input").click(function() {
        if (this.checked) {
            $("td input:checkbox").each(function() {
                this.checked = true
            });
        } else {
            $("td input:checkbox").each(function() {
                this.checked = false
            });
        }
    });

    $(document).on("click", ".select-item-checkbox", function() {
        if ($('.select-item-checkbox:checked').length == $('.select-item-checkbox').length) {
            $('.all-item-check').prop('checked', true);
        } else {
            $('.all-item-check').prop('checked', false);
        }
    });

    if (localStorage.getItem("successIndicator") == "ON" && localStorage.getItem("successIndicator") != undefined) {
        if (localStorage.getItem("successIndicatorUpdate") == "ON" && localStorage.getItem("successIndicatorUpdate") != undefined) {
            $(".successs-msg").html("Successfully updated the secondary user details");
        } else {
            $(".successs-msg").html("New contact has been succesfully created. An email will be sent to the contact with their temporary password.");
        }
        $(".success-message").removeClass("d-none");
        $(".success-message").fadeIn(1000);
        $(".success-message").parent().parent()[0].scrollIntoView();
        setTimeout(function() {
            $(".success-message").fadeOut(20000);
        }, 20000);
        localStorage.removeItem("successIndicator");
        localStorage.removeItem("successIndicatorUpdate");
    }



    var completeAccountDetails = JSON.parse(getCookie("completeAccountDetails"));
    var selectedCustomer = getCookie("selectedCustomer");
    var defaultIndex = completeAccountDetails.findIndex(element => parseInt(element.company_number) === parseInt(selectedCustomer));

    $(".account-name").html(completeAccountDetails[defaultIndex].company_name);
    relation(selectedCustomer);


    $(".showcontactfordropdown").change(function() {
        $(".show_active_users").hide();
        $(".show_inactive_users").show();
        var contactNumber = $(".showcontactfordropdown").val();
        setContactDetails(1, contactNumber);
    });


    $(".export-pdf").click(function() {
        var count = 0;
        $('#contactTable input[type=checkbox]:checked').each(function() {
            count = count + 1;
        });
        if (count > 0) {
            download_table_as_csv("contactTable", separator = ',', "selected");
        } else {
            var rows = document.querySelectorAll('table#contactTable tr');
            if (rows.length < 2) {
                respMsgDisplay(202, "No products to Export");
            } else {
                download_table_as_csv("contactTable", separator = ',', "all");
            }
        }
    });

    $(".create-new-contact-btn").click(function() {
        var url = $("#create-New-Contact-Url").val();
        location.href = url;
        //window.open(url);
    });
    $(".display-item").change(function() {
        var showItem = $(this).val();
        var pageNumber = $(".display-page").val();
        $(".display-item").val(showItem);
        $(".display-page").val(pageNumber);
        pagination(showItem, pageNumber, "contactTable", "display-page", "display-page-index");
    });

    $(".display-page").change(function() {
        var showItem = $(".display-item").val();
        var pageNumber = $(this).val();
        $(".display-item").val(showItem);
        $(".display-page").val(pageNumber);
        pagination(showItem, pageNumber, "contactTable", "display-page", "display-page-index");
    });

    $('#contactTable .img-down-icon').click(function() {
        var tableId = "contactTable";
        var rowIndex = $(this).parent().parent().parent().parent().index('#' + tableId + ' tr');
        var thIndex = $(this).parent().parent().parent().index('#' + tableId + ' tr:eq(' + rowIndex + ') th');
        sortTable(parseInt(thIndex), 'asc', tableId);
        var showItem = $(".display-item").val();
        var pageNumber = $(".display-page").val();
        pagination(showItem, pageNumber, "contactTable", "display-page", "display-page-index");

    });

    $('#contactTable .img-up-icon').click(function() {
        var tableId = "contactTable";
        var rowIndex = $(this).parent().parent().parent().parent().index('#' + tableId + ' tr');
        var thIndex = $(this).parent().parent().parent().index('#' + tableId + ' tr:eq(' + rowIndex + ') th');
        sortTable(parseInt(thIndex), 'desc', tableId);
        var showItem = $(".display-item").val();
        var pageNumber = $(".display-page").val();
        pagination(showItem, pageNumber, "contactTable", "display-page", "display-page-index");

    });

    $(".show_active_users").click(function(e) {
        e.preventDefault();
        $(".display-item").val("1");
        $(".display-page").val("20")
        $(".show_active_users").hide();
        $(".show_inactive_users").show();
        var contactNumber = $(".showcontactfordropdown").val();
        setContactDetails(1, contactNumber);
    });

    $(".show_inactive_users").click(function(e) {
        e.preventDefault();
        $(".display-item").val("1");
        $(".display-page").val("20")
        $(".show_active_users").removeClass("d-none");
        $(".show_active_users").show();
        $(".show_inactive_users").hide();
        var contactNumber = $(".showcontactfordropdown").val();
        setContactDetails(0, contactNumber);
    });

});

function download_table_as_csv(table_id, separator = ',', download = "") {
    var rows = document.querySelectorAll('table#' + table_id + ' tr');
    var csv = [];
    if (download == "selected") {
        for (var i = 0; i < rows.length; i++) {
            var row = [],
                cols = rows[i].querySelectorAll('td, th');

            for (var j = 0; j < cols.length - 1; j++) {
                if (i >= 1 && cols[0].children.length > 0 && cols[0].children[0].checked) {

                    var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
                    data = data.replace(/"/g, '""');
                    row.push('"' + data + '"');
                } else if (i == 0) {
                    var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
                    data = data.replace(/"/g, '""');
                    row.push('"' + data + '"');
                }
            }
            csv.push(row.join(separator));
        }
    } else {
        for (var i = 0; i < rows.length; i++) {
            var row = [],
                cols = rows[i].querySelectorAll('td, th');

            for (var j = 0; j < cols.length - 1; j++) {
                var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
                data = data.replace(/"/g, '""');
                row.push('"' + data + '"');

            }
            csv.push(row.join(separator));
        }
    }
    var csv_string = csv.join('\n');
    var filename = 'export_' + table_id + '_' + new Date().toLocaleDateString() + '.csv';
    var link = document.createElement('a');
    link.style.display = 'none';
    link.setAttribute('target', '_blank');
    link.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv_string));
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function searchTable() {
    var input, filter, table, tr, td, i, txtValue;
    input = $("#searchText").val();
    filter = input;
    if (isNaN(input)) {
        filter = input.toUpperCase();
    }
    table = document.getElementById("contactTable");
    tr = table.getElementsByTagName("tr");
    for (i = 1; i < tr.length; i++) {
        for (var j = 1; j < 9; j++) {
            td = tr[i].getElementsByTagName("td")[j];
            if (td) {
                txtValue = td.textContent || td.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                    break;
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    }
}

function relation(selectedCustomer) {
    var data = {
        "resourcePath": $('#componentPath').val(),
        "companyNumber": parseInt(selectedCustomer)

    }
    $.ajax({
        type: "GET",
        url: "/bin/merclink/relation",
        ContentType: "application/json",
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {

            if (data != null && data != "" && data.data != null && data.data != undefined && data.data.length > 0) {
                var company = data.data.sort((a, b) => (a.customer_number > b.customer_number) ? 1 : -1);

                var company_name = JSON.parse(getCookie("completeAccountDetails")).filter(element => element.company_number == selectedCustomer)[0].company_name;
                var parent = { "customer_number": selectedCustomer, "company_name": company_name };
                company.unshift(parent);

                var options = "";
                var setectedContact = getCookie("setectedContact") != null && getCookie("setectedContact") != "" ? JSON.parse(getCookie("setectedContact")).contact : "";
                var notFoundSelected = true;
                var unSelectedCompanyData = "";
                company.forEach((element, index) => {
                    if (setectedContact == element.customer_number) {
                        options += '<option value="' + element.customer_number + '" selected>' + element.customer_number + ' ' + element.company_name + '</option>';
                        $(".showcontactfordropdown").empty();
                        $(".showcontactfordropdown").html(options);
                        setContactDetails(1, element.customer_number);
                        notFoundSelected = false;
                    } else {
                        if (index === 0) {
                            unSelectedCompanyData = element.customer_number;
                        }
                        options += '<option value="' + element.customer_number + '">' + element.customer_number + ' ' + element.company_name + '</option>';
                    }
                });
                $(".showcontactfordropdown").empty();
                $(".showcontactfordropdown").html(options);

                if (notFoundSelected) {
                    if (unSelectedCompanyData != "") {
                        setContactDetails(1, unSelectedCompanyData);
                    }
                }
            } else {
                var company_name = JSON.parse(getCookie("completeAccountDetails")).filter(element => element.company_number == selectedCustomer)[0].company_name
                var options = '<option value="' + selectedCustomer + '" selected>' + selectedCustomer + ' ' + company_name + '</option>';
                $(".showcontactfordropdown").empty();
                $(".showcontactfordropdown").html(options);
                setContactDetails(1, selectedCustomer);

            }
        },
        error: function(e) {
            console.log(e);
        },
    });
}


function setContactDetails(status, contactNumber) {
    var details = {
        contact: contactNumber,
        contactDesc: $(".showcontactfordropdown [value='" + contactNumber + "']").text()
    }
    setCookie("setectedContact", JSON.stringify(details), 30);
    var data = {
        "componentPath": $('#componentPath').val(),
        "company_number": parseInt(contactNumber),
        "status": parseInt(status),
    }
    $.ajax({
        type: "POST",
        url: "/bin/uam/childUserDetailsServlet",
        ContentType: 'application/json',
        async: false,
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            if (data != null) {
                if (data.GetChildUsers != null) {
                    tableData(data.GetChildUsers);
                } else {
                    $("table tbody").empty();
                    var data = [];
                    tableData(data);
                }
            }
        },
        error: function(e) {}
    });
}


function edit(customerid) {
    location.href = $("#edit-Contact-Url").val() + "?customerid=" + customerid + "&page=edit";
}

function tableData(data) {
    $("table tbody").empty();
    if (data.length != 0) {
        $(".display-page").prop("disabled", false);
        $(".display-item").prop("disabled", false);
        var html = '';
        data.forEach(function(element, index) {
            var middleName = element.middlename != null ? element.middlename : "";
            var telePhone = element.telephone != null ? element.telephone : "";
            html += "<tr class='row-" + index + "'><td><input class='form-check-input select-item-checkbox ms-0' type='checkbox' value='" + element.customerid + "'></td><td>" + element.firstname + "</td><td>" + middleName + "</td><td>" + element.lastname + "</td><td>" + element.customerid + "</td><td>" + element.email + "</td><td>" + telePhone + "</td><td>" + element.start_date + "</td><td>" + element.end_date + "</td><td><a href='#' onclick='edit(\"" + element.customerid + "\")'>Edit</a></td></tr>";
        });
        $("table tbody").append(html);
        pagination(20, 1, "contactTable", "display-page", "display-page-index");
    } else {
        $(".display-page-index").html("0-0 of 0 Results");
        $(".display-page").prop("disabled", true);
        $(".display-item").prop("disabled", true);
    }
}