//  directItemEntry.js
$(document).ready(function() {

    $(".add-to-wishlist").click(function() {
        var count = 0;
        $('#directItemEntryTable input[type=checkbox]:checked').each(function() {
            count = count + 1;
        });
        if (count > 0) {
            getWishlistModal();
        } else {
            respMsgDisplay(202, "Please select at least one product to add to wish list");
        }
    });

    $(".tooltip-box").click(function() {
        $(this).parent().addClass("tooltip-open");
    });

    $(".tooltip-close").click(function() {
        $(this).parents().removeClass("tooltip-open");
    });

    $("#directItemEntryTable tbody").empty();
    setTable(1, 10);


    $('.addtocart').on('click', function(e) {
        var cartArray = [];
        $(".select-item-checkbox").each(function() {
            if ($(this).is(":checked")) {
                var itemNumber = $(this).data("index");
                var qty = $("#qty" + itemNumber).val();
                var itemName = $("#item" + itemNumber).val();
                if (itemName != "" && itemName != null && qty != "" && qty != "0" && qty != null) {
                    var cartobj = {
                        "skuid": itemName.toString(),
                        "quantity": qty.toString()
                    }
                    cartArray.push(cartobj);
                }
            }
        });
        if (cartArray.length > 0) {
            addToCart(cartArray)
        }
    });



    $(".oe-table-add-more-rows").click(function(e) {
        e.preventDefault();
        var from = (($("#directItemEntryTable tr").length - 1) / 2) + 1;
        var to = from + 10;
        setTable(from, to);
    });

    $(".remove-items").click(function() {
        $(".select-item-checkbox").each((index, element) => {
            if ($(element).is(":checked")) {
                var index = $(element).data("index");
                $(".remove-check-" + index).remove();
                $("#remove-product").modal("hide");
                var successSingleMessage = "Item(s) were removed from order entry";
                $(".success-msg").html(successSingleMessage);
                $(".mm-success-msg").removeClass("d-none");
                $(".mm-success-msg").fadeIn(1000);
                $(".success-msg").parent().parent()[0].scrollIntoView();
                setTimeout(function() {
                    $(".mm-success-msg").fadeOut(1000);
                }, 20000);

            }
        });
    });

    $("input[type=file]").change(function() {
        var fileInput = document.getElementById("oeChooseFile");
        var regex = new RegExp("(.*?)\.(csv)$");
        if (!(regex.test(fileInput.value.toLowerCase()))) {
            fileInput.value = '';
            respMsgDisplay(202, "Please upload only CSV file format");
        } else {
            let file = fileInput.files[0];
            let fr = new FileReader();
            fr.onload = receivedText;
            fr.readAsText(file);

            function receivedText() {
                var csv = fr.result;
                var lines = csv.split("\n");

                var result = [];
                var headers = lines[0].split(",");
                headers[0] = "item_number";
                headers[1] = "qty";
                var maxLength = $("#maxCsv").val();
                if (lines.length <= parseInt(maxLength)) {
                    for (var i = 1; i < lines.length; i++) {
                        if (lines[i] && lines[i] != "") {
                            var obj = {};
                            var currentline = lines[i].split(",");
                            for (var j = 0; j < headers.length; j++) {
                                obj[headers[j]] = currentline[j];
                            }
                            result.push(obj);
                        }
                    }
                    directItemValue(result);
                    $('input[type="file"]').val("");
                } else {
                    respMsgDisplay(202, "CSV Content exceeds Max Length allowed");
                    $('input[type="file"]').val("");
                }
            }
        }
    });

    loadInitialData();
});



function checkSingleItem(rowNumber) {
    var data = {
        "componentPath": $('#resourcePath').val(),
        "sku": $("#item" + rowNumber).val(),
        "companyNumber": getCookie("selectedCustomer"),
    }
    $.ajax({
        type: "POST",
        url: "/bin/quickOrderSingleItem",
        ContentType: "application/json",
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            if (data != null) {

                if (data.quickOrderSingleItem) {
                    $(".itemHelpRow" + rowNumber).removeClass("d-none");
                    var message = data.quickOrderSingleItem;
                    $(".itemHelpText" + rowNumber).html(message);
                } else {
                    var items = data.quickOrderProductsAnzp.items;
                    if (items.length > 0) {
                        var item = items[0];
                        setItemValue(rowNumber, item);
                    } else {
                        if (data.quickOrderProductsAnzp.user_errors) {
                            $("#qty" + rowNumber).prop("readonly", true);
                            $(".itemHelpRow" + rowNumber).removeClass("d-none");
                            var message = data.quickOrderProductsAnzp.user_errors[0].message;
                            $(".itemHelpText" + rowNumber).html(message);
                        }
                    }
                }
            }
        }
    });
}


function addToCart(cartArray) {
    var data = {
        "componentPath": $('#resourcePath').val(),
        cartId: getCookie("cartId"),
        cartobj: cartArray
    }

    $.ajax({
        type: "POST",
        url: "/bin/cart/addToCartQuery",
        ContentType: "application/json",
        dataType: "json",
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            if (data && data.addProductsToCart) {
                if (data.addProductsToCart.cart && data.addProductsToCart.cart.items && data.addProductsToCart.cart.items.length > 0) {
                    $(".cart-item-display-number").html(data.addProductsToCart.cart.items.length);
                    setCookie("cartCount", data.addProductsToCart.cart.items.length, 30);

                    var sendSkuId = cartArray.map(element => element.skuid);
                    var matchedCartItemArray = data.addProductsToCart.cart.items.filter(element => sendSkuId.indexOf(element.product.sku) != -1);
                    var matchedCartItem = matchedCartItemArray.map(element => element.product.sku);
                    if (matchedCartItem.length > 0) {
                        var msg = 'Item(s) have been added/updated to Cart: ' + matchedCartItem.join().toString();
                        respMsgDisplay(200, msg);
                        var productDetailsArray = [];
                        matchedCartItemArray.forEach((element, indexe) => {
                            var quantityFilter = cartArray.filter(cartElement => cartElement.skuid == element.product.sku);
                            var productDetails = {
                                "productQuantity": quantityFilter.length > 0 ? quantityFilter[0].quantity : 0,
                                "productInfo": {
                                    "productID": element.product.sku,
                                    "productName": element.product.name,
                                }
                            };
                            productDetailsArray.push(productDetails);
                        });
                        if (typeof digitalData !== "undefined") {
                            digitalData.addtoCart = {
                                "product": productDetailsArray,
                            }
                        }
                        _satellite.track('Add to cart', { linkName: $(".addtocart").html() });
                    }
                }
                var errMsg = "";
                if (data.addProductsToCart.cart && data.addProductsToCart.cart.erp_errors && data.addProductsToCart.cart.erp_errors.length > 0) {
                    data.addProductsToCart.cart.erp_errors.forEach((element) => {
                        errMsg += element.message + ", "
                    });
                }

                if (data.addProductsToCart.user_errors != null && data.addProductsToCart.user_errors.length > 0) {
                    data.addProductsToCart.user_errors.forEach((element) => {
                        errMsg += element.message + ", "
                    });
                }

                if (errMsg.length > 0) {
                    respMsgDisplay(202, errMsg);
                }
            } else if (data && data.createCartId) {
                respMsgDisplay(202, data.createCartId);
            }
        },
        error: function(status, errorthrown) {
            console.log("function error" + errorthrown);
        }
    });
}

function validateAllItems(skuItems) {
    var data = {
        "componentPath": $('#resourcePath').val(),
        "sku": skuItems,
        "companyNumber": getCookie("selectedCustomer"),
    }
    $.ajax({
        type: "POST",
        url: "/bin/quickOrderSingleItem",
        ContentType: "application/json",
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            if (data != null) {

                if (data.quickOrderSingleItem) {
                    $(".mm-error-msg").removeClass("d-none");
                    var errorSingleMessage = data.quickOrderSingleItem;
                    $(".error-msg").html(errorSingleMessage);
                    $(".insertItem").each((index, element) => {
                        if ($(element).val() != "" && errorSingleMessage.search($(element).val()) != -1) {
                            var rowNumber = $(element).data("row");
                            $("#item" + rowNumber).val("");
                            $("#qty" + rowNumber).val("");
                            $("#qty" + rowNumber).prop("readonly", true);
                            var items = "";
                            $(".insertItem").each((index, element) => {
                                if ($(element).val() != "") {
                                    items += $(element).val() + '\",\"';
                                }
                            });
                            validateAllItems(items.substring(0, items.length - 3));
                        }
                    });
                } else {
                    if (data.quickOrderProductsAnzp.items) {
                        var items = data.quickOrderProductsAnzp.items;
                        if (items.length > 0) {
                            items.forEach((item, index) => {

                                $(".insertItem").each((index, element) => {
                                    var itemSku = item.sku;
                                    if (item.ss_item_number && item.ss_item_number != "") {
                                        itemSku = item.ss_item_number
                                    }
                                    if ($(element).val() != "" && $(element).val() == itemSku) {
                                        var rowNumber = $(element).data("row");
                                        setItemValue(rowNumber, item);
                                    }
                                });
                            });
                        }
                        loadInitialData();
                    }
                    if (data.quickOrderProductsAnzp.user_errors) {
                        var messageItems = data.quickOrderProductsAnzp.user_errors;
                        if (messageItems.length > 0) {
                            messageItems.forEach((item, index) => {
                                var errorMessage = item.message;
                                $(".insertItem").each((index, element) => {
                                    if ($(element).val() != "" && errorMessage.search($(element).val()) != -1) {
                                        var rowNumber = $(element).data("row");
                                        $("#qty" + rowNumber).val("");
                                        $("#qty" + rowNumber).prop("readonly", true);
                                        $(".select-item-checkbox[data-index='"+rowNumber+"']").attr("disabled", true);
                                        $(".itemHelpRow" + rowNumber).removeClass("d-none");
                                        $(".itemHelpText" + rowNumber).html(errorMessage);
                                    }
                                });
                            });
                        }
                    }
                }
            }
        }
    });
}

function setItemValue(rowNumber, item) {
    var availability = item.availability;
    var description = item.description;
    var estimated_availability_date = item.estimated_availability_date != null ? item.estimated_availability_date : "";
    var id = item.id;
    var item_number = item.item_number;
    var masterpartlowestsellinguomqty = item.masterpartlowestsellinguomqty != null ? parseInt(item.masterpartlowestsellinguomqty) : 1;
    var sku = item.sku;
    var stock_status = item.stock_status;
    var superseeded = item.ss_item_number;
    var warehouse_total = item.warehouse_total != null ? item.warehouse_total : 0;
    if (item_number != superseeded) {
        $("#ss" + rowNumber).val(superseeded);
    }

    var qtyVal = parseInt($("#qty" + rowNumber).val());
    if (!isNaN(qtyVal) && qtyVal > masterpartlowestsellinguomqty) {
        if (masterpartlowestsellinguomqty == 0 || qtyVal % masterpartlowestsellinguomqty == 0) {
            qtyVal = qtyVal;
        } else {
            qtyVal = parseInt(qtyVal / masterpartlowestsellinguomqty) * masterpartlowestsellinguomqty;
        }
    } else {
        qtyVal = masterpartlowestsellinguomqty;
    }

    $("#item" + rowNumber).val(item_number);
    $(".tooltip-context-" + rowNumber).html(estimated_availability_date);
    $("#qty" + rowNumber).prop("readonly", false);
    $("#qty" + rowNumber).val(qtyVal);
    $("#qty" + rowNumber).attr("min", masterpartlowestsellinguomqty);
    $("#qty" + rowNumber).attr("step", masterpartlowestsellinguomqty);
    var validate = "this.value=='' ? this.value = " + masterpartlowestsellinguomqty + " : '' ; this.value % " + masterpartlowestsellinguomqty + " || this.value == 0  ?  this.value = (parseInt(this.value)+(" + masterpartlowestsellinguomqty + "-(parseInt(this.value) % " + masterpartlowestsellinguomqty + " )))  : '' ";
    $("#qty" + rowNumber).attr("onfocusout", validate);
    $("#qty" + rowNumber).attr("data-warehouse", parseInt(warehouse_total));
    $("#des" + rowNumber).val(description);
    if (warehouse_total >= qtyVal) {
        availability = "HW-" + qtyVal;
        $("#avail" + rowNumber).attr("data-avail", "HW-" + qtyVal + ",");
    } else {
        $("#avail" + rowNumber).attr("data-avail", "HW-" + warehouse_total + ",");
    }

    $("#avail" + rowNumber).val(availability);
}

function setTable(from, to) {
    $(".all-item-check").prop("checked", false);
    var tableData = ""
    for (var i = from; i < to; i++) {
        tableData += '<tr class="remove-check-' + i + '">' +
            '<td class="oe-table-input-width"><input class="form-check-input select-item-checkbox" type="checkbox" value="" data-index="' + i + '"></td>' +
            '<td class="oe-table-ss-width"><div class="oe-table-ss"><input class=" " type="text " name=" " id="ss' + i + '" readonly disabled/></div></td>' +
            '<td data-bs-toggle="modal" data-bs-target="#product-item" class="oe-table-item-no-width"><div class="oe-table-item-no"><input class="insertItem" type="text" data-warehouse="0" data-row="' + i + '" name="" id="item' + i + '"> </div></td>' +
            '<td class="oe-table-qty-width"><div class="input-group mm-quantity"><input class="form-control input-number qtyclass" type="number" name=" " id="qty' + i + '" min="1" step="1" onkeypress="return event.charCode >= 48"  onfocusout="" readonly></div></td>' +
            '<td class="oe-table-item-desc-width"><div class="oe-table-item-desc"><input class=" " type="text " name=" " id="des' + i + '" readonly disabled/> </div></td>' +
            '<td class="position-relative oe-table-availability-width"><div><input class="oe-table-item-availability data-tooltip-display" type="text " data-item="' + i + '" name=" " id="avail' + i + '" data-avail="" readonly disabled /></div></td>' +
            '</tr >' +
            '<tr class="d-none itemHelpRow' + i + ' remove-check-' + i + '">' +
            '<td class="tableHelpText"></td>' +
            '<td scope="row " class="tableHelpText"></td>' +
            '<td colspan="3" class="tableHelpText"><span class="itemHelpText' + i + '"></span></td>' +
            '<td class="tableHelpText"></td>' +
            '<td class="tableHelpText"></td>' +
            '</tr>';
    }
    $("#directItemEntryTable tbody").append(tableData);
    loadInitialData();
    warning_pagination(20, 1, "directItemEntryTable", "display-page", "display-page-index");
}

function directItemValue(csvValue) {
    $(".all-item-check").prop("checked", false);
    var tableData = "";
    $("#directItemEntryTable tbody").empty();
    $.each(csvValue, function(index, element) {
        var i = index + 1;
        if (element.qty != undefined) {
            tableData += '<tr class="remove-check-' + i + '">' +
                '<td class="oe-table-input-width"><input class="form-check-input select-item-checkbox" type="checkbox" value="" data-index="' + i + '"></td>' +
                '<td class="oe-table-ss-width"><div class="oe-table-ss"><input class=" " type="text " name=" " id="ss' + i + '" readonly disabled/></div></td>' +
                '<td data-bs-toggle="modal" data-bs-target="#product-item" class="oe-table-item-no-width"><div class="oe-table-item-no"><input class="insertItem" type="text" data-warehouse="0" data-row="' + i + '" name="" id="item' + i + '" value=' + element.item_number + '> </div></td>' +
                '<td class="oe-table-qty-width"><div class="input-group mm-quantity"><input class="form-control input-number qtyclass" type="number" name=" " id="qty' + i + '" min="1" step="1" onkeypress="return event.charCode >= 48"  onfocusout="" value=' + element.qty + ' readonly></div></td>' +
                '<td class="oe-table-item-desc-width"><div class="oe-table-item-desc"><input class=" " type="text " name=" " id="des' + i + '" readonly disabled/> </div></td>' +
                '<td class="position-relative oe-table-availability-width"><div><input class="oe-table-item-availability data-tooltip-display" type="text " data-item="' + i + '" name=" " id="avail' + i + '" data-avail="" readonly disabled /></div></td>' +
                '</tr >' +
                '<tr class="d-none itemHelpRow' + i + ' remove-check-' + i + '">' +
                '<td class="tableHelpText"></td>' +
                '<td scope="row " class="tableHelpText"></td>' +
                '<td colspan="3" class="tableHelpText"><span class="itemHelpText' + i + '"></span></td>' +
                '<td class="tableHelpText"></td>' +
                '<td class="tableHelpText"></td>' +
                '</tr>';

        }
    });
    $("#directItemEntryTable tbody").append(tableData);
    var items = "";
    $(".insertItem").each((index, element) => {
        if ($(element).val() != "") {
            items += $(element).val() + '\",\"';
        }
    });
    validateAllItems(items.substring(0, items.length - 3));
    loadInitialData();
    $(".display-item").val("20");
    warning_pagination(20, 1, "directItemEntryTable", "display-page", "display-page-index");
}

function combine(arr) {
    var combined = arr.reduce(function(result, item) {
        var current = result[item.item_number];
        result[item.item_number] = !current ? item : {
            item_number: item.item_number,
            qty: (toNumeric(current.qty) + toNumeric(item.qty)).toString()
        };

        return result;
    }, {});

    return Object.keys(combined).map(function(key) {
        return combined[key];
    });
}

function toNumeric(numb) {
    if (numb != undefined && numb != null)
        return parseInt(numb.toString().replace(/[^0-9\.]+/g, ""));
}

function respMsgDisplay(statusCode, message, ) {
    if (statusCode == 200) {
        $(".mm-success-msg span").empty();
        $(".mm-success-msg span").text("" + message + "");
        $(".mm-success-msg").removeClass("d-none");
        $(".mm-success-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-success-msg").offset().top
        }, 'slow');
        setTimeout(function() { $(".mm-success-msg").fadeOut("slow"); }, 20000);
    } else if (statusCode == 202) {
        $(".mm-error-msg span").empty();
        $(".mm-error-msg span").text("" + message + "");
        $(".mm-error-msg").removeClass("d-none");
        $(".mm-error-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-error-msg").offset().top
        }, 'slow');
        setTimeout(function() { $(".mm-error-msg").fadeOut("slow"); }, 20000);
    }
}

function showLoader(className) {
    $("#loader").removeClass("hidden");
    $('.' + className).addClass("backDisabled");
}

function hideLoader(className) {
    $("#loader").addClass("hidden");
    $('.' + className).removeClass("backDisabled");
}

function addtoWishListItem() {
    var c = [];
    var productDetailsArray = [];
    $("#directItemEntryTable .select-item-checkbox:checked").each(function() {
        var b = parseInt(document.getElementById("qty" + $(this).data("index")).value);
        var wishArray = {
            skuid: "" + document.getElementById("item" + $(this).data("index")).value + "",
            quantity: b.toString()
        }
        c.push(wishArray);
        
        var productDetails = {
            "productQuantity": b > 0 ? b : 0,
            "productInfo": {
                "productID": "" + document.getElementById("item" + $(this).data("index")).value + "",
                "productName": $("#des"+$(this).data("index")).val(),
            }
        };
        
        productDetailsArray.push(productDetails);
    });
    AddProductToWishL(c, "addfromcart", "", "available", "").success(function(b) {
        $("#cartTable .form-check-input:checked").each(function() {
            this.checked = !1
        });
        b.alreadyExists ? ($("#add-to-wishlist-modal").modal("hide"),
            $(".mm-error-msg span").html(""),
            $(".mm-error-msg span").text(b.alreadyExists).css("color", "black").fadeIn("slow"),
            $(".mm-error-msg").removeClass("d-none"),
            setTimeout(function() {
                $(".mm-error-msg").fadeOut("slow");
                $(".mm-error-msg").addClass("d-none")
            }, 3E3)) : ($("#add-to-wishlist-modal").modal("hide"),
            $(".mm-success-msg span").html(""),
            $(".mm-success-msg span").append("Item(s) have been added to your wish list : " + b.wishlistname).css("color", "black"),
            $(".mm-success-msg").removeClass("d-none"),
            $(".mm-success-msg").fadeIn("slow"),
            setTimeout(function() {
                $(".mm-success-msg").fadeOut("slow");
                $(".mm-success-msg").addClass("d-none")
            }, 1E4))
            if(b!=null && b.wishlisttype != null){
                addToWishlist = {};
                addToWishlist['product'] = productDetailsArray;
                digitalData["addtoWishlist"] = addToWishlist;
                _satellite.track('Add to wishlist', { linkName: $(".add-to-wishlist").html() });
            }
    })

}

function loadInitialData() {
    $(".insertItem").unbind("change");
    $(".insertItem").change(function() {
        var rowNumber = $(this).attr("data-row");
        $(".itemHelpRow" + rowNumber).removeClass("d-none");
        $(".itemHelpRow" + rowNumber).addClass("d-none");
        $(".tooltip-context-" + rowNumber).html("");
        $("#ss" + rowNumber).val();
        $("#qty" + rowNumber).prop("readonly", true);
        $("#qty" + rowNumber).val("");
        $("#qty" + rowNumber).attr("min", 1);
        $("#qty" + rowNumber).attr("step", 1);
        $("#qty" + rowNumber).attr("onfocusout", "");
        $("#qty" + rowNumber).attr("data-warehouse", 0);
        $("#des" + rowNumber).val("");
        $("#avail" + rowNumber).val("");
        if ($("#item" + rowNumber).val() != "") {
            checkSingleItem(rowNumber);
        }
    });

    $(".qtyclass").change(function() {
        var qtyId = $(this).prop("id");
        var qtyVal = parseInt($(this).val());
        var minValue = parseInt($(this).attr("min").replace(/^\D+/g, ''));
        var warehouse = parseInt($(this).attr("data-warehouse").replace(/^\D+/g, ''));
        var itemNumber = parseInt(qtyId.replace(/^\D+/g, ''));
        var calValue = qtyVal % minValue || qtyVal == 0 ? qtyVal = (parseInt(qtyVal) + (minValue - (parseInt(qtyVal) % minValue))) : qtyVal;
        if ($("#item" + itemNumber) != "" && qtyVal > 0) {
            var availData = "";
            if (warehouse >= qtyVal) {
                availData += "HW-" + qtyVal + ",";
                $("#avail" + itemNumber).attr("data-avail", availData)
            } else {
                if ($("#avail" + itemNumber).attr("data-avail") != "HW-0,") {
                    availData += "HW-" + warehouse + ",";
                    $("#avail" + itemNumber).attr("data-avail", availData)
                }
            }

            if (qtyVal > warehouse && calValue > warehouse) {
                availData += "BO-" + parseInt(calValue - warehouse).toString() + ",";
            }
            $("#avail" + itemNumber).val(availData.slice(0, -1));
        } else {
            $("#avail" + itemNumber).attr("data-avail", "HW-0,")
            $("#avail" + itemNumber).val("");
        }
    });

    $(".display-item").change(function() {
        var showItem = $(this).val();
        var pageNumber = $(".display-page").val();
        $(".display-item").val(showItem);
        $(".display-page").val(pageNumber);
        warning_pagination(showItem, pageNumber, "directItemEntryTable", "display-page", "display-page-index");
    });

    $(".display-page").change(function() {
        var showItem = $(".display-item").val();
        var pageNumber = $(this).val();
        $(".display-item").val(showItem);
        $(".display-page").val(pageNumber);
        warning_pagination(showItem, pageNumber, "directItemEntryTable", "display-page", "display-page-index");
    });

    $(".all-item-check").click(function() {
        if ($(this).is(":checked")) {
            $(".select-item-checkbox").not(":disabled").prop("checked", true);
        } else {
            $(".select-item-checkbox").prop("checked", false);
        }
    });

    $(".select-item-checkbox").click(function() {
        var totalLength = $(".select-item-checkbox").length;
        var checkedLength = 0;
        $(".select-item-checkbox").each(function(index, element) {
            if ($(element).is(":checked")) {
                checkedLength++;
            }
        });
        if (totalLength == checkedLength) {
            $(".all-item-check").prop("checked", true);
        } else {
            $(".all-item-check").prop("checked", false);
        }
    });
}