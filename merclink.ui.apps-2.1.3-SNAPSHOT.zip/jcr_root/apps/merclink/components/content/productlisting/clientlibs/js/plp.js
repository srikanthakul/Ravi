let filterArrayObjectFacet = []
let isApplyfilter = false;
let catparam;
let cattitle;
$(document).ready(function() {

    $("#filter-sidebar").click((e) => {
        e.target.getAttribute("data-category-attrcode") ?
            e.target.checked ?
            filterArrayObjectFacet.find((item) => { return item.attrCode == e.target.getAttribute("data-category-attrCode") }) ?
            filterArrayObjectFacet = filterArrayObjectFacet.map((x) => {
                return x.attrCode == e.target.getAttribute("data-category-attrCode") ? {
                        attrCode: x.attrCode,
                        facetLabel: x.facetLabel,
                        facetList: [...x.facetList, {
                            'attrCode': e.target.getAttribute("data-options-attrCode"),
                            'attrLabel': e.target.getAttribute("data-options-attrLabel")
                        }]
                    } :
                    x
            }) :
            filterArrayObjectFacet = [...filterArrayObjectFacet, {
                'attrCode': e.target.getAttribute("data-category-attrCode"),
                'facetLabel': e.target.getAttribute("data-category-facetLabel"),
                'facetList': [{
                    'attrCode': e.target.getAttribute("data-options-attrCode"),
                    'attrLabel': e.target.getAttribute("data-options-attrLabel")
                }]
            }] :


            filterArrayObjectFacet = filterArrayObjectFacet.map((item) => {
                return item.attrCode == e.target.getAttribute("data-category-attrCode") ? { attrCode: item.attrCode, facetLabel: item.facetLabel, facetList: item.facetList.filter((a) => a.attrCode != e.target.getAttribute("data-options-attrCode")) } :
                    item
            })

        : ''

    })





    let searchParams = new URLSearchParams(window.location.search);

    catparam = searchParams.get("id");
    cattitle = decodeURIComponent(searchParams.get("name"));
    console.log("id   " + catparam + " name  " + cattitle);
    isApplyfilter = false;
    getDataAndRenderPage();


    $(".add-to-wishlist").click(function() {
        $(".mm-error-msg").addClass("d-none");

        let productArrayInit = []
        $("#card-display-section .form-check-input:checked").each(function() {
            console.log($(this).attr('data-itemid'))
            let quantity = document.getElementById('qty-' + $(this).attr('data-itemid')).value
            productArrayInit = [...productArrayInit, { skuid: $(this).attr('data-itemid'), quantity }]

        });

        if (productArrayInit.length != 0) {

            getWishlistModal();

        } else {

            respMsgDisplay(202, "Please select at least one product to add to wishlist");

        }

    });




    $(".addtocart").click(function() {
        $(".mm-error-msg").addClass("d-none");
        let productArray = []
        $("#card-display-section .form-check-input:checked").each(function() {
            console.log($(this).attr('data-itemid'))
            let quantity = document.getElementById('qty-' + $(this).attr('data-itemid')).value
            productArray = [...productArray, { skuid: $(this).attr('data-itemid').toString(), quantity }]

        });


        if (productArray.length != 0) {

            var data = {
                "componentPath": $('#resourcePath').val(),
                cartId: getCookie("cartId"),
                cartobj: productArray
            }

            $.ajax({
                type: "POST",
                url: "/bin/cart/addToCartQuery",
                ContentType: "application/json",
                dataType: "json",
                async: false,

                data: {
                    'data': JSON.stringify(data)
                },
                success: function(data) {
                    if (data && data.addProductsToCart) {
                        if (data.addProductsToCart.cart && data.addProductsToCart.cart.items && data.addProductsToCart.cart.items.length > 0) {
                            $(".cart-item-display-number").html(data.addProductsToCart.cart.items.length);
                            setCookie("cartCount", data.addProductsToCart.cart.items.length, 30);

                            var sendSkuId = productArray.map(element => element.skuid);
                            var matchedCartItemArray = data.addProductsToCart.cart.items.filter(element => sendSkuId.indexOf(element.product.sku) != -1);
                            var matchedCartItem = matchedCartItemArray.map(element => element.product.sku);
                            if (matchedCartItem.length > 0) {
                                var msg = 'Item(s) have been added/updated to Cart: ' + matchedCartItem.join().toString();
                                var productDetailsArray = [];
                                matchedCartItemArray.forEach((element, indexe) => {
                                    var quantityFilter = productArray.filter(cartElement => cartElement.skuid == element.product.sku);
                                    var productDetails = {
                                        "productQuantity": quantityFilter.length > 0 ? quantityFilter[0].quantity : 0,
                                        "productInfo": {
                                            "productID": element.product.sku,
                                            "productName": element.product.name,
                                        }
                                    };
                                    productDetailsArray.push(productDetails);
                                });

                                if (typeof digitalData !== "undefined") {
                                    digitalData.addtoCart = {
                                        "product": productDetailsArray,
                                    }
                                }
                                _satellite.track('Add to cart', { linkName: $(".addtocart").html() });
                                respMsgDisplay(200, msg);
                            }
                        }
                        var errMsg = "";
                        if (data.addProductsToCart.cart && data.addProductsToCart.cart.erp_errors && data.addProductsToCart.cart.erp_errors.length > 0) {
                            data.addProductsToCart.cart.erp_errors.forEach((element) => {
                                errMsg += element.message + ", "
                            });
                        }

                        if (data.addProductsToCart.user_errors != null && data.addProductsToCart.user_errors.length > 0) {
                            data.addProductsToCart.user_errors.forEach((element) => {
                                errMsg += element.message + ", "
                            });
                        }

                        if (errMsg.length > 0) {
                            respMsgDisplay(202, errMsg);
                        }
                    } else if (data && data.createCartId) {
                        respMsgDisplay(202, data.createCartId);
                    }
                },
                error: function(status, errorthrown) {
                    console.log("function error" + errorthrown);
                    var msg = 'Something Went wrong. Please try again';
                    respMsgDisplay(202, msg);
                }
            });
        } else {
            respMsgDisplay(202, "Please select at least one product to add to cart");
        }

    });



    $("#but").click(function() {

        isApplyfilter = true;

        getDataAndRenderPage();

    });

    $(".mySelect").change(function(e) {
        $( ".gridview" ).trigger( "click" )
        isApplyfilter = false;
        $(".mySelect").val(e.target.value);
        getDataAndRenderPage();

    });

    $(".pagesize").change(function(e) {
        $( ".gridview" ).trigger( "click" )
        isApplyfilter = true;
        $(".pagesize").val(e.target.value);
        getDataAndRenderPage();

    });

    $(".sort").change(function(e) {
        $( ".gridview" ).trigger( "click" )
        isApplyfilter = !1;
        $(".sort").val(e.target.value)
        getDataAndRenderPage()
    });


    $('.bi-chevron-left').click(() => $(".mySelect > option:selected").prev().val() && $(".mySelect").val($(".mySelect > option:selected").prev().val()) && $(".mySelect").change())
    $('.bi-chevron-right').click(() => $(".mySelect > option:selected").next().val() && $(".mySelect").val($(".mySelect > option:selected").next().val()) && $(".mySelect").change())




    $(document).on("click", ".mm-plp-center-filter .mm-hide-price", function() {
        $(".mm-show-price").removeClass("d-none");
        $(".table").addClass("table_add_container w-50");
        $(".mm-plp-center-filter .mm-hide-price").addClass("d-none");
        $("#card-display-section .mm-hide-price").addClass("d-none");
        $(".card").addClass("card-height");
    });


    $(document).on("click", ".mm-plp-center-filter .mm-show-price", function() {
        $("#card-display-section .mm-hide-price").removeClass("d-none");
        $(".table").addClass("table_add_container w-50");
        $(".mm-plp-center-filter .mm-hide-price").removeClass("d-none");
        $(".mm-plp-center-filter .mm-show-price").addClass("d-none");
        $(".card ").removeClass("card-height");
    });




    $(document).on("click", ".listview", function() {



        $(".gridview").removeClass("d-none");
        $(".plp-grid-display-control").removeClass("row-cols-md-4");
        $(".plp-card-main-container").addClass("plp-card-main-container__removethisforlistview");
        $(".plp-grid-display-control").addClass("plp-list-display-control");
        $(".listview").addClass("d-none");

        // for switch list view
        if ($(".plp-grid-display-control").find(".plp-list-display-control")) {

            let plp_list_view = $(".plp-card-main-container__item2");
            $('.product-code').each(function(i) {
                plp_list_view.eq(i).prepend($(this));
            });
            $('.card-text').each(function(i) {
                plp_list_view.eq(i).append($(this));
            });
        }
    });



    $(document).on("click", ".gridview", function() {
        $(".listview").removeClass("d-none");
        $(".plp-grid-display-control").addClass("row-cols-md-4");
        $(".plp-card-main-container").removeClass("plp-card-main-container__removethisforlistview");
        $(".plp-grid-display-control").removeClass("plp-list-display-control");
        $(".gridview").addClass("d-none");

        // for switch grid view reverse
        if ($(".plp-grid-display-control").not(".plp-list-display-control")) {
            let plp_grid_view = $(".card");
            $('.product-code').each(function(i) {
                plp_grid_view.eq(i).prepend($(this));
            });
            $('.card-text').each(function(i) {
                plp_grid_view.eq(i).append($(this));
            });
        }
    });





});



function respMsgDisplay(statusCode, message, ) {
    if (statusCode == 200) {
        $(".mm-success-msg span").empty();
        $(".mm-success-msg span").text("" + message + "");
        $(".mm-success-msg").removeClass("d-none");
        $(".mm-success-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-success-msg").offset().top
        }, 'slow');
        setTimeout(function() { $(".mm-success-msg").fadeOut("slow"); }, 3000);
    } else if (statusCode == 202) {
        $(".mm-error-msg span").empty();
        $(".mm-error-msg span").text("" + message + "");
        $(".mm-error-msg").removeClass("d-none");
        $(".mm-error-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-error-msg").offset().top
        }, 'slow');
        setTimeout(function() { $(".mm-error-msg").fadeOut("slow"); }, 3000);
    }
}



function addtoWishListItem() {
    let productArray = []
    $("#card-display-section .form-check-input:checked").each(function() {
        console.log($(this).atte('data-itemid'))
        let quantity = document.getElementById('qty-' + $(this).attr('data-itemid')).value
        productArray = [...productArray, { skuid: $(this).attr('data-itemid').toString(), quantity }]

    });


    var itemStatus = "available";
    var packageQuantity = "";
    var itemStatus = "available";
    var packageQuantity = "";
    var addingType = "addfromcart";
    var productQty = "";

    let addToWLResponse = AddProductToWishL(productArray, addingType, productQty, itemStatus, packageQuantity);

    addToWLResponse.success(function(data) {
        $("#card-display-section .form-check-input:checked").each(function() { this.checked = false });

        if (data.alreadyExists) {
            $("#add-to-wishlist-modal").modal("hide");
            respMsgDisplay(202, data.alreadyExists);

        } else {
			if(data!=null && data.wishlisttype != null){
            var productDetailsArray = [];
                data.cartobj.forEach((element, index) => {

                    var description = $(".prodName" + element.skuid).html();
					var productDetails = {
                        "productQuantity": element.quantity > 0 ? element.quantity : 0,
                        "productInfo": {
                            "productID": element.skuid,
                            "productName": description,
                        }
                    };
                    
                    productDetailsArray.push(productDetails);
                    
                });    
                addToWishlist = {};
                addToWishlist['product'] = productDetailsArray;
                digitalData["addtoWishlist"] = addToWishlist;
                _satellite.track('Add to wishlist', { linkName: $(".add-to-wishlist").html() });
			}
            $("#add-to-wishlist-modal").modal("hide");
            respMsgDisplay(200, "Item(s) have been added to your wish list : " +
                data["wishlistname"] + "");
        }

    });

}



function convertNumberNextValue(itemId, minimumQty)

{


    var value1 = $('#' + itemId).val();

    var num = value1 % minimumQty

    var final = parseInt(value1) + (minimumQty - num);

    $('#' + itemId).value = final;

}


function getDataAndRenderPage() {


    $('#plptitle').html('<p>' + cattitle + '</p>');

    $(".page-title").html(cattitle);


    var jsonString = JSON.stringify(filterArrayObjectFacet);
    var pagestring;
    if (isApplyfilter) {
        pagestring = 1;
    } else {
        pagestring = $(".mySelect option:selected").val();
    }

    var genericdata = {
        "page": pagestring,
        "categoryId": catparam,
        "catPath": "test/test1",
        "resourcePath": $('#resourcePath').val(),
        "size": $(".pagesize option:selected").val(),
        "sort": $(".sort option:selected").val(),
    };

    console.log("testdata  " + jsonString);

    $.ajax({
        url: "/bin/productlistingservlet",
        type: "POST", //send it through get method
        ContentType: "application/json",
        data: {
            data: jsonString,
            genericData: JSON.stringify(genericdata),

        },
        beforeSend: function() {
            $(".header").append("<div id='loader1' class='overlay lds-dual-ring1' ></div>");
        },

        success: function(response) {

            if (response.prodList != undefined) {
                $('.showresults').html("");
                $(".accordion").html("");


                $(".plp-grid-display-control").html("");

                var count = parseInt(response.prodCount);
                $(".allid").val(count);
                var sizing = $(".pagesize option:selected").val();

                var pageHit;
                if (isApplyfilter) {
                    pageHit = 1;
                } else {
                    pageHit = $(".mySelect option:selected").val();
                }

                // var pageHit = $("#mySelect option:selected").val();
                if (pageHit == undefined) {
                    pageHit = 1;

                }



                if (pageHit != null && sizing != null) {

                    var pageStart = (parseInt(sizing) * (parseInt(pageHit) - 1)) + 1;

                    var pageEnd;
                    if (count <= sizing) {
                        pageEnd = count;
                    } else {
                        pageEnd = parseInt(sizing) + (pageStart - 1) > count ? count :
                            parseInt(sizing) + (pageStart - 1);
                    }


                    $('.showresults').append(pageStart + ' - ' + pageEnd + " of " + count + " Results");

                }



                var temp = count % sizing == 0 ? (Math.floor(count / sizing)) : (Math.floor(count / sizing) + 1);

                console.log('total number of pages  ' + temp);
                $('.mySelect').html("");
                var i = 1;
                while (i <= temp) {
                    var text;
                    text = "Page " + i + ' of ' + temp;
                    $('.mySelect').append('<option value="' + i + '">' + text + '</option>');
                    i++;
                }
                $('.mySelect').val(pageHit);



                $('.plp-filter-select').empty()
                filterArrayObjectFacet.sort((a, b) => b.facetList.length - a.facetList.length).forEach((item, countParrent) => {



                        item.facetList.forEach((facetItem, countChild) => {

                            if (countChild == 0) {
                                countParrent == 0 ? $('.plp-filter-select').append(`<div class="clear-all pe-2"><a href="javascript:void(0)">Clear All</a> </div>`) : ''
                                $('.plp-filter-select').append(`<ul class="list-group list-group-horizontal rounded-0 flex-wrap">
                                                                <li id="filter-${item.attrCode}" class="list-group-item border-0 bg-transparent p-2">
                                                                    <label>${item.facetLabel}</label>
                                                                    <span class="p-2 mx-1">${facetItem.attrLabel}<img src="/content/dam/merclink/cross-image-filter.svg" width="13"  class="ms-2" data-category-attrCode="${item.attrCode}" data-category-facetLabel="${item.facetLabel}" data-options-attrCode="${facetItem.attrCode}"  data-options-attrLabel="${facetItem.attrLabel}" ></span>
                                                                </li>                          
                                                             </ul>`)
                            } else {

                                $(`#filter-${item.attrCode}`).append(`<span class="p-2 mx-1">${facetItem.attrLabel}<img src="/content/dam/merclink/cross-image-filter.svg" width="13"  class="ms-2" data-category-attrCode="${item.attrCode}" data-category-facetLabel="${item.facetLabel}" data-options-attrCode="${facetItem.attrCode}"  data-options-attrLabel="${facetItem.attrLabel}" ></span>`)

                            }
                        })
                    }

                )

                //registring event
                $('.plp-filter-select img').click((e) => {
                    console.log(e)
                    filterArrayObjectFacet = filterArrayObjectFacet.map((item) => {
                        return item.attrCode == e.target.getAttribute("data-category-attrCode") ? { attrCode: item.attrCode, facetLabel: item.facetLabel, facetList: item.facetList.filter((a) => a.attrCode != e.target.getAttribute("data-options-attrCode")) } :
                            item
                    })
                    isApplyfilter = false;
                    getDataAndRenderPage();

                })

                $(".clear-all").click(function() {
                    isApplyfilter = true;
                    filterArrayObjectFacet = [];
                    getDataAndRenderPage();

                });




                $.each(response.facetList.filter(item => item.attrCode != "category_uid"), function(key, item) {
                    $(".accordion").append(`
                                    <div class="accordion-item border-start-0 border-end-0 border-top border-bottom bg-transparent">
                                    <h2 class="accordion-header border-start-0 border-end-0 border-top-0 " id=${item.attrCode}>
                                    <button class="accordion-button px-0 bg-transparent" type="button" data-bs-toggle="collapse" data-bs-target="#render-${item.attrCode}" aria-expanded="true" aria-controls="horsepower">
                                        ${item.facetLabel}
                                          </button>
                                    </h2>
                                    <div id="render-${item.attrCode}" class="accordion-collapse collapse show" aria-labelledby="${item.attrCode}" data-bs-parent="#filter-sidebar">
                                        <div class="accordion-body  pt-0">
                                        `)
                    $.each(item.facetList, function(key, item1) {
                        $(`#render-${item.attrCode} > .accordion-body:first-child`).append(`
                            
                                                    <div class="form-check form-check ps-0 my-3 ${key > 5 ? 'mm-filter-toggle-view d-none' : ''}">                                                        
                                                        <input class="form-check-input mt-0  ms-0 " type="checkbox" id="${item1.attrCode}" value="option1"  data-category-attrCode="${item.attrCode}" data-category-facetLabel="${item.facetLabel}" data-options-attrCode="${item1.attrCode}"  data-options-attrLabel="${item1.attrLabel}"></input>                                    
                                                        <label class="form-check-label ms-3" for="inlineCheckbox1">${item1.attrLabel}  (${item1.attrCount})</label>
                                                    </div>

                                                    ${key == item.facetList.length - 1 && key > 5 ? "<div class='see-more'><a href='javascript:void(0)' class='text-decoration-none'><span class='see-more-text'> <img class='img-responsive'  src='/content/dam/merclink/plus-lg.svg' > See More</span></a></div><div class='see-less d-none'><a href='javascript:void(0)' class='text-decoration-none'><span class='see-less-text'><img class='img-responsive' src='/content/dam/merclink/dash-lg.svg' > See Less</span></a></div>" : ''}
                                `);


                    });
                    $(".accordion-item").append(`  </div>
                    </div>
                    </div>
                    `)
                    filterArrayObjectFacet.forEach((item) => {
                        item.facetList.forEach((facetitem) => {
                            $(`[data-category-attrcode="${item.attrCode}"][data-options-attrcode="${facetitem.attrCode}"]`).prop('checked', true);
                        })
                    })

                    //see more

                    $(".see-more").click(function() {

                        $(".mm-filter-toggle-view").removeClass('d-none')
                        $(".see-more").addClass('d-none')
                        $(".see-less").removeClass('d-none')

                    });
                    $(".see-less").click(function() {
                        $(".mm-filter-toggle-view").addClass('d-none')
                        $(".see-more").removeClass('d-none')
                        $(".see-less").addClass('d-none')

                    });

                });

                /**********************/
                // $("#right").append("<div><b> Products count:::" + parseInt(response.prodCount) + "</b></div>");
                console.log("response.prodList  " + response.prodList);
                if (response.prodCount == 0) {
                    $(".plp-grid-display-control").append("No products match your search criteria");
                } else {
                    $.each(response.prodList, function(key, item2) {

                        $(".plp-grid-display-control").append(`
                            <div class="col col-sm-6 col-lg-3 col-md-4  mb-3">
                            <div class="card border p-2">
                                <div class="d-flex justify-content-between  qty-box align-items-center pb-1">
                                   <div class=" h3 mb-0">${item2.buyPrice && item2.buyPrice != 0 ? "<input class='form-check-input' type='checkbox' data-itemId=" + item2.sku + " id='flexCheckDefault'>" : ''}</div>
                                    <div class="d-flex justify-content-end align-items-center"><span class=" me-2">Qty
                                                          </span><input type="number" id="qty-${item2.sku}"  min ="${item2.quantity}" step ="${item2.quantity}" class="w-50 py-2" value="${item2.quantity}" onkeypress="return event.charCode >= 48"  onfocusout=" this.value=='' ? this.value = ${item2.quantity} : '' ; this.value % ${item2.quantity} || this.value == 0  ?  this.value = (parseInt(this.value,10)+(${item2.quantity}-(parseInt(this.value,10) % ${item2.quantity} )))  : '' ; ">
                                    </div>
                                </div>
                                <div class="h3  product-code">${item2.sku}</div>
                                <div class="plp-card-main-container  ">
                                    <div class="plp-card-main-container__item1 text-center"> <img src=${item2.imageUrl ? item2.imageUrl : "/content/dam/merclink/mm-no-image.png"} class="card-img-top" alt="..."></div>

                                    <div class=" plp-card-main-container__item2 text-center">
                                        <h4 class="card-title prodName${item2.sku}">${item2.name}</h4>
                                          ${item2.buyPrice != 0 && item2.availability ? "<h5 class='card-Subtitle'>" + item2.availability + "</h5>" : "<h5 class='card-Subtitle'></h5>"}

                                        ${item2.availableDate != undefined && item2.buyPrice != 0 ? " <span class='card-Subtitle'>" + item2.availableDate + "</span>" : "<span class='card-Subtitle'></span>"}


                                    </div>
                                    <div class="plp-card-main-container__item3 ">
                                        <table class=" table  table-bordered text-center  m-auto ">
                                            <tbody>
                                                <tr class="table-secondary ">
                                                    ${item2.listPrice !=0 && item2.listPrice ? "<th scope='col'>List Price</th>" : '' }
                                                    ${item2.buyPrice !=0 && item2.buyPrice ? "<th scope='col'  class='mm-hide-price'>Buy Price</th>" : ''}

                                                </tr>
                                                <tr>
                                                          ${item2.listPrice !=0  && item2.listPrice ? "<td scope='col'>$"+currencyFormat(parseFloat(item2.listPrice).toFixed(2)) +"</td>" : '' }
                                                          ${item2.buyPrice !=0 && item2.buyPrice ?  "<td scope='col'  class='mm-hide-price'>$" + currencyFormat(parseFloat(item2.buyPrice).toFixed(2)) + "</td>" : ''}
                                                  
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div class="d-flex justify-content-center">
                                            <a href=${$("#pdppage").val()}.html?sku=${item2.sku} class="my-3 btn btn-primary " data-analytics="plpvp" >View Product</a>
                                        </div>
                                    </div>

                                </div>
${item2.prop65 ? "<p class='card-text mb-2'><i> <img src='/content/dam/merclink/warning.svg' class='warning-img'> </i><strong class='text-capitalize '>WARNING: </strong> "+item2.prop65+" -www.P65Warning.ca.gov</p>" : ''}
${item2.hazardousCode == "1" ? "<p class='card-text mb-2'><i> <img src='/content/dam/merclink/warning.svg' class='warning-img'> </i>Hazardous goods. AIR Freight prohibited.</p>" : ''}


                            </div>
                        </div>

                        `)

                    });
                }
            } else {
                $(".accordion").html("");
                $(".plp-grid-display-control").html("<b> '" + response.errors + "' </b>");
            }

        },
        complete: function() { // Set our complete callback, adding the .hidden class and hiding the spinner.
            $('#loader1').remove()
        },
        error: function(xhr) {
            //Do Something to handle error
        }
    });
}