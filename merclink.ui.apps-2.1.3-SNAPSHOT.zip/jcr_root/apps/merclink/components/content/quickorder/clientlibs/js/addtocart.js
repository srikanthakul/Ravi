$(document).ready(function() {
    $('.addtocart').on('click', function(e) {
        var cartArray = [];
        $(".addtoCartCheckBox").each(function() {
            if ($(this).is(":checked")) {
                var itemNumber = $(this).attr("data-item");
                var qty = $("#qty" + itemNumber).val();
                var itemName = $("#item" + itemNumber).val();
                if (itemName != "" && itemName != null && qty != "" && qty != "0" && qty != null) {
                    var cartobj = {
                        "skuid": itemName.toString(),
                        "quantity": qty.toString()
                    }
                    cartArray.push(cartobj);
                }
            }
        });
        if (cartArray.length > 0) {
            var data = {
                "componentPath": $('#resourcePath').val(),
                cartId: getCookie("cartId"),
                cartobj: cartArray
            }
            $.ajax({
                type: "POST",
                url: "/bin/cart/addToCartQuery",
                ContentType: "application/json",
                dataType: "json",
                data: {
                    'data': JSON.stringify(data)
                },
                success: function(data) {
                    if (data && data.addProductsToCart) {
                        if (data.addProductsToCart.cart && data.addProductsToCart.cart.items && data.addProductsToCart.cart.items.length > 0) {
                            $(".cart-item-display-number").html(data.addProductsToCart.cart.items.length);
                            setCookie("cartCount", data.addProductsToCart.cart.items.length, 30);

                            var sendSkuId = cartArray.map(element => element.skuid);
                            var matchedCartItemArray = data.addProductsToCart.cart.items.filter(element => sendSkuId.indexOf(element.product.sku) != -1);
                            var matchedCartItem = matchedCartItemArray.map(element => element.product.sku);
                            if (matchedCartItem.length > 0) {
                                var msg = 'Item(s) have been added/updated to Cart: ' + matchedCartItem.join().toString();
                                var productDetailsArray = [];
                                matchedCartItemArray.forEach((element, indexe) => {
                                    var quantityFilter = cartArray.filter(cartElement => cartElement.skuid == element.product.sku);
                                    var productDetails = {
                                        "productQuantity": quantityFilter.length > 0 ? quantityFilter[0].quantity : 0,
                                        "productInfo": {
                                            "productID": element.product.sku,
                                            "productName": element.product.name,
                                        }
                                    };
                                    productDetailsArray.push(productDetails);
                                });

                                if (typeof digitalData !== "undefined") {
                                    digitalData.addtoCart = {
                                        "product": productDetailsArray,
                                    }
                                }
                                _satellite.track('Add to cart', { linkName: $(".addtocart").html() });
                                respMsgDisplay(200, msg);
                                setTimeout(function() {
                                    location.href = location.href = $("#cartpagelink").val();
                                }, 5000);
                            }
                        }
                        var errMsg = "";
                        if (data.addProductsToCart.cart && data.addProductsToCart.cart.erp_errors && data.addProductsToCart.cart.erp_errors.length > 0) {
                            data.addProductsToCart.cart.erp_errors.forEach((element) => {
                                errMsg += element.message + ", "
                            });
                        }

                        if (data.addProductsToCart.user_errors != null && data.addProductsToCart.user_errors.length > 0) {
                            data.addProductsToCart.user_errors.forEach((element) => {
                                errMsg += element.message + ", "
                            });
                        }

                        if (errMsg.length > 0) {
                            respMsgDisplay(202, errMsg);
                        }
                    } else if (data && data.createCartId) {
                        respMsgDisplay(202, data.createCartId);
                    }
                },
                error: function(status, errorthrown) {
                    console.log("function error" + errorthrown);
                }
            });
        } else {
            respMsgDisplay(202, "Please add valid item(s) to cart.");
        }

    });
});

function respMsgDisplay(statusCode, message, ) {
    if (statusCode == 200) {
        $(".mm-success-msg span").empty();
        $(".mm-success-msg span").text("" + message + "");
        $(".mm-success-msg").removeClass("d-none");
        $(".mm-success-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-success-msg").offset().top
        }, 'slow');
        setTimeout(function() { $(".mm-success-msg").fadeOut("slow"); }, 3000);
    } else if (statusCode == 202) {
        $(".mm-error-msg span").empty();
        $(".mm-error-msg span").text("" + message + "");
        $(".mm-error-msg").removeClass("d-none");
        $(".mm-error-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-error-msg").offset().top
        }, 'slow');
        setTimeout(function() { $(".mm-error-msg").fadeOut("slow"); }, 3000);
    }
}