// QuickOrder.Js

$(document).ready(function() {
    var tableData = ""
    for (var i = 1; i < 6; i++) {
        tableData += '<tr>' +
            '<th scope="row "><input class="w-100 d-none addtoCartCheckBox" data-item="' + i + '" type="checkbox" checked/><input class="w-100 " type="text " name=" " id="ss' + i + '" readonly disabled/></th>' +
            '<td><input class="w-100 insertItem" type="text" data-warehouse="0" data-row="' + i + '" name="" id="item' + i + '"></td>' +
            '<td class="qty-width"><input class="w-100 qtyclass" type="number" name=" " id="qty' + i + '" min="1" step="1" onkeypress="return event.charCode >= 48"  onfocusout="" readonly></td>' +
            '<td><input class="w-100 " type="text " name=" " id="des' + i + '" readonly disabled/></td>' +
            '<td><span id="data-tooltip-click-' + i + '"><input class="w-100 data-tooltip-display" type="text " data-item="' + i + '" name=" " id="avail' + i + '" data-avail="" readonly disabled /></span>' +
            '<div id="data-tooltip-' + i + '" class="tooltip bs-tooltip-top d-none" role="tooltip"><div><div class="tooltip-header"><div class="d-flex flex-nowrap justify-content-between"><div>Estimated Availability Date</div><div>&nbsp;&nbsp;</div><div><span data-item="' + i + '" class="close-tooltip">X</span></div></div></div><div class="tooltip-context-' + i + '">07/19/2022</div></div></div></td>' +
            '</tr>' +
            '<tr class="d-none itemHelpRow' + i + '">' +
            '<th scope="row " class="tableHelpText"></th>' +
            '<td colspan="3" class="tableHelpText"><span class="itemHelpText' + i + '">Order from Seaway 425-412-4006</span></td>' +
            '<td class="tableHelpText"></td>' +
            '<td class="tableHelpText"></td>' +
            '</tr>';
    }

    $(".homepage_quickorder_table").append(tableData);

    $(".insertItem").change(function() {
        var rowNumber = $(this).attr("data-row");
        $(".itemHelpRow" + rowNumber).removeClass("d-none");
        $(".itemHelpRow" + rowNumber).addClass("d-none");
        $(".tooltip-context-" + rowNumber).html("");
        $("#qty" + rowNumber).prop("readonly", true);
        $("#qty" + rowNumber).val("");
        $("#qty" + rowNumber).attr("min", 1);
        $("#qty" + rowNumber).attr("step", 1);
        $("#qty" + rowNumber).attr("onfocusout", "");
        $("#qty" + rowNumber).attr("data-warehouse", 0);
        $("#des" + rowNumber).val("");
        $("#avail" + rowNumber).val("");
        if ($("#item" + rowNumber).val() != "") {
            checkItem(rowNumber);
        }
    });

    $(".qtyclass").change(function() {
        var qtyId = $(this).prop("id");
        var qtyVal = parseInt($(this).val());
        var minValue = parseInt($(this).attr("min").replace(/^\D+/g, ''));
        var warehouse = parseInt($(this).attr("data-warehouse").replace(/^\D+/g, ''));
        var itemNumber = parseInt(qtyId.replace(/^\D+/g, ''));
        var calValue = qtyVal % minValue || qtyVal == 0 ? qtyVal = (parseInt(qtyVal) + (minValue - (parseInt(qtyVal) % minValue))) : qtyVal;
        if ($("#item" + itemNumber) != "" && qtyVal > 0) {
            var availData = "";
            if (warehouse >= qtyVal) {
                availData += "HW-" + qtyVal + ",";
                $("#avail" + itemNumber).attr("data-avail", availData);
            } else {
                if ($("#avail" + itemNumber).attr("data-avail") != "HW-0,") {
                    availData += "HW-" + warehouse + ",";
                    $("#avail" + itemNumber).attr("data-avail", availData);
                }
            }

            if (qtyVal > warehouse && calValue > warehouse) {
                availData += "BO-" + parseInt(calValue - warehouse).toString() + ",";
            }
            $("#avail" + itemNumber).val(availData.slice(0, -1));
        }else{
            $("#avail" + itemNumber).attr("data-avail", "HW-0,");
            $("#avail" + itemNumber).val("");
        }
    });

    $('#header-tooltip-click-availability').click(function() {
        $('#header-tooltip-availability').removeClass('d-none');
        $('#header-tooltip-availability').addClass('show');
    });

    $('.header-close-tooltip-availability').click(function() {
        $('#header-tooltip-availability').removeClass('show');
        $('#header-tooltip-availability').addClass('d-none');
    });

    $(".data-tooltip-display").click(function() {
        var itemNumber = $(this).attr("data-item");
        if ($("#avail" + itemNumber).val() != "" && $(".tooltip-context-" + itemNumber).html() != "") {
            $('#data-tooltip-' + itemNumber).removeClass('d-none');
            $('#data-tooltip-' + itemNumber).addClass('show');
        }
    });

    $(".close-tooltip").click(function() {
        var itemNumber = $(this).attr("data-item");
        $('#data-tooltip-' + itemNumber).removeClass('show');
        $('#data-tooltip-' + itemNumber).addClass('d-none');
    });
});

function checkItem(rowNumber) {
    var data = {
        "componentPath": $('#resourcePath').val(),
        "sku": $("#item" + rowNumber).val(),
        "companyNumber": getCookie("selectedCustomer"),
    }
    $.ajax({
        type: "POST",
        url: "/bin/quickOrderSingleItem",
        ContentType: "application/json",
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            if (data != null) {
                if (data.quickOrderSingleItem) {
                    $(".itemHelpRow" + rowNumber).removeClass("d-none");
                    var message = data.quickOrderSingleItem;
                    $(".itemHelpText" + rowNumber).html(message);
                } else {
                    var item = data.quickOrderProductsAnzp.items;
                    if (item.length > 0) {
                        var availability = item[0].availability;
                        var description = item[0].description;
                        var estimated_availability_date = item[0].estimated_availability_date != null ? item[0].estimated_availability_date : "";
                        var id = item[0].id;
                        var item_number = item[0].item_number;
                        var masterpartlowestsellinguomqty = item[0].masterpartlowestsellinguomqty != null ? parseInt(item[0].masterpartlowestsellinguomqty) : 1;
                        var sku = item[0].sku;
                        var stock_status = item[0].stock_status;
                        var superseeded = item[0].ss_item_number;
                        var warehouse_total = item[0].warehouse_total != null ? item[0].warehouse_total : 0;

                        if (item_number != superseeded) {
                            $("#ss" + rowNumber).val(superseeded);
                        }
                        $("#item" + rowNumber).val(item_number);
                        $(".tooltip-context-" + rowNumber).html(estimated_availability_date);
                        $("#qty" + rowNumber).prop("readonly", false);
                        $("#qty" + rowNumber).val(masterpartlowestsellinguomqty);
                        $("#qty" + rowNumber).attr("min", masterpartlowestsellinguomqty);
                        $("#qty" + rowNumber).attr("step", masterpartlowestsellinguomqty);
                        var validate = "this.value=='' ? this.value = " + masterpartlowestsellinguomqty + " : '' ; this.value % " + masterpartlowestsellinguomqty + " || this.value == 0  ?  this.value = (parseInt(this.value)+(" + masterpartlowestsellinguomqty + "-(parseInt(this.value) % " + masterpartlowestsellinguomqty + " )))  : '' ";
                        $("#qty" + rowNumber).attr("onfocusout", validate);
                        $("#qty" + rowNumber).attr("data-warehouse", parseInt(warehouse_total));
                        $("#des" + rowNumber).val(description);
                        if (warehouse_total >= masterpartlowestsellinguomqty) {
                            availability = "HW-" + masterpartlowestsellinguomqty;
                            $("#avail" + rowNumber).attr("data-avail", "HW-" + masterpartlowestsellinguomqty + ",");
                        } else {
                            $("#avail" + rowNumber).attr("data-avail", "HW-" + warehouse_total + ",");
                        }
                        $("#avail" + rowNumber).val(availability);
                    } else {
                        if (data.quickOrderProductsAnzp.user_errors) {
                            $("#qty" + rowNumber).prop("readonly", true);
                            $(".itemHelpRow" + rowNumber).removeClass("d-none");
                            var message = data.quickOrderProductsAnzp.user_errors[0].message;
                            $(".itemHelpText" + rowNumber).html(message);
                        }
                    }
                }
            }
        }
    });
}