$(document).ready(function() {
    pagination(20, 1, "newsTable", "display-page", "display-page-index");

    $(".display-item").change(function() {
        var showItem = $(this).val();
        var pageNumber = $(".display-page").val();
        $(".display-item").val(showItem);
        $(".display-page").val(pageNumber);
        pagination(showItem, pageNumber, "newsTable", "display-page", "display-page-index");
    });

    $(".display-page").change(function() {
        var showItem = $(".display-item").val();
        var pageNumber = $(this).val();
        $(".display-item").val(showItem);
        $(".display-page").val(pageNumber);
        pagination(showItem, pageNumber, "newsTable", "display-page", "display-page-index");
    });

    $(".news-date").each(function() {
        var str = $(this).text();
        if (str != '' || str != undefined) {
            if (str.indexOf('T') != -1) {
                var date = str.split("T")[0].split("-");
                $(this).text(date[2] + "-" + date[1] + "-" + date[0]);
            }
        }
    });
});