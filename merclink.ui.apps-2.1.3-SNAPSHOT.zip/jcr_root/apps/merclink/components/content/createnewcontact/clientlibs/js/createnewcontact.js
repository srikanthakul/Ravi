// editContact.js

$(".cum_info_remove_icon-inner").click(function() {
    $(".mm-remove-inner-tooltip").show();
});
$(".cum_info_remove_icon-close-btn").click(function() {
    $(".mm-remove-inner-tooltip").hide();
});

var resourcePath = $('#componentPath').val();

function back() {
    location.href = $("#uamPath").val();
}

function saveCreateNewContactDetails() {
    var setectedContact = JSON.parse(getCookie("setectedContact"));
    let company_account_number = setectedContact.contact;
    let cnc_firstName = document.getElementById('cnc_firstName').value;
    let cnc_middileName = document.getElementById('cnc_middileName').value;
    let cnc_lastName = document.getElementById('cnc_lastName').value;
    let cnc_email = document.getElementById('cnc_email').value;
    let cnc_phone = document.getElementById('cnc_phone').value;
    let cnc_startDate = document.getElementById('cnc_startDate').value;
    let cnc_endDate = document.getElementById('cnc_endDate').value;

    var nameValidation = /^[a-zA-Z ]{2,30}$/;
    var mailValidation = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    var phoneValidation = /^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\s\./0-9]*$/;
    if (!cnc_firstName || !cnc_lastName || !cnc_email || !cnc_startDate || !cnc_firstName.match(nameValidation) || !cnc_lastName.match(nameValidation) || !cnc_email.match(mailValidation) || (cnc_phone && !cnc_phone.match(phoneValidation))) {
        respMsgDisplay(202, `Please Verify : <ol type="1"> ${!cnc_firstName  || !cnc_firstName.match(nameValidation) ? '<li> First name is blank or Format is incorrect. </li>' : ''} ${!cnc_lastName || !cnc_lastName.match(nameValidation) ? '<li> Last name is blank or Format is incorrect. </li>' : ''} ${!cnc_email || !cnc_email.match(mailValidation) ? '<li> Email is blank or Format is incorrect. </li>' : ''}  ${(cnc_phone &&  !cnc_phone.match(phoneValidation))  ? '<li> Phone number format is incorrect. </li>' : ''}   ${!cnc_startDate ? '<li> Start date is blank </li>' : ''}</ol>`);
        return;
    }

    var privilegesList = "";
    $('.dynamicPrivileges  input[type=checkbox]:checked').each(function() {
        privilegesList = privilegesList + $(this).attr("value") + ",";
    });

    var data = {
        "componentPath": $('#componentPath').val(),
        "email": cnc_email,
        "firstname": cnc_firstName,
        "lastname": cnc_lastName,
        "middlename": cnc_middileName,
        "job_title": "User",
        "telephone": cnc_phone,
        "start_date": cnc_startDate,
        "end_date": cnc_endDate,
        "permissions": "",
        "roles": privilegesList,
        "updated_by": getCookie("customer_id"),
        "company_account_number": company_account_number
    }
    $.ajax({
        type: "POST",
        url: "/bin/uam/createChildUserServlet",
        ContentType: 'application/json',
        async: false,
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            if (data != undefined && data.createChildUser != undefined && data.createChildUser != null) {
                localStorage.setItem("successIndicator", 'ON');
                location.href = $("#uamPath").val();
            } else if (data.companyUserError != null) {
                var splitData = data.companyUserError.split(",");
                if (splitData[0] == "Customer with same Email ID already assigned to the same company") {
                    var itemList = [];
                    var customer_id = "";
                    if (splitData[0] == "Customer with same Email ID already assigned to the same company") {
                        splitData.forEach((element, index) => {
                            var item = element.split("=");
                            if (item[0] == "firstname") {
                                itemList["cnc_firstName"] = item[1];
                            }
                            if (item[0] == "middlename") {
                                itemList["cnc_middileName"] = item[1];
                            }
                            if (item[0] == "lastname") {
                                itemList["cnc_lastName"] = item[1];
                            }
                            if (item[0] == "email") {
                                itemList["cnc_email"] = item[1];
                            }
                            if (item[0] == "telephone") {
                                itemList["cnc_phone"] = item[1];
                            }
                            if (item[0] == "start_date") {
                                itemList["cnc_startDate"] = item[1];
                            }
                            if (item[0] == "end_date") {
                                itemList["cnc_endDate"] = item[1];
                            }
                            if (item[0] == "customer_id") {
                                customer_id = item[1];
                            }
                        });

                        $("#assign-contact").modal("show");
                        $(".assign-contact-to-customer").unbind("click");
                        $(".assign-contact-to-customer").click(function() {
                            console.log(customer_id);
                            console.log(itemList);
                            for (var key in itemList) {
                                $("#" + key).val(itemList[key]);
                            }
                            saveUpdateContactDetails(parseInt(customer_id), parseInt(company_account_number))
                        });
                    }
                } else {
                    respMsgDisplay(202, data.companyUserError);
                }
            }
        },
        error: function(e) {
            console.log("Error = " + e);
        }
    });
    return false;
}

function saveUpdateContactDetails(id, comId) {
    let cnc_firstName = document.getElementById('cnc_firstName').value;
    let cnc_middileName = document.getElementById('cnc_middileName').value;
    let cnc_lastName = document.getElementById('cnc_lastName').value;
    let cnc_email = document.getElementById('cnc_email').value;
    let cnc_phone = document.getElementById('cnc_phone').value;
    let cnc_startDate = document.getElementById('cnc_startDate').value;
    let cnc_endDate = document.getElementById('cnc_endDate').value;

    let cnc_removeUser = "no";
    if ($("#cnc_removeUser").is(":checked")) {
        cnc_removeUser = "yes"
    }

    var privilegesList = "";

    $('.dynamicPrivileges  input[type=checkbox]:checked').each(function() {
        privilegesList = privilegesList + $(this).attr("value") + ",";
    });

    var data = {
        "componentPath": $('#componentPath').val(),
        "email": cnc_email,
        "firstname": cnc_firstName,
        "lastname": cnc_lastName,
        "middlename": cnc_middileName,
        "updated_by": comId,
        "telephone": cnc_phone,
        "start_date": cnc_startDate,
        "end_date": cnc_endDate,
        "permissions": "",
        "company_number": comId,
        "customerid": id,
        "remove_user": cnc_removeUser,
        "roles": privilegesList
    }
    $.ajax({
        type: "POST",
        url: "/bin/uam/childUserUpdateServlet",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            if (data != undefined && data.updateChildUser != undefined && data.updateChildUser != null) {
                localStorage.setItem("successIndicator", 'ON');
                localStorage.setItem("successIndicatorUpdate", 'ON');
                location.href = $("#uamPath").val();
            } else if (data.companyUserError != null) {
                respMsgDisplay(202, data.companyUserError);
            } else if (data.companyUserUpdateError != null) {
                respMsgDisplay(202, data.companyUserUpdateError);
            }
        },
        error: function(e) {
            console.log("Error = " + e);
        }
    });
    return false;
}

$(document).ready(function() {

    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })

    var url = new URL(location.href);
    var page = url.searchParams.get("page");

    var setectedContact = JSON.parse(getCookie("setectedContact"));
    $(".cum-account-desc").html(setectedContact.contactDesc);

    var customerid = url.searchParams.get("customerid");
    var company_number = setectedContact.contact;

    if (page == "edit") {
        if (customerid != "" && customerid != undefined && company_number != "" && company_number != undefined) {
            editContact(customerid, company_number);
        }
        $("#cnc_removeUser").prop("checked", false);
    } else {
        $(".cum-remove-option").removeClass("d-flex");
        $(".cum-remove-option").hide();
    }


    $("#cnc_startDate")
        .datepicker({
            format: "dd-mm-yyyy",
            autoclose: true,
        })
        .on("changeDate", function(selected) {
            var minDate = new Date(selected.date.valueOf());
            $("#cnc_endDate").datepicker("setStartDate", minDate);
        });



    $("#cnc_endDate")
        .datepicker({
            format: "dd-mm-yyyy",
            autoclose: true,
        })
        .on("changeDate", function(selected) {
            var minDate = new Date(selected.date.valueOf());
            $("#cnc_startDate").datepicker("setEndDate", minDate);
        });
});


function editContact(cid, comId) {

    $("#saveButtonFunction").attr('onClick', "saveUpdateContactDetails(" + cid + "," + comId + ")");
    var data = {
        "componentPath": $('#componentPath').val(),
        "customer_Id": parseInt(cid),
        "company_number": parseInt(comId)
    }
    $.ajax({
        type: "POST",
        url: "/bin/uam/childSecondaryUserDetailsServlet",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            var result = data.ChildUserDetail[0];
            document.getElementById('cnc_firstName').value = result.firstname;
            document.getElementById('cnc_middileName').value = result.middlename ? result.middlename : "";
            document.getElementById('cnc_lastName').value = result.lastname;
            document.getElementById('cnc_email').value = result.email;
            document.getElementById('cnc_phone').value = result.telephone ? result.telephone : "";
            document.getElementById('cnc_startDate').value = result.start_date;
            document.getElementById('cnc_endDate').value = result.end_date;
            var roles = result.roles;
            var myarray = roles.split(',');
            myarray.forEach(element => {
                $(`.form-check-input[value='${element}']`).attr('checked', true);;
            });
        },
        error: function(e) {}
    });
}

function respMsgDisplay(statusCode, message, ) {
    if (statusCode == 200) {
        $(".mm-success-msg span").empty();
        $(".mm-success-msg span").html("" + message + "");
        $(".mm-success-msg").removeClass("d-none");
        $(".mm-success-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-success-msg").offset().top
        }, 'slow');
        setTimeout(function() {
            $(".mm-success-msg").fadeOut("slow");
        }, 20000);
    } else if (statusCode == 202) {
        $(".mm-error-msg span").empty();
        $(".mm-error-msg span").html("" + message + "");
        $(".mm-error-msg").removeClass("d-none");
        $(".mm-error-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-error-msg").offset().top
        }, 'slow');
        setTimeout(function() {
            $(".mm-error-msg").fadeOut("slow");
        }, 20000);
    }
}