$(document).ready(function() {
    var currloc = window.location.href;
    var urlSite = new URL(currloc);
	var titleChange = urlSite.searchParams.get("rb");
    if(titleChange == "MCR"){
        $(".inner-title h2").html("Mercruiser Registration Rebate");
    }else if(titleChange == "DIE"){
        $(".inner-title h2").html("Diesel Registration Rebate");
    }

    $('#years').attr('required', 'required');
    $('#periodNumber').attr('required', 'required');

    $(".mm-csv-btn").click(function(){
        if ($("#rebeat_table input:checkbox:checked").length > 0) {
            download_table_as_csv("rebeat_table", separator = ',');
        }else{
            var expError = "Please select the rows you want to export";
            respMsgDisplay(202, expError);
        }
    });

    $(".resultperpage").change(function() {
        var showItem = $(this).val();
        var pageNumber = $(".curpage").val();
        $(".resultperpage").val(showItem);
        $(".curpage").val(pageNumber);
        pagination(showItem, pageNumber, "rebeat_table", "curpage", "total-value");
    });
    $(".curpage").change(function() {
        var showItem = $(".resultperpage").val();
        var pageNumber = $(this).val();
        $(".resultperpage").val(showItem);
        $(".curpage").val(pageNumber);
        pagination(showItem, pageNumber, "rebeat_table", "curpage", "total-value");
    });

     /* select all checkbox*/

    $('.selectall').click(function (e) {
    $(this).closest('table').find('td input:checkbox').prop('checked', this.checked);
    });

     mercruiserdieselrebate();

    function mercruiserdieselrebate() {
	var currentloc = window.location.href;
	var url = new URL(currentloc);
	var rebateType = url.searchParams.get("rb");
	var selectedCustomer = getCookie("selectedCustomer");
        var data = {
            "resourcePath": $("#resourcePathRebate").val(),
            "customerNumber": parseInt(selectedCustomer),
			"rebateType": rebateType
        }
        $.ajax({
            type: "GET",
            url: "/bin/merclink/powerofchoice",
            ContentType: "application/json",
            data: {
                data: JSON.stringify(data),
            },
            success: function (data) {
               
                if (data != null && data.data != null){
                var responseData = data.data;
                var yearsList = responseData.fiscal_years;
                var listYears= "";
                var listPeriodNumber = "";
                listYears = "<option>Select Year</option>";
                listPeriodNumber = "<option>Select Period Number</option>";
                for (var i = 0; i < yearsList.length; i++){

                    listYears+= "<option value='" + yearsList[i].fiscal_year + "'>" + yearsList[i].fiscal_year + "</option>";
                }

                $("#years").html(listYears);
                $('#periodNumber').html(listPeriodNumber);
                $("#years").change(function () {

                    var selYear = this.value;
                    for (var make in responseData.fiscal_years) {
                       if(responseData.fiscal_years[make].fiscal_year == selYear){
                           listPeriodNumberNew = "<option>Select Period Number</option>";
                           for (var i = 0; i < responseData.fiscal_years[make].date_intervals.length; i++){
                               listPeriodNumberNew += "<option value='" + responseData.fiscal_years[make].date_intervals[i].date_internal_code + "'>" + responseData.fiscal_years[make].date_intervals[i].date_internal_code + "</option>";
                           }
                         }
                    }

                    $('#periodNumber').html(listPeriodNumberNew);
                });
               }else{
                    console.log('servlet null');
               }
              
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                console.log("Status: " + textStatus);
                console.log("Error: " + errorThrown);
            }
        });
     }





    function dieselregistrationrebate(){
       var selectedCustomer = getCookie("selectedCustomer");
       var currentloc = window.location.href;
	   var url = new URL(currentloc);
	   var rebateType = url.searchParams.get("rb");
       var data = {
           "resourcePath": $("#resourcePathRebate").val(),
           "customerNumber": parseInt(selectedCustomer),
           "rebateType": rebateType,
		   "fiscal_year": $("#years").val(),
		   "date_interval_code": $("#periodNumber").val()
       }
       $.ajax({
            type: "GET",
            url: "/bin/merclink/regRebateServlet",
            ContentType: "application/json",
            data: {
                data: JSON.stringify(data),
            },
           success: function (data) { 
               
               if (data != null && data.data != null){
               var rebatetable = data.data.grid_lines;
               $(rebatetable).each(function(i, e) {
               if(rebatetable.length > 0){
               $(".tableData").append(
                            '<tr><td> <input class="form-check-input ms-0" type="checkbox" value=""/></td>'+ 
                            '<td>'+ rebatetable[i].column_value1 + ' </td>'+
                            '<td>' + rebatetable[i].column_value2 + '</td>'+
                            '<td>'+ rebatetable[i].column_value3 + '</td>'+
                            '<td>'+ rebatetable[i].column_value4 +'</td>'+
                            '<td>'+ rebatetable[i].column_value5 +'</td>'+
                            '</tr>'
                           )
                    pagination(20, 1, "rebeat_table", "curpage", "total-value");

                       }
               })

               }else{
                 console.log('rebate servlet null');
               }
           },
           error: function (XMLHttpRequest, textStatus, errorThrown) {
            console.log("Status: " + textStatus);
            console.log("Error: " + errorThrown);
           }


        });
    }



/* search button */

   $(".searchBtn").click(function(){
        var searchYears = $('#years').val();
        var searchPeriodNumber = $('#periodNumber').val();
        var intRegex = /^\d+$/;
        if(intRegex.test(searchYears) && searchYears.length == 4){
            $('.Valid-Year').addClass('d-none');
            if(searchPeriodNumber != null && searchPeriodNumber != 'Select Period Number'){
                $('.rebatetabale').addClass('d-none');
                $('.Valid-Period').addClass('d-none');
                $('.tableData').empty();
                dieselregistrationrebate();
                $('.rebatetabale').removeClass('d-none');
                $('.rebate_page').removeClass('d-none');
            }else {
				$('.Valid-Period').removeClass('d-none');
            }
        }else {
            $('.Valid-Year').removeClass('d-none');
        }
   });

      /* reset Button */

        $(".resetBtn").click(function(){
        $('.rebatetabale').addClass('d-none');
        $('.rebate_page').addClass('d-none');
        $('.tableData').empty();
        $('#periodNumber').prop('selectedIndex',0);
        $('#years').prop('selectedIndex',0);


    });



});


/* export file */

function download_table_as_csv(rebeat_table, separator = ',') {
    var rows = document.querySelectorAll('table#' + rebeat_table + ' tr');
    var csv = [];
    for (var i = 0; i < rows.length; i++) {
        var row = [],row1 = [],
         cols = rows[i].querySelectorAll('td, th');
        for (var j = 0; j < cols.length; j++) {
            if(i >= 1 && cols[0].children.length > 0 && cols[0].children[0].checked ){
                var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
                data = data.replace(/"/g, '""');
                row.push('"' + data + '"');
            }else if(i==0){
                var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
                data = data.replace(/"/g, '""');
                row.push('"' + data + '"');

            }

        }
       
        if (typeof row !== 'undefined' && row.length > 0) {
            csv.push(row.join(separator));
        }

    }
  

    var csv_string = csv.join('\n');
    var filename = 'rebate_table_' + new Date().toLocaleDateString() + '.csv';
    var link = document.createElement('a');
    link.style.display = 'none';
    link.setAttribute('target', '_blank');
    link.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv_string));
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

/* search button */
$('.searchBtn').click(function(){
    dieselregistrationrebate();
});

/* toastr */
function respMsgDisplay(statusCode, message, ) {
    if (statusCode == 200) {
        $(".mm-success-msg span").empty();
        $(".mm-success-msg span").text("" + message + "");
        $(".mm-success-msg").removeClass("d-none");
        $(".mm-success-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-success-msg").offset().top
        }, 'slow');
        setTimeout(function () {
            $(".mm-success-msg").fadeOut("slow");
        }, 20000);

    } else if (statusCode == 202) {
        $(".mm-error-msg span").empty();
        $(".mm-error-msg span").text("" + message + "");
        $(".mm-error-msg").removeClass("d-none");
        $(".mm-error-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-error-msg").offset().top
        }, 'slow');
        setTimeout(function () {
            $(".mm-error-msg").fadeOut("slow");
        }, 20000);

    }
}
