$(document).ready(function() {

    // tootltip hide show

    $(".tooltip-box").click(function() {
        $(this).parent().addClass("tooltip-open");
    });

    $(".tooltip-close").click(function() {
        $(this).parents().removeClass("tooltip-open");
    });

    // Select all checkbox
    $("th input").click(function () {
        if (this.checked) {
            $("td input:checkbox").each(function () {
                this.checked = true
            });
        } else {
            $("td input:checkbox").each(function () {
                this.checked = false
            });
        }
    });

// Pagination arrow work
    $('.bi-left').click(()=> $(".cart-arrow-select > option:selected").prev().val() && $(".cart-arrow-select").val($(".cart-arrow-select > option:selected").prev().val() ) &&  $(".cart-arrow-select").change())
$('.bi-right').click(()=>$(".cart-arrow-select > option:selected").next().val() && $(".cart-arrow-select").val($(".cart-arrow-select > option:selected").next().val()) &&  $(".cart-arrow-select").change())
                     

});