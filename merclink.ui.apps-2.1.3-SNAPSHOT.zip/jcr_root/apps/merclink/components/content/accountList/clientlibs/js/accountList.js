// accountList.js

$(document).ready(function() {
    setMyAccountData();
    $(".save-default-account").click(function() {
        var compantNumber = $("input[type='radio']:checked").attr("data-company");
        setDefaultAccount(compantNumber);
    });

    $(".change-email-btn").click(function() {
        var email = $("input[type='email']").val();
        changeEmail(email);
    });
});

function setMyAccountData() {
    var data = JSON.parse(getCookie("merclinkCustomerPersonalInfo"));
    var customer_id = data.billing_address.customer_id;
    var firstname = data.billing_address.firstname;
    var lastname = data.billing_address.lastname;
    var email = data.email;
    $(".contact-person-email").html(email);
    $(".contact-person-email").attr("href", "mailto:" + email);
    $("input[type='email']").val(email);
    var accountItemList = "";
    var defaultComapny = "";
    data.account_list.forEach(element => {
        var is_default = 0;
        var checked = "";
        if (element.is_default === "Yes") {
            is_default = 1;
            checked = "checked"
            defaultComapny = element.company_number + ", " + element.company_name;
        }
        accountItemList += '<tr><td class="ps-md-5"><input class="form-check-input ms-0" type="radio" data-company="' + +element.company_number + '" name="1" value="' + is_default + '" ' + checked + '/></td><td>' + element.company_number + '</td><td><span id="companyName-' + element.company_number + '">' + element.company_name + '</td><td>' + element.is_admin + '</td></tr>';
    });

    $(".contact-person-details").html(defaultComapny);
    $("tbody").append(accountItemList);
}


function setDefaultAccount(compantNumber) {
    var data = {
        "componentPath": $("#componentPath").val(),
        "company_number": compantNumber
    }
    $.ajax({
        type: "POST",
        url: "/bin/uam/setDefaultAccountServlet",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            if (data != null || data != undefined) {
                if (data.setAnzpDefaultCompany != null || data.setAnzpDefaultCompany != undefined) {
                    if (data.setAnzpDefaultCompany.message != null || data.setAnzpDefaultCompany.message != undefined) {
                        $(".contact-person-details").html(compantNumber + ", " + $("#companyName-" + compantNumber).html());
                        $(".default-acc-msg").html(data.setAnzpDefaultCompany.message);
                        $(".default-acc-msg").parent().removeClass("d-none");
                        $(".default-acc-msg").fadeIn(1000);
                        $(".default-acc-msg").parent().parent()[0].scrollIntoView();
                        setTimeout(function() {
                            $(".default-acc-msg").parent().fadeOut(1000);
                        }, 20000);
                        loadPersonalInformation();
                    }
                }
            }
        },
        error: function(e) {}
    });
}


function changeEmail(email) {
    var data = {
        "componentPath": $("#componentPath").val(),
        "email": email
    }
    $.ajax({
        type: "POST",
        url: "/bin/uam/changeUserEmail",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            if (data != null || data != undefined) {
                if (data.changeAnzpEmail != null || data.changeAnzpEmail != undefined) {
                    if (data.changeAnzpEmail.message != null || data.changeAnzpEmail.message != undefined) {
                        $("#change-email").modal("hide");
                        $(".change-email-msg").html(data.changeAnzpEmail.message);
                        $(".change-email-msg").parent().removeClass("d-none");
                        $(".change-email-msg").fadeIn(1000);
                        $(".change-email-msg").parent().parent()[0].scrollIntoView();
                        setTimeout(function() {
                            $(".change-email-msg").parent().fadeOut(1000);
                        }, 20000);
                        loadPersonalInformation();
                    }
                }
            }
        },
        error: function(e) {}
    });
}