$(document).ready(function() {

	$(document).on("click", ".export-check", function() {
        if ($('.export-check:checked').length == $('.export-check').length) {
            $('.exp-select-all').prop('checked', true);
        } else {
            $('.exp-select-all').prop('checked', false);
        }
    });
	
	$(".datepicker").datepicker({
        autoclose: true,
        dateFormat: 'dd/mm/yyyy',
        todayHighlight: true
    });
	
	var selectedCustomer = getCookie("selectedCustomer");
	var data = {
		"orderInLast": "",
	    "startDate": "",
	    "endDate": "",
	    "currentPage": $("#resourcePathPage").val(),
	    "customerNumber": selectedCustomer,
	    "orderNumber": "",
	    "poNumber": "",
	    "itemNumber": "",
	    "orderStatus": "",
	    "invoice_number": ""
		};
    
    $(".resultperpage").change(function() {
        var showItem = $(this).val();
        var pageNumber = $(".curpage").val();
        $(".resultperpage").val(showItem);
        $(".curpage").val(pageNumber);
        pagination(showItem, pageNumber, "order_history", "curpage", "total-value");
    });

    $(".curpage").change(function() {
        var showItem = $(".resultperpage").val();
        var pageNumber = $(this).val();
        $(".resultperpage").val(showItem);
        $(".curpage").val(pageNumber);
        pagination(showItem, pageNumber, "order_history", "curpage", "total-value");
    });
    
    $(".order-open").on('change', function () {
        $('.order-invoice').val($(this).val());
        $(".order-open-text").attr("placeholder", "" + $(this).val());
        if($(".order-open :selected").val() != "") {
			$(".order-in-last option").eq(0).prop("selected",true);
			$(".order-in-last").change();
		}
    });
    
    last30DaysRecords();

    function last30DaysRecords() {
        var date = new Date();
        date.setDate(date.getDate() - 30);
        var dateString = date.toISOString().split('T')[0];
        dateString = dateString.split("-").reverse().join("-");
        $(".mm-from-date").val(dateString);
        var todayDate = new Date();
        todayDate = todayDate.toISOString().split('T')[0];
        todayDate = todayDate.split("-").reverse().join("-");
        $(".mm-to-date").val(todayDate);
    }
    
    var fromDate = $(".mm-from-date").val();
	var toDate = $(".mm-to-date").val();
	
	data["startDate"] = fromDate.split("-").reverse().join("-");
	data["endDate"] = toDate.split("-").reverse().join("-");

    $(".order-in-last").change(function(){
        var date = new Date();
        if($(".order-in-last :selected").val().toLowerCase().trim() == "0") {
			$(".mm-from-date").val("");
			$(".mm-to-date").val("");
        }
        if($(".order-in-last :selected").val().toLowerCase().trim() == "30") {
            last30DaysRecords();
        }
        if($(".order-in-last :selected").val().toLowerCase().trim() == "60") {
            date.setDate(date.getDate() - 60);
            var dateString = date.toISOString().split('T')[0];
            dateString = dateString.split("-").reverse().join("-");
            $(".mm-from-date").val(dateString);
            var todayDate = new Date();
            todayDate = todayDate.toISOString().split('T')[0];
            todayDate = todayDate.split("-").reverse().join("-");
            $(".mm-to-date").val(todayDate);
        }
        if($(".order-in-last :selected").val().toLowerCase().trim() == "90") {
            date.setDate(date.getDate() - 90);
            var dateString = date.toISOString().split('T')[0];
            dateString = dateString.split("-").reverse().join("-");
            $(".mm-from-date").val(dateString);
            var todayDate = new Date();
            todayDate = todayDate.toISOString().split('T')[0];
            todayDate = todayDate.split("-").reverse().join("-");
            $(".mm-to-date").val(todayDate);
        }

    });

    $(".mm-to-date").change(function(){
        var toDateVal = $(this).val().split("-").reverse().join("-");
        var fromDateVal = $(".mm-from-date").val().split("-").reverse().join("-");
        $(".order-in-last option[value=0]").prop("selected",true);
		$(".order-in-last").change();
		$(this).val(toDateVal.split("-").reverse().join("-"));
		$(".mm-from-date").val(fromDateVal.split("-").reverse().join("-"));
        if(new Date(fromDateVal).getTime() > new Date(toDateVal).getTime() || fromDateVal == 0) {
            $(".mm-to-date").val("");
            $(".mm-order-history-page").before(`<div class="mm-error-msg  mb-3 date-val-msg"><img src="/content/dam/merclink/images/Error.svg" width="25" class="me-1" /> Please enter valid to date</div>`);
			setTimeout(function(){
				$(".date-val-msg").remove();
			},5000);
        }
        else {
		}
    });
    
    $(".mm-from-date").change(function(){
		var fromDateVal = $(this).val().split("-").reverse().join("-");
        var toDateVal = $(".mm-to-date").val().split("-").reverse().join("-");
        $(".order-in-last option[value=0]").prop("selected",true);
		$(".order-in-last").change();
		$(this).val(fromDateVal.split("-").reverse().join("-"));
		$(".mm-to-date").val(toDateVal.split("-").reverse().join("-"));
        if(new Date(fromDateVal).getTime() > new Date(toDateVal).getTime()) {
            $(".mm-from-date").val("");
            $(".mm-to-date").val("");
            $(".mm-order-history-page").before(`<div class="mm-error-msg  mb-3 date-val-msg"><img src="/content/dam/merclink/images/Error.svg" width="25" class="me-1" /> Please enter valid from date</div>`);
			setTimeout(function(){
				$(".date-val-msg").remove();
			},5000);
        }
    });
    
    tableAjaxCall();
    
    $(".mm-search-filter").click(function(){
	
		var fromDate = $(".mm-from-date").val();
		var toDate = $(".mm-to-date").val();
		
		if($(".order-open :selected").val().toLowerCase().trim() == "enter item number") {
			var enteredInput = $(".order-open-text").val().toLowerCase().trim();
			data["itemNumber"] = enteredInput;
			data["orderNumber"] = "";
			data["poNumber"] = "";
		}
		if($(".order-open :selected").val().toLowerCase().trim() == "enter order number") {
			var enteredInput = $(".order-open-text").val().toLowerCase().trim();
			data["itemNumber"] = "";
			data["orderNumber"] = enteredInput;
			data["poNumber"] = "";
		}
		if($(".order-open :selected").val().toLowerCase().trim() == "enter po number") {
			var enteredInput = $(".order-open-text").val().toLowerCase().trim();
			data["itemNumber"] = "";
			data["orderNumber"] = "";
			data["poNumber"] = enteredInput;
		}
		
		if($(".order-status :selected").val().toLowerCase().trim() == "all") {
			data["orderStatus"] = "";
		}
		if($(".order-status :selected").val().toLowerCase().trim() == "canceled") {
			data["orderStatus"] = "canceled";
		}
		if($(".order-status :selected").val().toLowerCase().trim() == "invoiced") {
			data["orderStatus"] = "invoiced";
		}
		if($(".order-status :selected").val().toLowerCase().trim() == "open order") {
			data["orderStatus"] = "open order";
		}
		
		if($(".order-in-last :selected").val().toLowerCase().trim() == "30") {
			data["orderInLast"] = "30";
		}
		if($(".order-in-last :selected").val().toLowerCase().trim() == "60") {
			data["orderInLast"] = "60";
		}
		if($(".order-in-last :selected").val().toLowerCase().trim() == "60") {
			data["orderInLast"] = "90";
		}
		
		data["startDate"] = fromDate.split("-").reverse().join("-");
		data["endDate"] = toDate.split("-").reverse().join("-");
		
		tableAjaxCall();
	    
    });
    
    $('#order_history .img-down-icon').click(function() {

        var tableId = "order_history";

        var rowIndex = $(this).parent().parent().parent().parent().index('#' + tableId + ' tr');

        var thIndex = $(this).parent().parent().parent().index('#' + tableId + ' tr:eq(' + rowIndex + ') th');

        sortTable(parseInt(thIndex), 'asc', tableId);

        var showItem = $(".resultperpage").val();

        var pageNumber = $(".curpage").val();

        pagination(showItem, pageNumber, "order_history", "curpage", "total-value");

    });
    
    $('#order_history .img-up-icon').click(function() {

        var tableId = "order_history";

        var rowIndex = $(this).parent().parent().parent().parent().index('#' + tableId + ' tr');

        var thIndex = $(this).parent().parent().parent().index('#' + tableId + ' tr:eq(' + rowIndex + ') th');

        sortTable(parseInt(thIndex), 'desc', tableId);

        var showItem = $(".resultperpage").val();

        var pageNumber = $(".curpage").val();

        pagination(showItem, pageNumber, "order_history", "curpage", "total-value");

    });
    
    $('.bi-chevron-left').click(()=> $(".curpage > option:selected").prev().val() && $(".curpage").val($(".curpage > option:selected").prev().val() ) && $(".curpage").change());

    $('.bi-chevron-right').click(()=>$(".curpage > option:selected").next().val() && $(".curpage").val($(".curpage > option:selected").next().val()) && $(".curpage").change());
    
    setInterval(function(){
		$(".exp-select-all").change(function(){
			if($(".exp-select-all").is(":checked")) {
				$(".export-check").prop("checked", true);
				$(".export-check").change();
				$(".tableData tr").addClass("exp-active");
				$(".mm-csv-btn").css("pointer-events", "all");
				$(".mm-error-msg").addClass("d-none");
			}
			else{
				$(".tableData tr").removeClass("exp-active");
				$(".export-check").prop("checked", false);
				$(".export-check").change();
			}
		});
		$(".tableData tr").each(function(){
			$(this).click(function(){
				if($(this).children().find(".export-check").is(":checked")) {
					$(this).addClass("exp-active");
					$(".mm-csv-btn").css("pointer-events", "all");
					$(".mm-error-msg").addClass("d-none");
				}
				else {
					$(this).removeClass("exp-active");
				}
			});
		});
		if(!$(".export-check").is(":checked")) {
			$(".mm-csv-btn").css("pointer-events", "none");
		}
		$(".exp-btn-parent").click(function(){
			if(!$(".export-check").is(":checked")) {
				$(".mm-error-msg").removeClass("d-none");
				$(window).scrollTop(0);
				setTimeout(function(){
					$(".mm-error-msg").addClass("d-none");
				},3000);
			}
		});
	},500);

	$(".mm-reset").click(function(){
		$(".order-open option").eq(0).prop("selected" , true);
		$(".order-open").change();
        $(".order-open-text").val("");
		$(".order-open-text").change();
        $(".order-status option[value=all]").prop("selected" , true);
        $(".order-status").change();
        $(".order-in-last option[value=0]").prop("selected" , true);
        $(".order-in-last").change();
		$(".mm-error-msg").addClass("d-none");
		$(".date-val-msg").remove();
		data["orderNumber"] = "";
		data["itemNumber"] = "";
		data["poNumber"] = "";
		data["orderStatus"] = "";
		data["orderInLast"] = "";
		data["startDate"] = "";
		data["endDate"] = "";
    });
	
	var itemNumLink = $(".mm-item-num-link").text();
	
	function tableAjaxCall() {
		$.ajax({
		    type: "GET",
		    url: "/bin/merclink/orderhistory", 
		    ContentType: 'application/json',
		    async: true,
		    data: {
		        'data': JSON.stringify(data)
		    },
		    beforeSend: function () { 
                $('#loader').removeClass('hidden')
            },
		    success: function (data) {
				$(".tableData tr").remove();
				$(".date-val-msg").remove();
				if(data.length != 0) {
					var jsonData = JSON.parse(data);
			        if(jsonData.orderResults != null) {
						jsonData.orderResults.sort((a,b)=>new Date(b.orderedDate) - new Date(a.orderedDate));
						$(".mm-table-filter").remove();
						for(i in jsonData.orderResults) {
							orderNum = jsonData.orderResults[i].orderNumber;
							poNum = jsonData.orderResults[i].poNumber;
							ordDate = jsonData.orderResults[i].orderedDate.split("-").reverse().join("-");
							ordStatus = jsonData.orderResults[i].status;
							shipTo = jsonData.orderResults[i].shippingAddress.shipToAddress.name;
							ordSource = jsonData.orderResults[i].orderSource;
							ordType = jsonData.orderResults[i].orderType;
							$(".tableData").append(`<tr class="mm-csv-row">
			                                <td><input class="form-check-input ms-0 export-check" type="checkbox" value=""></td>
			                                <td><a href="${itemNumLink}?order_number=${orderNum}"> ${orderNum} </a></td>
			                                <td> ${poNum} </td>
			                                <td> ${ordDate} </td>
			                                <td> ${ordStatus} </td>
			                                <td> ${shipTo} </td>
			                                <td> ${ordSource} </td>
			                                <td> ${ordType} </td>
			                            </tr>`);
			            	pagination(20, 1, "order_history", "curpage", "total-value");
			            	
			            	$(".tableData tr td").each(function(){
								if($(this).text().trim() == "undefined" || $(this).text().trim() == "null") {
									$(this).text(""); 
								}
							});
						}
					}
					if(jsonData.orderResults == 0 || jsonData.orderResults == null) {
						$(".mm-table-filter").remove();
						$("table").after("<div class='mm-table-filter' style='text-align:center'>No data found</div>");
						$(".total-value").html("0 of 0 Results");
						$(".curpage option").remove();
						$(".curpage").append(`<option value="1" selected="">Page 1 of 1</option>`);
					}
					
				}
		        
	        },
	        complete: function () {
                $('#loader').addClass('hidden')
            },

	    });
	}
	
	
	
	$(".mm-csv-btn").click(function() {
        if ($('.export-check:checkbox:checked').length > 0) {
            download_table_as_csv("order_history", separator = ',');
        } else {
            return false;
        }

    });
	
	function download_table_as_csv(order_history, separator = ',') {
        var rows = document.querySelectorAll('table#' + order_history + ' tr');
        var csv = [];
        for (var i = 0; i < rows.length; i++) {
            var row = [],
                row1 = [],
                cols = rows[i].querySelectorAll('td, th');
            for (var j = 0; j < cols.length; j++) {
                if (i >= 1 && cols[0].children.length > 0 && cols[0].children[0].checked) {
                    var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
                    data = data.replace(/"/g, '""');
                    row.push('"' + data + '"');
                } else if (i == 0) {
                    var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
                    data = data.replace(/"/g, '""');
                    row.push('"' + data + '"');

                }

            }

            if (typeof row !== 'undefined' && row.length > 0) {
                csv.push(row.join(separator));
            }

        }

        var csv_string = csv.join('\n');
        var filename = 'export_' + order_history + '_' + new Date().toLocaleDateString() + '.csv';
        var link = document.createElement('a');
        link.style.display = 'none';
        link.setAttribute('target', '_blank');
        link.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv_string));
        link.setAttribute('download', filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
});