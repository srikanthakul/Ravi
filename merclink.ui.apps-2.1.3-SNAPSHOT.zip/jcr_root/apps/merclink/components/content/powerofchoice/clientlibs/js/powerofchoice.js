$(document).ready(function() {

    $("#companyName").prop("readonly", true);
    $("#toDate").prop("readonly", true);
    $("#fromDate").prop("readonly", true);

    $('#fromDate').attr('required', 'required');
    $('#toDate').attr('required', 'required');
    $('#years').attr('required', 'required');
    $('#periodNumber').attr('required', 'required');

    loadPowerOfChoice();

    function loadPowerOfChoice() { 

       var selectedCustomer = getCookie("selectedCustomer");

       var data = {
           "resourcePath": $("#resourcePathPoc").val(),
           "customerNumber": parseInt(selectedCustomer),
           "rebateType": $("#rebateType").val()
       }

        $.ajax({
            type: "GET",
            url: "/bin/merclink/powerofchoice",
            ContentType: "application/json",
            data: {
                data: JSON.stringify(data),
            },
            success: function (data) {
                if (data != null && data.data != null){

                var responseData = data.data;
                var yearsList = responseData.fiscal_years;
                var listYears= "";
                var listPeriodNumber = "";

                $("#companyName").val(responseData.company_name);
				listYears = "<option>Select Year</option>";
                listPeriodNumber = "<option>Select Period Number</option>";
                for (var i = 0; i < yearsList.length; i++){

                    listYears+= "<option value='" + yearsList[i].fiscal_year + "'>" + yearsList[i].fiscal_year + "</option>";
                }

                $("#years").html(listYears);
                $('#periodNumber').html(listPeriodNumber);

                $("#years").change(function () {

                    $('#fromDate').val('');
                    $('#toDate').val('');

                    $(this).prop('selected', true);
                    var selYear = this.value;

                     for (var make in responseData.fiscal_years) {              

                         if(responseData.fiscal_years[make].fiscal_year == selYear){

                              var listPeriodNumberNew = "";
                              listPeriodNumberNew = "<option>Select Period Number</option>";

                             for (var i = 0; i < responseData.fiscal_years[make].date_intervals.length; i++){

                                    listPeriodNumberNew += "<option value='" + responseData.fiscal_years[make].date_intervals[i].date_internal_code + "'>" + responseData.fiscal_years[make].date_intervals[i].date_internal_code + "</option>";

                             }
                         }

				     }

                     $('#periodNumber').html(listPeriodNumberNew);

                });


				$("#periodNumber").change(function () {

                    $(this).prop('selected', true);
					var currYear = $("#years").val();
					var currPeriod = this.value;

                    for (var make in responseData.fiscal_years) {              
                         if(responseData.fiscal_years[make].fiscal_year == currYear){

                             for (var i = 0; i < responseData.fiscal_years[make].date_intervals.length; i++){
                                 if(responseData.fiscal_years[make].date_intervals[i].date_internal_code == currPeriod){
									 var currFromDate = responseData.fiscal_years[make].date_intervals[i].from_date;
                                     var currToDate = responseData.fiscal_years[make].date_intervals[i].to_date;
                                     $("#fromDate").val(currFromDate);
                                     $("#toDate").val(currToDate);

                                 }

                             }
                         }

				     }

                });
              }else{
                     console.log("poc servlet data null");
              }

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                console.log("Status: " + textStatus);
                console.log("Error: " + errorThrown);
            }
        });
     }


    function loadRebate(){

       var selectedCustomer = getCookie("selectedCustomer");
       //var selectedFromDate = $('#fromDate').val();
       //var selectedToDate = $('#toDate').val();

       var data = {
           "resourcePath": $("#resourcePathPoc").val(),
           "customerNumber": parseInt(selectedCustomer),
           "rebateType": $("#rebateType").val(),
		   "fiscal_year": $("#years").val(),
		   "date_interval_code": $("#periodNumber").val()
       }

       $.ajax({
            type: "GET",
            url: "/bin/merclink/regRebateServlet",
            ContentType: "application/json",
            data: {
                data: JSON.stringify(data),

            },
           success: function (data) { 

              if (data != null && data.data != null){
               var summary = data.data.summary;
               if (typeof summary !== 'undefined' && summary.length > 2) {
                   if(summary[0].description != null && summary[0].value != null){
						$('.firstRow').append('<p class="rowFirst">'+summary[0].description+'</p><span class="rowFirst">'+summary[0].value+'</span>');
                   }

                   if(summary[summary.length-1].description != null && summary[summary.length-1].value != null){
						$('.lastRow').append('<p class="rowLast"><strong>'+summary[summary.length-1].description+'</strong></p><span class="rowLast">'+summary[summary.length-1].value+'</span>');
                   }

                   $(summary).each(function(i, e) {
                       if((i>0) && (i != summary.length-1)){
                           $(".rebateDetails").append(
                               '<div class="d-flex justify-content-between"> <p>' + summary[i].description + '<p/><span>' + summary[i].value + '</span></div>'
                           )
                       }
                   })
               }

                   var rebatetable = data.data.grid_lines;
                   if (typeof rebatetable !== 'undefined' && rebatetable.length > 0) {
                       $(rebatetable).each(function(i, e) {
                           if(rebatetable.length > 0){
                               $(".PocRebateTable").append(
                                   '<tr><td>' + rebatetable[i].column_value1 + '</td><td>' + rebatetable[i].column_value2 + '</td><td>'+ rebatetable[i].column_value3 + '</td><td>'+ rebatetable[i].column_value4 +'</td></tr>'
                               )
                           }
                       })
                   }
               }else{
					console.log("servlet data null");
               }

           },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                console.log("Status: " + textStatus);
                console.log("Error: " + errorThrown);
            }

        });
    }


    $(".searchBtn").click(function(){

        var searchFromDate = $('#fromDate').val();
        var searchToDate = $('#toDate').val();
        var searchYear = $('#years').val();
        var searchPeriodNumber = $('#periodNumber').val();
        var intRegex = /^\d+$/;
        var dateRegex = /^(?=\d)(?:(?:31(?!.(?:0?[2469]|11))|(?:30|29)(?!.0?2)|29(?=.0?2.(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00)))(?:\x20|$))|(?:2[0-8]|1\d|0?[1-9]))([-.\/])(?:1[012]|0?[1-9])\1(?:1[6-9]|[2-9]\d)?\d\d(?:(?=\x20\d)\x20|$))?(((0?[1-9]|1[012])(:[0-5]\d){0,2}(\x20[AP]M))|([01]\d|2[0-3])(:[0-5]\d){1,2})?$/;

        if(intRegex.test(searchYear) && searchYear.length == 4){
		    $('.Valid-Year').addClass('d-none');

            if(searchPeriodNumber != null && searchPeriodNumber != 'Select Period Number'){
			    $('.Valid-Period').addClass('d-none');
                $('.PocSummary').addClass('d-none');
                    $('.pocTable').addClass('d-none');
                    
                    $('.PocRebateTable').empty();
                    $('.rebateDetails').empty();
                    
                    $('.rowFirst').remove();
                    $('.rowLast').remove();
                    
                    loadRebate();
                    $('.PocSummary').removeClass('d-none');
                    $('.pocTable').removeClass('d-none');


            }else{
				$('.Valid-Period').removeClass('d-none');
            }

        }else{
            $('.Valid-Year').removeClass('d-none');
        }


    });


    $(".resetBtn").click(function(){
        $('#fromDate').val('');
        $('#toDate').val('');
        $('#years').prop('selectedIndex',0);
        $('#periodNumber').prop('selectedIndex',0);
        $('.PocSummary').addClass('d-none');
        $('.pocTable').addClass('d-none');

    });

});



