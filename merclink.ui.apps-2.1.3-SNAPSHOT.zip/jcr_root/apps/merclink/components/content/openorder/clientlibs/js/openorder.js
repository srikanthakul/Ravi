$(document).ready(function(){

	$(document).on("click", ".export-check", function() {
        if ($('.export-check:checked').length == $('.export-check').length) {
            $('.exp-select-all').prop('checked', true);
        } else {
            $('.exp-select-all').prop('checked', false);
        }
    });
	
	var selectedCustomer = getCookie("selectedCustomer");
	var data = {
		    "orderInLast": "",
		    "creditHold": "",
		    "holdFlag": "",
		    "startDate": "",
		    "endDate": "",
		    "currentPage": $("#resourcePathPage").val(),
		    "customerNumber": selectedCustomer,
		    "orderNumber": "",
		    "poNumber": "",
		    "itemNumber": "",
		    "orderDate": "" 
		};
	
	$(".resultperpage").change(function() {
        var showItem = $(this).val();
        var pageNumber = $(".curpage").val();
        $(".resultperpage").val(showItem);
        $(".curpage").val(pageNumber);
        pagination(showItem, pageNumber, "open_order", "curpage", "total-value");
    });

    $(".curpage").change(function() {
        var showItem = $(".resultperpage").val();
        var pageNumber = $(this).val();
        $(".resultperpage").val(showItem);
        $(".curpage").val(pageNumber);
        pagination(showItem, pageNumber, "open_order", "curpage", "total-value");
    });
    
    $("table").after("<div class='mm-table-filter' style='text-align:center'>No data found</div>");
    
    $(".order-open").on('change', function () {
        $('.order-invoice').val($(this).val());
        $(".order-open-text").attr("placeholder", "" + $(this).val());
        if($(".order-open :selected").val() != "") {
			$(".order-in-last option").eq(0).prop("selected",true);
			$(".order-in-last").change();
		}
    });
    
    last30DaysRecords();

    function last30DaysRecords() {
        var date = new Date();
        date.setDate(date.getDate() - 30);
        var dateString = date.toISOString().split('T')[0];
        $(".mm-from-date").val(dateString);
        var todayDate = new Date();
        todayDate = todayDate.toISOString().split('T')[0];
        $(".mm-to-date").val(todayDate);
    }
    var fromDate = $(".mm-from-date").val();
	var toDate = $(".mm-to-date").val();
	
	data["startDate"] = fromDate;
	data["endDate"] = toDate;
    
    $(".order-in-last").change(function(){
        var date = new Date();
        if($(".order-in-last :selected").val().toLowerCase().trim() == "0") {
			$(".mm-from-date").val("");
			$(".mm-to-date").val("");
        }
        if($(".order-in-last :selected").val().toLowerCase().trim() == "30") {
            last30DaysRecords();
        }
        if($(".order-in-last :selected").val().toLowerCase().trim() == "60") {
            date.setDate(date.getDate() - 60);
            var dateString = date.toISOString().split('T')[0];
            $(".mm-from-date").val(dateString);
            var todayDate = new Date();
            todayDate = todayDate.toISOString().split('T')[0];
            $(".mm-to-date").val(todayDate);
        }
        if($(".order-in-last :selected").val().toLowerCase().trim() == "90") {
            date.setDate(date.getDate() - 90);
            var dateString = date.toISOString().split('T')[0];
            $(".mm-from-date").val(dateString);
            var todayDate = new Date();
            todayDate = todayDate.toISOString().split('T')[0];
            $(".mm-to-date").val(todayDate);
        }

    });
    
    openOrderTable();
    
    $(".mm-search-filter").click(function(){
		
		if($(".order-open :selected").val().toLowerCase().trim() == "enter item number") {
			var enteredInput = $(".order-open-text").val().toLowerCase().trim();
			data["itemNumber"] = enteredInput;
			data["orderNumber"] = "";
			data["poNumber"] = "";
		}
		if($(".order-open :selected").val().toLowerCase().trim() == "enter order number") {
			var enteredInput = $(".order-open-text").val().toLowerCase().trim();
			data["itemNumber"] = "";
			data["orderNumber"] = enteredInput;
			data["poNumber"] = "";
		}
		if($(".order-open :selected").val().toLowerCase().trim() == "enter po number") {
			var enteredInput = $(".order-open-text").val().toLowerCase().trim();
			data["itemNumber"] = "";
			data["orderNumber"] = "";
			data["poNumber"] = enteredInput;
		}
		
		var fromDate = $(".mm-from-date").val();
		var toDate = $(".mm-to-date").val();
		
		data["startDate"] = fromDate;
		data["endDate"] = toDate;
		
		if($("#hold-order-check").is(":checked")) {
			data["holdFlag"] = "Y";
		}
		else {
			data["holdFlag"] = "";
		}
		
		openOrderTable();
	    
		
	});
	
	$('#open_order .img-down-icon').click(function() {

        var tableId = "open_order";

        var rowIndex = $(this).parent().parent().parent().parent().index('#' + tableId + ' tr');

        var thIndex = $(this).parent().parent().parent().index('#' + tableId + ' tr:eq(' + rowIndex + ') th');

        sortTable(parseInt(thIndex), 'asc', tableId);

        var showItem = $(".resultperpage").val();

        var pageNumber = $(".curpage").val();

        pagination(showItem, pageNumber, "open_order", "curpage", "total-value");

    });
    
    $('#open_order .img-up-icon').click(function() {

        var tableId = "open_order";

        var rowIndex = $(this).parent().parent().parent().parent().index('#' + tableId + ' tr');

        var thIndex = $(this).parent().parent().parent().index('#' + tableId + ' tr:eq(' + rowIndex + ') th');

        sortTable(parseInt(thIndex), 'desc', tableId);

        var showItem = $(".resultperpage").val();

        var pageNumber = $(".curpage").val();

        pagination(showItem, pageNumber, "open_order", "curpage", "total-value");

    });
	
	setInterval(function(){
		$(".exp-select-all").change(function(){
			if($(".exp-select-all").is(":checked")) {
				$(".export-check").prop("checked", true);
				$(".export-check").change();
				$(".tableData tr").addClass("exp-active");
				$(".mm-csv-btn").css("pointer-events", "all");
				$(".mm-error-msg").addClass("d-none");
			}
			else{
				$(".tableData tr").removeClass("exp-active");
				$(".export-check").prop("checked", false);
				$(".export-check").change();
			}
		});
		$(".tableData tr").each(function(){
			$(this).click(function(){
				if($(this).children().find(".export-check").is(":checked")) {
					$(this).addClass("exp-active");
					$(".mm-csv-btn").css("pointer-events", "all");
					$(".mm-error-msg").addClass("d-none");
				}
				else {
					$(this).removeClass("exp-active");
				}
			});
		});
		if(!$(".export-check").is(":checked")) {
			$(".mm-csv-btn").css("pointer-events", "none");
		}
		$(".exp-btn-parent").click(function(){
			if(!$(".export-check").is(":checked")) {
				$(".mm-error-msg").removeClass("d-none");
				$(window).scrollTop(0);
				setTimeout(function(){
					$(".mm-error-msg").addClass("d-none");
				},5000);
			}
		});
	},500);
	
    $(".mm-reset").click(function(){
		$(".order-open option").eq(0).prop("selected",true);
		$(".order-open").change();
		$(".order-in-last option").eq(0).prop("selected",true);
		$(".order-in-last").change();
		$(".order-open-text").val("");
		$("#hold-order-check").prop("checked" , false);
		$("#hold-order-check").change();
		$(".mm-error-msg").addClass("d-none");
		data["itemNumber"] = "";
		data["orderNumber"] = "";
		data["poNumber"] = "";
		data["orderInLast"] = "";
		data["startDate"] = "";
		data["endDate"] = "";
	});
	
	$('.bi-chevron-left').click(()=> $(".curpage > option:selected").prev().val() && $(".curpage").val($(".curpage > option:selected").prev().val() ) && $(".curpage").change());

    $('.bi-chevron-right').click(()=>$(".curpage > option:selected").next().val() && $(".curpage").val($(".curpage > option:selected").next().val()) && $(".curpage").change());
    
    var itemNumLink = $(".mm-item-num-link").text();
    
    function openOrderTable() {
		$.ajax({
	        type: "GET",
	        url: "/bin/merclink/openorder",
	        ContentType: 'application/json',
	        async: true,
	        data: {
	            'data': JSON.stringify(data)
	        },
	        beforeSend: function () { 
                $('#loader').removeClass('hidden')
            },
	        success: function (data) {
				if(data.length != 0) {
					var jsondata = JSON.parse(data);
		            jsondata.sort((a,b)=>new Date(b.orderDate[0]) - new Date(a.orderDate[0]));
					$(".tableData tr").remove();
					if(jsondata.length != 0) {
						$(".mm-table-filter").remove();
							$(jsondata).each(function(i) { 
								var orderDate = jsondata[i].orderDate.toString();
								orderDate = orderDate.split("-").reverse().join("-");
								var reqDate = jsondata[i].requestDate.toString();
								reqDate = reqDate.split("-").reverse().join("-");
								var estAvailDate = jsondata[i].estimatedAvailabilityDate.toString();
								estAvailDate = estAvailDate.split("-").reverse().join("-");
			                    $(".tableData").append('<tr class="mm-csv-row"><td><input class="form-check-input export-check" type="checkbox" value="" /></td><td data-bs-toggle="modal" data-bs-target="#product-item" class="oo-item-num"><a href="'+itemNumLink+'?sku='+jsondata[i].itemNumber +'" class="text-decoration-underline"><csv>'+ jsondata[i].itemNumber +'</csv></a></td>'+ 
			                        '<td>'+ jsondata[i].itemDescription +'</td>'+
			                        '<td>'+ jsondata[i].orderNumber +'</td>'+
			                        '<td>'+ orderDate +'</td>'+
			                        '<td>'+ jsondata[i].poNumber +'</td>'+
			                        '<td>'+ jsondata[i].orderedQuantity +'</td>'+ 
			                        '<td>'+ reqDate +'</td>'+ 
			                        '<td>'+ estAvailDate +'</td>'+ 
			                        '<td>'+ jsondata[i].warehouse +'</td>'+ 
			                        '<td>'+ jsondata[i].shipTo +'</td>'+ 
									'<td>'+ jsondata[i].holdFlag +'</td>'+
			                        '</tr>');
			                    pagination(20, 1, "open_order", "curpage", "total-value");
			                    
			                    $(".tableData tr td").each(function(){
									if($(this).text() == "undefined" || $(this).text() == "null") {
										$(this).text("");
										
									}
								});
			            	});
		            }
		            else{
						$(".mm-table-filter").remove();
						$("table").after("<div class='mm-table-filter' style='text-align:center'>No data found</div>");
						$(".total-value").html("0 of 0 Results");
						$(".curpage option").remove();
						$(".curpage").append(`<option value="1" selected="">Page 1 of 1</option>`);
					}
				}
	            if (data.length == 0) {
					$(".mm-table-filter").remove();
					$("table").after("<div class='mm-table-filter' style='text-align:center'>No data found</div>");
				}
	        },
	        complete: function () {
                $('#loader').addClass('hidden')
            },
	    });
	}
	
	$(".mm-csv-btn").click(function() {
        if ($('.export-check:checkbox:checked').length > 0) {
            download_table_as_csv("open_order", separator = ',');
        } else {
            return false;
        }
    });
	
	function download_table_as_csv(open_order, separator = ',') {
        var rows = document.querySelectorAll('table#' + open_order + ' tr');
        var csv = [];
        for (var i = 0; i < rows.length; i++) {
            var row = [],
                row1 = [],
                cols = rows[i].querySelectorAll('td, th');
            for (var j = 0; j < cols.length; j++) {
                if (i >= 1 && cols[0].children.length > 0 && cols[0].children[0].checked) {
                    var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
                    data = data.replace(/"/g, '""');
                    row.push('"' + data + '"');
                } else if (i == 0) {
                    var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
                    data = data.replace(/"/g, '""');
                    row.push('"' + data + '"');

                }

            }

            if (typeof row !== 'undefined' && row.length > 0) {
                csv.push(row.join(separator));
            }

        }

        var csv_string = csv.join('\n');
        var filename = 'export_' + open_order + '_' + new Date().toLocaleDateString() + '.csv';
        var link = document.createElement('a');
        link.style.display = 'none';
        link.setAttribute('target', '_blank');
        link.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv_string));
        link.setAttribute('download', filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
 
});