/*contactus.js*/
$(document).ready(function() {


    $.ajax({
        type: "GET",
        url: "/bin/merclinkcontactUsVerifyUserServlet",
        ContentType: "application/json",
        data: {
            resourcePath: $("#componentPath").val(),
            customerToken: getCookie("customerToken")
        },
        success: function(data) {
            if (data != null || data != undefined) {
                if (data.company != null || data.company != undefined) {
                    let customer_number = getCookie("selectedCustomer");
                    let name = data.company.name;
                    let phone = data.company.legal_address.telephone;
                    $("#CustomerNumber").val(customer_number);
                    $("#AccountName").val(name);
                    $("#Phone").val(phone);
                }
                if (data.customer != null || data.customer != undefined) {
                    let firstname = data.customer.firstname;
                    let lastname = data.customer.lastname;
                    let email = data.customer.email;
                    $("#FirstName").val(firstname);
                    $("#LastName").val(lastname);
                    $("#Email").val(email);
                }
                if (data.department_list != null || data.department_list != undefined) {
                    var option = "<option value='' selected disabled>Select Any Option</option>";

                    data.department_list.forEach(function(element, index) {

                        option += "<option value='" + element.department_name + "'>" + element.department_name + "</option>";

                    });
                    $("#inputState").empty();
                    $("#inputState").append(option);
                }
            }
        },
        error: function(e) {
            console.log(e);
        },
    });
    $("#messagearea").keypress(function(e) {
        $(".inp-msg").addClass("d-none");
        $(".inp-msg").removeClass("show");
    });
    $("#inputState").change(function(e) {

        $(".select-dept").addClass("d-none");

        $(".select-dept").removeClass("show");

    });
    $("#submit-contact").click(function() {

        if ($("#messagearea").val().trim() === "" || $("#inputState").val() === "" || $("#inputState").val() == null) {

            if ($("#messagearea").val().trim() === "") {
                $(".inp-msg").removeClass("d-none");
                $(".inp-msg").addClass("show");
                $(".inp-msg")[0].scrollIntoView();
            }

            if ($("#inputState").val().trim() === "" || $("#inputState").val().trim() == null) {
                $(".select-dept").removeClass("d-none");
                $(".select-dept").addClass("show");
                $(".select-dept")[0].scrollIntoView();
            }

            return;
        }


        var data = {
            "fname": $("#FirstName").val().replace(/\d+/g, ''),
            "lname": $("#LastName").val().replace(/\d+/g, ''),
            "customerno": $("#CustomerNumber").val(),
            "email": $("#Email").val(),
            "companyname": $("#AccountName").val(),
            "dept": $("#inputState").val(),
            "phone": $("#Phone").val(),
            "subject": $("#Subject").val(),
            "message": $("#messagearea").val(),
            "resourcePath": $("#componentPath").val(),
        };

        $.ajax({
            type: "POST",
            url: "/bin/merclinkcontactUsServlet",
            ContentType: "application/json",
            data: {
                data: JSON.stringify(data),
                formtype: "",
            },
            success: function(data) {
                console.log(data);
                if (data != null || data != undefined) {
                    if (
                        data.SubmitContactForm != null ||
                        data.SubmitContactForm != undefined
                    ) {
                        if (
                            data.SubmitContactForm.success_message != null ||
                            data.SubmitContactForm.success_message != undefined
                        ) {
                            $(".success-message-text").html(
                                data.SubmitContactForm.success_message
                            );
                            $(".success-message").removeClass("d-none");
                            $(".success-message").fadeIn(1000);
                            $(".success-message").parent().parent()[0].scrollIntoView();
                            setTimeout(function() {
                                $(".success-message").fadeOut(1000);
                                $("#inputState").parent().parent()[0].scrollIntoView();
                            }, 20000);
                            _satellite.track('Contact us completed', { formName: 'Contact us', departmentName: $("#inputState").val() });
                        }
                    }
                }
            },
            error: function(e) {
                console.log(e);
            },
        });
    });
});