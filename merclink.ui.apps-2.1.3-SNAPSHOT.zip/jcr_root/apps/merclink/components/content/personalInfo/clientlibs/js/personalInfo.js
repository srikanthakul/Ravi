$(document).ready(function() {
    allChildUser();
});

function allChildUser() {
    var data = {
        "componentPath": $('#componentPath').val(),

        "company_number": parseInt($(".showcontactfordropdown").val())
    }
    $.ajax({
        type: "POST",
        url: "/bin/uam/childUserDetailsServlet",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            console.log("Data2 = " + data + " : " + JSON.stringify(data));
            if (data != null) {
                var itemCount = data.GetChildUsers.length;
                var showItem = 20;
                if ((itemCount % showItem) == 0) {
                    totalPage = parseInt(itemCount / showItem);
                } else {
                    totalPage = parseInt(itemCount / showItem) + 1;
                }
                var option = "";
                for (var i = 1; i <= totalPage; i++) {
                    // console.log(i);
                    option += "<option value='" + i + "'>Page " + i + " of " + totalPage + "</option>";
                }
                $(".display-page").append(option);
                if (showItem < itemCount) {
                    var index = "1-" + showItem + " of " + itemCount + " Results";
                } else {
                    var index = "1-" + itemCount + " of " + itemCount + " Results";
                }
                $(".display-page-index").html(index);

                var html = '';

                data.GetChildUsers.forEach(function(element, index) {

                    html += "<tr class='row-" + index + "'><td><input class='form-check-input ms-0' type='checkbox' value='" + element.customerid + "'></td><td>" + element.firstname + "</td><td>" + element.middlename + "</td><td>" + element.lastname + "</td><td>" + element.customerid + "</td><td>" + element.email + "</td><td>" + element.telephone + "</td><td>" + element.start_date + "</td><td>" + element.end_date + "</td><td><a href='#' id='edit('" + element.customerid + "')'>Edit</a></td></tr>";

                });

                console.log(html);

                $("table tbody").empty();

                $("table tbody").append(html);
            }
        },
        error: function(e) {}
    });
}