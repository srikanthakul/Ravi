// login.js
function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function setCookie(cname, cvalue, exdays) {
    const d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    let expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
$(document).ready(function() {
    var pageUrl = window.location.href;
    var arr = pageUrl.split("/");
    var website = arr[0] + "//" + arr[2];
    if (website == "https://qac-merclink.mercurymarine.co.nz" || website == "https://uat-merclink.mercurymarine.co.nz" || website == "https://stg-merclink.mercurymarine.co.nz" || website == "https://prd-merclink.mercurymarine.co.nz" || website == "https://merclink.mercurymarine.co.nz") {
        $("#desktop-header-login-btn").attr("action", "/bin/anzpnzloginservlet");
    }

    setInterval(function() {
        var customerTokenCheck = getCookie("customerToken");
        if (customerTokenCheck == null || customerTokenCheck == "" || customerTokenCheck == "null") {
            setCookie("customerToken", null, 0);
            setCookie("cartId", null, 0);
            setCookie("isDifferentUser", true, 30);
            setCookie("selectedCustomer", null, 0);
            setCookie("customerNumber", null, 0);
            setCookie("customer_id", null, 0);
            setCookie("completeAccountDetails", null, 0);
            setCookie("merclinkCustomerPersonalInfo", null, 0);
            $("button[type='submit']").click();
        }else{
            location.href=$("#homePagePath").val();
        }
    }, 3000);
    var customerToken = getCookie("customerToken");
    if (customerToken == null || customerToken == "" || customerToken == "null") {
        setCookie("customerToken", null, 0);
        setCookie("cartId", null, 0);
        setCookie("isDifferentUser", true, 30);
        setCookie("selectedCustomer", null, 0);
        setCookie("customerNumber", null, 0);
        setCookie("customer_id", null, 0);
        setCookie("completeAccountDetails", null, 0);
        setCookie("merclinkCustomerPersonalInfo", null, 0);
        $("button[type='submit']").click();
    }else{
        location.href=$("#homePagePath").val();
    }
});