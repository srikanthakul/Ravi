// orderSummary.js

let cartDetails = [];

$(document).ready(function() {
	
	$(document).on("click", ".order-product-checkBox", function() {
        if ($('.order-product-checkBox:checked').length == $('.order-product-checkBox').length) {
            $('.select_all_cart_item').prop('checked', true);
        } else {
            $('.select_all_cart_item').prop('checked', false);
        }
    });

    var cartId = getCookie("cartId");
    setTimeout(() => {
        var cartUpdatedAt = getCookie("cartUpdatedAt");
        var cartRunTime = getCookie("cartRunTime");
        if (cartUpdatedAt === cartRunTime) {
            tableDetails(localStorage.getItem("cartDetails") ? JSON.parse(localStorage.getItem("cartDetails")) : []);
        } else {
            cartData(cartId);
        }
    }, 0);

    $(".add-to-wishlist").click(function() {
        var count = 0;
        $('#cartTable tbody input[type=checkbox]:checked').each(function() {
            count = count + 1;
        });
        if (count > 0) {
            getWishlistModal();
        } else {
            respMsgDisplay(202, "Please select at least one product to add to wish list");
        }
    });

    $(".exportCart").click(function() {
        var count = 0;
        $('#cartTable input[type=checkbox]:checked').each(function() {
            count = count + 1;
        });
        if (count > 0) {
            download_table_as_csv("cartTable", separator = ',', "selected");
        } else {
            var rows = document.querySelectorAll('table#cartTable tr');
            if (rows.length < 2) {
                respMsgDisplay(202, "No products to Export");
            } else {
                download_table_as_csv("cartTable", separator = ',', "all");
            }
        }
    });

    $(".update-btn").click(function() {
        var cartArray = [];
        $(".qtyclass").each((index, element) => {
            if ($(element).val() != $(element).data("org")) {
                var itemNumber = $(element).attr("data-item");
                var id = parseInt($(element).data("id"));
                var qty = parseInt($("#qty" + itemNumber).val());
                var cartobj = {
                    "cart_item_id": id.toString(),
                    "quantity": qty.toString()
                }
                cartArray.push(cartobj);
            }
        });
        if (cartArray.length > 0) {
            updateCart(cartId, cartArray, "update");
        }
    });


    $(".remove-yes").click(function() {
        $("#remove-product").modal("hide");
        var cartArray = [];
        var productItems = [];
        var itemSkuArray = [];
        $(".order-product-checkBox").each((index, element) => {
            if ($(element).is(":checked") == true) {
                if ($(element).data('cpq') != "") {
                    $(".order-product-checkBox[data-cpq='" + $(element).data('cpq') + "']").each((index, element) => {
                        if (itemSkuArray.indexOf($(element).val()) == -1) {
                            itemSkuArray.push($(element).val());
                        }
                    });
                } else {
                    itemSkuArray.push($(element).val());
                }
            }
        });

        itemSkuArray.forEach((item) => {
            var element = $(".order-product-checkBox[value='" + item + "']");
            var id = parseInt($(element).val());
            var cartobj = {
                "cart_item_id": id.toString(),
                "quantity": "0"
            }
            cartArray.push(cartobj);
            var itemNumber = $(element).data("item");
            var productItem = {
                "productQuantity": $("#qty" + itemNumber).data("org"),
                "productInfo": {
                    "productID": $(element).data("sku").toString(),
                    "productName": $("#item-des-" + itemNumber).html(),
                    "productConfig": $(element).data("cpq").toString().length > 0 ? $(element).data("cpq") : "website"
                }
            }
            productItems.push(productItem);
        });

        if (cartArray.length > 0) {
            updateCart(cartId, cartArray, "remove", productItems);
        } else {
            $(".error-msg").html("No item(s) were selected to be removed.");
            $(".mm-error-msg").removeClass("d-none");
            $(".mm-error-msg").fadeIn(1000);
            $(".mm-error-msg").parent().parent()[0].scrollIntoView();
            setTimeout(function() {
                $(".mm-error-msg").fadeOut(1000);
            }, 20000);
        }
    });


    $(".display-item").change(function() {
        var showItem = $(this).val();
        var pageNumber = $(".display-page").val();
        $(".display-item").val(showItem);
        $(".display-page").val(pageNumber);
        warning_pagination(showItem, pageNumber, "cartTable", "display-page", "display-page-index");
    });

    $(".display-page").change(function() {
        var showItem = $(".display-item").val();
        var pageNumber = $(this).val();
        $(".display-item").val(showItem);
        $(".display-page").val(pageNumber);
        warning_pagination(showItem, pageNumber, "cartTable", "display-page", "display-page-index");
    });

    $(".proceed-btn").click(function(e) {
        var cartItem = parseInt($(".cart-item-display-number").text());
        if (cartItem === 0) {
            e.preventDefault();
            $(".error-msg").html("Your cart is empty. Please add item(s) to proceed.");
            $(".mm-error-msg").removeClass("d-none");
            window.scrollTo(0, 0);
        }
    });

    // Order Summary Component not changing button text or hiding button if there is no button text
    if ($('.cart-img .btn-basic').text() == '' || $('.cart-img .btn-basic').attr('href') == '#' || !$('.cart-img .btn-basic').attr('href')) {
        $('.cart-img .img-fluid').addClass("w-100");
        $('.cart-img .btn-basic').addClass("d-none");
    };

});

function download_table_as_csv(table_id, separator = ',', download = "") {
    var rows = document.querySelectorAll('table#' + table_id + ' tr');
    var csv = [];
    if (download == "selected") {
        for (var i = 0; i < rows.length; i++) {
            var row = [],
                cols = rows[i].querySelectorAll('td, th');

            for (var j = 0; j < cols.length; j++) {
                if (i >= 1 && cols[0].children.length > 0 && cols[0].children[0].checked) {
                    if (cols[j].children.length > 0) {
                        if (i >= 1 && j == 5) {
                            row.push(cols[j].children[0].children[0].value);
                        } else {
                            row.push("\"" + cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ').replace(/"/g, '""') + "\"");
                        }
                    } else if (j >= 1 && cols[j].children.length > 0) {
                        var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
                        data = "\"" + data.replace(/"/g, '""') + "\"";
                        row.push(data);
                    } else {
                        row.push("\"" + cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ').replace(/"/g, '""') + "\"");
                    }
                } else if (i == 0) {
                    var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
                    data = "\"" + data.replace(/"/g, '""') + "\"";
                    row.push(data);
                }
            }
            csv.push(row.join(separator));
        }
    } else {
        for (var i = 0; i < rows.length; i++) {
            var row = [],
                cols = rows[i].querySelectorAll('td, th');

            for (var j = 0; j < cols.length; j++) {
                if (cols[j].children.length > 0) {
                    if (i >= 1 && j == 5) {
                        row.push(cols[j].children[0].children[0].value);
                    } else {
                        row.push("\"" + cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ').replace(/"/g, '""') + "\"");
                    }
                } else {
                    var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
                    data = "\"" + data.replace(/"/g, '""') + "\"";
                    row.push(data);
                }
            }
            csv.push(row.join(separator));
        }
    }
    var csv_string = csv.join('\n');
    var filename = 'export_' + table_id + '_' + new Date().toLocaleDateString() + '.csv';
    var link = document.createElement('a');
    link.style.display = 'none';
    link.setAttribute('target', '_blank');
    link.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv_string));
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function addtoWishListItem() {
    var c = [];
    $("#cartTable tbody .form-check-input:checked").each(function() {
        var q = parseInt(document.getElementById("qty" + $(this).data("item")).value);
        var wishArray = {
            skuid: "" + $(this).data("sku") + "",
            quantity: q.toString()
        }
        c.push(wishArray);
    });
    AddProductToWishL(c, "addfromcart", "", "available", "").success(function(b) {
        $("#cartTable .form-check-input:checked").each(function() {
            this.checked = !1
        });
        b.alreadyExists ? ($("#add-to-wishlist-modal").modal("hide"),
            $(".mm-error-msg span").html(""),
            $(".mm-error-msg span").text(b.alreadyExists).css("color", "black").fadeIn("slow"),
            $(".mm-error-msg").removeClass("d-none"),
            setTimeout(function() {
                $(".mm-error-msg").fadeOut("slow");
                $(".mm-error-msg").addClass("d-none")
            }, 3E3)) : ($("#add-to-wishlist-modal").modal("hide"),
            $(".mm-success-msg span").html(""),
            $(".mm-success-msg span").append("Item(s) have been added to your wish list : " + b.wishlistname).css("color", "black"),
            $(".mm-success-msg").removeClass("d-none"),
            $(".mm-success-msg").fadeIn("slow"),
            setTimeout(function() {
                $(".mm-success-msg").fadeOut("slow");
                $(".mm-success-msg").addClass("d-none")
            }, 1E4));
        if (b != null && b.wishlisttype != null) {
            var productDetailsArray = [];
            b.cartobj.forEach((element, index) => {
                description = $("#item-des-" + $("input[data-sku='" + element.skuid + "']").data("item")).html();
                var productDetails = {
                    "productQuantity": element.quantity ? element.quantity : 0,
                    "productInfo": {
                        "productID": element.skuid,
                        "productName": description,
                    }
                };
                productDetailsArray.push(productDetails);
            });
            addToWishlist = {};
            addToWishlist['product'] = productDetailsArray;
            if (typeof digitalData != "undefined") {
                digitalData["addtoWishlist"] = addToWishlist;
                _satellite.track('Add to wishlist', { linkName: $(".add-to-wishlist").html() });
            }
        }
    });
}

function respMsgDisplay(statusCode, message, ) {
    if (statusCode == 200) {
        $(".mm-success-msg span").empty();
        $(".mm-success-msg span").text("" + message + "");
        $(".mm-success-msg").removeClass("d-none");
        $(".mm-success-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-success-msg").offset().top
        }, 'slow');
        setTimeout(function() {
            $(".mm-success-msg").fadeOut("slow");
        }, 20000);
    } else if (statusCode == 202) {
        $(".mm-error-msg span").empty();
        $(".mm-error-msg span").text("" + message + "");
        $(".mm-error-msg").removeClass("d-none");
        $(".mm-error-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-error-msg").offset().top
        }, 'slow');
        setTimeout(function() {
            $(".mm-error-msg").fadeOut("slow");
        }, 20000);
    }
}

function updateCart(cartId, cartArray, type, productItems) {
    var data = {
        "componentPath": $("#componentPath").val(),
        cartId: cartId,
        cartobj: cartArray
    }

    $.ajax({
        type: "POST",
        url: "/bin/cart/updateMultipleCartItem",
        ContentType: "application/json",
        dataType: "json",
        data: {
            'data': JSON.stringify(data)
        },
        beforeSend: function() {
            $('#loader').removeClass('hidden')
        },
        complete: function() {
            $('#loader').addClass('hidden')
        },
        success: function(data) {
            if (data != null && data.updateCartItems.cart != null && data.updateCartItems.cart.items != null) {
                $(".cart-item-display-number").html(data.updateCartItems.cart.items.length);
                setCookie("cartCount", data.updateCartItems.cart.items.length, 30);
                if (type === "remove") {
                    $(".success-msg").html("Item(s) were removed from your cart.");
                    $(".mm-success-msg").removeClass("d-none");
                    $(".mm-success-msg").fadeIn(1000);
                    $(".mm-success-msg").parent().parent()[0].scrollIntoView();
                    setTimeout(function() {
                        $(".mm-success-msg").fadeOut(1000);
                    }, 20000);
                    $(".proceed-btn").show();
                    $(".update-btn").hide();

                    if (typeof digitalData !== "undefined") {
                        digitalData.removeCart = {
                            "product": productItems,
                        }
                    }
                    _satellite.track('Remove from cart', { linkName: $("a[data-bs-target='#remove-product']").html() });

                    var removeItem = cartArray.map(element => element.cart_item_id);
                    var filteredItem = cartDetails.filter(element => removeItem.indexOf(element.id) == -1);
                    tableDetails(filteredItem);
                }

                if (type === "update") {
                    cartData(cartId);
                    $(".success-msg").html("Item(s) were updated.");
                    $(".mm-success-msg").removeClass("d-none");
                    $(".mm-success-msg").fadeIn(1000);
                    $(".mm-success-msg").parent().parent()[0].scrollIntoView();
                    setTimeout(function() {
                        $(".mm-success-msg").fadeOut(1000);
                    }, 20000);

                    $(".proceed-btn").show();
                    $(".update-btn").hide();
                }
            }

        },
        error: function(status, errorthrown) {
            console.log("function error" + errorthrown);
        }
    });
}

function cartData(cartId) {
    var data = {
        "componentPath": $("#componentPath").val(),
        "cartId": cartId
    }
    $.ajax({
        type: "POST",
        url: "/bin/cart/cartPageQuery",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(data)
        },
        beforeSend: function() {
            $("body").append("<div id='loader1-cart' class='overlay lds-dual-ring1' ></div>");
        },
        complete: function() {
            $('#loader1-cart').remove();
        },
        success: function(data) {
            if (data != null && data.cart != null) {
                if (data.cart.items) {
                    var cartUpdatedAt = getCookie("cartUpdatedAt");
                    setCookie("cartRunTime", cartUpdatedAt, 1);
                    tableDetails(data.cart.items);
                }
            }
        },
        error: function(e) {}
    });
}

function tableDetails(data) {
    cartDetails = data;
    $(".itemCount").html(data.length);
    if (data.length > 0) {
        localStorage.setItem("cartDetails", JSON.stringify(data));
        var productPrice = 0;
        var tableData = "";
        $(".display-page").prop("disabled", false);
        $(".display-item").prop("disabled", false);

        var plpPath = $("#pdpPath").val() != null & $("#pdpPath").val() != "" ? $("#pdpPath").val() : "#";
        var productAnalyseArray = [];
        data.forEach((element, index) => {
            var id = element.id
            var name = element.product.name;
            var sku = element.product.sku;
            var cpqSession = element.cpq_session ? element.cpq_session : "";

            var quantity = parseInt(element.quantity);
            if (element.item_attributes.length > 0) {
                var availability = element.item_attributes[0].availability ? element.item_attributes[0].availability : "";
                var availability_date = element.item_attributes[0].availability_date != null ? element.item_attributes[0].availability_date : "";
                var customer_price = JSON.parse(element.item_attributes[0].customer_price);
                var backorder_qty = element.item_attributes[0].backorder_qty;
            }


            var warehouse = 0;
            var availhtml = "";
            var dataAvail = "HW-0,";
            availability.split(",").forEach(function(element, index) {
                if (element.split("-")[0] === "HW") {
                    warehouse = parseInt(element.split("-")[1]);

                    if (warehouse >= quantity) {
                        dataAvail = "HW-" + quantity + ",";
                        availhtml += "HW-" + quantity + ",";
                    } else {
                        dataAvail = "HW-" + warehouse + ",";
                        availhtml += "HW-" + warehouse + ",";
                    }

                } else if (element.split("-")[0] === "BO") {
                    availhtml += "BO-" + parseInt(element.split("-")[1]) + ",";
                }
            });


            var masterpartlowestsellinguomqty = element.product.product_data[0].masterpartlowestsellinguomqty ? parseInt(element.product.product_data[0].masterpartlowestsellinguomqty) : 0;
            var weight_unit = element.product.product_data[0].weight_unit != null ? element.product.product_data[0].weight_unit : "";
            var weight = element.product.product_data[0].weight != null ? parseFloat(parseFloat(element.product.product_data[0].weight) / 1000).toFixed(4) + " " + "kg" : "";
            var validate = "this.value=='' ? this.value = " + masterpartlowestsellinguomqty + " : '' ; this.value % " + masterpartlowestsellinguomqty + " || this.value == 0  ?  this.value = (parseInt(this.value)+(" + masterpartlowestsellinguomqty + "-(parseInt(this.value) % " + masterpartlowestsellinguomqty + " )))  : '' ";

            var warning_message = element.product.product_data[0].warning_message != null ? element.product.product_data[0].warning_message : "";
            var prop65_msg = element.product.masterpartprop65code != null ? element.product.masterpartprop65code : "";
			var propMsg_avl = "";
			if(prop65_msg.length > 0){
				propMsg_avl = '<i class="me-1"> <img src="/content/dam/merclink/images/warning.svg" class="warning-img"> </i> <span><strong>WARNING</strong>: '+prop65_msg+' - <a href="www.P65Warnings.ca.gov" target="_blank">www.P65Warnings.ca.gov</a></span>';
				}
            var hazous_flag = '<tr class="warn-border">' +
                '<td></td>' +
                '<td></td>' +
                '<td></td>' +
                '<td colspan="5" class="small">' +
                '</td>' +
                '</tr>';
            if (warning_message.length > 0 && warning_message === "1") {
                hazous_flag = '<tr class="warn-border">' +
                    '<td></td>' +
                    '<td></td>' +
                    '<td></td>' +
                    '<td colspan="5" class="small">' +
                    '<div class="d-flex align-items-center">' +
                    '<i class="me-1"> <img src="/content/dam/merclink/images/warning.svg" class="warning-img"> </i> <span> Hazardous goods. AIR Freight prohibited. </span>' +
					'</div>' +
					'<div class="d-flex align-items-center">' +
                    ''+propMsg_avl+''+
                    '</div>' +
                    '</td>' +
                    '</tr>';
            }
            productPrice += parseFloat(quantity * parseFloat(customer_price.selling_price));

            var productAnalyse = {
                "productQuantity": quantity,
                "productInfo": {
                    "productID": sku,
                    "productName": name,
                    "productConfig": element.cpq_session ? element.cpq_session : "website",
                }
            };
            productAnalyseArray.push(productAnalyse);
            var qtyField = "<span class='px-3'>" + quantity + "</span>";
            if (cpqSession.length < 1) {
                qtyField = '<input type="number" name="quantity" id="qty' + index + '" data-item="' + index + '" data-id="' + id + '" data-org="' + quantity + '"  class="form-control input-number qtyclass" value="' + quantity + '" min="' + masterpartlowestsellinguomqty + '"  step="' + masterpartlowestsellinguomqty + '" data-warehouse = "' + warehouse + '"  onkeypress="return event.charCode >= 48"  onfocusout="' + validate + '"/>';
            }


            tableData += '<tr scope="row">' +
                '<td><input class="form-check-input order-product-checkBox" data-cpq="' + cpqSession + '"  data-item="' + index + '" data-sku="' + sku + '" type="checkbox" value="' + id + '" /></td>' +
                '<td></td>' +
                '<td><a href="' + plpPath + '?sku=' + sku + '"><span class="text-decoration-underline">' + sku + '</span></a></td>' +
                '<td><span id="item-des-' + index + '">' + name + '</td>' +
                '<td>' + cpqSession + '</td>' +
                '<td>' + weight + '</td>' +
                '<td>' +
                '<div class="input-group mm-quantity">' +
                qtyField +
                '<div class="up-down-icon">' +
                '<span class="input-group-btn">' +
                '<i class="bi bi-caret-up-fill"></i>' +
                '</span>' +
                '<span class="input-group-btn">' +
                '<i class="bi bi-caret-down-fill"></i>' +
                '</span>' +
                '</div>' +
                '</div>' +
                '</td>' +
                '<td class="position-relative ">' +
                '<strong data-item="' + index + '" id="avail' + index + '" data-avail="' + dataAvail + '">' + availhtml.slice(0, -1) + '</strong>' +
                '</td>' +
                '<td class="text-end">$<span id="unit-price-' + index + '">' + currencyFormat(parseFloat(customer_price.selling_price).toFixed(2)) + '<span></td>' +
                '<td class="text-end" rowspan="2">' +
                ' $<span class="itemTotal" id="total-price-' + index + '">' + currencyFormat(parseFloat(quantity * parseFloat(customer_price.selling_price)).toFixed(2)) + "</span>" +
                '</td>' +
                '</tr>' + hazous_flag;
        });
        $("table tbody").empty();
        $("table tbody").append(tableData);
        $(".product-total").html("$" + currencyFormat(productPrice.toFixed(2)));
        $(".grandTotal").html("$" + currencyFormat(productPrice.toFixed(2)));

        warning_pagination(20, 1, "cartTable", "display-page", "display-page-index");

        $(".qtyclass").change(function() {
            var oneCheck = false;
            $(".qtyclass").each((index, element) => {
                if ($(element).val() != $(element).data("org")) {
                    oneCheck = true;
                    return;
                }
            });
            if (oneCheck) {
                $(".proceed-btn").hide();
                $(".update-btn").show();
            } else {
                $(".proceed-btn").show();
                $(".update-btn").hide();
            }

            var qtyId = $(this).prop("id");
            var qtyVal = parseInt($(this).val());
            var minValue = parseInt($(this).attr("min").replace(/^\D+/g, ''));
            var warehouse = parseInt($(this).attr("data-warehouse").replace(/^\D+/g, ''));
            var itemNumber = parseInt(qtyId.replace(/^\D+/g, ''));
            var calValue = qtyVal % minValue || qtyVal == 0 ? qtyVal = (parseInt(qtyVal) + (minValue - (parseInt(qtyVal) % minValue))) : qtyVal;
            if (qtyVal > 0) {
                var availData = "";
                if (warehouse >= qtyVal) {
                    availData += "HW-" + qtyVal + ",";
                    $("#avail" + itemNumber).attr("data-avail", availData)
                } else {
                    if ($("#avail" + itemNumber).attr("data-avail") != "HW-0,") {
                        availData += "HW-" + warehouse + ",";
                        $("#avail" + itemNumber).attr("data-avail", availData)
                    }
                }

                if (qtyVal > warehouse && calValue > warehouse) {
                    availData += "BO-" + parseInt(calValue - warehouse).toString() + ",";
                }
                $("#avail" + itemNumber).html(availData.slice(0, -1));
            } else {
                $("#avail" + itemNumber).attr("data-avail", "HW-0,")
                $("#avail" + itemNumber).html("");
            }
        });

        if (typeof digitalData !== "undefined") {
            digitalData.cart = {
                "item": productAnalyseArray,
            }
        }

        _satellite.track('view cart');
    } else {
        $(".display-page-index").html("0-0 of 0 Results");
        $(".display-page").prop("disabled", true);
        $(".display-item").prop("disabled", true);
        $(".product-total").html("$0.00");
        $(".grandTotal").html("$0.00");
        $("table tbody").empty();
        $("table tbody").append("<tr><td colspan='9'><div class='text-center'><img src='/content/dam/merclink/images/warning.svg' width='25' > <span >Cart is Empty !!</span></div></td></tr>");
    }
}