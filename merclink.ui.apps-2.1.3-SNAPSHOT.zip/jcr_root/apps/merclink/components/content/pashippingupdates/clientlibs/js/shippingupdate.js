/*shipping updates.js */
/*$(document).ready(function(){alert("hello");}); */