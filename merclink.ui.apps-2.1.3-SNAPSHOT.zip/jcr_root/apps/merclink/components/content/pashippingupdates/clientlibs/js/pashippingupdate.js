 $(document).ready(function() {
     var url_string = window.location.href;
     var url = new URL(url_string);
     var id = "newsItem-" + url.searchParams.get("id");
     $("." + id).removeClass("d-none");
     $(".news-date").each(function() {
         var str = $(this).text();
         if (str != '' || str != undefined) {
             if (str.indexOf('T') != -1) {
                 var date = str.split("T")[0].split("-");
                 $(this).text(date[2] + "-" + date[1] + "-" + date[0]);
             }
         }
     });
     digitalData.page.pageInfo["pageName"] = pageNameVal + ":" + $("." + id + " h4 label").text().toLowerCase();
 });