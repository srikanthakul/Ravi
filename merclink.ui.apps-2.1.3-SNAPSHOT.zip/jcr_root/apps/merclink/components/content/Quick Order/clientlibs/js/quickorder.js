// QuickOrder.Js

$(document).ready(function() {
    var tableData = ""
    for (var i = 1; i < 5; i++) {
        tableData += '<tr>' +
            '<th scope="row "><input class="w-100 " type="text " name=" " id="ss' + i + '" readonly /></th>' +
            '<td><input class="w-100 insertItem" type="text" data-row="' + i + '" name="" id="item' + i + '"></td>' +
            '<td><input class="w-100 " type="number" name=" " id="qty' + i + '" min="1"></td>' +
            '<td><input class="w-100 " type="text " name=" " id="des' + i + '" readonly /></td>' +
            '<td><input class="w-100 " type="text " name=" " id="avail' + i + '" readonly /></td>' +
            '</tr>' +
            '<tr class="d-none itemHelpRow' + i + '">' +
            '<th scope="row " class="tableHelpText"></th>' +
            '<td colspan="3" class="tableHelpText"><span class="itemHelpText' + i + '">Order from Seaway 425-412-4006</span></td>' +
            '<td class="tableHelpText"></td>' +
            '<td class="tableHelpText"></td>' +
            '</tr>';
    }
    // console.log(tableData);
    $(".homepage_quickorder_table").append(tableData);

    $(".insertItem").change(function() {
        var rowNumber = $(this).attr("data-row");
        $(".itemHelpRow" + rowNumber).removeClass("d-none");
        $(".itemHelpRow" + rowNumber).addClass("d-none");
        if ($("#item" + rowNumber).val() != "") {
            checkItem(rowNumber);
        }
    });
});

function checkItem(rowNumber) {
    var data = {
        "componentPath": $('#resourcePath').val(),
        "sku": $("#item" + rowNumber).val(),
        "companyNumber": getCookie("selectedCustomer"),
        // "companyNumber": "300827"
    }
    $.ajax({
        type: "POST",
        url: "/bin/quickOrderSingleItem",
        ContentType: "application/json",
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            console.log("data==>");
            console.log(data);
            if (data != null) {

                if (data.quickOrderSingleItem) {
                    console.log("Inside If");
                    $(".itemHelpRow" + rowNumber).removeClass("d-none");
                    var message = data.quickOrderSingleItem;
                    $(".itemHelpText" + rowNumber).html(message);
                    console.log(message);
                } else {
                    var item = data.quickOrderProductsAnzp.items;
                    if (item.length > 0) {
                        var availability = item[0].availability;
                        var description = item[0].description;
                        var estimated_availability_date = item[0].estimated_availability_date;
                        var id = item[0].id;
                        var item_number = item[0].item_number;
                        var masterpartlowestsellinguomqty = item[0].masterpartlowestsellinguomqty;
                        // var replacement_item = item[0].replacement_item;
                        // var seaway_message = item[0].seaway_message;
                        var sku = item[0].sku;
                        var stock_status = item[0].stock_status;
                        var superseeded = item[0].ss_item_number;
                        var warehouse_total = item[0].warehouse_total;

                        $("#ss" + rowNumber).val(superseeded);
                        // $("#item" + rowNumber).val(item_number);
                        $("#qty" + rowNumber).val(parseInt(masterpartlowestsellinguomqty));
                        $("#qty" + rowNumber).attr("min", parseInt(masterpartlowestsellinguomqty));
                        $("#des" + rowNumber).val(description);
                        $("#avail" + rowNumber).val(availability);
                    } else {
                        $(".itemHelpRow" + rowNumber).removeClass("d-none");
                        var message = data.quickOrderProducts.user_errors[0].message;
                        $(".itemHelpText" + rowNumber).html(message);
                        console.log(message);
                    }
                }
            }
        }
    });
}