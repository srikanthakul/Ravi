$(document).ready(function() {
    $(".news-date").each(function() {
        var str = $(this).text();
        if (str != '' || str != undefined) {
            if (str.indexOf('T') != -1) {
                var date = str.split("T")[0].split("-");
                $(this).text(date[2] + "-" + date[1] + "-" + date[0]);
            }
        }
    });
});