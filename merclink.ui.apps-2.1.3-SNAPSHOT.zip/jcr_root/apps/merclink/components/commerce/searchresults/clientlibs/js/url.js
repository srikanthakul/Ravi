"use strict"; 
use(function(){
return this.value2+"."+this.value1+".html";
});