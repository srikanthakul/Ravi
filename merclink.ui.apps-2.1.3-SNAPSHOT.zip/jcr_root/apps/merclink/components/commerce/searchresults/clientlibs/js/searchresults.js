var isApplyfilter = false;
var isApplySort = false;
var filterArrayObjectFacet = []
$(document).ready(function() {
	var key = []
	var currentpageurl = window.location.href;
	if(currentpageurl.indexOf("?") == -1 || (!(currentpageurl.indexOf("?") == -1) && currentpageurl.endsWith("?"))) {} else if(!(currentpageurl.indexOf("?") == -1) && currentpageurl.includes("?search=") && !(currentpageurl.indexOf("?") == -1) && !currentpageurl.includes("blogs")) {
		var url = window.location.href.slice(window.location.href.indexOf('?') + 1);
		key = url.split("=");
		var searchValue = key[1];
		if(searchValue.includes("%20")) {
			searchValue = searchValue.replaceAll("%20", " ");
		} else if(searchValue.includes("%2520")) {
			searchValue = searchValue.replaceAll("%2520", " ");
		} else if(searchValue.includes("%22")) {
			searchValue = searchValue.replaceAll("%22", " ");
		}
		$('.search').val(searchValue);
		$('.contentsearch-list-heading').html("<h2>Results for \"" + searchValue + "\"</h2>");
		callproducts();
	}
	$("#filter-sidebar").click((e) => {
			e.target.getAttribute("data-category-attrcode") ? e.target.checked ? filterArrayObjectFacet.find((item) => {
				return item.attrCode == e.target.getAttribute("data-category-attrCode")
			}) ? filterArrayObjectFacet = filterArrayObjectFacet.map((x) => {
				return x.attrCode == e.target.getAttribute("data-category-attrCode") ? {
					attrCode: x.attrCode,
					facetLabel: x.facetLabel,
					facetList: [...x.facetList, {
						'attrCode': e.target.getAttribute("data-options-attrCode"),
						'attrLabel': e.target.getAttribute("data-options-attrLabel")
					}]
				} : x
			}) : filterArrayObjectFacet = [...filterArrayObjectFacet, {
				'attrCode': e.target.getAttribute("data-category-attrCode"),
				'facetLabel': e.target.getAttribute("data-category-facetLabel"),
				'facetList': [{
					'attrCode': e.target.getAttribute("data-options-attrCode"),
					'attrLabel': e.target.getAttribute("data-options-attrLabel")
				}]
			}] : filterArrayObjectFacet = filterArrayObjectFacet.map((item) => {
				return item.attrCode == e.target.getAttribute("data-category-attrCode") ? {
					attrCode: item.attrCode,
					facetLabel: item.facetLabel,
					facetList: item.facetList.filter((a) => a.attrCode != e.target.getAttribute("data-options-attrCode"))
				} : item
			}) : ''
		})
		//Function for List View
	$(document).on("click", ".listview", function() {
		$(".gridview").removeClass("d-none");
		$(".productsearch-grid-display-control").removeClass("row-cols-md-4");
		$(".productsearch-card-main-container").addClass("productsearch-card-main-container__removethisforlistview");
		$(".productsearch-grid-display-control").addClass("productsearch-list-display-control");
		$(".listview").addClass("d-none");
		// for switch list view
		if($(".productsearch-grid-display-control").find(".productsearch-list-display-control")) {
			let product_list_view = $(".productsearch-card-main-container__item2");
			$('.product-code').each(function(i) {
				product_list_view.eq(i).prepend($(this));
			});
			$('.card-text').each(function(i) {
				product_list_view.eq(i).append($(this));
			});
		}
	});
	$(document).on("click", ".gridview", function() {
		$(".listview").removeClass("d-none");
		$(".productsearch-grid-display-control").addClass("row-cols-md-4");
		$(".productsearch-card-main-container").removeClass("productsearch-card-main-container__removethisforlistview");
		$(".productsearch-grid-display-control").removeClass("productsearch-list-display-control");
		$(".gridview").addClass("d-none");
		// for switch grid view reverse
		if($(".productsearch-grid-display-control").not(".productsearch-list-display-control")) {
			let product_grid_view = $(".card");
			$('.product-code').each(function(i) {
				product_grid_view.eq(i).prepend($(this));
			});
			$('.card-text').each(function(i) {
				product_grid_view.eq(i).append($(this));
			});
		}
	});
	//Add to Wishlist functionality
	$(".search-add-to-wish-list").click(function() {
	var count = 0;
	$("#card-display-section .form-check-input:checked").each(function() {
		count++;
	});
	if(count == 0) {
		respMsgDisplay(202, "Please select at least one product to add to wishlist");
	}
	if(count > 0) {
		getWishlistModal();
	}
});


	//Add to Cart functionality
	$(".addtocart").click(function() {
		$(".mm-error-msg").addClass("d-none");
		let productArray = []
		$("#card-display-section .form-check-input:checked").each(function() {
			let quantity = document.getElementById('qty-' + $(this).data('itemid')).value
			productArray = [...productArray, {
				skuid: $(this).data('itemid').toString(),
				quantity
			}]
		});
		if(productArray.length != 0) {
			var data = {
				"componentPath": $('#resourcePath').val(),
				cartId: getCookie("cartId"),
				cartobj: productArray
			}
			$.ajax({
				type: "POST",
				url: "/bin/cart/addToCartQuery",
				ContentType: "application/json",
				dataType: "json",
				data: {
					'data': JSON.stringify(data)
				},
				beforeSend: function() {
					$("#loader").removeClass("hidden");
					$('body').addClass("backDisabled");
				},
				success: function(data) {
					if (data && data.addProductsToCart) {
                        if (data.addProductsToCart.cart && data.addProductsToCart.cart.items && data.addProductsToCart.cart.items.length > 0) {
                            $(".cart-item-display-number").html(data.addProductsToCart.cart.items.length);
                            setCookie("cartCount", data.addProductsToCart.cart.items.length, 30);
        
                            var sendSkuId = productArray.map(element => element.skuid);
                            var matchedCartItemArray = data.addProductsToCart.cart.items.filter(element => sendSkuId.indexOf(element.product.sku) != -1);
                            var matchedCartItem = matchedCartItemArray.map(element => element.product.sku);
                            if (matchedCartItem.length > 0) {
                                var msg = 'Item(s) have been added/updated to Cart: ' + matchedCartItem.join().toString();
                                respMsgDisplay(200, msg);
                                var productDetailsArray = [];
                                matchedCartItemArray.forEach((element, indexe) => {
                                    var quantityFilter = productArray.filter(cartElement => cartElement.skuid == element.product.sku);
                                    var productDetails = {
                                        "productQuantity": quantityFilter.length > 0 ? quantityFilter[0].quantity : 0,
                                        "productInfo": {
                                            "productID": element.product.sku,
                                            "productName": element.product.name,
                                        }
                                    };
                                    productDetailsArray.push(productDetails);
                                });
                                console.log("Cart Array" +productDetailsArray);
                                if (typeof digitalData !== "undefined") {
                                    digitalData.addtoCart = {
                                        "product": productDetailsArray,
                                    }
                                }
                                _satellite.track('Add to cart', { linkName: $(".addtocart").html() });
                            }
                        }
                        var errMsg = "";
                        if (data.addProductsToCart.cart && data.addProductsToCart.cart.erp_errors && data.addProductsToCart.cart.erp_errors.length > 0) {
                            data.addProductsToCart.cart.erp_errors.forEach((element) => {
                                errMsg += element.message + ", "
                            });
                        }
        
                        if (data.addProductsToCart.user_errors != null && data.addProductsToCart.user_errors.length > 0) {
                            data.addProductsToCart.user_errors.forEach((element) => {
                                var msgDesc = element.message;
								if(msgDesc.includes("This product don't have price")){
									errMsg += msgDesc.replace("This product don't have price","This product is unable to be priced and can not be ordered") + ", "
								}else{
									errMsg += element.message + ", "
								}
                            });
                        }
        
                        if (errMsg.length > 0) {
                            respMsgDisplay(202, errMsg);
                        }
                    } else if (data && data.createCartId) {
                        respMsgDisplay(202, data.createCartId);
                    }
				},
				complete: function() {
					$("#loader").addClass("hidden");
					$('body').removeClass("backDisabled");
				},
				error: function(status, errorthrown) {
					var msg = 'Something Went wrong. Please try again';
					respMsgDisplay(202, msg);
				}
			});
		} else {
			respMsgDisplay(202, "Please select at least one product to add to cart");
		}
	});
	$("#product-search-tab").click(function() {
		callproducts();
	});
	$(".pagesize").change(function(e) {
		isApplySort = false;
		isApplyfilter = true;
		$(".pagesize").val(e.target.value);
		callproducts();
	});
	$(".mySelect").change(function(e) {
		isApplySort = false;
		isApplyfilter = false;
		$(".mySelect").val(e.target.value);
		callproducts();
	});
	//Sort By function
	$(".sort").change(function(e) {
		isApplySort = true;
		$(".sort").val(e.target.value);
		sortval = $(this).val();
		$(".accordion").empty();
		callproducts();
	});
	$('.bi-chevron-left').click(() => $(".mySelect > option:selected").prev().val() && $(".mySelect").val($(".mySelect > option:selected").prev().val()) && callproducts())
	$('.bi-chevron-right').click(() => $(".mySelect > option:selected").next().val() && $(".mySelect").val($(".mySelect > option:selected").next().val()) && callproducts())

	function showLoader(className) {
		$("#loader").removeClass("hidden");
		$('.' + className).addClass("backDisabled");
	}

	function hideLoader(className) {
		$("#loader").addClass("hidden");
		$('.' + className).removeClass("backDisabled");
	}

	// Content Search Implementation
	$('#content-search-tab').click(function() {
		callContent();
		$(".contentsearch-grid-display-control").hide();
		$(".contentlist").show();
	});
	$(".contentopt").change(function(e) {
		$(".contentopt").val(e.target.value);
		callContent();
	});
	$(".contentselect").change(function(e) {
		$(".contentselect").val(e.target.value);
		callContent();
	});
	$('#applyfiltersearch').on('click', function() {
		isApplyfilter = true;
		callproducts();
	});
});


function addtoWishListItem() {
		let productArray = []
		$("#card-display-section .form-check-input:checked").each(function() {
			let quantity = document.getElementById('qty-' + $(this).data('itemid')).value
			productArray = [...productArray, {
				skuid: $(this).data('itemid').toString(),
				quantity
			}]
		});   
     
	var itemStatus = "available";   
	var packageQuantity = "";    
	var addingType = "addfromcart";   
	var productQty = "";
	var description="";
	let addToWLResponse = AddProductToWishL(productArray, addingType, productQty, itemStatus, packageQuantity);
	addToWLResponse.success(function(data) {
		$("#card-display-section .form-check-input:checked").each(function() {
			this.checked = false
		});
		if(data.alreadyExists) {
			$("#add-to-wishlist-modal").modal("hide");
			respMsgDisplay(202, data.alreadyExists);
		} else {
			$("#add-to-wishlist-modal").modal("hide");
			respMsgDisplay(200, "Item(s) have been added to your wish list : " + data["wishlistname"] + "");
		}
		
		if(data!=null && data.wishlisttype != null){

                var productDetailsArray = [];

                data.cartobj.forEach((element, index) => {

                    description = $("#desc" + element.skuid).html();

                    var productDetails = {

                        "productQuantity": element.quantity > 0 ? element.quantity : 0,

                        "productInfo": {

                            "productID": element.skuid,

                            "productName": description,

                        }

                    };                   

                    productDetailsArray.push(productDetails);


                });    

                addToWishlist = {};

                addToWishlist['product'] = productDetailsArray;

                digitalData["addtoWishlist"] = addToWishlist;

                _satellite.track('Add to wishlist', { linkName: $(".search-add-to-wish-list").html() });

            }
	}); 
}

function respMsgDisplay(statusCode, message) {
		if(statusCode == 200) {
			$(".mm-success-msg span").empty();
			$(".mm-success-msg span").text("" + message + "");    
			$(".mm-success-msg").removeClass("d-none");    
			$(".mm-success-msg").fadeIn("slow");
			$('html,body').animate({
				scrollTop: $(".mm-success-msg").offset().top
			}, 'slow');    
			setTimeout(function() {      
				$(".mm-success-msg").fadeOut("slow");    
			}, 3000);
		} else if(statusCode == 202) {
			$(".mm-error-msg span").empty();
			$(".mm-error-msg span").text("" + message + "");    
			$(".mm-error-msg").removeClass("d-none");
			$(".mm-error-msg").fadeIn("slow");
			$('html,body').animate({
				scrollTop: $(".mm-error-msg").offset().top
			}, 'slow');    
			setTimeout(function() {      
				$(".mm-error-msg").fadeOut("slow");    
			}, 3000);
		}
}



function callproducts() {

	var resultscount = 0;
	var filterArray = "";
	var searchValue = $('.search').val().trim();
	if(searchValue.includes("%20")) {
		searchValue = searchValue.replaceAll("%20", " ");
	} else if(searchValue.includes("%2520")) {
		searchValue = searchValue.replaceAll("%2520", " ");
	}
	var pagesize = $(".pagesize option:selected").val();
	var pagestring;
	if(isApplyfilter) {
		pagestring = 1;
		filterArray = convertFilterArray(filterArrayObjectFacet);
	} else {
		pagestring = $(".mySelect option:selected").val();
	}
	if(pagestring ==undefined){
     pagestring = 1;
    }
	console.log("PageString" + pagestring);
	var data1 = {
		"keyword": searchValue.trim(),
		"path": $('#resourcePath').val(),
		"type": "product",
		"pagesize": pagesize,
		"page": pagestring
	}
	if(filterArray.length > 0) {
		data1["type"] = "productfilters";
		data1["filters"] = filterArray;
	}
	if(isApplySort) {
		if(sortval) {
			data1["sort"] = sortval.split(" ")[0];
			data1["sortdirection"] = sortval.split(" ")[1];
		}
	}
	var jsonData = JSON.stringify(data1);
	$.ajax({
		type: "POST",
		url: "/ecomm/mm.searchResultsServlet.json",
		ContentType: 'application/json',
		data: {
			'data': jsonData
		},
		beforeSend: function() {
			$("#loader").removeClass("hidden");
			$('body').addClass("backDisabled");
		},
		success: function(responsedata) {
									  
			if(responsedata != null && responsedata.data != null && responsedata.data.products != null) {
				$('.allid').val(responsedata.data.products.totalCount);
				$('.showresults').html("");
				$(".productsearch-grid-display-control").html("");
				$(".accordion").html("");
				var products = responsedata.data.products;
				resultscount = products.totalCount;

			      //Analytics code changes.
				   let search_val = searchValue.trim();
				   
                  if (resultscount == 0){
                   _satellite.track('Search', {searchTerms: search_val , result: "0"});
                    }else{
                    _satellite.track('Search', {searchTerms: search_val , result: resultscount});
                    }
                //Analytics code changes.

				var sizing = $(".pagesize option:selected").val();
				if(resultscount == 0){
                  sizing =0;
                }
				var pageHit;
				if(isApplyfilter) {
					pageHit = 1;
				} else {
					pageHit = $(".mySelect option:selected").val();
				}
				if(pageHit == undefined) {
					pageHit = 1;
				}

				if(pageHit != null && sizing != null) {
					var pageStart = (parseInt(sizing) * (parseInt(pageHit) - 1)) + 1;
					var pageEnd;
					if(resultscount <= sizing) {
						pageEnd = resultscount;
					} else {
						pageEnd = parseInt(sizing) + (pageStart - 1) > resultscount ? resultscount : parseInt(sizing) + (pageStart - 1);
					}
					$('.showresults').append(pageStart + ' - ' + pageEnd + " of " + resultscount + " Results");
				}
				if(resultscount == sizing) {
					var temp = 1;
				} else {
					var temp = resultscount / sizing == 0 ? (Math.floor(resultscount / sizing)) : (Math.floor(resultscount / sizing) + 1);
				}

				$('.mySelect').html("");
				var i = 1;
				while(i <= temp) {
					var text;
					text = "Page " + i + ' of ' + temp;
					$('.mySelect').append('<option value="' + i + '">' + text + '</option>');
					i++;
				}
				$('.mySelect').val(pageHit);

$('.product-filter-select').empty();
				filterArrayObjectFacet.sort((a,b)=> b.facetList.length - a.facetList.length).forEach((item, countParrent) => {
						item.facetList.forEach((facetItem, countChild) => {
							if(countChild == 0) {
								countParrent == 0 ? $('.product-filter-select').append(`<div class="clear-all pe-2"><a href="javascript:void(0)">Clear All</a> </div>`) : ''
								$('.product-filter-select').append(`<ul class="list-group list-group-horizontal rounded-0 flex-wrap">
                                                                <li id="filter-${item.attrCode}" class="list-group-item border-0 bg-transparent p-2">
                                                                    <label>${item.facetLabel}</label>
                                                                    <span class="p-2 m-1 d-inline-block">${facetItem.attrLabel}<img class='ms-2' src="/content/dam/merclink/cross-image-filter.svg" data-category-attrCode="${item.attrCode}" data-category-facetLabel="${item.facetLabel}" data-options-attrCode="${facetItem.attrCode}"  data-options-attrLabel="${facetItem.attrLabel}" ></span>
                                                                </li>                          
                                                             </ul>`)
							} else {
								$(`#filter-${item.attrCode}`).append(`<span class="p-2 m-1 d-inline-block">${facetItem.attrLabel}<img class='ms-2' src="/content/dam/merclink/cross-image-filter.svg" data-category-attrCode="${item.attrCode}" data-category-facetLabel="${item.facetLabel}" data-options-attrCode="${facetItem.attrCode}"  data-options-attrLabel="${facetItem.attrLabel}" ></span>`)
							}
						})
					})
					//registring event
				$('.product-filter-select img').click((e) => {
					filterArrayObjectFacet = filterArrayObjectFacet.map((item) => {
						return item.attrCode == e.target.getAttribute("data-category-attrCode") ? {
							attrCode: item.attrCode,
							facetLabel: item.facetLabel,
							facetList: item.facetList.filter((a) => a.attrCode != e.target.getAttribute("data-options-attrCode"))
						} : item
					})
					isApplyfilter = true;
					callproducts();
				})
				$(".clear-all").click(function() {
					isApplyfilter = false;
					filterArrayObjectFacet = [];
					callproducts();
				});
				
				if (products.totalCount == 0 || products.items == ""){

					$(".accordion").html("");
					$(".productsearch-grid-display-control").append("<h5 align='center'>No Product Found</h5>");
				 }
                else{
				$.each(products.aggregations.filter((item)=>item.attributeCode != "price" && item.attributeCode != "category_uid"), function(key, item) {
					$(".accordion").append(`
                                    <div class="accordion-item border-start-0 border-end-0 border-top border-bottom bg-transparent">
                                    <h2 class="accordion-header border-start-0 border-end-0 border-top-0 " id=${item.attributeCode}>
                                    <button class="accordion-button px-0 bg-transparent" type="button" data-bs-toggle="collapse" data-bs-target="#render-${item.attributeCode}" aria-expanded="true" aria-controls="horsepower">
                                        ${item.label}
                                          </button>
                                    </h2>
                                    <div id="render-${item.attributeCode}" class="accordion-collapse collapse show" aria-labelledby="${item.attributeCode}" data-bs-parent="#filter-sidebar">
                                        <div class="accordion-body  pt-0">
                                        `)
					$.each(item.options, function(key, item1) {
						$(`#render-${item.attributeCode} > .accordion-body:first-child`).append(`

                                                    <div class="form-check form-check ps-0 my-3 ${key > 5 ? 'mm-filter-toggle-view d-none' : ''}">                                                        
                                                        <input class="form-check-input mt-0  ms-0 " type="checkbox" id="${item1.value}" value="option1"  data-category-attrCode="${item.attributeCode}" data-category-facetLabel="${item.label}" data-options-attrCode="${item1.value}"  data-options-attrLabel="${item1.label}"></input>                                    
                                                        <label class="form-check-label ms-3" for="inlineCheckbox1">${item1.label}  (${item1.count})</label>
                                                    </div>

                                                    ${key == item.options.length - 1 && key > 5 ? "<div class='see-more'><a href='javascript:void(0)' class='text-decoration-none'><span class='see-more-text'> <img class='img-responsive'  src='/content/dam/merclink/plus-lg.svg' > See More</span></a></div><div class='see-less d-none'><a href='javascript:void(0)' class='text-decoration-none'><span class='see-less-text'><img class='img-responsive' src='/content/dam/merclink/dash-lg.svg' > See Less</span></a></div>" : ''}
                                `);
					});
					$(".accordion-item").append(`  </div>
                    </div>
                    </div>
                    `)
					filterArrayObjectFacet.forEach((item) => {
							item.facetList.forEach((facetitem) => {
								$(`[data-category-attrcode="${item.attrCode}"][data-options-attrcode="${facetitem.attrCode}"]`).prop('checked', true);
							})
						})
						//see more
					$(".see-more").click(function() {
						$(".mm-filter-toggle-view").removeClass('d-none')
						$(".see-more").addClass('d-none')
						$(".see-less").removeClass('d-none')
					});
					$(".see-less").click(function() {
						$(".mm-filter-toggle-view").addClass('d-none')
						$(".see-more").removeClass('d-none')
						$(".see-less").addClass('d-none')
					});
				});
				//call products
				$.each(products.items, function(key, item2) {
					if(item2.masterpartprop65code == "Cancer" || item2.masterpartprop65code == "1") {
						prop65code = "Cancer";
					} else if(item2.masterpartprop65code == "Cancer and Reproductive Harm" || item2.masterpartprop65code == "3" || item2.masterpartprop65code == "Yes") {
						prop65code = "Cancer and Reproductive Harm";
					} else if(item2.masterpartprop65code == "Reproductive Harm" || item2.masterpartprop65code == "No" || item2.masterpartprop65code == "2") {
						prop65code = "Reproductive Harm";
					} else {
						prop65code = null;
					}
					$(".productsearch-grid-display-control").append(`
                            <div class="col col-sm-6 col-lg-3 col-md-4  mb-3">
                            <div class="card border p-2">
                                <div class="d-flex justify-content-between align-items-center qty-box pb-1">
                                  <div class=" h3 mb-0">${item2.priceRange.maximumPrice.finalPrice.value != 0 ? "<input class='form-check-input' type='checkbox' data-itemId=" + item2.sku + " id='flexCheckDefault'>" : ''}</div>
                                    <div class="d-flex justify-content-end align-items-center"><span class=" me-2">Qty
                                       </span><input type="number" id="qty-${item2.sku}"  min ="${item2.masterpartlowestsellinguomqty}" step ="${item2.masterpartlowestsellinguomqty}" class="w-50 py-2" value="${item2.masterpartlowestsellinguomqty}" onkeypress="return event.charCode >= 48"  onfocusout=" this.value=='' ? this.value = ${item2.masterpartlowestsellinguomqty} : '' ; this.value % ${item2.masterpartlowestsellinguomqty} || this.value == 0  ?  this.value = (parseInt(this.value)+(${item2.masterpartlowestsellinguomqty}-(parseInt(this.value) % ${item2.masterpartlowestsellinguomqty} )))  : '' ; ">
                                    </div>
                                </div>
                                <div class="h3  product-code">${item2.sku}</div>
                                <div class="productsearch-card-main-container ">
                                    <div class="productsearch-card-main-container__item1 text-center"> <img src=${item2.smallImage.url ? item2.smallImage.url : "/content/dam/merclink/mm-no-image.png"} class="card-img-top" alt="..."></div>

                                    <div class="productsearch-card-main-container__item2 text-center">
                                        <h4 id="desc${item2.sku}" class="card-title">${item2.name}</h4>
                                    </div>
                                    <div class="productsearch-card-main-container__item3 ">

                                        <div class="d-flex justify-content-center">
                                            <a href=${$("#pdpurlauthor").val()}.html?sku=${item2.sku} class="my-3 btn btn-primary ">View Product</a>
                                        </div>
                                    </div>

                                </div>
										${prop65code ? "<p class='card-text mb-2'><i> <img src='/content/dam/merclink/warning.svg' class='warning-img'> </i><strong class='text-capitalize '>WARNING: </strong> "+prop65code+" -www.P65Warning.ca.gov</p>" : ''}
                               </div>
                            </div>
                        </div>

                        `)
				});
				if($(".listview").hasClass("d-none")) {
					document.querySelector('.listview').click();
				}
			  }
			  
			
			} else {
				//Analytics code changes.
                let search_val = searchValue.trim();
                if(search_val == ""){
                   search_val = "error-" +responsedata.errorCode;
                }
                _satellite.track('Search', {searchTerms: search_val , result:"0"});
                //Analytics code changes.
				$(".accordion").html("");
				$(".productsearch-grid-display-control").html("");
				$(".productsearch-grid-display-control").append("<h5 align='center'>Something went wrong. Please try again</h5>");
			}
		
		},
		complete: function() {
			$("#loader").addClass("hidden");
			$('body').removeClass("backDisabled");
		},
		error: function(e) {
			$("#loader").addClass("hidden");
			$('body').removeClass("backDisabled");
			_satellite.track('Search', {searchTerms: searchValue , result:""});
			$(".productsearch-grid-display-control").append("<h5 align='center'>Something went wrong. Please try again</h5>");
		}
	});
} //end of call products

function callContent() {
	console.log("inside call content");
	var searchValue = $('.search').val();
	if(searchValue.includes("%20")) {
		searchValue = searchValue.replaceAll("%20", " ");
	} else if(searchValue.includes("%2520")) {
		searchValue = searchValue.replaceAll("%2520", " ");
	} else if(searchValue.includes("%22")) {
		searchValue = searchValue.replaceAll("%22", " ");
	}
	$('.search').val(searchValue);
	$('.contentsearch-list-heading').html("<h2>Results for \"" + searchValue + "\"</h2>");
	var data = {
			"keyword": $('.search').val(),
			"path": $('#resourcePath').val(),
			"type": "content",
			"pagesize": $(".contentopt option:selected").val(),
			"page": $(".contentselect option:selected").val()
		}
		//var contentresultssize;
	var jsonData = JSON.stringify(data);
	$.ajax({
		type: "POST",
		url: "/ecomm/mm.searchResultsServlet.json",
		ContentType: 'application/json',
		data: {
			'data': jsonData
		},
		beforeSend: function() {
			$("#loader").removeClass("hidden");
			$('body').addClass("backDisabled");
		},
		success: function(response) {
			$(".contentlist").html("");
			$(".showcontentresults").html("");
			if(response != null && response.data != null && response.data.contents != null) {
				$('#allcid').val(response.data.contents.results.length);
			}
			if(response.data != null) {
				var metadata = response.data.contents.meta;
				//contentresultssize = metadata.size;
				var resultsContentCount = response.data.contents.results.length;
				//Analytics code changes.
                _satellite.track('Search', {searchTerms: searchValue.trim() , result: resultsContentCount});
                //Analytics code changes.
				
				var pagesize = $(".contentopt option:selected").val();
				var pageNumber = $(".contentselect option:selected").val();
				if(pageNumber != null && pagesize != null) {
					var pageStart = (parseInt(pagesize) * (parseInt(pageNumber) - 1)) + 1;
					var pageEnd;
					if(resultsContentCount <= pagesize) {
						pageEnd = resultsContentCount;
					} else {
						pageEnd = parseInt(pagesize) + (pageStart - 1) > resultsContentCount ? resultsContentCount : parseInt(pagesize) + (pageStart - 1);
					}
					$('.showcontentresults').append(pageStart + ' - ' + pageEnd + " of " + resultsContentCount + " Results");
				}
				if(resultsContentCount == pagesize) {
					var temp = 1;
				} else {
					var temp = resultsContentCount / pagesize == 0 ? (Math.floor(resultsContentCount / pagesize)) : (Math.floor(resultsContentCount / pagesize) + 1);
				}
				console.log('total number of pages  ' + temp);
				$('.contentselect').html("");
				var i = 1;
				while(i <= temp) {
					var text;
					text = "Page " + i + ' of ' + temp;
					$('.contentselect').append('<option value="' + i + '">' + text + '</option>');
					i++;
				}
				$('.contentselect').val(pageNumber);
				$.each(response.data.contents.results, function(index, element) {
					if((element.title !== "undefined") && (typeof(element.description) !== "undefined") && (element.url !== "undefined")) {
						$(".contentlist").append("<div class='items-div'id = 'item_" + index + "'><p class ='element_title'>" + element.title + "</p>" + "<p>" + element.description + "</p>" + "<p><a href='" + element.url + "' target='_blank'>" + element.url + "</a></p>" + "</div>");
					} else if((element.title !== "undefined") && (typeof(element.description) !== "undefined")) {
						$(".contentlist").append("<div class='items-div'id = 'item_" + index + "'><p class ='element_title'>" + element.title + "</p>" + "<p>" + element.description + "</p>" + "</div>");
					} else if((element.title !== "undefined") && (typeof(element.url) !== "undefined")) {
						$(".contentlist").append("<div class='items-div'id = 'item_" + index + "'><p class ='element_title'>" + element.title + "</p>" + "<p><a href='" + element.url + "' target='_blank'>" + element.url + "</a></p>" + "</div>");
					} else {
						$(".contentlist").append("<div class='items-div'id = 'item_" + index + "'><p class ='element_title'>" + element.title + "</p></div>");
					}
				});
			} else {
				//Analytics code changes.
                let search_val = searchValue.trim();
                if(search_val == ""){
                   search_val = "";
                }
                _satellite.track('Search', {searchTerms: search_val , result:""});
                //Analytics code changes.
				$(".contentlist").append("<h5 align='center'>No Content Found</h5>");
				$('.showresultsreturn').hide();
			}
		},
		complete: function() {
			$("#loader").addClass("hidden");
			$('body').removeClass("backDisabled");
		},
		error: function(e) {
			$("#loader").addClass("hidden");
			$('body').removeClass("backDisabled");
		}
	});
}

function convertFilterArray(filterArrayObjectFacet) {
var finalString = "";

filterArrayObjectFacet.forEach((item, idx, array) => {

    item.facetList.forEach((item1, idx1, array1) => {

        if (idx1===0){
				 if(idx===0) {
                    finalString += item.attrCode + "=["
				} else {
				finalString += "&"+ item.attrCode + "=["    
				}         
       }
		 if (idx1 === array1.length - 1) {
					finalString +=   '\"' + item1.attrCode + '\"]'
         } else {
                finalString +=  '\"' + item1.attrCode + '\",'
         }
})

})

finalString = finalString.split('')

finalString[0] == '&' ? finalString[0] ='':''

finalString = finalString.join('')

console.log("final --> " + finalString);
return finalString;
}