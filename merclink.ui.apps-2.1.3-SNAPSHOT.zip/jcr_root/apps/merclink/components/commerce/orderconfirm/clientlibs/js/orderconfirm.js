// Initialize tooltips
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
})
	
$(document).ready(function () {
    $(window).on('popstate', function (event) {
        //$("#errormessage").removeClass('d-none');
        console.log("clicked Back Button");
    }); 

    $(".orderid").html("Order #: " + getCookie("erpOrderNumber"));
    $(".orderdate").html(" Order Date: " + getCookie("OrderCreated"));
    var currentloc = window.location.href;
    if(currentloc.includes("orderconfirm.html")){
	try{
	    var cartOrderAnalytics = JSON.parse(localStorage.getItem("chekoutLineItem"));
   	    var checkoutDetailsAnalytics = JSON.parse(localStorage.getItem("checkoutDetails"));
	    var digiItems = [];
	    if(cartOrderAnalytics && checkoutDetailsAnalytics)
	    {
	    cartOrderAnalytics.forEach((element, index) => {
	        var name = element.product.name;
	        var sku = element.product.sku;
	        var quantity = parseInt(element.quantity);
	        var customer_price = JSON.parse(element.item_attributes[0].customer_price);
	        digiItems.push({
	            productQuantity: quantity,
	            productInfo: {
	                productID: sku,
	                productName: name,
					productConfig: element.cpq_session ? element.cpq_session : "website"
	            },
	            price: {
	                sellingPrice: parseFloat(customer_price.selling_price).toFixed(2),
	            }
	        });
	    });	   
	    var appliedTaxes = checkoutDetailsAnalytics.cart.prices.applied_taxes.length > 0 ? checkoutDetailsAnalytics.cart.prices.applied_taxes[0].amount.value != null ? parseFloat(checkoutDetailsAnalytics.cart.prices.applied_taxes[0].amount.value) : 0 : 0;
	    var shippingCharge = checkoutDetailsAnalytics.cart.shipping_addresses[0].selected_shipping_method.amount.value ? checkoutDetailsAnalytics.cart.shipping_addresses[0].selected_shipping_method.amount.value : 0;
	    var grandTotalCharge = checkoutDetailsAnalytics.cart.prices.grand_total.value ? checkoutDetailsAnalytics.cart.prices.grand_total.value : 0;
	    if(typeof digitalData != "undefined"){
	    digitalData.transaction =  {
	            orderID: getCookie("erpOrderNumber"),
	            total: {
	                currency: "USD",
	                netPrice: parseFloat(grandTotalCharge).toFixed(2),   //pass the Total price of order value.(including all the additions/deductions)
	                tax: parseFloat(appliedTaxes).toFixed(2),
	                shippingCharges: parseFloat(shippingCharge).toFixed(2)	                
	            },
	            item: digiItems
    		}   
    	} 
	    _satellite.track('order confirmation');
	   }
	}catch(e){
	    console.log(e);
	}
	}
	if(currentloc.includes("bulk-order-confirmation.html")){
	try{
	    var cartOrderAnalytics = JSON.parse(localStorage.getItem("chekoutBulkLineItem"));
   	    //var checkoutDetailsAnalytics = JSON.parse(localStorage.getItem("checkoutDetails"));
	    var digiItems = [];
	    if(cartOrderAnalytics)
	    {
		if(typeof digitalData != "undefined"){
	    digitalData.transaction =  {
	            orderID: getCookie("erpOrderNumber"),
	            total: {
	                currency: "USD",
	                shippingCharges: cartOrderAnalytics.shipping_cost	                
	            },
	            item: cartOrderAnalytics.items_data
    		}   
    	} 
	    _satellite.track('bulk order confirmation');
	   }
	}catch(e){
	    console.log(e);
	}
	}
    localStorage.removeItem("chekoutLineItem");
    localStorage.removeItem("chekoutBulkLineItem");
    localStorage.removeItem("shippingMethodDetails");
    localStorage.removeItem("checkoutDetails");
    
    $("a.Print-Page").click(function () {
        var cssLink = "";
        $("link[rel='stylesheet']").each(function () {
            cssLink +=
                "<link rel='stylesheet' href='" +
                $(this).prop("href") +
                "' type='text/css'>";
        });

        const element = document.getElementById("pdf-container");
        var divToPrint = element.cloneNode(true);
        var newWin = window.open("", "Print-Window");
        newWin.document.open();
        newWin.document.write(
            "<html><head>" +
            cssLink +
            '</head><body onload="window.print()"><div class="mm-order-confirmation-page"><div class="container"><div class="row text-center thank-you-msg bg-white border p-3 pb-md-4"><div class="col-md-12 ">' +
            divToPrint.innerHTML +
            "</div></div></div></div></body></html>"
        );
        newWin.document.close();
        setTimeout(function () {
            newWin.close();
        }, 100);
    });


});

/* save as pdf*/
$(document).on("click", "#order-conf-pdf", function () {

    getPDForderConfirmation();
});
//PDF Download //
function getPDForderConfirmation() {
    var d = jQuery.Deferred(),
        p = d.promise();
    p.pipe(generatePdforderConfirmation);
    d.resolve();
}
function generatePdforderConfirmation() {
    kendo.drawing.drawDOM($('#pdf-container'), {
        paperSize: "A4",
        margin: {
            left: "2cm",
            top: "1.25cm",
            right: "2cm",
            bottom: "0cm"
        },
        scale: 0.6,
        multiPage: true,
        landscape: true,
        repeatHeaders: false,
        template: $("#orderConfirmation_page").html(),
        forcePageBreak: ".page-break"
    }).then(function (group) {
        kendo.drawing.pdf.saveAs(group, "order-confirmation.pdf");
    })
}
