let bulkCartId = "";
let totalWeight = 0;
$(document).ready(function() {
	 $(document).on("click", ".select-item-checkbox", function() {
        if ($('.select-item-checkbox:checked').length == $('.select-item-checkbox').length) {
            $('.all-item-check').prop('checked', true);
        } else {
            $('.all-item-check').prop('checked', false);
        }
    });
    
     $(".remove-items").click(function() {	
		if($('table tbody tr').lenth > 0 || $('table tbody tr td').html().trim() == "Please upload csv file."){
			  $("#remove-product").modal("hide");
    		  var msg = "No item(s) to remove.";
	          respMsgDisplay(202, msg);
	          return false;
		}
	    $(".select-item-checkbox").each((index, element) => {
            if ($(element).is(":checked")) {
                var index = $(element).data("index");
                var weight = $("#qty-"+index).data("weight");
                totalWeight = totalWeight - weight;        		
                $(".remove-check-" + index).remove();
                $("#remove-product").modal("hide");
                var msg = "Item(s) were removed from order entry";
	            respMsgDisplay(200, msg);
            }
        });
        totalWeight = totalWeight.toFixed(4);
        $("#totalweight").html((totalWeight) + " kg");
        _satellite.track('Remove from Bulk checkout', { linkName: $("a[data-bs-target='#remove-product']").eq(1).html() });
    });

    $("input[type=file]").change(function() {	
	 $('.all-item-check').prop('checked', false);    
        var fileInput = document.getElementById("oeChooseFile");
        var regex = new RegExp("(.*?)\.(csv)$");
        if (!(regex.test(fileInput.value.toLowerCase()))) {
            fileInput.value = '';
            respMsgDisplay(202, "Please upload only CSV file format");
        } else {
            let file = fileInput.files[0];
            let fr = new FileReader();
            fr.onload = receivedText;
            fr.readAsText(file);
            function receivedText() {
                var csv = fr.result;
                var lines = csv.split("\n");
                var result = [];
                var headers = lines[0].split(",");
                headers[0] = "item_number";
                headers[1] = "qty";
                var maxLength = $("#maxcsv").val();
                if (lines.length <= parseInt(maxLength)) {
                    for (var i = 1; i < lines.length; i++) {
                        if (lines[i] && lines[i] != "") {
                            var obj = {};
                            var currentline = lines[i].split(",");
                            for (var j = 0; j < headers.length; j++) {
                                obj[headers[j]] = currentline[j];
                            }
                            result.push(obj);
                        }
                    }
                    directItemValue(result);
                    $('input[type="file"]').val("");
                    totalWeight = 0;
                } else {
                    respMsgDisplay(202, "CSV Content exceeds Max Length allowed");
                    $('input[type="file"]').val("");
                }
            }
        }
    });

    $(".all-item-check").click(function() {
        if ($(this).is(":checked") == true) {
            $(".select-item-checkbox").prop('checked', true);
        } else {
            $(".select-item-checkbox").prop('checked', false);
        }
    });
    
    $(".select-item-checkbox").click(function() {
        var totalLength = $(".select-item-checkbox").length;
        var checkedLength = 0;
        $(".select-item-checkbox").each(function(index, element) {
            if ($(element).is(":checked")) {
                checkedLength++;
            }
        });
        if (totalLength == checkedLength) {
            $(".all-item-check").prop("checked", true);
        } else {
            $(".all-item-check").prop("checked", false);
        }
    });
    
     
});

function directItemValue(csvValue) {
    var tableData = "";
    $("#directItemEntryTable tbody").empty();
    $.each(csvValue, function(index, element) {
        if (element.qty != undefined && element.item_number != '') {
            var qty = isNaN(parseInt(element.qty.replaceAll(",", ""))) ? 0 : parseInt(element.qty.replaceAll(",", ""));
        	qty = qty == 0 ? 1 : qty;
            tableData += '<tr class="remove-check-' + index + '">' +
                '<td class="oe-table-input-width"><input class="form-check-input select-item-checkbox" type="checkbox" value="" data-index="' + index + '"></td>' +
                '<td class="oe-table-ss-width">' +
                '<div class="oe-table-ss"><input type="text" class="form-control" id="ss-' + index + '" value=""> </div>' +
                '</td>' +
                '<td data-bs-toggle="modal" data-bs-target="#product-item" class="oe-table-item-no-width">' +
                '<div class="oe-table-item-no"><input type="text" data-index="' + index + '" class="form-control insertItem" value="' + element.item_number + '" class="warn-item"></div>' +
                '<div class="oe-table-warning mt-1 d-none invalid-item-' + index + '"> Invalid Item </div>' +
                '</td>' +
                '<td class="oe-table-qty-width">' +
                '<div class="input-group mm-quantity">' +
                '<input type="number" id="qty-' + index + '" name="quantity" data-weight="" class="form-control w-100" value="' + qty + '" min="1 " max="100 ">' +
                '</div>' +
                '</td>' +
                '<td class="oe-table-weight weight-' + index + '"></td>' +
                '<td class="oe-table-item-desc-width ">' +
                '<div class="oe-table-item-desc "><input type="text" class="form-control" id="des-' + index + '"value=""> </div>' +
                '</td>' +
                '</tr>';

        }
    });
    $("table tbody").empty();
    $("table tbody").append(tableData);
    var items = "";
    var itemArray = [];
    $(".insertItem").each((index, element) => {
        var sku = $(element).val();
        if (sku != "" && itemArray.indexOf(sku) == -1) {
            items += sku + '\",\"';
            itemArray.push(sku);
        }
    });
	var totalItemCount = itemArray.length;
	if(totalItemCount > 0)
	{
	var minLoop = totalItemCount % 500 == 0 ? parseInt(totalItemCount / 500) : parseInt(totalItemCount / 500) + 1;
	var minCount = 0;
	for (var i = 0; i < minLoop; i++) {
		var newItem = [];
		for (var j = minCount; j < minCount + 500; j++) {
			if (j < totalItemCount) {
				newItem.push(itemArray[j]);
			} else {
				break;
			}
		}
		var newItems = "";
		newItem.forEach(function(element, index) {
			newItems += element + '\",\"';
		});	
		showLoader();	
		validateAllItems(newItems.substring(0, items.length - 3)); 
		minCount = minCount + 500;
		}		
	}	
}

function validateAllItems(skuItems) {
	showLoader();
    var data = {
        "componentPath": $('#resourcePath').val(),
        "sku": skuItems,
        "companyNumber": getCookie("selectedCustomer"),
    }
    
    $.ajax({
        type: "POST",
        url: "/bin/bulkItemSearchServlet",
        ContentType: "application/json",
        async : true,
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            if (data != null) {
                if (data.quickOrderProductsAnzp) {
                    if (data.quickOrderProductsAnzp.items) {
                        data.quickOrderProductsAnzp.items.forEach(function(element, index) {
                            setItemValue(element);
                        });
                        totalWeight = totalWeight / 1000;
					    $("#totalweight").html((totalWeight).toFixed(4) + " kg");
                    }

                    if (data.quickOrderProductsAnzp.user_errors) {
                        data.quickOrderProductsAnzp.user_errors.forEach(function(element, index) {
                            setItemErrorValue(element);
                        });
                    }
                }
                if (data.bulkItemSearch) {
					var msg = data.bulkItemSearch;
	                respMsgDisplay(202, msg);	                
	                return false;
                }
            }
        }, 
        complete: function() {
            hideLoader();
        },
        error: function(jqXHR, exception) {
			hideLoader();
            var msg = '';
		    if (jqXHR.status === 0) {
		        msg = 'Not connect.\n Verify Network.';
		    } else if (jqXHR.status == 404) {
		        msg = 'Requested page not found. [404]';
		    } else if (jqXHR.status == 500) {
		        msg = 'Internal Server Error [500].';
		    } else if (exception === 'parsererror') {
		        msg = 'Requested JSON parse failed.';
		    } else if (exception === 'timeout') {
		        msg = 'Time out error.';
		    } else if (exception === 'abort') {
		        msg = 'Ajax request aborted.';
		    } else {
		        msg = 'Uncaught Error.\n' + jqXHR.responseText;
		    }
		    respMsgDisplay(202, msg);
		    return false;
        }
    });
}

function showLoader() {
    $("body").append("<div id='loader8' class='overlay lds-dual-ring loader8' ></div>");
}

function hideLoader() {
    setTimeout(function () {
            $(".loader8").remove();
            $("#loader").remove();
            $(".loader").remove();
            $("body").removeClass("backDisabled");
    }, 1000);
}

function setItemValue(item) {
    var id = item.id ? item.id : "";
    var sku = item.sku ? item.sku : "";
    var item_number = item.item_number ? item.item_number : "";
    var ss_item_number = item.ss_item_number ? item.ss_item_number : "";
    var description = item.description ? item.description : "";
    var masterpartlowestsellinguomqty = item.masterpartlowestsellinguomqty ?
        isNaN(parseInt(item.masterpartlowestsellinguomqty)) ?
        1 : parseInt(item.masterpartlowestsellinguomqty) : 1;
    var mp_pkg_ea_weight_uom_metric = item.mp_pkg_ea_weight_uom_metric ? item.mp_pkg_ea_weight_uom_metric : "";
    var mp_pkg_ea_weight_metric = item.mp_pkg_ea_weight_metric ? item.mp_pkg_ea_weight_metric : "";

	var weight = isNaN(parseFloat(mp_pkg_ea_weight_metric)) ? "" : parseFloat(parseFloat(mp_pkg_ea_weight_metric) / 1000).toFixed(2) + " kg" ;

    var itemWeight = isNaN(parseFloat(mp_pkg_ea_weight_metric)) ? 0 : parseFloat(parseFloat(mp_pkg_ea_weight_metric) / 1000).toFixed(2) ;
   
    var item = ss_item_number.length > 0 ? ss_item_number : item_number;
     
    masterpartlowestsellinguomqty = masterpartlowestsellinguomqty == 0 ? 1 : masterpartlowestsellinguomqty;

    var validate = "this.value=='' ? this.value = " + masterpartlowestsellinguomqty + " : '' ; this.value % " + masterpartlowestsellinguomqty + " || this.value == 0  ?  this.value = (parseInt(this.value)+(" + masterpartlowestsellinguomqty + "-(parseInt(this.value) % " + masterpartlowestsellinguomqty + " )))  : '' ";

    $(".insertItem").each((index, element) => {
        if ($(element).val() == item) {
            var rowNumber = $(element).data('index');
            $("#qty-" + rowNumber).attr("onfocusout", validate);
            $("#qty-" + rowNumber).attr("min", masterpartlowestsellinguomqty);
            $("#qty-" + rowNumber).attr("step", masterpartlowestsellinguomqty);
			$("#qty-" + rowNumber).attr("data-weight", itemWeight);
            var orgQtyVal = parseInt($("#qty-" + rowNumber).val());
            orgQtyVal = orgQtyVal == 0 ? 1 : orgQtyVal;           
            var qtyVal = 1;
            if (!isNaN(orgQtyVal) && orgQtyVal > masterpartlowestsellinguomqty) {
                if (masterpartlowestsellinguomqty == 0 || orgQtyVal % masterpartlowestsellinguomqty == 0) {
                    qtyVal = orgQtyVal;
                } else {
                    qtyVal = (parseInt(orgQtyVal / masterpartlowestsellinguomqty) + 1) * masterpartlowestsellinguomqty;
                }
            } else {
                qtyVal = masterpartlowestsellinguomqty;
            }

            if (orgQtyVal != qtyVal) {
                $(".invalid-item-" + rowNumber).removeClass("d-none");
                $(".invalid-item-" + rowNumber).html("Qty changed from " + orgQtyVal + " to " + qtyVal);
            }
            $("#qty-" + rowNumber).val(qtyVal);
            $(element).val(item_number);
            $("#ss-" + rowNumber).val(ss_item_number);
            $(".weight-" + rowNumber).html(weight);
            $("#des-" + rowNumber).val(description);

            totalWeight += isNaN(parseFloat(mp_pkg_ea_weight_metric)) ? 0 : parseFloat(mp_pkg_ea_weight_metric);
           
        }
    });
  
}

function setItemErrorValue(messageItem) {
    var errorMessage = messageItem.message;
    $(".insertItem").each((index, element) => {
        if ($(element).val() != "" && errorMessage.search($(element).val()) != -1) {
            var rowNumber = $(element).data("index");
            $("#qty-" + rowNumber).val("");
            $("#qty-" + rowNumber).prop("readonly", true);
            $(".invalid-item-" + rowNumber).removeClass("d-none");
            $(".invalid-item-" + rowNumber).html(errorMessage);
        }
    });
}

function createbulkCartId() {
    var data = {
        "componentPath": $('#componentPath').val(),
        "companyNumber": getCookie("selectedCustomer")
    }

    $.ajax({
        type: "POST",
        url: "/bin/createBulkCartServlet",
        ContentType: "application/json",
        data: {
            'data': JSON.stringify(data)
        },
        success: function(data) {
            if (data) {
                if (data.customerCart) {
                    if (data.customerCart.id) {
                        bulkCartId = data.customerCart.id;
                        cartquery(false,bulkCartId);

                    }
                    if (data.customerCart.erp_errors.length > 0) {
                        var msg = data.customerCart.erp_errors;
		                respMsgDisplay(202, msg);
		                return false;
                    }
                }
                if (data.createBulkCart) {
                    var msg = data.createBulkCart;
	                respMsgDisplay(202, msg);
	                return false;
                }
            }
        }
    });
}

function confirmBulkOrder(){
	 $('#errormessage').addClass('d-none');
	
	if ($("input[name='radio-1']:checked").val() == null || $("input[name='radio-1']:checked").val() == '') {
        var msg = "Select the shipping Priority";
        respMsgDisplay(202, msg);
        return false;
    }	
    // Warning message is not displayed ship date is blank(start)(start)
    if ($("#shippingdate").val() == "") {
        var msg = "Select Requested Ship Date";
        respMsgDisplay(202, msg);
        window.scrollTo(0, 0);
        return false;
    }	
    // Warning message is not displayed ship date is blank(start)(end)
    if ($("#Method").val() == "Select Method" || $("#Method").val() == null || $("#Method").val() == '') {
        var msg = "Select the shipping method";
        respMsgDisplay(202, msg);
        return false;
    }    
    if ($("#po-number").val() == "") {
        var msg = "Enter the PO Number";
        respMsgDisplay(202, msg);
        return false;
    }
    if ($("input[name='radio-2']:checked").val() == null || $("input[name='radio-2']:checked").val() == '') {
        var msg = "Select the Payment Type";
        respMsgDisplay(202, msg);
        return false;
    }
    if($('table tbody tr').lenth > 0 || $('table tbody tr td').html().trim() == "Please upload csv file."){
   		 var msg = "Please upload CSV to submit.";
		 respMsgDisplay(202, msg);
		 return false;
	}
    if ($('input:checkbox:checked').length > 0) {
   		 $('#submitConfirmation').modal('show');
	}else {
		bulksubmitCheckout();
	}
	
	try {
        _satellite.track('checkoutso', { linkName: $(".proceed-btn").html() });
    } catch (e) {
        console.log(e);
    }
}

function bulksubmitCheckout()
{
    var items = "";
    $(".insertItem").each((index, element) => {
        var sku = $(element).val();
        if (sku != "") {
            var rowNumber = $(element).data('index');
            var qty = $("#qty-" + rowNumber).val();
            if (qty != "") {
                items += '{sku:"' + sku + '",qty:' + qty + '},'
            }
        }
    });
    placeBulkOrder(items.substring(0, items.length - 1));
}

function placeBulkOrder(items) {
    $("#submitConfirmation").modal("hide");
    if ($("input[name='radio-1']:checked").val() == "standard") {
        var date = $("#shippingdate").val();
        var datearray = date.split("-");
        var shipdate = datearray[2] + '-' + datearray[1] + '-' + datearray[0];
    } else {
        var shipdate = '';
    }
    var dropshipinfo = JSON.parse(getCookie("completeAccountDetails"));
    var selectedCustomer = getCookie("selectedCustomer");
    var dropShipSelect = dropshipinfo.filter(element => element.company_number == selectedCustomer);
    if (dropShipSelect.length > 0 && dropShipSelect[0].dropship == 1 && $("input[name='radio-3']:checked").val() == "drop-ship-yes") {
        var dropship = true;
    } else {
        var dropship = false;
    }
    var shipVal = '';
	if ($("#Method").val() == "Pickup") {
		shipVal = "pickup_pickup";
	} else if ($("#Method").val() == "Road") {
		shipVal = "road_road";
	} else if ($("#Method").val() == "Sea") {
		shipVal = "sea_sea";
	}    
    var couponStr = '';
    coupons.map((val) => couponStr += val.value + ',');
    var bulkData = {
        "componentPath": $('#componentPath').val(),
        "cart_id": bulkCartId,
        "po_number": $("#po-number").val(),
        "order_comment": $("#po-instructions").val(),
        "requested_ship_date": shipdate,
        "payment_method": $("input[name='radio-2']:checked").val(),
        "shipping_method": shipVal,
        "shipping_cost": "0",
        "attribute19": couponStr.slice(0, -1),
        "is_dropship": dropship,
        "items_data": '[' + items + ']'
    }

    $.ajax({
        type: "POST",
        url: "/bin/bulkPlaceOrderServlet",
        ContentType: "application/json",
        data: {
            'data': JSON.stringify(bulkData)
        },
        success: function(data) {
            if (data) {
                if (data.placeBulkOrder) {
                    if (data.placeBulkOrder.errors) {
                        if (data.placeBulkOrder.errors.message) {
                            var msg = data.placeBulkOrder.errors.message;
			                respMsgDisplay(202, msg);
			                return false;
                        }
                    }
                }
                if (data.placeBulkOrder) {
                    setCookie("erpOrderNumber", data.placeBulkOrder.data.order_numer, 1);
	                setCookie("OrderCreated", data.placeBulkOrder.data.created, 1);
	                JSON.stringify(localStorage.setItem("chekoutBulkLineItem", JSON.stringify(bulkData)));
	                location.href = $(".proceed-btn").val();
                }
            }
        }
    });

}