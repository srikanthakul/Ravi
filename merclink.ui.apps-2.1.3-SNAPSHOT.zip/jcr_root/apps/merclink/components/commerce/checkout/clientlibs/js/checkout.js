// checkout.js
let shippingAddressList;
let firstorder;
let customerAddressId;
let coupons = [];
let loaderCount = 0;
let cartDataAnalytics;
let checkoutAnalyticsFlag = 0;
let cartDetails = [];

function submitCheckout() {
    $('#errormessage').addClass('d-none');
    // Warning message is not displayed ship date is blank(start)(start)
    if ($("#shippingdate").val() == "") {
        var msg = "Select Requested Ship Date";
        respMsgDisplay(202, msg);
        window.scrollTo(0, 0);
        return false;
    }
    // Warning message is not displayed ship date is blank(start)(end)
    if ($("#Method").val() == "Select Method" || $("#Method").val() == null || $("#Method").val() == '') {
        var msg = "Select the shipping method";
        respMsgDisplay(202, msg);
        return false;
    }
    if ($("input[name='radio-1']:checked").val() == null || $("input[name='radio-1']:checked").val() == '') {
        var msg = "Select the shipping Priority";
        respMsgDisplay(202, msg);
        return false;
    }
    if ($("input[name='radio-2']:checked").val() == null || $("input[name='radio-2']:checked").val() == '') {
        var msg = "Select the Payment Type";
        respMsgDisplay(202, msg);
        return false;
    }
    if ($("#po-number").val() == "") {
        var msg = "Enter the PO Number";
        respMsgDisplay(202, msg);
        return false;
    }
    if (parseInt(getCookie("cartCount")) <= 0) {
        var msg = "No item in the cart please add item to the cart";
        respMsgDisplay(202, msg);
        return false;
    }
    if ($('input:checkbox:checked').length > 0) {
        $('#submitConfirmation').modal('show');
    } else {
        confirmCheckoutOrder();
    }

    try {
        _satellite.track('checkoutso', { linkName: $(".proceed-btn").html() });
    } catch (e) {
        console.log(e);
    }
}

function confirmCheckoutOrder() {
    $("#submitConfirmation").modal("hide");
    if ($("input[name='radio-1']:checked").val() == "standard") {
        var date = $("#shippingdate").val();
        var datearray = date.split("-");
        var shipdate = datearray[2] + '-' + datearray[1] + '-' + datearray[0];
    } else {
        var shipdate = '';
    }
    var dropshipinfo = JSON.parse(getCookie("completeAccountDetails"));
    var selectedCustomer = getCookie("selectedCustomer");
    var dropShipSelect = dropshipinfo.filter(element => element.company_number == selectedCustomer);
    if (dropShipSelect.length > 0 && dropShipSelect[0].dropship == 1 && $("input[name='radio-3']:checked").val() == "drop-ship-yes") {
        var dropship = true;
    } else {
        var dropship = false;
    }
    var couponStr = '';
    coupons.map((val) => couponStr += val.value + ',');
    var formData = {
        componentPath: $("#resourcePath").val(),
        cartId: getCookie("cartId"),
        shipping_priority: $("input[name='radio-1']:checked").val(),
        requestedshipdate: shipdate,
        shipping_method: $("#Method").val(), //ifcondition
        ponumber: $("#po-number").val(),
        ordercomment: $("#po-instructions").val(),
        shippingAddress: $("#shippingAddress").val(),
        billing_address: $("#billingAddress").val(),
        payment_method: $("input[name='radio-2']:checked").val(),
        shipping_cost: $(".shipping-charge").text(),
        attribute19: couponStr.slice(0, -1),
        is_dropship: dropship,
    };
    $.ajax({
        type: "POST",
        url: "/bin/merclink/submitOrderServlet",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(formData)
        },
        beforeSend: function() {
            enableDisableLoader(true);
        },
        success: function(data) {
            if (data != null && data.placeOrder != null) {
                setCookie("erpOrderNumber", data.placeOrder.order.erp_order_number, 1);
                setCookie("OrderCreated", data.placeOrder.order.order_created, 1);
                JSON.stringify(localStorage.setItem("chekoutLineItem", localStorage.getItem("cartDetails")));
                location.href = $(".proceed-btn").val();
            }
            if (data != null && data.submitOrder != null) {
                var msg = data.submitOrder;
                respMsgDisplay(202, msg);
                $("#submitConfirmation").modal("hide");
                return false;
            }
        },
        complete: function() {
            enableDisableLoader(false);
        },
        error: function(jqXHR, exception) {
            handleAjaxExceptionMessage(jqXHR, exception);
        }
    });
}

function pagination_checkout(itemNumer, pageNumber, tableId, pageNumberClass, pageIndex) {
    var showItem = parseInt(itemNumer);
    var itemCount = ($(".order-product-checkBox").length - 1);
    if ((itemCount % showItem) == 0) {
        totalPage = parseInt(itemCount / showItem);
    } else {
        totalPage = parseInt(itemCount / showItem) + 1;
    }
    if (pageNumber > totalPage) {
        pageNumber = totalPage;
    }
    var displayItemsTo = (parseInt(pageNumber) * parseInt(showItem) - 1);
    var displayItemsFrom = parseInt(pageNumber) * parseInt(showItem) - parseInt(showItem);
    var option = "";
    for (var i = 1; i <= totalPage; i++) {
        var selected = "";
        if (i == pageNumber) {
            selected = "selected";
        }
        option += "<option value='" + i + "'" + selected + ">Page " + i + " of " + totalPage + "</option>";
    }
    $("." + pageNumberClass).empty();
    $("." + pageNumberClass).append(option);
    if (option == '') {
        $("." + pageNumberClass).hide();
        $(".mm-total-result").attr('style', 'display: none !important;');
    } else {
        $("." + pageNumberClass).show();
        $(".mm-total-result").show();
    }
    if (displayItemsTo < itemCount) {
        var index = displayItemsFrom + 1 + "-" + (displayItemsTo + 1) + " of " + itemCount + " Results";
    } else {
        var index = displayItemsFrom + 1 + "-" + itemCount + " of " + itemCount + " Results";
    }
    if (itemCount == 0) {
        $("." + pageIndex).html('');
    } else {
        $("." + pageIndex).html(index);
    }
    $(".order-product-checkBox").each((index, element) => {
        if (index >= displayItemsFrom && index <= displayItemsTo) {
            $("#child_tr_" + index).show();
            $("#parent_tr_" + index).show();
        } else {
            $("#child_tr_" + index).hide();
            $("#parent_tr_" + index).hide();
        }
    });
}
$(document).ready(function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        })
        // Warning message is not displayed for future requested ship date is greater than 180 days - Start
    $("#shippingdate").change(function() {
        var date = $("#shippingdate").val();
        var datearray = date.split("-");
        var selectedDate = datearray[2] + '-' + datearray[1] + '-' + datearray[0];
        $('#warningmessageDate').addClass('d-none');
        if ($("#shippingdate").val() != "") {
            var daysDiff = ((new Date(selectedDate).getTime() - new Date().getTime()) / (1000 * 3600 * 24));
            if (Math.round(daysDiff) > 180) {
                $('#warningmessageDate').removeClass('d-none');
                $('#messagedisplay-warning').html("ship date is greater than 180 days");
                window.scrollTo(0, 0);
            }
        }
    });
    // Warning message is not displayed for future requested ship date is greater than 180 days - End      
    $(".datepicker").datepicker({
        autoclose: true,
        startDate: new Date(),
        todayHighlight: true
    }).datepicker('update', new Date());

    $(".proceed-btn").show();
    $(".remove-cart").show();
    if (getCookie("merclinkCustomerPersonalInfo")) {
        var personalinfo = JSON.parse(getCookie("merclinkCustomerPersonalInfo"));
        var groupbool = personalinfo.roles_permission.customer_group == "Anzp Default Customer Group";
        var rolesbool = false;
        if (personalinfo.roles_permission.customer_roles) {
            personalinfo.roles_permission.customer_roles.split(",").forEach(element => {
                if (element != null && element != '') {
                    if (element == "Order Entry") {
                        rolesbool = true;
                    }
                }
            });
        }
        if (!groupbool && !rolesbool) {
            $(".proceed-btn").hide();
            $(".proceed-btn").removeClass("proceed-btn");
        }
    }
    var cartId = getCookie("cartId");
    setTimeout(() => {
        var cartUpdatedAt = getCookie("cartUpdatedAt");
        var cartRunTime = getCookie("cartRunTime");
        var checkoutRunTime = getCookie("checkoutRunTime");
        if (cartUpdatedAt === cartRunTime) {
            tableDetails(localStorage.getItem("cartDetails") ? JSON.parse(localStorage.getItem("cartDetails")) : []);
            if (cartUpdatedAt === checkoutRunTime && localStorage.getItem("shippingMethodDetails") && localStorage.getItem("checkoutDetails")) {
                shippingListData(localStorage.getItem("shippingMethodDetails") ? JSON.parse(localStorage.getItem("shippingMethodDetails")) : []);
                diplayShipAddress(localStorage.getItem("checkoutDetails") ? JSON.parse(localStorage.getItem("checkoutDetails")) : []);
                diplayBillAddress(localStorage.getItem("checkoutDetails") ? JSON.parse(localStorage.getItem("checkoutDetails")) : []);
                diplayPaymentType(localStorage.getItem("checkoutDetails") ? JSON.parse(localStorage.getItem("checkoutDetails")) : []);
                setShippingPriorityData(localStorage.getItem("checkoutDetails") ? JSON.parse(localStorage.getItem("checkoutDetails")) : []);
                setCartPrice(localStorage.getItem("checkoutDetails") ? JSON.parse(localStorage.getItem("checkoutDetails")) : []);
                setShippingMethodData(localStorage.getItem("checkoutDetails") ? JSON.parse(localStorage.getItem("checkoutDetails")) : []);
                setdropship(localStorage.getItem("checkoutDetails") ? JSON.parse(localStorage.getItem("checkoutDetails")) : []);
            } else {
                setCookie("checkoutRunTime", cartUpdatedAt, 1);
                shippingmethod(true);
            }
        } else {
            cartPageData(cartId);
            setCookie("checkoutRunTime", cartUpdatedAt, 1);
            shippingmethod(true);
        }
    }, 0);

    $('input[type=radio][name=radio-3]').change(function() {
        dropShipCost($("input[name='radio-3']:checked").val());
    });
    $(".global-check-box").click(function() {
        if ($(this).is(":checked") == true) {
            $(".order-product-checkBox").prop('checked', true);
        } else {
            $(".order-product-checkBox").prop('checked', false);
        }
    });
    $(".remove-yes").click(function() {
        $("#confirmation").modal("hide");
        var cartArray = [];
        var productItems = [];
        var itemSkuArray = [];
        $(".order-product-checkBox").each((index, element) => {
            if ($(element).is(":checked") == true) {
                if ($(element).data('cpq') != "") {
                    $(".order-product-checkBox[data-cpq='" + $(element).data('cpq') + "']").each((index, element) => {
                        if (itemSkuArray.indexOf($(element).val()) == -1) {
                            itemSkuArray.push($(element).val());
                        }
                    });
                } else {
                    itemSkuArray.push($(element).val());
                }
            }
        });
        itemSkuArray.forEach((item) => {
            var element = $(".order-product-checkBox[value='" + item + "']");
            var id = parseInt($(element).val());
            var cartobj = {
                "cart_item_id": id.toString(),
                "quantity": "0"
            }
            cartArray.push(cartobj);
            var itemNumber = $(element).data("item");
            var productItem = {
                "productQuantity": $("#qty" + itemNumber).html(),
                "productInfo": {
                    "productID": $(element).data("sku").toString(),
                    "productName": $("#item-des-" + itemNumber).html(),
                    "productConfig": $(element).data("cpq").toString().length > 0 ? $(element).data("cpq") : "website",
                }
            }
            productItems.push(productItem);
        });
        if (cartArray.length > 0) {
            updateCart(cartArray, productItems);
        } else {
            var msg = "No item(s) were selected to be removed.";
            respMsgDisplay(202, msg);
        }
    });
    $(".bi-left").click(function() {
        return $(".curpage option:selected").prev().val() && $(".curpage").val($(".curpage option:selected").prev().val()) && $(".curpage").change()
    });
    $(".bi-right").click(function() {
        return $(".curpage option:selected").next().val() && $(".curpage").val($(".curpage option:selected").next().val()) && $(".curpage").change()
    });
    $(".resultperpage").change(function() {
        var showItem = $(this).val();
        var pageNumber = $(".curpage").val();
        $(".resultperpage").val(showItem);
        $(".curpage").val(pageNumber);
        pagination_checkout(showItem, pageNumber, "checkout_table", "curpage", "total-value");
    });
    $(".curpage").change(function() {
        var showItem = $(".resultperpage").val();
        var pageNumber = $(this).val();
        $(".resultperpage").val(showItem);
        $(".curpage").val(pageNumber);
        pagination_checkout(showItem, pageNumber, "checkout_table", "curpage", "total-value");
    });
    $('input[type=radio][name=radio-1]').change(function() {
        hideDisplayRequestDate();
        shippinPrioritySelected();
    });
    $("#Method").change(function() {
        var ShippingValue = $("#Method").val();
        shippingMethodCost(ShippingValue);
    });
});

function cartquery(getDataVal) {
    var data = {
        "componentPath": $("#resourcePath").val(),
        "cartId": getCookie("cartId"),
        "item": getDataVal
    }
    $.ajax({
        type: "POST",
        url: "/bin/cart/cartQuery",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(data)
        },
        beforeSend: function() {
            $("body").append("<div id='loader8' class='overlay lds-dual-ring1' ></div>");
        },
        success: function(data) {
            if (data != null && data.cartQuery != null) {
                var msg = data.cartQuery;
                respMsgDisplay(202, msg);
            }
            if (data != null && data.cart != null) {
                localStorage.setItem("checkoutDetails", JSON.stringify(data));
                cartDataAnalytics = data.cart.item ? data.cart.item : JSON.parse(localStorage.getItem("cartDetails"));
                if (checkoutAnalyticsFlag == 0) {
                    diplayShipAddress(data);
                    diplayBillAddress(data);
                    diplayPaymentType(data);
                    checkoutAnalyticsFlag += 1;
                }
                setShippingPriorityData(data);
                setShippingMethodData(data);
                setCartPrice(data);
                setdropship(data);
                if (getDataVal == true) {
                    if (!localStorage.getItem("cartDetails") && getCookie("cartCount") > 0) {
                        localStorage.setItem("cartDetails", JSON.stringify(data.cart.items));
                        var dataDetails = JSON.parse(localStorage.getItem("cartDetails"));
                        tableDetails(dataDetails);
                        $(".remove-cart").show();
                        $(".order-product-checkBox").show();
                        $(".proceed-btn").show();
                        $(".bi-left").show();
                        $(".bi-right").show();
                    }
                }
                if (getCookie("completeAccountDetails")) {
                    var shipping_method = data.cart.shipping_addresses;
                    if (shipping_method.length > 0 && shipping_method[0].selected_shipping_method && shipping_method[0].selected_shipping_method.carrier_code != '' && shipping_method[0].selected_shipping_method.carrier_code != null) {
                        var shippingMethod = shipping_method[0].selected_shipping_method.carrier_code;
                        shippingMethod = shippingMethod.charAt(0).toUpperCase() + shippingMethod.slice(1);
                    }
                    var selectedCustomer = getCookie("selectedCustomer");
                    var dropshipinfo = JSON.parse(getCookie("completeAccountDetails"));
                    var dropShipSelect = dropshipinfo.filter(element => element.company_number == selectedCustomer);
                    if (dropShipSelect.length > 0 && dropShipSelect[0].dropship == 1) {
                        $('#dropShipCustomer').removeClass('d-none');
                        dropHideShow(data.cart.prices.shipping_priority[0].code, shippingMethod);
                    }
                }
            }

        },
        complete: function() {
            $("#loader8").remove();
        },
        error: function(jqXHR, exception) {
            handleAjaxExceptionMessage(jqXHR, exception);
        }
    });
}

function tableDetails(data) {
    cartDetails = data;
    var productPrice = 0;
    var tableData = "";
    var totalweight = 0;
    var plpPath = "/content/ecommerce/merclink/au/en/productdetails.html";
    $(".itemCount").html(getCookie("cartCount"));
    if (data && data.length > 0) {
        localStorage.setItem("cartDetails", JSON.stringify(data));
        var productAnalyseArray = [];
        data.forEach((element, index) => {
            var name = element.product.name;
            var sku = element.product.sku;
            var quantity = parseInt(element.quantity);
            var id = parseInt(element.id);
            var cpqSession = element.cpq_session ? element.cpq_session : "";
            var weight;

            if (element.product.product_data[0].weight != undefined) {
                weight = Number(element.product.product_data[0].weight);
                totalweight += (quantity * parseFloat(weight));
                weight = parseFloat(weight / 1000).toFixed(4) + " kg";
            } else {
                weight = ''
            }
            var availability_date = element.item_attributes[0].availability_date != null ? element.item_attributes[0].availability_date : "";
            var customer_price = JSON.parse(element.item_attributes[0].customer_price);
            productPrice += parseFloat(quantity * parseFloat(customer_price.selling_price));
            var productAnalyse = {
                "productQuantity": quantity,
                "productInfo": {
                    "productID": sku,
                    "productName": name,
                    "productConfig": element.cpq_session ? element.cpq_session : "website"
                }
            };
            productAnalyseArray.push(productAnalyse);
            var warning_message = element.product.product_data[0].warning_message != null ? element.product.product_data[0].warning_message : "";
			var prop65_msg = element.product.masterpartprop65code != null ? element.product.masterpartprop65code : "";
			var propMsg_avl = "";
			if(prop65_msg.length > 0){
				propMsg_avl = '<i class="me-1"> <img src="/content/dam/merclink/images/warning.svg" class="warning-img"> </i> <span><strong>WARNING</strong>: '+prop65_msg+' - <a href="www.P65Warnings.ca.gov" target="_blank">www.P65Warnings.ca.gov</a></span>';
				}
            var hazous_flag = '<tr  id="child_tr_' + index + '" class="warn-border">' + '<td></td>' + '<td></td>' + '<td></td>' + '<td colspan="5" class="small">' + '</td>' + '</tr>';
            if (warning_message.length > 0 && warning_message == "1") {
                hazous_flag = '<tr id="child_tr_' + index + '" class="warn-border">' + '<td></td>' + '<td></td>' + '<td></td>' + '<td colspan="5" class="small">' + '<div class="d-flex align-items-center">' + '<i class="me-1"> <img alt="Warn Icon" src="/content/dam/merclink/images/warn.png" class="warning-img"> </i> <span>Hazardous goods. AIR Freight prohibited.</span>' + '</div>'+ '<div class="d-flex align-items-center">'+ ''+propMsg_avl+'' +'</div>' + '</td>' + '</tr>';
            }
            tableData += '<tr id="parent_tr_' + index + '">' + '<td><input class="form-check-input ms-0 order-product-checkBox" data-cpq="' + cpqSession + '" data-item="' + index + '" type="checkbox" data-sku="' + sku + '" data-qty="' + quantity + '" value="' + id + '" /></td>' + '<td>' + " " + '</td>' + '<td data-bs-toggle="modal" data-bs-target="#product-item"><a href="' + plpPath + '?sku=' + sku + '"><span class="text-decoration-underline">' + sku + '</span></a></td>' + '<td><span id="item-des-' + index + '">' + name + '</td>' + '<td>' + cpqSession + '</td>' + '<td>' + weight + '</td>' + '<td id="qty' + index + '">' + quantity + '</td>' + '<td class="position-relative ">' + availability_date + '</td>' + '<td class="text-end">$' + currencyFormat(parseFloat(customer_price.selling_price).toFixed(2)) + '</td>' + '<td class="text-end">$' + (currencyFormat(parseFloat((quantity * parseFloat(customer_price.selling_price))))) + '</td>' + '</tr>' + hazous_flag;
        });
        try {
            if (typeof digitalData !== "undefined") {
                digitalData.cart = {
                    "item": productAnalyseArray,
                }
            }
        } catch (e) {
            console.log(e);
        }
        _satellite.track('checkout');
    }

    $("#totalweight").html(parseFloat((totalweight / 1000).toFixed(4)) + " kg");
    $("#datacart").html(tableData);
    $(".product-total").html("$" + currencyFormat(parseFloat(productPrice).toFixed(2)));
    pagination_checkout(20, 1, "checkout_table", "curpage", "total-value");
    if (tableData == "") {
        localStorage.removeItem("cartDetails");
        tableData += '<tr class="warn-border">' + '<td></td>' + '<td></td>' + '<td></td>' + '<td colspan="6" class="small">' + '<div class="d-flex align-items-center">' + ' <span><strong>No data Found, Please add items in cart.</strong></span>' + '</div>' + '</td>' + '</tr>';
        $("#datacart").html(tableData);
        $(".remove-cart").hide();
        $(".order-product-checkBox").hide();
        $(".proceed-btn").hide();
        $(".bi-left").hide();
        $(".bi-right").hide();
    }

    $(".order-product-checkBox").change(function() {
        var oneCheck = false;
        var unchecked = false;
        $(".order-product-checkBox").each((index, element) => {
            if ($(element).is(":checked") == true) {
                oneCheck = true;
                return;
            }
        });
        $(".order-product-checkBox").each((index, element) => {
            if ($(element).is(":checked") == false && index != 0) {
                unchecked = true;
                return;
            }
        });
        var checked = $('input[type=checkbox].order-product-checkBox:checked');
        var checkbox = $('input[type=checkbox].order-product-checkBox');
        if (checkbox.length == 2 && unchecked == true) {
            $(".order-product-checkBox").prop('checked', false);
            $(".global-check-box").prop('checked', true);
        }
        if ($(".global-check-box").is(":checked") == true && unchecked) {
            $(".global-check-box").prop('checked', false);
        } else if ($(".global-check-box").is(":checked") == false && checked.length == (checkbox.length - 1)) {
            $(".global-check-box").prop('checked', true);
        }
    });
}

function diplayShipAddress(data) {
    if (data.cart.shipping_addresses) {
        var shippingAddressDisplay = data.cart.shipping_addresses != null ? data.cart.shipping_addresses : [];
        customerAddressId = data.cart.shipping_addresses[0].company_address_id != null ? data.cart.shipping_addresses[0].company_address_id : '';
        for (var i = 0; i < shippingAddressDisplay.length; i++) {
            $("#shippingAddress").val(shippingAddressDisplay[i]['street'] + "\n" + shippingAddressDisplay[i]['city'] + ", " + shippingAddressDisplay[i]['region']['code'] + ", " + shippingAddressDisplay[i]['country']['code']);
        }
    }
}

function diplayBillAddress(data) {
    if (data.cart.billing_address) {
        $("#billingAddress").val(data.cart.billing_address.street + "\n" + data.cart.billing_address.city + ", " + data.cart.billing_address.region.code + ", " + data.cart.billing_address.postcode + ", " + data.cart.billing_address.country.code);
    }
}

function diplayPaymentType(data) {
    if (data.cart.available_payment_methods) {
        var paymentMethods = data.cart.available_payment_methods.filter(element => element.code != "chcybersource");
        var paymentMethodsOption = "";
        for (var i = 0; i < paymentMethods.length; i++) {
            paymentMethodsOption += '<div class="form-check form-check-inline ps-0 my-1"><input class="form-check-input ms-0 mt-0" type="radio" name="radio-2" id="radio_' + paymentMethods[i] + '" value="' + paymentMethods[i]["code"] + '" > <label class="form-check-label ms-2 mb-0" for="on-account">' + paymentMethods[i]["title"] + '</label></div>';
        }
        $("#paymentRadio").html(paymentMethodsOption);
    }
}

function minimumCharge(data) {
    var minimum_charges = data.cart.prices.minimum_charge.length > 0 ? data.cart.prices.minimum_charge[0].minimum != null ? parseFloat(data.cart.prices.minimum_charge[0].minimum) : 0 : 0;
    if (minimum_charges > 0) {
        $(".minimum-charge").html("$" + currencyFormat(parseFloat(minimum_charges).toFixed(2)));
        $("#minimumCharges").removeClass('d-none');
        $('#warningrMessage').removeClass('d-none');
        $('#warningMessageDisplay').html(data.cart.prices.minimum_charge[0].message);
        window.scrollTo(0, 0);
    }
}

function setdropship(data) {
    if (data.cart.is_dropship == true) {
        $("#drop-ship-yes").prop("checked", true);
    }
    if (data.cart.is_dropship == false) {
        $("#drop-ship-no").prop("checked", true);
    }
}

function shippinPrioritySelected() {
    var data = {
        resourcePath: $("#resourcePath").val(),
        shippingType: $("input[name='radio-1']:checked").val(),
        cartId: getCookie("cartId"),
    }
    $.ajax({
        type: "POST",
        url: "/bin/shippingPriorityML",
        ContentType: "application/json",
        data: {
            data: JSON.stringify(data),
        },
        beforeSend: function() {
            enableDisableLoader(true);
        },
        success: function(data) {
            if (data != null && data.shipping_type != null) {
                cartqueryShippingpriority("priority");
            } else {}
        },
        complete: function() {
            enableDisableLoader(false);
        },
        error: function(jqXHR, exception) {
            handleAjaxExceptionMessage(jqXHR, exception);
        }
    });
}

function cartqueryShippingpriority(priceVal) {
    var data = {
        "componentPath": $("#resourcePath").val(),
        "cartId": getCookie("cartId")
    }
    $.ajax({
        type: "POST",
        url: "/bin/cartPriceML",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(data)
        },
        beforeSend: function() {
            $("body").append("<div id='loader8' class='overlay lds-dual-ring1' ></div>");
        },
        success: function(data) {
            if (data != null && data.cartQuery != null) {
                var msg = data.cartQuery;
                respMsgDisplay(202, msg);
            }
            if (data != null && data.cart != null) {
                if (priceVal == "dropship") {
                    setCartPrice(data);
                }
                if (priceVal == "priority") {
                    setShippingPriorityData(data);
                }
                if (localStorage.getItem("checkoutDetails")) {
                    var checkoutDetailsJson = JSON.parse(localStorage.getItem("checkoutDetails"));
                    checkoutDetailsJson.cart.prices = data.cart.prices;
                    localStorage.setItem('checkoutDetails', JSON.stringify(checkoutDetailsJson));
                }
            }
        },
        complete: function() {
            $("#loader8").remove();
        },
        error: function(jqXHR, exception) {
            handleAjaxExceptionMessage(jqXHR, exception);
        }
    });
}

function setShippingPriorityData(data) {
    if (data.cart.prices.shipping_priority.length > 0 && data.cart.prices.shipping_priority[0].code && data.cart.prices.shipping_priority[0].code != '') {
        $('#emergencypriority').addClass('d-none');
        var shippingPriority = data.cart.prices.shipping_priority[0].code;
        $("#" + shippingPriority.toLowerCase()).prop("checked", true);
        hideDisplayRequestDate();
        if (data.cart.prices.shipping_priority[0].value != undefined && data.cart.prices.shipping_priority[0].value != '' && data.cart.prices.shipping_priority[0].code != 'standard') {
            $('#emergencypriority').removeClass('d-none');
            $('.emergency-priority-charge').html("$" + currencyFormat(parseFloat(data.cart.prices.shipping_priority[0].value).toFixed(2)));
        }
    } else {
        $("#standard").prop("checked", true);
        hideDisplayRequestDate();
    }
    var total = data.cart.prices.grand_total.value ? "$" + currencyFormat(parseFloat(data.cart.prices.grand_total.value).toFixed(2)) : 0;
    if (total == 0) {
        $(".grandTotal").html("$0.00");
    } else {
        $(".grandTotal").html(total);
    }
}

function hideDisplayRequestDate() {
    if ($('input[type=radio][name=radio-1]:checked').val() == "emergency") {
        $("#shipDateDiv").hide();
        $("#shippingPriorityDiv").addClass(".col-md-6").removeClass(".col-md-4");
    } else {
        $("#shipDateDiv").show();
        $("#shippingPriorityDiv").removeClass(".col-md-6").addClass(".col-md-4");
    }
}

function shippingmethod(setVal) {
    var selectedCustomer = getCookie("selectedCustomer");
    var methoddata = {
        resourcePath: $("#resourcePath").val(),
        cartId: getCookie("cartId"),
        customerNumber: parseInt(selectedCustomer)
    }
    $.ajax({
        type: "POST",
        url: "/bin/shippingMethodServlet",
        ContentType: 'application/json',
        async: true,
        data: {
            'data': JSON.stringify(methoddata)
        },
        beforeSend: function() {
            enableDisableLoader(true);
        },
        success: function(data) {
            if (data != null && data.shipping_method != null) {
                var shippingList = data.shipping_method;
                localStorage.setItem("shippingMethodDetails", JSON.stringify(shippingList));
                shippingListData(shippingList);
            }
            if (setVal == true) {
                if (localStorage.getItem("cartDetails") != "") {
                    cartquery(false);
                } else {
                    cartquery(true);
                }
            }
        },
        complete: function() {
            enableDisableLoader(false);
        },
        error: function(jqXHR, exception) {
            handleAjaxExceptionMessage(jqXHR, exception);
        }
    });
}

function shippingListData(shippingList) {
    var listOptions = "";
    listOptions = "<option>Select Method</option>";
    for (var i = 0; i < shippingList.length; i++) {
        listOptions += "<option value='" + shippingList[i]['name'] + "'>" + shippingList[i]['name'] + "</option>";
    }
    $("#Method").html(listOptions);
}

function shippingMethodCost(dataValue) {
    if ($("#Method").val() != "Select Method") {
        var data = {
            resourcePath: $("#resourcePath").val(),
            shipping_mode: dataValue,
            cartId: getCookie("cartId"),
        }
        $.ajax({
            type: "POST",
            url: "/bin/merclink/shippingCostServlet",
            ContentType: 'application/json',
            data: {
                'data': JSON.stringify(data)
            },
            beforeSend: function() {
                enableDisableLoader(true);
            },
            success: function(data) {
                if (data != null && data.shipping_cost != null) {
                    $('#shipcharge').removeClass('d-none');
                    $('.shipping-charge').html("$" + currencyFormat(parseFloat((data.shipping_cost)).toFixed(2)));
                    cartqueryShippingMethod();
                } else {
                    $("#shipcharge").addClass("d-none");
                    var msg = data.shippingCost;
                    respMsgDisplay(202, msg);
                }
            },
            complete: function() {
                enableDisableLoader(false);
            },
            error: function(jqXHR, exception) {
                handleAjaxExceptionMessage(jqXHR, exception);
            }
        });
    }
}

function cartqueryShippingMethod() {
    var data = {
        "componentPath": $("#resourcePath").val(),
        "cartId": getCookie("cartId")
    }
    $.ajax({
        type: "POST",
        url: "/bin/shippingMethodCartQueryML",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(data)
        },
        beforeSend: function() {
            $("body").append("<div id='loader8' class='overlay lds-dual-ring1' ></div>");
        },
        success: function(data) {
            if (data != null && data.cartQuery != null) {
                var msg = data.cartQuery;
                respMsgDisplay(202, msg);
            }
            if (data != null && data.cart != null) {
                setShippingMethodData(data);
                if (localStorage.getItem("checkoutDetails")) {
                    var checkoutDetailsJson = JSON.parse(localStorage.getItem("checkoutDetails"));
                    checkoutDetailsJson.cart.prices = data.cart.prices;
                    checkoutDetailsJson.cart.shipping_addresses = data.cart.shipping_addresses;
                    localStorage.setItem('checkoutDetails', JSON.stringify(checkoutDetailsJson));
                    setCartPrice(data);
                }
            }
        },
        complete: function() {
            $("#loader8").remove();
        },
        error: function(jqXHR, exception) {
            handleAjaxExceptionMessage(jqXHR, exception);
        }
    });
}

function setShippingMethodData(data) {
    var shipping_method = data.cart.shipping_addresses;
    if (shipping_method.length > 0 && shipping_method[0].selected_shipping_method && shipping_method[0].selected_shipping_method.carrier_code != '' && shipping_method[0].selected_shipping_method.carrier_code != null) {
        var shippingAmount = shipping_method[0].selected_shipping_method.amount.value;
        var shippingMethod = shipping_method[0].selected_shipping_method.carrier_code;
        shippingMethod = shippingMethod.charAt(0).toUpperCase() + shippingMethod.slice(1);
        $("#Method").val(shippingMethod);
        $('#shipcharge').removeClass('d-none');
        $('.shipping-charge').html("$" + currencyFormat(parseFloat((shippingAmount)).toFixed(2)));
    }
    if (getCookie("completeAccountDetails")) {
        var dropshipinfo = JSON.parse(getCookie("completeAccountDetails"));
        var selectedCustomer = getCookie("selectedCustomer");
        var dropShipSelect = dropshipinfo.filter(element => element.company_number == selectedCustomer);
        if (dropShipSelect.length > 0 && dropShipSelect[0].dropship == 1) {
            $('#dropShipCustomer').removeClass('d-none');
            dropHideShow(data.cart.prices.shipping_priority[0].code, shippingMethod);
        }
    }
    if ($("#Method").val() == null || $("#Method").val() == '') {
        $("#Method").val("Select Method");
    }
    var total = data.cart.prices.grand_total.value ? "$" + currencyFormat(parseFloat(data.cart.prices.grand_total.value).toFixed(2)) : 0;
    $(".grandTotal").html(total);
}

function Shippingaddress() {
    var selectedCustomer = getCookie("selectedCustomer");
    var data = {
        resourcePath: $("#resourcePath").val(),
        customerNumber: parseInt(selectedCustomer)
    }
    $.ajax({
        type: "GET",
        url: "/bin/merclink/getAddressesServlet",
        ContentType: "application/json",
        async: true,
        data: {
            data: JSON.stringify(data),
        },
        beforeSend: function() {
            enableDisableLoader(true);
        },
        success: function(data) {
            if (data != null && data.data != null) {
                shippingAddressList = data.data;
                var addressListOptions = "";
                addressListOptions = "<option value='' selected disabled>Select Address</option>";
                for (var i = 0; i < shippingAddressList.length; i++) {
                    if (customerAddressId == shippingAddressList[i]['customer_address_id']) {
                        var addressSelected = "selected";
                    } else {
                        var addressSelected = shippingAddressList[i]['primary_flag'] == true ? "selected" : '';
                    }
                    if (shippingAddressList[i]['address_type'] == "shipping") {
                        addressListOptions += "<option value='" + shippingAddressList[i]['customer_address_id'] + "' " + addressSelected + ">" + shippingAddressList[i]['full_address'] + "</option>";
                    }
                }
                $("#shipaddress").html(addressListOptions);
            }
        },
        complete: function() {
            enableDisableLoader(false);
        },
        error: function(jqXHR, exception) {
            handleAjaxExceptionMessage(jqXHR, exception);
        }
    });
}

function Selectaddress() {
    $('#change-address').modal('hide');
    let addressId = document.getElementById("shipaddress").value;
    if (addressId != customerAddressId) {
        var index = shippingAddressList.findIndex((v) => v.customer_address_id == addressId);
        var customerShipDetails = {
            cartId: getCookie("cartId"),
            "firstname": shippingAddressList[index].name.split(" ")[0],
            "lastname": shippingAddressList[index].name.split(" ").length > 1 ? shippingAddressList[index].name.split(" ").splice(1).toString().split(",").join(" ") : shippingAddressList[index].name.split(" ")[0],
            "company": "",
            "address1": shippingAddressList[index].street[0] ? shippingAddressList[index].street[0].replaceAll("/", '-').replaceAll(/[^a-zA-Z.,0-9- ]/g, " ").replaceAll("  ", " ") : "",
            "city": shippingAddressList[index].city ? shippingAddressList[index].city : "",
            "regioncode": shippingAddressList[index].region ? shippingAddressList[index].region : "",
            "postalcode": shippingAddressList[index].postal_code ? shippingAddressList[index].postal_code : "",
            "country": shippingAddressList[index].country_code ? shippingAddressList[index].country_code : "",
            "telephone": "8675309",
            "addressbook": false,
            "companyAddrId": shippingAddressList[index].customer_address_id ? parseInt(shippingAddressList[index].customer_address_id) : "",
            "resourcePath": $("#resourcePath").val()
        }
        $.ajax({
            type: "POST",
            url: "/bin/setShippingaddresstocartML",
            ContentType: "application/json",
            data: {
                data: JSON.stringify(customerShipDetails),
            },
            beforeSend: function() {
                enableDisableLoader(true);
            },
            success: function(data) {
                if (data.cart && data.cart.shipping_addresses.length > 0) 
				{
                    customerAddressId = shippingAddressList[index].customer_address_id;
                    $("#warningAddress").addClass('d-none');
                    var x = shippingAddressList[index]['full_address'];
                    i = 0;
                    x = x.replace(/\n/g, m => !i++ ? m : ', ').replaceAll(" , ", ", ");
                    $('#change-address').modal('hide');
                    $("#shippingAddress").val(x);
                } else {
                    var msg = data.checkoutError;
                    respMsgDisplay(200, msg);
                }
            },
            complete: function() {
                enableDisableLoader(false);
            },
            error: function(jqXHR, exception) {
                handleAjaxExceptionMessage(jqXHR, exception);
            }
        });
    }
}

function dropShipCost(dropShipValue) {
    if (dropShipValue == 'drop-ship-yes') {
        dropShipValue = true;
    }
    if (dropShipValue == 'drop-ship-no') {
        dropShipValue = false;
    }
    var data = {
        resourcePath: $("#resourcePath").val(),
        is_dropship: dropShipValue,
        cartId: getCookie("cartId"),
    }

    $.ajax({
        type: "POST",
        url: "/bin/merclink/DropShipCostServlet",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(data)
        },
        beforeSend: function() {
            enableDisableLoader(true);
        },
        success: function(data) {
            if (data != null && data.setDropShip != null) {
                if (localStorage.getItem("checkoutDetails")) {
                    var checkoutDetailsJson = JSON.parse(localStorage.getItem("checkoutDetails"));
                    checkoutDetailsJson.cart.is_dropship = data.setDropShip.is_dropship;
                    localStorage.setItem('checkoutDetails', JSON.stringify(checkoutDetailsJson));
                }
                cartPageData(getCookie("cartId"));
                var cartUpdatedAt = getCookie("cartUpdatedAt")
                setCookie("checkoutRunTime", cartUpdatedAt, 1);
                cartqueryShippingpriority("dropship");
                dropHideShow($("input[name='radio-1']:checked").val(), $("#Method").val());
            } else {
                var msg = data.submitOrder;
                respMsgDisplay(202, msg);
            }
        },
        complete: function() {
            enableDisableLoader(false);
        },
        error: function(jqXHR, exception) {
            handleAjaxExceptionMessage(jqXHR, exception);
        }
    });
}

function dropHideShow(selectedvalue, selectedShipMethod) {
    if ($("input[name='radio-3']:checked").val() == "drop-ship-yes") {
        $('#emergency').prop('disabled', true);
        $("#Method").prop("disabled", false);
        if (selectedvalue != "standard") {
            $("#standard").prop("checked", true);
            shippinPrioritySelected();
        }
        if (selectedvalue == "standard") {
            $("#standard").prop("checked", true);
        }
        $("#Method").val(selectedShipMethod);
    } else {
        $('#emergency').prop('disabled', false);
        $("#Method").prop("disabled", false);
    }
}

function displayCouponCode(code) {
    if (code != null) {
        var index = coupons.findIndex((val) => val.value == code);
        if (index >= 0) {
            $("#couponCode").val('');
            $("#promotionsError").html("Entered coupon code has already been used");
            setTimeout(() => {
                $("#promotionsError").html("");
            }, 10000);
            return false;
        }
        var ranId = Math.random().toString(16).slice(2);
        coupons.push({
            id: ranId,
            value: code
        });
        $("#promotions").html("Applied Coupons");
        $("#couponList").append('<div class="d-flex align-items-end justify-content-between" id="appliedCouponList_' + ranId + '"><a href="#" class="sale promotions">' + code + '</a> <a href="#" class="remove promotions" id="removeId" onclick="removeCoupon(event)">Remove</a></div>');
        $("#appliedCouponList_" + ranId).removeClass('d-none');
        $("#couponCode").val("")
        $("#promotionsError").html("");
    } else {
        if (coupons.length == 0) {
            return false;
        }
        var parentId = event.target.parentElement.id;
        document.getElementById(parentId).remove();
        var randId = parentId.split('_');
        var index = coupons.findIndex((val) => val.id == randId[1])
        coupons.splice(index, 1);
        $("#promotionsError").html("");
        if (coupons.length == 0) {
            $("#promotions").html("");
        }
    }
}

function invalidCouponCode(code) {
    if (code != null) {
        $("#couponCode").val('');
        $("#promotionsError").html("Coupon code is not valid");
        setTimeout(() => {
            $("#promotionsError").html("");
        }, 10000);
    }
}

function applyCoupon() {
    if (coupons.length > 4) {
        $("#promotionsError").html("Maximum number of coupons has been reached");
        $("#couponCode").val('');
        setTimeout(() => {
            $("#promotionsError").html("");
        }, 10000);
        return false;
    }
    if (document.getElementById("couponCode").value == '') {
        $("#promotionsError").html("Enter coupon code");
        setTimeout(() => {
            $("#promotionsError").html("");
        }, 10000);
        return false;
    }
    var data = {
        resourcePath: $("#resourcePath").val(),
        couponNumber: encodeURIComponent(document.getElementById("couponCode").value)
    }
    $.ajax({
        type: "GET",
        url: "/bin/merclink/getValidCoupon",
        ContentType: "application/json",
        data: {
            data: JSON.stringify(data),
        },
        beforeSend: function() {
            enableDisableLoader(true);
        },
        success: function(data) {
            if (data && data.data) {
                if (data.data.validity_flag && data.data.validity_flag == true) {
                    displayCouponCode(decodeURIComponent(data.data.coupon_code));
                } else {
                    invalidCouponCode(decodeURIComponent(data.data.coupon_code));
                }
            } else {
                invalidCouponCode(decodeURIComponent(document.getElementById("couponCode").value));
            }
        },
        complete: function() {
            enableDisableLoader(false);
        },
        error: function(jqXHR, exception) {
            handleAjaxExceptionMessage(jqXHR, exception);
        }
    });
}

function removeCoupon(e) {
    e = e || window.event;
    e.preventDefault();
    displayCouponCode(null);
}

function updateCart(cartArray, productItems) {
    var data = {
        componentPath: $("#resourcePath").val(),
        "cartId": getCookie("cartId"),
        cartobj: cartArray
    }
    $.ajax({
        type: "POST",
        url: "/bin/cart/updateMultipleCartItem",
        ContentType: "application/json",
        dataType: "json",
        data: {
            'data': JSON.stringify(data)
        },
        beforeSend: function() {
            enableDisableLoader(true);
        },
        complete: function() {
            enableDisableLoader(false);
        },
        success: function(data) {
            if (data != null && data.updateCartQuery != null) {
                var msg = data.updateCartQuery;
                respMsgDisplay(202, msg);
            }
            if (data != null && data.updateCartItems.cart != null && data.updateCartItems.cart.items != null) {
                try {
                    if (typeof digitalData !== "undefined") {
                        digitalData.removeCart = {
                            "product": productItems,
                        }
                    }
                    _satellite.track('Remove from cart checkout', { linkName: $("a[data-bs-target='#confirmation']").eq(1).html() });
                } catch (e) {
                    console.log(e);
                }
                shippingmethod(false);
                $(".cart-item-display-number").html(data.updateCartItems.cart.items.length);
                setCookie("cartCount", data.updateCartItems.cart.items.length, 30);
                var msg = "Item(s) were removed from your cart.";
                respMsgDisplay(200, msg);
                var removeItem = cartArray.map(element => element.cart_item_id);
                var filteredItem = cartDetails.filter(element => removeItem.indexOf(element.id) == -1);
                tableDetails(filteredItem);
                cartqueryRemoveItem();
            }
        },

        error: function(jqXHR, exception) {
            handleAjaxExceptionMessage(jqXHR, exception);
        }
    });
}

function cartqueryRemoveItem() {
    var data = {
        "componentPath": $("#resourcePath").val(),
        "cartId": getCookie("cartId")
    }
    $.ajax({
        type: "POST",
        url: "/bin/removeCartItemML",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(data)
        },
        beforeSend: function() {
            $("body").append("<div id='loader8' class='overlay lds-dual-ring1' ></div>");
        },
        success: function(data) {
            if (data != null && data.cartQuery != null) {
                var msg = data.cartQuery;
                respMsgDisplay(202, msg);
            }
            if (data != null && data.cart != null) {
                setCartPrice(data);
            }
        },
        complete: function() {
            $("#loader8").remove();
        },
        error: function(jqXHR, exception) {
            handleAjaxExceptionMessage(jqXHR, exception);
        }
    });
}

function setCartPrice(data) {
    if (data.cart.prices) {
        var total = "$" + currencyFormat(parseFloat(data.cart.prices.grand_total.value).toFixed(2));
        $(".grandTotal").html(total);
        var applied_taxes = data.cart.prices.applied_taxes.length > 0 ? data.cart.prices.applied_taxes[0].amount.value != null ? parseFloat(data.cart.prices.applied_taxes[0].amount.value) : 0 : 0;
        $(".tax").html("$" + currencyFormat(parseFloat(applied_taxes).toFixed(2)));
        $("#taxes").removeClass('d-none');
    }
    minimumCharge(data);
}

function enableDisableLoader(loading) {
    if (loading) {
        loaderCount += 1;
        $('.lds-dual-ring').removeClass('hidden');
        $("body").addClass("backDisabled");
    } else {
        loaderCount -= 1;
        if (loaderCount <= 0) {
            $('.lds-dual-ring').addClass('hidden');
            $("body").removeClass("backDisabled");
        }
    }
}

function respMsgDisplay(statusCode, message) {
    if (statusCode == 200) {
        $(".mm-success-msg span").empty();
        $(".mm-success-msg span").text("" + message + "");
        $(".mm-success-msg").removeClass("d-none");
        $(".mm-success-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-success-msg").offset().top
        }, 'slow');
        setTimeout(function() {
            $(".mm-success-msg").fadeOut("slow");
        }, 20000);
    } else if (statusCode == 202) {
        $(".mm-error-msg span").empty();
        $(".mm-error-msg span").text("" + message + "");
        $(".mm-error-msg").removeClass("d-none");
        $(".mm-error-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-error-msg").offset().top
        }, 'slow');
        setTimeout(function() {
            $(".mm-error-msg").fadeOut("slow");
        }, 20000);
    } else if (statusCode == 503) {
        $(".mm-error-msg span").empty();
        $(".mm-error-msg span").text("" + message + "");
        $(".mm-error-msg").removeClass("d-none");
        $(".mm-error-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-error-msg").offset().top
        }, 'slow');
        setTimeout(function() {
            $(".mm-error-msg").fadeOut("slow");
        }, 20000);
    }
}

function handleAjaxExceptionMessage(jqXHR, exception) {
    var msg = '';
    if (jqXHR.status === 0) {
        msg = 'Not connect.\n Verify Network.';
    } else if (jqXHR.status == 404) {
        msg = 'Requested page not found. [404]';
    } else if (jqXHR.status == 500) {
        msg = 'Internal Server Error [500].';
    } else if (exception === 'parsererror') {
        msg = 'Requested JSON parse failed.';
    } else if (exception === 'timeout') {
        msg = 'Time out error.';
    } else if (exception === 'abort') {
        msg = 'Ajax request aborted.';
    } else {
        msg = 'Uncaught Error.\n' + jqXHR.responseText;
    }
    respMsgDisplay(202, msg);
    return false;
}

function cartPageData(cartId) {
    var data = {
        "componentPath": $("#resourcePath").val(),
        "cartId": cartId
    }
    $.ajax({
        type: "POST",
        url: "/bin/cart/cartPageQuery",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(data)
        },
        beforeSend: function() {
            $("body").append("<div id='loader1-cart' class='overlay lds-dual-ring1' ></div>");
        },
        complete: function() {
            $('#loader1-cart').remove();
        },
        success: function(data) {
            if (data != null && data.cart != null) {
                if (data.cart.items) {
                    var cartUpdatedAt = getCookie("cartUpdatedAt");
                    setCookie("cartRunTime", cartUpdatedAt, 1);
                    tableDetails(data.cart.items);
                }
            }
        },
        error: function(e) {}
    });
}