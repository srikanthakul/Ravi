$(document).ready(function() {

    $('#itemAvailability').on('input',function() {
        this.value = this.value.toUpperCase();
    });
    
    $(".searcAvailability").on("click",function(){
        if($("#itemAvailability").val() == ""){
			var msg = 'Please enter the Item Number.';
			respMsgDisplay(202,msg);
        }else{
        var data = {
            resourcePath: $("#resourcePath").val(),
            itemNumber: $("#itemAvailability").val()
        };
        $.ajax({
            type: "POST",
            url: "/bin/merclink/productAvailability",
            ContentType: "application/json",
            data: {
                data: JSON.stringify(data),
            },
			
            success: function (data) {
            showLoader("mm-availability-page");
                if(data.products.items.length <= 0){
					var msg = 'Invalid Item Number';
					respMsgDisplay(202,msg);
					hideLoader("mm-availability-page");
                }else if(data.products.items.length > 0 && data.products.items !=null){
					if (typeof digitalData != "undefined") {

								_satellite.track('pdpsearch', { linkName: $(".searcAvailability").html().trim() ,availabilitySearchTerm : $("#itemAvailability").val() });

						}
					 var redirectLocation = $("#pdpurl").val();
					location.href = redirectLocation+"?sku="+data.products.items[0].sku;
                    return false;
				}else{
					var msg = 'Invalid Item Number';
					respMsgDisplay(202,msg);
					hideLoader("mm-availability-page");
                }

            },
			
            error: function (e) {
                hideLoader("mm-availability-page");
                var msg = 'Something Went wrong. Please try again';
				respMsgDisplay(202,msg);
            }
        });
    }
});
});

function showLoader(className){
	$("#loader").removeClass("hidden");
	$('.'+className).addClass("backDisabled");
}

function hideLoader(className){
	$("#loader").addClass("hidden");
	$('.'+className).removeClass("backDisabled");
}

function respMsgDisplay(statusCode,message,){
	if(statusCode == 200){
		$(".mm-success-msg span").empty();
		$(".mm-success-msg span").text(""+message+"");
        $(".mm-success-msg").removeClass("d-none");
        $(".mm-success-msg").fadeIn("slow");
		$('html,body').animate({
			scrollTop: $(".mm-success-msg").offset().top
		}, 'slow');
        setTimeout(function() {
            $(".mm-success-msg").fadeOut("slow");
        }, 3000);
	}else if(statusCode == 202){
		$(".mm-error-msg span").empty();
		$(".mm-error-msg span").text(""+message+"");
        $(".mm-error-msg").removeClass("d-none");
        $(".mm-error-msg").fadeIn("slow");
		$('html,body').animate({
			scrollTop: $(".mm-error-msg").offset().top
		}, 'slow');
        setTimeout(function() {
            $(".mm-error-msg").fadeOut("slow");
        }, 3000);
	}
}


function toNumeric(numb) {
    if (numb != undefined && numb != null)
        return parseInt(numb.toString().replace(/[^0-9\.]+/g, ""));
}
