$(document).ready(function() {
    $(".mm-wishlist-product-details").addClass("d-none");
    $(".exportAll").on("click", function() {
        if ($(".childcheckbox-wish:checked").length > 0) {
            var table_id = "wishlist_prod_table";
            download_table_as_csv(table_id, separator = ',')
        } else {
            var wishID = $(this).attr("wishlistid")
            var daata = getWishDetailsExport(wishID, 1, 0);
        }
    })
    $('.prod-wish-create').css('display', 'none');

    $(".resultperpage").change(function() {
        var showItem = $(this).val();
        var pageNumber = $(".curpage").val();
        $(".resultperpage").val(showItem);
        $(".curpage").val(pageNumber);
        pagination(showItem, pageNumber, "wishlist_table", "curpage", "total-value");
    });

    $(".curpage").change(function() {
        var showItem = $(".resultperpage").val();
        var pageNumber = $(this).val();
        $(".resultperpage").val(showItem);
        $(".curpage").val(pageNumber);
        pagination(showItem, pageNumber, "wishlist_table", "curpage", "total-value");
    });

    $('#wishlist_table .img-down-icon').click(function() {

        var tableId = "wishlist_table";

        var rowIndex = $(this).parent().parent().parent().parent().index('#' + tableId + ' tr');

        var thIndex = $(this).parent().parent().parent().index('#' + tableId + ' tr:eq(' + rowIndex + ') th');

        sortTable(parseInt(thIndex), 'asc', tableId);

        var showItem = $(".resultperpage").val();

        var pageNumber = $(".curpage").val();

        pagination(showItem, pageNumber, "wishlist_table", "curpage", "total-value");

    });
    $('#wishlist_table .img-up-icon').click(function() {

        var tableId = "wishlist_table";

        var rowIndex = $(this).parent().parent().parent().parent().index('#' + tableId + ' tr');

        var thIndex = $(this).parent().parent().parent().index('#' + tableId + ' tr:eq(' + rowIndex + ') th');

        sortTable(parseInt(thIndex), 'desc', tableId);

        var showItem = $(".resultperpage").val();

        var pageNumber = $(".curpage").val();

        pagination(showItem, pageNumber, "wishlist_table", "curpage", "total-value");

    });

    $(document).on("click", ".select_all", function() {
        var wishlistid = $(this).attr("wishlistID");
        if (this.checked) {
            $('.childcheckbox_' + wishlistid).each(function() {
                this.checked = true;
            });
        } else {
            $('.childcheckbox_' + wishlistid).each(function() {
                this.checked = false;
            });
        }
    });

    $(document).on("click", ".childcheckbox-wish", function() {
        var wishlistid = $(this).attr("wishlistID");
        if ($('.childcheckbox_' + wishlistid + ':checked').length == $('.childcheckbox_' + wishlistid).length) {
            $('.select_all_' + wishlistid).prop('checked', true);
        } else {
            $('.select_all_' + wishlistid).prop('checked', false);
        }
    });
    $(document).on("click", ".select_all_wishlist", function() {
        if (this.checked) {
            $('.childCheckbox_wishlist').each(function() {
                this.checked = true;
            });
        } else {
            $('.childCheckbox_wishlist').each(function() {
                this.checked = false;
            });
        }
    });

    $(document).on("click", ".childCheckbox_wishlist", function() {
        if ($('.childCheckbox_wishlist:checked').length == $('.childCheckbox_wishlist').length) {
            $('.select_all_wishlist').prop('checked', true);
        } else {
            $('.select_all_wishlist').prop('checked', false);
        }
    });

    if ($("input[name=copyWishList]:checked").val() == "copyWishListToNew") {
        $(".form-control.copywishlist").attr('disabled', 'disabled');
        $("#newWishlist").removeAttr('disabled');
    } else if ($("input[name=copyWishList]:checked").val() == "copyWishListFromExisting") {
        $("#newWishlist").attr('disabled', 'disabled');
        $(".form-control.copywishlist").removeAttr('disabled');
    }

    $(".removewish").on("click", function() {
        var itemsid;
        var wishlistid;
        var prodArryan = [];
        $(".wishlist-table-product  input[type=checkbox]:checked").each(function(
            index
        ) {
            if ($(this).attr("itemsid") !== "") {
                if (index > 0) {
                    itemsid = itemsid + $(this).attr("itemsid");
                } else {
                    itemsid = $(this).attr("itemsid");
                }
                var temp = itemsid + ",";
                itemsid = temp;
                wishlistid = $(this).attr("wishlistid");
                var prodDet = {
                    "productQuantity": $(this).attr("quantity"),
                    "productInfo": {
                        "productID": $(this).attr("skuid"),
                        "productName": $(this).attr("description"),
                    }
                }
                prodArryan.push(prodDet);
            }
        });
        if (itemsid !== undefined) {
            var pagesize = parseInt(
                $(
                    "#wishdetails_" + wishlistid + " .selectedrteturnopt option:selected"
                ).val()
            );
            var data = {
                wishlistId: wishlistid,
                ItemsList: itemsid,
                resourcePath: $("#resourcePath").val(),
            };
            var jsonData = JSON.stringify(data);

            $.ajax({
                type: "POST",
                url: "/bin/removeMercWishlistItemServlet",
                ContentType: "application/json",
                data: {
                    data: jsonData,
                },
                beforeSend: function() {
                    $("#remove-wish-product-details").modal('hide');
                    $("#loader").removeClass("hidden");
                    $('body').addClass("backDisabled");
                    console.log("hi");
                },
                success: function(data) {
                    if (data != null && data != "") {
                        reomveWishlist = {};
                        reomveWishlist['product'] = prodArryan;
                        digitalData["removeWishlist"] = reomveWishlist;
                        _satellite.track('Remove wishlist', { linkName: $(".remove-prod").html() });
                    }
                    var msg = 'Products deleted from Wishlist successfully';
                    respMsgDisplay(200, msg);
                    getWishDetails("wishdetails_" + wishlistid, "1", pagesize);

                },
                complete: function() {
                    $("#loader").addClass("hidden");
                    $('body').removeClass("backDisabled");
                },
                error: function(e) {
                    $("#loader").addClass("hidden");
                    $('body').removeClass("backDisabled");
                },
            });
        }
    });

    $('.go-left').click(() => $(".curpage > option:selected").prev().val() && $(".curpage").val($(".curpage > option:selected").prev().val()) && $(".curpage").trigger("change"))
    $('.go-right').click(() => $(".curpage > option:selected").next().val() && $(".curpage").val($(".curpage > option:selected").next().val()) && $(".curpage").trigger("change"))

    loadCustomerWishlists();

});





function loadCustomerWishlists() {
    $(".manage-list").hide();
    var data = {
        resourcePath: $("#resourcePath").val(),
        pageSize: "0",
        currentPage: "0",
    };
    $.ajax({
        type: "GET",
        url: "/bin/getMercCustomerWishlists",
        ContentType: "application/json",
        data: {
            data: JSON.stringify(data),
        },
        beforeSend: function() {
            $("#loader").removeClass("hidden");
            $('body').addClass("backDisabled");
        },
        success: function(data) {
            if (data.customer != null || data.customer.length > 0) {
                if (null != data.customer.wishlists && data.customer.wishlists.length > 0) {
                    var wishlists = data.customer.wishlists.reverse();
                    $("#desk-wishlistdiv").empty();
                    for (var i = 0; i < wishlists.length; i++) {
                        var wishlistid = wishlists[i].id;
                        var wishlistName = wishlists[i].name;
                        $('.form-control.copywishlist').append("<option id = " + wishlistid + " value = " + wishlistName + " >" + wishlistName + "</option>");
                        console.log(">>>" + wishlistName);
                        var wishHtml = '<tr >' +
                            '<td><input class="form-check-input childCheckbox_wishlist " wishlistid="' + wishlistid + '" type="checkbox" value="" /></td>' +
                            '<td data-bs-toggle="modal" data-bs-target="#product-item" > <input type="hidden" id="' + wishlistid + '" value="' + wishlists[i].items_count + '">' +
                            '<a href="#" class="text-decoration-underline wish_prod wishdetails_' + wishlistid + ' " addedat="' + wishlists[i].added_at + '" isDefault="' + wishlists[i].isDefault + '">' + wishlists[i].name + '</a> </td>' +
                            '<td >' + data.customer.firstname + '</td>' +
                            '<td >' + formatDate(wishlists[i].added_at) + '</td>' +
                            '<td >' + wishlists[i].visibility + '</td>' +
                            '</tr>';
                        $("#desk-wishlistdiv").append(wishHtml);
                        pagination(20, 1, "wishlist_table", "curpage", "total-value");

                    }

                } else {
                    $(".total-value").empty();
                    $(".total-value").text("0 - 0 of 0 Results");
                    $("#desk-wishlistdiv").append('<tr class="warn-border"> <td></td> <td></td> <td></td> <td colspan="2" class="small no-data-text pt-3"> <div class="d-flex align-items-center"> <i> <img src="' + $("#warningIcon").val() + 'g" class="warning-img"> </i> <span><strong>Your wish list is empty. Add items by searching above or from your shopping cart.</strong></span> </div> </td> <td></td> </tr>');
                }
            } else {
                $(".total-value").empty();
                $(".total-value").text("0 - 0 of 0 Results");
                $("#desk-wishlistdiv").append('<tr class="warn-border"> <td></td> <td></td> <td></td> <td colspan="2" class="small no-data-text pt-3"> <div class="d-flex align-items-center"> <i> <img src="' + $("#warningIcon").val() + 'g" class="warning-img"> </i> <span><strong>Your wish list is empty. Add items by searching above or from your shopping cart.</strong></span> </div> </td> <td></td> </tr>');
            }
        },
        complete: function() {
            $("#loader").addClass("hidden");
            $('body').removeClass("backDisabled");
        },
        error: function(e) {
            $("#loader").addClass("hidden");
            $('body').removeClass("backDisabled");
            console.log(e);
        }
    });
}

function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();
    if (month.length < 2)
        month = '0' + month;
    if (day.length < 2)
        day = '0' + day;
    return [day, month, year].join('-');
}

//product details
var itemscountvar;
var splitvalue = 1;
var selectedvalue = 20;
$(document).on("click", ".wish_prod", function() {
    $(".mm-wishlist-details").hide();
    $(".wish-product").html("");
    $(".mm-wishlist-product-details").removeClass("d-none");

    var classvalue = $(this).attr("class");
    var parentid = classvalue.split(" ")[2];
    var prodId = parentid.split("_")[1];
    $(".mm-wishlist-product-details").attr('id', parentid);

    $(".product_table_det").attr('id', 'refreshDiv_' + prodId);
    $(".createdOn").html("");
    $(".createdOn").html("Created On " + formatDate($(this).attr('addedat')));
    var page = 1;
    var pagesize = $("#" + parentid + " .selectedrteturnopt option:selected").val();
    getWishDetails(parentid, page, pagesize);
});

function getUrl(pdplink, urlKey, prop65) {
    var obj = {};
    if (pdplink == null || pdplink == "" || urlKey == null || urlKey == "") {
        obj.url = "/content/ecommerce/merclink/us/en/home.html";
    } else {
        obj.url = pdplink + ".html/" + urlKey + ".html";
    }
    var warnings = {
        Cancer: "cancer",
        "Cancer and Reproductive Harm": "cancerandreproductiveharm",
        "Reproductive Harm": "reproductiveharm",
        "N": "reproductiveharm",
        "001": "cancer",
        "003": "cancerandreproductiveharm",
        "002": "reproductiveharm",
        "Yes": "cancerandreproductiveharm",
    };
    obj.warn = warnings[prop65];
    return obj;
}

function getval(value) {
    if (value == null || typeof value == null) return "";
    else return value;
}

function removeComma1(minimum) {
    if ($(minimum).val() != undefined && $(minimum).val() != null) {
        $(minimum).val(toNumeric($(minimum).val()));
        temp = toNumeric($(minimum).val()).toString();
    }
}

function toInternationalFormat(numb) {
    if (numb != undefined && numb != null)
        return numb.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
}

function toNumeric(numb) {
    if (numb != undefined && numb != null)
        return parseInt(numb.toString().replace(/[^0-9\.]+/g, ""));
}

//update function for product
$(document).on("focusout", ".number-product", function() {
    if (
        $(this).val() == "" &&
        $("#componentPath").val() === $("#resourcePath").val()
    ) {
        $(this).val("1");
    }
});

var map = {};
var finalMap = {};
var commentMap = {};
var temp = "";

function setDefaultQty(minimum) {
    var minval = $(minimum).attr("minqty");
    if (minval) {
        var changedVal = toNumeric($(minimum).val()).toString();
        var check_val_type = changedVal.split(".");

        if (check_val_type.length > 1) {
            $(minimum).val(toInternationalFormat(minval));
            $(minimum).attr("value", toInternationalFormat(minval));
        } else {
            if (changedVal <= 1) {
                $(minimum).val(toInternationalFormat(minval));
                $(minimum).attr("value", toInternationalFormat(minval));
            } else if (changedVal != minval) {
                var val = changedVal / minval;
                var totalVal = Math.ceil(val) * minval;
                if (totalVal > 9999999) {
                    totalVal -= minval;
                }
                $(minimum).val(toInternationalFormat(totalVal));
                $(minimum).attr("value", toInternationalFormat(totalVal));
            } else {
                $(minimum).val(toInternationalFormat(minval));
            }
        }
        if ($(minimum).val() != "") {
            if (temp != toNumeric($(minimum).val()).toString()) {
                let id = "#" + $(minimum).attr("id");
                setTimeout(function() {
                    map[$(minimum).attr("itemsid")] = toNumeric(
                        $(minimum).val()
                    ).toString();
                    $(".addlist-to-cart_" + $(minimum).attr("wishlistid")).text("Update");
                }, 100);
            }
        }
    }
}

function changeButtonText(prodRow) {
    var qtyjsnon = {}
    if ($("." + prodRow).val() != "") {
        let id = "#" + $("." + prodRow).attr("id");
        if (finalMap.length != 0) {
            if ($(id).attr("itemsid") in finalMap) {
                finalMap[$(id).attr("itemsid")]["quantity"] = toNumeric($(id).val()).toString();
            } else {
                qtyjsnon["wishlistItemId"] = $(id).attr("itemsid");
                qtyjsnon["quantity"] = toNumeric($(id).val()).toString();
                finalMap[$(id).attr("itemsid")] = qtyjsnon;

            }
            console.log($(id).attr("itemsid") in finalMap);
            console.log(finalMap);
        } else {
            qtyjsnon["wishlistItemId"] = $(id).attr("itemsid");
            qtyjsnon["quantity"] = toNumeric($(id).val()).toString();
            finalMap[$(id).attr("itemsid")] = qtyjsnon;
            console.log(finalMap);
        }
        $(".addlist-to-cart_" + $(id).attr("wishlistid")).text("Update");
        $(".addlist-to-cart_" + $(id).attr("wishlistid")).addClass("quantity-update-call");
    }
}

function commentCartUpdate(prodRow) {
    commentjsnon = {};
    if (finalMap.length != 0) {
        if ($("." + prodRow).attr("itemsid") in finalMap) {
            finalMap[$("." + prodRow).attr("itemsid")]["comment"] = $("." + prodRow).val();

        } else {
            commentjsnon["wishlistItemId"] = $("." + prodRow).attr("itemsid");
            commentjsnon["comment"] = $("." + prodRow).val();
            finalMap[$("." + prodRow).attr("itemsid")] = commentjsnon;


        }
        console.log($("." + prodRow).attr("itemsid") in finalMap);
        console.log(finalMap);
    } else {
        commentjsnon["wishlistItemId"] = $("." + prodRow).attr("itemsid");
        commentjsnon["comment"] = $("." + prodRow).val();
        finalMap[$("." + prodRow).attr("itemsid")] = commentjsnon;
        console.log(finalMap);
    }
    $(".addlist-to-cart_" + $("." + prodRow).attr("wishlistid")).text("Update");

    $(".addlist-to-cart_" + $("." + prodRow).attr("wishlistid")).addClass("comment-update-call");
    $(".addlist-to-cart_" + $("." + prodRow).attr("wishlistid")).attr("CommentClass", prodRow);

}

function updateProductDetails(data) {
    var jsonData = JSON.stringify(data);
    console.log("final-data-comt-->" + jsonData);
    $.ajax({
        type: "POST",
        url: "/bin/addMercCommentWishlistServlet",
        ContentType: "application/json",
        data: {
            data: jsonData,
        },
        beforeSend: function() {
            $("#loader").removeClass("hidden");
            $('body').addClass("backDisabled");
        },
        success: function(data) {
            var msg = 'Updated Successfully';
            respMsgDisplay(200, msg);
        },
        complete: function() {
            $("#loader").addClass("hidden");
            $('body').removeClass("backDisabled");
        },
        error: function(e) {
            $("#loader").addClass("hidden");
            $('body').removeClass("backDisabled");
            console.log(e);
        },
    });
    $(".add-list-cart").text("Add To Cart");

    $(".add-list-cart").removeClass("comment-update-call");
    $(".add-list-cart").removeAttr("CommentClass");
    $(".add-list-cart").removeClass("quantity-update-call");

}
//global error/success msg
function respMsgDisplay(statusCode, message, ) {
    if (statusCode == 200) {
        $(".mm-success-msg span").empty();
        $(".mm-success-msg span").text("" + message + "");    
        $(".mm-success-msg").removeClass("d-none");    
        $(".mm-success-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-success-msg").offset().top
        }, 'slow');    
        setTimeout(function() {       $(".mm-success-msg").fadeOut("slow");     }, 3000);
    } else if (statusCode == 202) {
        $(".mm-error-msg span").empty();
        $(".mm-error-msg span").text("" + message + "");    
        $(".mm-error-msg").removeClass("d-none");
        $(".mm-error-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-error-msg").offset().top
        }, 'slow');    
        setTimeout(function() {       $(".mm-error-msg").fadeOut("slow");     }, 3000);
    }
}
$(document).on("click", ".add-list-cart", function() {

    var buttontext = $(this).text();
    var product = [];
    var addToCart = {};
    var fb = {
        content_category: "My Wish List",
    };
    var content = [];
    if (buttontext == "Add To Cart") {
        var cartArray = new Array();
        $(".product_table_det  input[type=checkbox]:checked").each(function() {
            var itemsid = $(this).attr("itemsid");
            var cartObj = {
                skuid: $(this).attr("skuid"),
                quantity: toNumeric($(".number-product-" + itemsid).val()).toString(),

            };
            cartArray.push(cartObj);
        });
        console.log(JSON.stringify(cartArray));
        if (cartArray.length == 0) {
            var msg = 'Please select at least one product to add to cart';
            respMsgDisplay(202, msg);

        } else {
            var data = {
                "componentPath": $("#resourcePath").val(),
                cartId: getCookie("cartId"),
                cartobj: cartArray
            }
            $.ajax({
                type: "POST",
                url: "/bin/cart/addToCartQuery",
                ContentType: "application/json",
                dataType: "json",
                data: {
                    'data': JSON.stringify(data)
                },
                beforeSend: function() {
                    $("#loader").removeClass("hidden");
                    $('body').addClass("backDisabled");
                },
                success: function(data) {
                    console.log(data);
                    if (data.addProductsToCart.cart && data.addProductsToCart.cart.items && data.addProductsToCart.cart.items.length > 0) {
                        console.log(data.addProductsToCart.cart.items.length);
                        $(".cart-item-display-number").html(data.addProductsToCart.cart.items.length);
                        setCookie("cartCount", data.addProductsToCart.cart.items.length, 30);
                        var sendSkuId = cartArray.map(element => element.skuid);
                        var matchedCartItemArray = data.addProductsToCart.cart.items.filter(element => sendSkuId.indexOf(element.product.sku) != -1);
                        var matchedCartItem = matchedCartItemArray.map(element => element.product.sku);
                        if (matchedCartItem.length > 0) {
                            var msg = 'Item(s) have been added/updated to Cart: ' + matchedCartItem.join().toString();
                            var productDetailsArray = [];
                            matchedCartItemArray.forEach((element, indexe) => {
                                var quantityFilter = cartArray.filter(cartElement => cartElement.skuid == element.product.sku);
                                var productDetails = {
                                    "productQuantity": quantityFilter.length > 0 ? quantityFilter[0].quantity : 0,
                                    "productInfo": {
                                        "productID": element.product.sku,
                                        "productName": element.product.name,
                                    }
                                };
                                productDetailsArray.push(productDetails);
                            });

                            addToCartlist = {};
                            addToCartlist['product'] = productDetailsArray;
                            digitalData["addtoCart"] = addToCartlist;
                            _satellite.track('Add to cart', { linkName: $(".add-list-cart").html() });
                            respMsgDisplay(200, msg);
                        }
                    }

                },
                complete: function() {
                    $("#loader").addClass("hidden");
                    $('body').removeClass("backDisabled");
                },
                error: function(status, errorthrown) {
                    $("#loader").addClass("hidden");
                    $('body').removeClass("backDisabled");
                    var msg = 'Something went wrong. Please try again later.';
                    respMsgDisplay(200, msg);
                }
            });
        }
    } else if (buttontext == "Update") {
        if ($(".add-list-cart").hasClass('comment-update-call') || $(".add-list-cart").hasClass('quantity-update-call')) {
            var finalArray = [];
            $.each(finalMap, function(index, element) {
                console.log(element);
                finalArray.push(element);
            });
            console.log(finalArray);
            //let updatedArray = qtyArray.map((item, i) => Object.assign({}, item, commetArray[i]));
            var data = {
                wishlistId: $(this).attr("wishlistid"),
                wishlistItemId: "",
                updateDtlsArray: finalArray,
                resourcePath: $("#resourcePath").val(),
            };
            console.log("comment" + JSON.stringify(finalArray));
            updateProductDetails(data);
        }
    }
});


//end

$(document).on("click", ".wishlist-qty-increment-list", function() {
    let id = $(this).attr("id");
    let id_no = id.substring(27);
    let min_qty = 1;
    if (
        $(this).parent().parent().find("input[type=text]").attr("minqty") &&
        $(this).parent().parent().find("input[type=text]").attr("minqty") != "0"
    ) {
        min_qty = parseInt(
            $(this).parent().parent().find("input[type=text]").attr("minqty")
        );
    }
    id = "#item-qty-" + id_no;

    let qty_val = toNumeric($(id).val()).toString();
    if (qty_val == "") {
        qty_val = min_qty;
    }
    qty_val = parseInt(qty_val);

    if (qty_val + min_qty <= 9999999) {
        qty_val = qty_val + min_qty;

        $(id).val(toInternationalFormat(qty_val)).trigger("change");
        $(id).attr("value", toInternationalFormat(qty_val));
    }
});

$(document).on("click", ".wishlist-qty-decrement-list", function() {
    let id = $(this).attr("id");
    let id_no = id.substring(29);

    id = "#item-qty-" + id_no;
    let min_qty = 1;
    if (
        $(this).parent().parent().find("input[type=text]").attr("minqty") &&
        $(this).parent().parent().find("input[type=text]").attr("minqty") != "0"
    ) {
        min_qty = parseInt(
            $(this).parent().parent().find("input[type=text]").attr("minqty")
        );
    }
    let qty_val = toNumeric($(id).val());
    if (qty_val == "") {
        qty_val = min_qty;
    }
    qty_val = parseInt(qty_val);
    if (qty_val > min_qty) {
        qty_val = qty_val - min_qty;
        $(id).val(toInternationalFormat(qty_val));
        $(id).val(toInternationalFormat(qty_val)).trigger("change");
        $(id).attr("value", toInternationalFormat(qty_val));
    }
});

//end

function getWishDetails(parentid, page, pagesize) {

    var wishid = parentid.split("_")[1];
    var data = {
        pageSize: pagesize,
        currentPage: page,
        wishlistid: wishid,
    };
    var jsonData = JSON.stringify(data);
    $.ajax({
        type: "POST",
        url: "/bin/WishlistMercDetailsServlet",
        ContentType: "application/json",
        data: {
            data: jsonData,
            resourcePath: $("#resourcePath").val(),
        },
        beforeSend: function() {
            $("#loader").removeClass("hidden");
            $('body').addClass("backDisabled");
        },
        success: function(data) {
            console.log("new-data  => " + data.customer);
            if (data != null && data.customer != null) {
                $(".wish-product").html(data.customer.wishlist_v2.name + '  <a href="#" class="ms-3 manage-wish-list">Edit</a>');
                $(".manage-wish-list").attr("wishlistid", wishid);
                $(".manage-wish-list").attr("wishlistname", data.customer.wishlist_v2.name);
                $(".manage-wish-list").attr("visibility", data.customer.wishlist_v2.visibility);
                $(".add-list-cart").attr("wishlistid", wishid);
                $(".wishlistpagination").attr("wishlistid", wishid);
                $(".selectedrteturnopt").attr("wishlistid", wishid);
                $(".exportalllink").attr("wishlistid", wishid);
                $(".exportAll").attr("wishlistid", wishid);
                $(".add-list-cart").addClass("addlist-to-cart_" + wishid);
                $(".select_all").addClass("select_all_" + wishid);
                $(".select_all").attr("wishlistid", wishid);
                $('.select_all').prop('checked', false);
                var itemslen = data.customer.wishlist_v2.items_count;
                $("#" + parentid + " .wishlistshow-top  option:last").attr("value", itemslen);
                $("#" + parentid + " .wishlistshow-bottom  option:last").attr("value", itemslen);
                if (page == "1") {
                    getpagination(parentid, itemslen);
                }
                $("#refreshDiv_" + wishid).empty();
                var count = 0;
                $.each(data.customer.wishlist_v2.items_v2.items, function(key, val) {

                    var i = 0;
                    var url = val.product.product_data_custom_[0].warning_message_custom_;
                    var prop_code = val.product.masterpartprop65code_custom_;
                    if (prop_code != undefined && prop_code != "" && prop_code != null) {
					var prop65_msg = '<i> <img src="/content/dam/merclink/images/warning.svg" class="warning-img"> </i> <span><strong>WARNING</strong>: '+prop_code+' - <a href="www.P65Warnings.ca.gov" target="_blank">www.P65Warnings.ca.gov</a></span>';
                    }else{
                        var prop65_msg = "";
                    }
                    if (url != undefined && url != "" && url == "1") {
                        var warningtext = '<i> <img src="' + $("#warningIcon").val() + '" class="warning-img"> </i> <span>Hazardous goods. AIR Freight prohibited.</span>';
                    } else {
                        var warningtext = "";
                    }
                    var name = "description =" + "'" + getval(val.product.name) + "'";
                    let lowestqty =
                        val.product.masterpartlowestsellinguomqty_custom_ &&
                        val.product.masterpartlowestsellinguomqty_custom_ != "0" ?
                        val.product.masterpartlowestsellinguomqty_custom_ :
                        1;
                    if (typeof warningtext == "undefined") {
                        $("#refreshDiv_" + wishid).append(
                            '<tr class="wishlist-table-product table-wish-' + wishid + ' wishcontainer-' + i + '"><input type="hidden" class="itemscount" value="' + itemslen + '" /><td><input class="form-check-input childcheckbox-wish childcheckbox_' + wishid + '" wishlistID="' + wishid + '" ' + name + ' itemsID="' + val.id + '" skuid="' + val.product.sku + '" quantity="' + val.quantity + '" typename="' + val.product.__typename + '" type="checkbox" value="" /></td><td class="pd-item-no"><a href="' + $("#PdpUrl").val() + '?sku=' + val.product.sku + '"><label class="itemno-' + wishid + "-" + count + '" prop65="' + val.product.masterpartprop65code_custom_ + '">' + val.product.sku + '</label></a></td><td><a href="' + $("#PdpUrl").val() + '?sku=' + val.product.sku + '"><label class="list-name-p  listname-' + wishid + "-" + count + '" data-sku= "' + val.product.sku + '" id="des-' + val.id + '">' + val.product.name + '</label></a></td><td class="mm-qty-txt"> <div class="input-group mm-quantity "> <input type="number" name="quantity" maxlength="7" onchange="changeButtonText(\'number-product-' + val.id + '\')" class="form-control input-number comma-international number-product number-product-' + val.id + '" value="' + val.quantity + '" wishlistid="' + wishid + '" ' + name + ' itemsid="' + val.id + '" step="' + lowestqty + '" minqty = "' + lowestqty + '" id="item-qty-' + count + '" onKeyPress="return (this.value.length<=6 && event.charCode > 47 && event.charCode< 58);" max="9999999" onpaste="return false;" ondrop="return false;" autocomplete="off"  oninput="validity.valid||(value=1);" min="' + lowestqty + '" onclick="removeComma1(this)" onfocusout=" this.value=="" ? this.value = ' + lowestqty + ' : "" ; this.value % ' + lowestqty + ' || this.value == 0  ?  this.value = (parseInt(this.value,10)+(' + lowestqty + '-(parseInt(this.value,10) % ' + lowestqty + ' )))  : "" ; "> </div> </td><td class="mm-comment-txt"> <div class="row m-0"> <div class="col-md-12 "> <input type="text" placeholder="Add Comment..." wishlistid="' + wishid + '" onkeydown="commentCartUpdate(\'commentfield_' + val.id + '\')" oninput="commentCartUpdate(\'commentfield_' + val.id + '\')" itemsid="' + val.id + '" value="' + getval(val.description) + '" class="form-control commentfield_' + val.id + '"> </div> </div> </td><tr class="warn-border add-comment"> <td></td> <td></td> <td colspan="2" class="small pt-0"> <div class="d-flex align-items-center"> ' + warningtext + '</span> </div><div class="d-flex align-items-center"> ' + prop65_msg + '</span> </div> </td> <td> </td> </tr>'

                        );
                        count++;
                    } else {
                        $("#refreshDiv_" + wishid).append(
                            '<tr class="wishlist-table-product table-wish-' + wishid + ' wishcontainer-' + i + '"><input type="hidden" class="itemscount" value="' + itemslen + '" /><td><input class="form-check-input childcheckbox-wish childcheckbox_' + wishid + '" wishlistID="' + wishid + '" ' + name + ' itemsID="' + val.id + '" skuid="' + val.product.sku + '" quantity="' + val.quantity + '" typename="' + val.product.__typename + '" type="checkbox" value="" /></td><td class="pd-item-no"><a href="' + $("#PdpUrl").val() + '?sku=' + val.product.sku + '"><label class="itemno-' + wishid + "-" + count + '" prop65="' + val.product.masterpartprop65code_custom_ + '">' + val.product.sku + '</label></a></td><td><a href="' + $("#PdpUrl").val() + '?sku=' + val.product.sku + '"><label class="list-name-p listname-' + wishid + "-" + count + '" data-sku= "' + val.product.sku + '"  id="des-' + val.id + '">' + val.product.name + '</label></a></td><td class="mm-qty-txt"> <div class="input-group mm-quantity "> <input type="number" name="quantity" maxlength="7" onchange="changeButtonText(\'number-product-' + val.id + '\')" class="form-control input-number comma-international number-product number-product-' + val.id + '" value="' + val.quantity + '" wishlistid="' + wishid + '" ' + name + ' itemsid="' + val.id + '" step="' + lowestqty + '" minqty = "' + lowestqty + '" id="item-qty-' + count + '" onKeyPress="return (this.value.length<=6 && event.charCode > 47 && event.charCode< 58);" max="9999999" onpaste="return false;" ondrop="return false;" autocomplete="off"  oninput="validity.valid||(value=1);" min="' + lowestqty + '" onclick="removeComma1(this)" onfocusout=" this.value=="" ? this.value = ' + lowestqty + ' : "" ; this.value % ' + lowestqty + ' || this.value == 0  ?  this.value = (parseInt(this.value,10)+(' + lowestqty + '-(parseInt(this.value,10) % ' + lowestqty + ' )))  : "" ; ">  </div> </td><td class="mm-comment-txt"> <div class="row m-0"> <div class="col-md-12 "> <input type="text" placeholder="Add Comment..." wishlistid="' + wishid + '" onkeydown="commentCartUpdate(\'commentfield_' + val.id + '\')" oninput="commentCartUpdate(\'commentfield_' + val.id + '\')" itemsid="' + val.id + '" value="' + getval(val.description) + '" class="form-control commentfield_' + val.id + '"> </div> </div> </td><tr class="warn-border add-comment"> <td></td> <td></td> <td colspan="2" class="small pt-0"> <div class="d-flex align-items-center"> ' + warningtext + '</span> </div><div class="d-flex align-items-center"> ' + prop65_msg + '</span> </div> </td> <td> </td> </tr>'


                        );
                        count++;
                    }
                    i++;
                });
            }
            if (data.customer.wishlist_v2.items_count == 0) {
                $("#refreshDiv_" + wishid).append('<tr class="warn-border"> <td></td> <td></td> <td></td> <td colspan="2" class="small no-data-text pt-3"> <div class="d-flex align-items-center"> <i> <img src="' + $("#warningIcon").val() + '" class="warning-img"> </i> <span><strong>Your wish list is empty. Add items by searching above or from your shopping cart.</strong></span> </div> </td> <td></td> </tr>');
            }
            $(".comma-international").each(function() {
                $(this).val(toInternationalFormat($(this).val()));
            });
            if ($("." + parentid).attr("isdefault") == "true") {
                $(".manage-list").hide();
            } else {
                $(".manage-list").show();

            }
        },
        complete: function() {
            $("#loader").addClass("hidden");
            $('body').removeClass("backDisabled");
        },
        error: function(e) {
            $("#loader").addClass("hidden");
            $('body').removeClass("backDisabled");
            if (page == "1") {
                // selected page val
                getpagination(parentid, "1");
            } else {
                $(".wishlistshow").val(itemscountvar);
            }
        },
    });
}

//edit popup and update wishlist name
$(document).on("click", ".manage-wish-list", function() {
    $("#edit-wishlist").modal("show");
    $(".update-button-wish").attr("wishlistid", $(this).attr("wishlistid"));
    $(".update-button-wish").attr("wishlistname", $(this).attr("wishlistname"));
    $(".delete-wish").attr("wishlistid", $(this).attr("wishlistid"));

    $("#editListname").val($(this).attr("wishlistname"));

    $(".update-button-wish").attr("visibility", $(this).attr("visibility"));
    if ($(this).attr("visibility") == "PUBLIC") {
        $("#public").prop("checked", true);
    } else {
        $("#private").prop("checked", true);
    }
});

$(document).on("click", ".update-button-wish", function() {
    var custToken = getCookie("customerToken");
    if (custToken === null || custToken == "") {
        // display session expired
    }
    if ($("#editListname").val().trim() !== "") {
        var id = $(this).attr("wishlistid");
        var data = {
            wishlistName: $("#editListname").val().trim(),
            wishlistId: $(this).attr("wishlistid"),
            visibility: $('input[name="optradio"]:checked').val(),
            resourcePath: $("#resourcePath").val(),
        };
        var jsonData = JSON.stringify(data);

        $.ajax({
            type: "POST",
            url: "/bin/updateMercWishlistServlet",
            ContentType: "application/json",
            data: {
                data: jsonData,
            },
            beforeSend: function() {
                $("#loader").removeClass("hidden");
                $('body').addClass("backDisabled");
            },
            success: function(data) {
                if (
                    data.alreadyExistError != null &&
                    data.alreadyExistError != undefined
                ) {
                    $("#edit-wishlist").modal("hide");
                    var msg = "" + data.alreadyExistError + "";
                    respMsgDisplay(202, msg);
                } else {
                    $("#edit-wishlist").modal("hide");
                    var msg = "Wishlist Updated Successfully";
                    respMsgDisplay(200, msg);
                    $(".update-button-wish").attr("wishlistname", data.wishlistName);
                    $(".update-button-wish").attr("visibility", data.visibility);
                    $(".manage-wish-list").attr("wishlistname", data.wishlistName);
                    $(".manage-wish-list").attr("visibility", data.visibility);
                    $span = $('.wish-product').find('a')
                    $('.wish-product').text(data.wishlistName);
                    $('.wish-product').append($span);
                }
            },
            complete: function() {
                $("#loader").addClass("hidden");
                $('body').removeClass("backDisabled");
            },
            error: function(e) {
                $("#loader").addClass("hidden");
                $('body').removeClass("backDisabled");
            },
        });
    } else {
        var msg = "Please enter name of wish List to edit";
        respMsgDisplay(202, msg);
    }
});

//wishlist copy function
$(document).on("click", ".copywishlist-link", function() {
    var count = 0;
    $('.product_table_det input[type=checkbox]:checked').each(function() {
        count = count + 1;
    });
    if (count > 0) {
        $('#add-to-wishlist').modal('show');
    } else {
        var msg = "Please select at least one product to copy to other wish list";
        respMsgDisplay(202, msg);
    }

});
//end
//pagination
$(document).on("change", ".wishlistshow", function() {
    var parentid = "wishdetails_" + $(this).attr("wishlistid");
    $("#" + parentid + " .wishlistshow").val($(this).val());
    var currentpage = parseInt(
        $("#" + parentid + " .selectedrteturnopt option:selected").val()
    );
    getWishDetails(parentid, "1", currentpage);
});

$(document).on("change", ".wishlistpagination", function() {
    var parentid = "wishdetails_" + $(this).attr("wishlistid");

    $("#" + parentid + " .wishlistpagination").val($(this).val());
    var currentpage = $("#" + parentid + " .wishlistpagination option:selected")
        .val()
        .split(" ")[0];
    var pagesize = parseInt(
        $("#" + parentid + " .selectedrteturnopt option:selected").val()
    );
    var totalvalue = $(".itemscount").val();
    if (currentpage != null && pagesize != null) {
        var start = (parseInt(pagesize) * (parseInt(currentpage) - 1)) + 1;
        if (totalvalue <= 20) {
            var end = totalvalue;
        } else {
            var end = parseInt(pagesize) + (start - 1) > totalvalue ? totalvalue :
                parseInt(pagesize) + (start - 1);
        }

        $(".resultDisplay").html("");
        $(".resultDisplay").html(start + " - " + end + " of " + totalvalue + " Results");
    }
    getWishDetails(parentid, currentpage, pagesize);
});


function getpagination(parentid, totalvalue) {
    var selectedpagevalue = $(
        "#" + parentid + " .wishlistpagination option:selected"
    ).val();
    if (selectedpagevalue) {
        splitvalue = parseInt(selectedpagevalue.substring(0, 1));
    } else {
        splitvalue = 1;
    }
    selectedvalue = parseInt(
        $("#" + parentid + " .selectedrteturnopt option:selected").val()
    );
    var lengthvalue = totalvalue / selectedvalue;
    lengthvalue = Math.ceil(lengthvalue);

    $("#" + parentid + " .wishlistpagination").empty();
    for (var i = 1; i < lengthvalue + 1; i++) {
        $("#" + parentid + " .wishlistpagination").append(
            '<option value="' +
            i +
            " of " +
            lengthvalue +
            '">' +
            i +
            " of " +
            lengthvalue +
            "</option>"
        );
    }
    if (lengthvalue == 0) {
        $("#" + parentid + " .wishlistpagination").append(
            '<option value=1">1 of 1</option>'
        );
    }
    $(".resultDisplay").empty();
    var page = $("#" + parentid + " .wishlistpagination option:selected")
        .val()
        .split(" ")[0];
    if (page != null && selectedvalue != null && totalvalue != 0) {
        var start = (parseInt(selectedvalue) * (parseInt(page) - 1)) + 1;
        if (totalvalue <= 20) {
            var end = totalvalue;
        } else {
            var end = parseInt(selectedvalue) + (start - 1) > totalvalue ? totalvalue :
                parseInt(selectedvalue) + (start - 1);
        }
        $(".resultDisplay").html("");
        $(".resultDisplay").html(start + " - " + end + " of " + totalvalue + " Results");
    } else if (totalvalue == 0) {
        $(".resultDisplay").html("0 - 0 of 0 Results");
    }
}



//export PDF function
function getPDF2() {
    var d = jQuery.Deferred(),
        p = d.promise();
    p.pipe(generatePdf2)
    d.resolve();
}

function generatePdf2() {
    $("#export-wishlist").modal('hide');
    kendo.drawing.drawDOM($('#wishlist_container123'), {
        paperSize: "A4",
        margin: {
            left: "0.6cm",
            top: "1.25cm",
            right: "0.6cm",
            bottom: "1cm"
        },
        scale: 0.6,
        multiPage: true,
        landscape: true,
        repeatHeaders: false,
        template: $("#page-template-2").html(),
        forcePageBreak: ".page-break"
    }).then(function(group) {

        kendo.drawing.pdf.saveAs(group, "MyWishlist.pdf");
    }).then(function() {
        $('#export-wishlist').css('opacity', '1');
        $("#export-wishlist").modal('hide');
    });
}

//export CSV Function
function convertToCSV(objArray) {
    var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
    var str = '';

    for (var i = 0; i < array.length; i++) {
        var line = '';
        for (var index in array[i]) {
            if (line != '') line += ','

            line += array[i][index];
        }

        str += line + '\r\n';
    }

    return str;
}

function exportCSVFile(headers, items, fileTitle) {
    if (headers) {
        items.unshift(headers);
    }

    // Convert Object to JSON
    var jsonObject = JSON.stringify(items);

    var csv = this.convertToCSV(jsonObject);

    var exportedFilenmae = fileTitle + '.csv' || 'export.csv';

    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    if (navigator.msSaveBlob) { // IE 10+
        navigator.msSaveBlob(blob, exportedFilenmae);
    } else {
        var link = document.createElement("a");
        if (link.download !== undefined) { // feature detection
            // Browsers that support HTML5 download attribute
            var url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", exportedFilenmae);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }
}

var headers = {
    ItemNumber: "Item Number",
    ItemDescription: "Item Description",
    Qantity: "Quantity",
    Comments: "description",
    prop65: "Prop65 Message",
};

var fileTitle = 'Wishlist Products';

var itemsFormatted = [];

function getWishDetailsExport(parentid, page, pagesize) {
    var wishid = parentid;
    var data = {
        pageSize: pagesize,
        currentPage: page,
        wishlistid: wishid,
    };
    var jsonData = JSON.stringify(data);
    $.ajax({
        type: "POST",
        url: "/bin/WishlistMercDetailsServlet",
        ContentType: "application/json",
        data: {
            data: jsonData,
            resourcePath: $("#resourcePath").val(),
        },
        beforeSend: function() {
            $("#loader").removeClass("hidden");
            $('body').addClass("backDisabled");
        },
        success: function(data) {
            console.log("new-data  => " + JSON.stringify(data.customer.wishlist_v2.items_v2.items));
            if (data != null && data.customer != null) {
                var itemslen = data.customer.wishlist_v2.items_count;
                console.log(data.customer.wishlist_v2.items_count)
                $.each(data.customer.wishlist_v2.items_v2.items, function(key, val) {

                    var i = 0;

                    var url = val.product.product_data_custom_[0].warning_message_custom_;
                    if (url != undefined && url != "" && url == "1") {
                        var warningtext = '<i> <img src="' + $("#warningIcon").val() + '" class="warning-img"> </i> <span>Hazardous goods. AIR Freight prohibited.</span>';
                    } else {
                        var warningtext = "";
                    }
                    var name = "description =" + "'" + getval(val.product.name) + "'";
                    itemsFormatted.push({
                        ItemNumber: val.product.sku,
                        ItemDescription: val.product.name,
                        Qantity: val.quantity,
                        Comments: getval(val.description),
                        prop65: warningtext,
                    });


                });
                exportCSVFile(headers, itemsFormatted, fileTitle);
            }

        },
        complete: function() {
            $("#loader").addClass("hidden");
            $('body').removeClass("backDisabled");
        },
        error: function(e) {
            $("#loader").addClass("hidden");
            $('body').removeClass("backDisabled");
            if (page == "1") {
                // selected page val
                getpagination(parentid, "1");
            } else {
                $(".wishlistshow").val(itemscountvar);
            }
        },
    });
}





function download_table_as_csv(table_id, separator = ',') {
    var rows = document.querySelectorAll('table#' + table_id + ' tr');
    var csv = [];
    for (var i = 0; i < rows.length; i++) {
        var row = [],
            cols = rows[i].querySelectorAll('td, th');

        for (var j = 0; j < cols.length; j++) {
            if (i >= 1 && cols[0].children.length > 0 && cols[0].children[0].checked) {
                if (cols[j].children.length > 0) {
                    if (i >= 1 && j == 3) {
                        row.push(cols[j].children[0].children[0].value);
                    } else if (i >= 1 && j == 4) {
                        row.push(cols[j].children[0].children[0].children[0].value);
                    } else {
                        row.push(cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ').replace(/"/g, '""'));
                    }
                } else {
                    var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
                    data = data.replace(/"/g, '""');
                    row.push('"' + data + '"');
                }
            } else if (i == 0) {
                var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
                data = data.replace(/"/g, '""');
                row.push('"' + data + '"');
            }
        }
        csv.push(row.join(separator));
    }
    var csv_string = csv.join('\n');
    console.log(csv_string);
    // Download it
    var filename = 'export_' + table_id + '_' + new Date().toLocaleDateString() + '.csv';
    var link = document.createElement('a');
    link.style.display = 'none';
    link.setAttribute('target', '_blank');
    link.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv_string));
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

//move/copy wishlist
$(document).on("click", "#saveCopywhishlist", function() {
    var count = 0;
    var cartArray = new Array();
    var sourcewishlistid;
    if ($(".childcheckbox-wish:checked").length > 0) {
        $(".childcheckbox-wish:checked").each(function() {
            let checkbox_sku = $(this).attr("itemsid");
            let qty = toNumeric($(this).attr("quantity")).toString();
            sourcewishlistid = $(this).attr("wishlistid");

            var cartObj = {
                wishlistItemId: checkbox_sku,
                quantity: qty,
            };
            cartArray.push(cartObj);

            count++;
        });
        if (cartArray.length > 0) {
            var data = "";
            if (
                $("input[name=copyWishList]:checked").val() == "copyWishListToNew"
            ) {
                data = {
                    sourceWishlistUid: sourcewishlistid,
                    destinationWishlistUid: "",
                    wishlisttype: "new",
                    listtype: $("input[name=copynewwishlistRdo]:checked").val(),
                    wishlistname: $("#newWishlist").val(),
                    items: cartArray,
                    resourcePath: $("#resourcePath").val(),
                };
            } else if (
                $("input[name=copyWishList]:checked").val() ==
                "copyWishListFromExisting"
            ) {
                data = {
                    sourceWishlistUid: sourcewishlistid,
                    destinationWishlistUid: $(".copywishlist")
                        .find(":selected")
                        .attr("id"),
                    wishlisttype: "existing",

                    items: cartArray,
                    resourcePath: $("#resourcePath").val(),
                };
            }
            var jsonData = JSON.stringify(data);
            console.log(jsonData);
            $.ajax({
                type: "POST",
                url: "/bin/copyMercItemToWishlist",
                ContentType: "application/json",
                data: {
                    data: jsonData,
                },
                beforeSend: function() {
                    $("#loader").removeClass("hidden");
                    $('body').addClass("backDisabled");
                },
                success: function(data) {
                    if (data.alreadyExists) {
                        $('#add-to-wishlist').modal('hide');
                        var msg = 'Wishlist already exists';
                        respMsgDisplay(202, msg);
                    } else {
                        $('#add-to-wishlist').modal('hide');
                        //analytics
                        if (data != null && data.wishlisttype != true) {
                            var productDetailsArray = [];
                            data.items.forEach((element, index) => {
                                var product = {
                                    "productQuantity": element.quantity,
                                    "productInfo": {
                                        "productID": $("#des-" + element.wishlistItemId).data("sku"),
                                        "productName": $("#des-" + element.wishlistItemId ).html(),
                                    }
                                };

                                productDetailsArray.push(product);

                            });

                            copywishlist = {};
                            copywishlist['product'] = productDetailsArray;
                            digitalData["addtoWishlist"] = copywishlist;
                            _satellite.track('Add to wishlist', { linkName: $(".copywishlist-link").html() });
                        }
                        var msg = 'Items have been successfully copied between wishlists';
                        respMsgDisplay(200, msg);
                    }
                },
                complete: function() {
                    $("#loader").addClass("hidden");
                    $('body').removeClass("backDisabled");
                },
                error: function(e) {
                    $("#loader").addClass("hidden");
                    $('body').removeClass("backDisabled");
                    $('#add-to-wishlist').modal('hide');
                    //createwish();
                },
            });
        }
    } else if ($(".childcheckbox-wish:checked").length == 0) {
        $('#add-to-wishlist').modal('hide');
        var msg = 'Please select at least one product to copy items between wishlists';
        respMsgDisplay(202, msg);
    }
});

$(document).on('click', '#copyWishList1', function() {
    $('.prod-wish-create').css('display', 'inline-flex');
    $(".form-control.copywishlist").attr('disabled', 'disabled');
    $("#newWishlist").removeAttr('disabled');
});
$(document).on('click', '#copyWishList2', function() {
    $('.prod-wish-create').css('display', 'none');
    $("#newWishlist").attr('disabled', 'disabled');
    $(".form-control.copywishlist").removeAttr('disabled');
});

//end


//create wishlist

$(document).on("click", ".create-button-wish", function() {
    $("#alreadyexists-wish").text("");
    $("#alreadyexists-wish").hide();
    if ($("#wListname").val().trim() !== "") {
        createwish();
    } else {
        $(".message").text("Please enter name of wishlist").css("color", "red");
        $("#alreadyexists-wish").show();
    }
});

function createwish() {
    var data = {
        wishlistName: $("#wListname").val().trim(),
        visibility: $('input[name="wishlistradio"]:checked').val(),
        resourcePath: $("#resourcePath").val(),
    };
    var jsonData = JSON.stringify(data);

    $.ajax({
        type: "POST",
        url: "/bin/createMercWishlistServlet",
        ContentType: "application/json",
        data: {
            data: jsonData,
        },
        beforeSend: function() {
            $("#loader").removeClass("hidden");
            $('body').addClass("backDisabled");
        },
        success: function(data) {
            if (data.includes("exists")) {
                $("#create-wishlist").modal("show");
                $("#alreadyexists-wish").text(data);
                $("#alreadyexists-wish").show();
            } else {
                $("#create-wishlist").modal("hide");
                window.location.reload(true);
            }
        },
        complete: function() {
            $("#loader").addClass("hidden");
            $('body').removeClass("backDisabled");
        },
        error: function(jqXHR, exception) {
            $("#loader").addClass("hidden");
            $('body').removeClass("backDisabled");
            var msg = '';
            if (jqXHR.status === 0) {
                msg = 'Not connect.\n Verify Network.';
            } else if (jqXHR.status == 404) {
                msg = 'Requested page not found. [404]';
            } else if (jqXHR.status == 500) {
                msg = 'Internal Server Error [500].';
            } else if (exception === 'parsererror') {
                msg = 'Requested JSON parse failed.';
            } else if (exception === 'timeout') {
                msg = 'Time out error.';
            } else if (exception === 'abort') {
                msg = 'Ajax request aborted.';
            } else {
                msg = 'Uncaught Error.\n' + jqXHR.responseText;
            }
            console.log(msg);
        },
    });
}

//remove wishlist 
function confirmRemove() {
    if ($(".mm-wishlist-table input:checkbox:checked").length > 0) {
        $("#remove-product").modal('show');
    }
}

$(document).on("click", ".delete-wish", function() {
    var data = {
        wishlistIds: $(this).attr("wishlistid"),
        resourcePath: $("#resourcePath").val(),
    };
    var reload = 1;
    removeWishlistCall(data, reload);
});

$(document).on("click", ".deletewish", function() {
    var wishlistid;
    $(".mm-wishlist-table  input[type=checkbox]:checked").each(function(index) {
        if ($(this).attr("wishlistid") !== "") {
            if (index > 0) {
                wishlistid = wishlistid + $(this).attr("wishlistid");
            } else {
                wishlistid = $(this).attr("wishlistid");
            }
            var temp = wishlistid + ",";
            wishlistid = temp;
        }
    });
    if (wishlistid !== undefined) {
        var data = {
            wishlistIds: wishlistid,
            resourcePath: $("#resourcePath").val(),
        };
        removeWishlistCall(data);
    }
});

function removeWishlistCall(data, reload = 0) {
    var jsonData = JSON.stringify(data);
    console.log("remove " + jsonData);
    $.ajax({
        type: "POST",
        url: "/bin/removeMercWishlistServlet",
        ContentType: "application/json",
        data: {
            data: jsonData,
        },
        beforeSend: function() {
            $("#loader").removeClass("hidden");
            $('body').addClass("backDisabled");
        },
        success: function(data) {
            if (data) {
                data = JSON.parse(data);
            }
            if (data && data.deleteWishlist && data.deleteWishlist.user_errors) {
                var msg = 'Default Wish List cannot be deleted.';
                respMsgDisplay(202, msg);
                if (reload == 1) {
                    location.reload();
                } else {
                    loadCustomerWishlists();
                }
            } else {
                $("#remove-product").modal('hide');
                //analytics
                if (data != null && data.deleteWishlist.status == true) {
                    var productDetailsArray = [];
                    var wishlistID = JSON.parse(jsonData);
                    var wisharry = wishlistID.wishlistIds.split(',');
                    wisharry.forEach((element, index) => {
                        if (element != null && element != "") {
                            var product = {
                                "productQuantity": $("#" + element).val(),
                                "productInfo": {
                                    "productID": element,
                                    "productName": $(".wishdetails_" + element).html(),
                                }
                            };

                            productDetailsArray.push(product);
                        }

                    });

                    reomveWishlist = {};
                    reomveWishlist['product'] = productDetailsArray;
                    digitalData["removeWishlist"] = reomveWishlist;
                    _satellite.track('Remove wishlist', { linkName: $(".removeanalytic").html() });
                }
                if (reload == 1) {
                    location.reload();
                } else {
                    var msg = 'Wish List deleted successfully';
                    respMsgDisplay(200, msg);
                    loadCustomerWishlists();
                }
            }
        },
        complete: function() {
            $("#loader").addClass("hidden");
            $('body').removeClass("backDisabled");
        },
        error: function(e) {
            $("#loader").addClass("hidden");
            $('body').removeClass("backDisabled");
        },
    });
}

//remove wishlist product function
$(document).on("click", ".remove-prod", function() {
    if ($(".wishlist-table-product input:checkbox:checked").length > 0) {
        $("#remove-wish-product-details").modal('show');
    } else {
        var msg = 'Please select at least one product to remove';
        respMsgDisplay(202, msg);
    }
});


// back to wishlist function
$(document).on("click", ".back-button-wish", function() {
    window.location.reload(true);
});