"use strict";
use(function () {
    if (this.value != null) { return parseFloat(this.value / 1000).toFixed(4); } return this.value;
});

