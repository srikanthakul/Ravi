"use strict";
use(function(){
	if(this.value != null && this.value <=10 ){
		if(this.value.toString().startsWith(".")){
		let temp = "0"+this.value.toString();
		return temp;
		}
		return this.value;
	}else{
		return 'Over 10';
	}
	
});