$(document).ready(function() {
    if($(".initialCartProdPrice").html() != ""){
    $(".initialCartProdPrice").html(parseFloat($(".initialCartProdPrice").html()).toFixed(2));
	}
	//analytics
	var productArray = [];

        var product = {

            productInfo: {

                productID: $("#sku-pdp").html().trim(),

                productName: $("#name-pdp").html().trim(),

            }

        }

        productArray.push(product);

        if (typeof digitalData != "undefined") {

            digitalData.product = productArray;

        }
		
    $(".page-title").html($("#name-pdp").html().trim());

    digitalData.page.pageInfo["pageName"] = pageNameVal+":"+$("#name-pdp").html().toLowerCase().trim();

    $('#itemAvailability').on('input',function() {
        this.value = this.value.toUpperCase();
    });

    var initialCartPrice = ($(".initialCartProdPrice").html() * toNumeric($(".product-details-right-qty-no").html()));
    $(".cartProdPrice").empty();
    $(".cartProdPrice").append("$" + parseFloat(initialCartPrice).toFixed(2));

    $(".pd-supersession-btn").on("click", function() {
        var data = {
            resourcePath: $("#resourcePath").val(),
            itemNumber: $("#sku-pdp").html().trim()
        };

        $.ajax({
            type: "POST",
            url: "/bin/merclink/productSupersession",
            ContentType: "application/json",
            data: {
                data: JSON.stringify(data),
            },
            beforeSend: function() {
                $("#loader").removeClass("hidden");
                $('.product-details-pd').addClass("backDisabled");
            },
            success: function(data) {

                if (data != null && data.data != null && data.data.supersession_chain != "") {
                    var supersessionArray = data.data.supersession_chain;
                    var count = 1;
                    var j = 0;
                    $("#supersessionData").empty();
                    $("#supersessionData").append('<tr class="table-secondary"><th scope="col" class="product-details-supersession-table__row">Row</th><th scope="col" class="product-details-supersession-table__class">Class</th><th scope="col" class="product-details-supersession-table__part">Part Number</th><th scope="col" class="product-details-supersession-table__ss">SS Level</th><th scope="col" class="product-details-supersession-table__disp">Disp</th><th scope="col" class="product-details-supersession-table__desc">Description</th></tr>');
                    for (var i = (supersessionArray.length - 1); i >= 0; i--) {
                        var str = "" + j;
                        var pad = "00"
                        var ans = pad.substring(0, pad.length - str.length) + str;
                        $("#supersessionData").append('<tr><td scope="col" class="product-details-supersession-table__row">' + count + '</td><td scope="col" class="product-details-supersession-table__class">-</td><td scope="col" class="product-details-supersession-table__part">' + supersessionArray[i].item_number + '</td><td scope="col" class="product-details-supersession-table__ss">' + ans + '</td><td scope="col" class="product-details-supersession-table__disp">' + supersessionArray[i].status + '</td><td scope="col" class="product-details-supersession-table__desc">' + supersessionArray[i].description + '</td></tr>');
                        count++;
                        j++;
                    }
                }
            },
            complete: function() {
                $("#loader").addClass("hidden");
                $('.product-details-pd').removeClass("backDisabled");
            },
            error: function(e) {
                $("#loader").addClass("hidden");
                $('.product-details-pd').removeClass("backDisabled");
                console.log(e);
                var msg = 'Something Went wrong. Please try again';
                respMsgDisplay(202, msg);
            }
        });
    })

    $(".searcAvailability").on("click", function() {
        if ($("#itemAvailability").val() == "") {
            var msg = 'Please enter the Item Number.';
            respMsgDisplay(202, msg);
        } else {
            var data = {
                resourcePath: $("#resourcePath").val(),
                itemNumber: $("#itemAvailability").val()
            };
            $.ajax({
                type: "POST",
                url: "/bin/merclink/productAvailability",
                ContentType: "application/json",
                data: {
                    data: JSON.stringify(data),
                },
                beforeSend: function() {
                    $("#loader").removeClass("hidden");
                    $('.product-details-pd').addClass("backDisabled");
                },
                success: function(data) {
                    if(data.products.items.length <= 0){
						var msg = 'Invalid Item Number';
						respMsgDisplay(202,msg);
					}else if(data.products.items.length > 0 && data.products.items !=null){
						if (typeof digitalData != "undefined") {

								_satellite.track('pdpsearch', { linkName: $(".searcAvailability").html().trim() ,availabilitySearchTerm : $("#itemAvailability").val() });

						}
						 var redirectLocation = location.href.split('?')[0];
						parent.location.href = redirectLocation+"?sku="+data.products.items[0].sku;
						return false;
					}else{
						var msg = 'Invalid Item Number';
						respMsgDisplay(202,msg);
					}

                },
                complete: function() {
                    $("#loader").addClass("hidden");
                    $('.product-details-pd').removeClass("backDisabled");
                },
                error: function(e) {
                    $("#loader").addClass("hidden");
                    $('.product-details-pd').removeClass("backDisabled");
                    console.log(e);
                    var msg = 'Something Went wrong. Please try again';
                    respMsgDisplay(202, msg);
                }
            });
        }
    });


    $(".pd-add-to-cart-btn").click(function() {
        var cartArray = [];

        var cartobj = {
            "skuid": $("#sku-pdp").html().trim(),
            "quantity": parseInt($("#total-product-qty").val()).toString()
        }
        cartArray.push(cartobj);

        console.log(cartArray);
        if (cartArray.length > 0) {
            var data = {
                "componentPath": $("#resourcePath").val(),
                cartId: getCookie("cartId"),
                cartobj: cartArray
            }

            $.ajax({
                type: "POST",
                url: "/bin/cart/addToCartQuery",
                ContentType: "application/json",
                dataType: "json",

                data: {
                    'data': JSON.stringify(data)
                },
                success: function(data) {
                    if (data && data.addProductsToCart) {
                        if (data.addProductsToCart.cart && data.addProductsToCart.cart.items && data.addProductsToCart.cart.items.length > 0) {
                            $(".cart-item-display-number").html(data.addProductsToCart.cart.items.length);
                            setCookie("cartCount", data.addProductsToCart.cart.items.length, 30);

                            var sendSkuId = cartArray.map(element => element.skuid);
                            var matchedCartItemArray = data.addProductsToCart.cart.items.filter(element => sendSkuId.indexOf(element.product.sku) != -1);
                            var matchedCartItem = matchedCartItemArray.map(element => element.product.sku);
                            if (matchedCartItem.length > 0) {
                                var msg = 'Item(s) added to your shopping cart';
                                var productDetailsArray = [];
                                matchedCartItemArray.forEach((element, indexe) => {
                                    var quantityFilter = cartArray.filter(cartElement => cartElement.skuid == element.product.sku);
                                    var productDetails = {
                                        "productQuantity": quantityFilter.length > 0 ? quantityFilter[0].quantity : 0,
                                        "productInfo": {
                                            "productID": element.product.sku,
                                            "productName": element.product.name,
                                        }
                                    };
                                    productDetailsArray.push(productDetails);
                                });
                                addToCartlist = {};
                                addToCartlist['product'] = productDetailsArray;
                                digitalData["addtoCart"] = addToCartlist;
                                _satellite.track('Add to cart', { linkName: $(".pd-add-to-cart-btn").val() });
                                respMsgDisplay(200, msg);
                                }
                        }
                        var errMsg = "";
                        if (data.addProductsToCart.cart && data.addProductsToCart.cart.erp_errors && data.addProductsToCart.cart.erp_errors.length > 0) {
                            data.addProductsToCart.cart.erp_errors.forEach((element) => {
                                errMsg += element.message + ", "
                            });
                        }

                        if (data.addProductsToCart.user_errors != null && data.addProductsToCart.user_errors.length > 0) {
                            data.addProductsToCart.user_errors.forEach((element) => {
                                errMsg += element.message + ", "
                            });
                        }

                        if (errMsg.length > 0) {
                            respMsgDisplay(202, errMsg);
                        }
                    } else if (data && data.createCartId) {
                        respMsgDisplay(202, data.createCartId);
                    }

                },
                error: function(status, errorthrown) {
                    var msg = 'Something Went wrong. Please try again';
                    respMsgDisplay(202, msg);
                }
            });
        }
    });

    $(".product-details-hide-price").click(function() {
        $(".product-details-hide-price").addClass("d-none");
        $(".product-details-show-price").removeClass("d-none");
        $(".pd-buy-price").addClass("d-none");
        $(".pd-hide-show").addClass("d-none");
        $(".product-details-list-buy").css("width", "50%");

    });

    $(".product-details-show-price").click(function() {
        $(".product-details-show-price").addClass("d-none");
        $(".product-details-hide-price").removeClass("d-none");
        $(".pd-buy-price").removeClass("d-none");
        $(".pd-hide-show").removeClass("d-none");
        $(".product-details-list-buy").css("width", "100%");
    });

    $(".tooltip-box").click(function() {
        $(this).parent().addClass("tooltip-open");
    });



    $(".tooltip-close").click(function() {
        $(this).parents().removeClass("tooltip-open");
    });

    $("#total-product-qty").on("change", function() {
        var qty = this.value;
        if (qty != "") {
            var minQty = $(".product-details-right-qty-no").html();
            var buyPrice = $(".initialCartProdPrice").html();
            if (toNumeric(qty) % toNumeric(minQty) != 0) {
                var nearestQty = Math.ceil(qty / minQty) * minQty;
                $("#total-product-qty").val(nearestQty);
            }
            if (qty != "0") {
                var currentQty = $("#total-product-qty").val();
            } else {
                var currentQty = toNumeric($(".product-details-right-qty-no").html());
                $("#total-product-qty").val(toNumeric($(".product-details-right-qty-no").html()));
            }
            var finalBuyPrice = buyPrice * (toNumeric(currentQty));
            finalBuyPrice = parseFloat(finalBuyPrice).toFixed(2);
            if (finalBuyPrice != undefined && finalBuyPrice != null) {
                $(".cartProdPrice").empty();
                $(".cartProdPrice").append("$" + finalBuyPrice);
            }
        } else {
            $(".cartProdPrice").empty();
            $("#total-product-qty").val(toNumeric($(".product-details-right-qty-no").html()));
            $(".cartProdPrice").append("$" + parseFloat(initialCartPrice).toFixed(2));
        }
    });

});

function toFloat(decimal) {
    if (decimal != undefined && decimal != null)
        return (Math.round(decimal * 100) / 100).toFixed(2)
}


function toNumeric(numb) {
    if (numb != undefined && numb != null)
        return parseInt(numb.toString().replace(/[^0-9\.]+/g, ""));
}

function respMsgDisplay(statusCode, message, ) {
    if (statusCode == 200) {
        $(".mm-success-msg span").empty();
        $(".mm-success-msg span").text("" + message + "");
        $(".mm-success-msg").removeClass("d-none");
        $(".mm-success-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-success-msg").offset().top
        }, 'slow');
        setTimeout(function() {
            $(".mm-success-msg").fadeOut("slow");
        }, 3000);
    } else if (statusCode == 202) {
        $(".mm-error-msg span").empty();
        $(".mm-error-msg span").text("" + message + "");
        $(".mm-error-msg").removeClass("d-none");
        $(".mm-error-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-error-msg").offset().top
        }, 'slow');
        setTimeout(function() {
            $(".mm-error-msg").fadeOut("slow");
        }, 3000);
    }
}


function addtoWishListItem() {
    var itemStatus = "available"; //$("#pdp-item-status").val();   value from magento
    var packageQuantity = $("#quantity-in-package").val(); // keep empty if multiple products is been added into wishlist or $("#quantity-in-package").val();


    var addingType = "singleItem"; // values : addfromcart or singleItem || values to choose between multiple product or single
    var productQty = $("#total-product-qty").val(); // keep empty if multiple products is been added into wishlist or $("#total-product-qty").val();
    var productArray = "";
    var addToWLResponse = AddProductToWishL(productArray, addingType, productQty, itemStatus, packageQuantity)


    addToWLResponse.success(function(data) {
        if (data.alreadyExists) {
            var msg = '' + data.alreadyExists + '';
            respMsgDisplay(202, msg);
        } else {
            var msg = "Item(s) have been added to your wish list : " + data["wishlistname"] + "";
            respMsgDisplay(200, msg);
        }
		//analytics

            if(data!=null && data.wishlisttype != null){

                var productDetailsArray = [];
				var descriptionwish = $("#name-pdp").html().trim();
				var productDetails = {

                        "productQuantity": data.quantity > 0 ? data.quantity : 0,

                        "productInfo": {

                            "productID": data.skuid,

                            "productName": descriptionwish,

                        }

                    };
				 productDetailsArray.push(productDetails);


                addToWishlist = {};

                addToWishlist['product'] = productDetailsArray;

				if (typeof digitalData != "undefined") {

					digitalData["addtoWishlist"] = addToWishlist;

					_satellite.track('Add to wishlist', { linkName: "Add To Wish List" });

				}

            }
    });
    addToWLResponse.error(function(e) {
        $("#loader").addClass("hidden");
        $('.product-details-pd').removeClass("backDisabled");
        console.log(e);
        var msg = 'Something Went wrong. Please try again';
        respMsgDisplay(202, msg);
    });
}