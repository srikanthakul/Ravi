"use strict";
use(function(){
	if(this.value != null){
		if(this.value.toString().startsWith(".")){
		let temp = "0"+this.value.toString();
		return parseFloat(temp).toFixed(2);
		}
	}
	return this.value;
});