"use strict";
use(function(){
	if(this.value != null){
		this.value = this.value.substring(0, this.value.length - 1);
		let n = parseInt(this.value);
		return n.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,") + "+";
	}
	return this.value;
});