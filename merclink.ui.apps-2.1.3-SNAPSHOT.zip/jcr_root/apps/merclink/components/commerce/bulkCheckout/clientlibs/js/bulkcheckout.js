// BulkCheckout.js
let shippingAddressList;
let customerAddressId;
let coupons = [];
let loaderCount = 0;
 
$(document).ready(function() {

    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
  // Warning message is not displayed for future requested ship date is greater than 180 days - Start
    $("#shippingdate").change(function() {
        var date = $("#shippingdate").val();
        var datearray = date.split("-");
        var selectedDate = datearray[2] + '-' + datearray[1] + '-' + datearray[0];
        $('#warningmessageDate').addClass('d-none');
        if ($("#shippingdate").val() != "") {
            var daysDiff =((new Date(selectedDate).getTime() - new Date().getTime()) /(1000 * 3600 * 24));
            if (Math.round(daysDiff) > 180) {
                $('#warningmessageDate').removeClass('d-none');
                $('#messagedisplay-warning').html("ship date is greater than 180 days");
                window.scrollTo(0, 0);
            }
        }
    });
    // Warning message is not displayed for future requested ship date is greater than 180 days - End      
    $(".datepicker").datepicker({
        autoclose: true,
        startDate: new Date(),
        todayHighlight: true
    }).datepicker('update', new Date());    
    $('input[type=radio][name=radio-3]').change(function() {
       dropHideShow();
    });
    createbulkCartId();
    $("#totalweight").html("0 kg");

}); 

function cartquery(getDataVal,bulkCartId) {
    var data = {
        "componentPath": $("#resourcePath").val(),
        "cartId": bulkCartId,
        "item": getDataVal
    }
    $.ajax({
        type: "POST",
        url: "/bin/cart/bulkCartQuery",
        ContentType: 'application/json',
        data: {
            'data': JSON.stringify(data)
        },
        beforeSend: function() {
            $("body").append("<div id='loader8' class='overlay lds-dual-ring1' ></div>");
        },
        success: function(data) {
            if (data != null && data.cartQuery != null) {
                var msg = data.cartQuery;
                respMsgDisplay(202, msg);
            }
            if (data != null && data.cart != null) {
                localStorage.setItem("checkoutDetails", JSON.stringify(data));
                cartDataAnalytics = data.cart.item ? data.cart.item : JSON.parse(localStorage.getItem("cartDetails"));
                    diplayShipAddress(data);
                    diplayBillAddress(data);
                    diplayPaymentType(data);
                	setShippingMethodData(data);               
            }

        },
        complete: function() {
            $("#loader8").remove();
        },
        error: function(jqXHR, exception) {
            handleAjaxExceptionMessage(jqXHR, exception);
        }
    });
}

function Selectaddress() {
    $('#change-address').modal('hide');
    let addressId = document.getElementById("shipaddress").value;
    if (addressId != customerAddressId) {
        var index = shippingAddressList.findIndex((v) => v.customer_address_id == addressId);
        var customerShipDetails = {
            cartId: getCookie("cartId"),
            "firstname": shippingAddressList[index].name.split(" ")[0],
            "lastname": shippingAddressList[index].name.split(" ").length > 1 ? shippingAddressList[index].name.split(" ").splice(1).toString().split(",").join(" ") : shippingAddressList[index].name.split(" ")[0],
            "company": "",
            "address1": shippingAddressList[index].street[0] ? shippingAddressList[index].street[0].replaceAll("/", '-').replaceAll(/[^a-zA-Z.,0-9- ]/g, " ").replaceAll("  ", " ") : "",
            "city": shippingAddressList[index].city ? shippingAddressList[index].city : "",
            "regioncode": shippingAddressList[index].region ? shippingAddressList[index].region : "",
            "postalcode": shippingAddressList[index].postal_code ? shippingAddressList[index].postal_code : "",
            "country": shippingAddressList[index].country_code ? shippingAddressList[index].country_code : "",
            "telephone": "8675309",
            "addressbook": false,
            "companyAddrId": shippingAddressList[index].customer_address_id ? parseInt(shippingAddressList[index].customer_address_id) : "",
            "resourcePath": $("#resourcePath").val()
        }
        $.ajax({
            type: "POST",
            url: "/bin/setShippingaddresstocartML",
            ContentType: "application/json",
            data: {
                data: JSON.stringify(customerShipDetails),
            },
            beforeSend: function() {
                enableDisableLoader(true);
            },
            success: function(data) {
                if (data.cart && data.cart.shipping_addresses.length > 0) {
                    $("#warningAddress").addClass('d-none');
                    var x = shippingAddressList[index]['full_address'];
                    i = 0;
                    x = x.replace(/\n/g, m => !i++ ? m : ', ').replaceAll(" , ", ", ");
                    $('#change-address').modal('hide');
                    $("#shippingAddress").val(x);
                } else {
                    var msg = data.checkoutError;
                    respMsgDisplay(200, msg);
                }
            },
            complete: function() {
                enableDisableLoader(false);
            },
            error: function(jqXHR, exception) {
                handleAjaxExceptionMessage(jqXHR, exception);
            }
        });
    }
}
	
function diplayShipAddress(data) {
    if (data.cart.shipping_addresses) {
        var shippingAddressDisplay = data.cart.shipping_addresses != null ? data.cart.shipping_addresses : [];
        customerAddressId = data.cart.shipping_addresses[0].company_address_id != null ? data.cart.shipping_addresses[0].company_address_id : '';
        for (var i = 0; i < shippingAddressDisplay.length; i++) {
            $("#shippingAddress").val(shippingAddressDisplay[i]['street'] + "\n" + shippingAddressDisplay[i]['city'] + ", " + shippingAddressDisplay[i]['region']['code'] + ", " + shippingAddressDisplay[i]['country']['code']);
        }
    }
}

function Shippingaddress() {
    var selectedCustomer = getCookie("selectedCustomer");
    var data = {
        resourcePath: $("#resourcePath").val(),
        customerNumber: parseInt(selectedCustomer)
    }
    $.ajax({
        type: "GET",
        url: "/bin/merclink/getAddressesServlet",
        ContentType: "application/json",
        async: true,
        data: {
            data: JSON.stringify(data),
        },
        beforeSend: function() {
            enableDisableLoader(true);
        },
        success: function(data) {
            if (data != null && data.data != null) {
                shippingAddressList = data.data;
                var addressListOptions = "";
                addressListOptions = "<option value='' selected disabled>Select Address</option>";
                for (var i = 0; i < shippingAddressList.length; i++) {
                    if (customerAddressId == shippingAddressList[i]['customer_address_id']) {
                        var addressSelected = "selected";
                    } else {
                        var addressSelected = shippingAddressList[i]['primary_flag'] == true ? "selected" : '';
                    }
                    if (shippingAddressList[i]['address_type'] == "shipping") {
                        addressListOptions += "<option value='" + shippingAddressList[i]['customer_address_id'] + "' " + addressSelected + ">" + shippingAddressList[i]['full_address'] + "</option>";
                    }
                }
                $("#shipaddress").html(addressListOptions);
            }
        },
        complete: function() {
            enableDisableLoader(false);
        },
        error: function(jqXHR, exception) {
            handleAjaxExceptionMessage(jqXHR, exception);
        }
    });
}
function diplayBillAddress(data) {
    if (data.cart.billing_address) {
        $("#billingAddress").val(data.cart.billing_address.street + "\n" + data.cart.billing_address.city + ", " + data.cart.billing_address.region.code + ", " + data.cart.billing_address.postcode + ", " + data.cart.billing_address.country.code);
    }
}

function diplayPaymentType(data) {
    if (data.cart.available_payment_methods) {
        var paymentMethods = data.cart.available_payment_methods.filter(element => element.code != "chcybersource" && element.code != "wellsfargo");
        var paymentMethodsOption = "";
        for (var i = 0; i < paymentMethods.length; i++) {
            paymentMethodsOption += '<div class="form-check form-check-inline ps-0 my-1"><input class="form-check-input ms-0 mt-0" type="radio" name="radio-2" id="radio_' + paymentMethods[i] + '" value="' + paymentMethods[i]["code"] + '" > <label class="form-check-label ms-2 mb-0" for="on-account">' + paymentMethods[i]["title"] + '</label></div>';
        }
        $("#paymentRadio").html(paymentMethodsOption);
    }
}

function setShippingMethodData(data) {
    var shipping_method = data.cart.shipping_addresses;
    if (getCookie("completeAccountDetails")) {
        var dropshipinfo = JSON.parse(getCookie("completeAccountDetails"));
        var selectedCustomer = getCookie("selectedCustomer");
        var dropShipSelect = dropshipinfo.filter(element => element.company_number == selectedCustomer);
        if (dropShipSelect.length > 0 && dropShipSelect[0].dropship == 1) {
            $('#dropShipCustomer').removeClass('d-none');
            dropHideShow();
        }
    }
    if ($("#Method").val() == null || $("#Method").val() == '') {
        $("#Method").val("Select Method");
    }
}

function dropHideShow() {
    if ($("input[name='radio-3']:checked").val() == "drop-ship-yes") {
        $("#Method").prop("disabled", false);
        if ($("#Method").val() != "Sea") {
            $("#Method").val("Sea");
        }
    } else {
        $("#Method").prop("disabled", false);
    }
}

function displayCouponCode(code) {
    if (code != null) {
        var index = coupons.findIndex((val) => val.value == code);
        if (index >= 0) {
            $("#couponCode").val('');
            $("#promotionsError").html("Entered coupon code has already been used");
            setTimeout(() => {
                $("#promotionsError").html("");
            }, 10000);
            return false;
        }
        var ranId = Math.random().toString(16).slice(2);
        coupons.push({
            id: ranId,
            value: code
        });
        $("#promotions").html("Applied Coupons");
        $("#couponList").append('<div class="d-flex align-items-end justify-content-between" id="appliedCouponList_' + ranId + '"><a href="#" class="sale promotions">' + code + '</a> <a href="#" class="remove promotions" id="removeId" onclick="removeCoupon(event)">Remove</a></div>');
        $("#appliedCouponList_" + ranId).removeClass('d-none');
        $("#couponCode").val("")
        $("#promotionsError").html("");
    } else {
        if (coupons.length == 0) {
            return false;
        }
        var parentId = event.target.parentElement.id;
        document.getElementById(parentId).remove();
        var randId = parentId.split('_');
        var index = coupons.findIndex((val) => val.id == randId[1])
        coupons.splice(index, 1);
        $("#promotionsError").html("");
        if (coupons.length == 0) {
            $("#promotions").html("");
        }
    }
}

function invalidCouponCode(code) {
    if (code != null) {
        $("#couponCode").val('');
        $("#promotionsError").html("Coupon code is not valid");
        setTimeout(() => {
            $("#promotionsError").html("");
        }, 10000);
    }
}

function applyCoupon() {
    if (coupons.length > 4) {
        $("#promotionsError").html("Maximum number of coupons has been reached");
        $("#couponCode").val('');
        setTimeout(() => {
            $("#promotionsError").html("");
        }, 10000);
        return false;
    }
    if (document.getElementById("couponCode").value == '') {
        $("#promotionsError").html("Enter coupon code");
        setTimeout(() => {
            $("#promotionsError").html("");
        }, 10000);
        return false;
    }
    var data = {
        resourcePath: $("#resourcePath").val(),
        couponNumber: encodeURIComponent(document.getElementById("couponCode").value)
    }
    $.ajax({
        type: "GET",
        url: "/bin/merclink/getValidCoupon",
        ContentType: "application/json",
        data: {
            data: JSON.stringify(data),
        },
        beforeSend: function() {
            enableDisableLoader(true);
        },
        success: function(data) {
            if (data && data.data) {
                if (data.data.validity_flag && data.data.validity_flag == true) {
                    displayCouponCode(decodeURIComponent(data.data.coupon_code));
                } else {
                    invalidCouponCode(decodeURIComponent(data.data.coupon_code));
                }
            } else {
                invalidCouponCode(decodeURIComponent(document.getElementById("couponCode").value));
            }
        },
        complete: function() {
            enableDisableLoader(false);
        },
        error: function(jqXHR, exception) {
            handleAjaxExceptionMessage(jqXHR, exception);
        }
    });
}

function removeCoupon(e) {
    e = e || window.event;
    e.preventDefault();
    displayCouponCode(null);
}

function enableDisableLoader(loading) {
    if (loading) {
        loaderCount += 1;
        $('#loader').removeClass('hidden');
        $("body").addClass("backDisabled");
    } else {
        loaderCount -= 1;
        if (loaderCount <= 0) {
            $('#loader').addClass('hidden');
            $("body").removeClass("backDisabled");
        }
    }
}

function handleAjaxExceptionMessage(jqXHR, exception) {
    var msg = '';
    if (jqXHR.status === 0) {
        msg = 'Not connect.\n Verify Network.';
    } else if (jqXHR.status == 404) {
        msg = 'Requested page not found. [404]';
    } else if (jqXHR.status == 500) {
        msg = 'Internal Server Error [500].';
    } else if (exception === 'parsererror') {
        msg = 'Requested JSON parse failed.';
    } else if (exception === 'timeout') {
        msg = 'Time out error.';
    } else if (exception === 'abort') {
        msg = 'Ajax request aborted.';
    } else {
        msg = 'Uncaught Error.\n' + jqXHR.responseText;
    }
    respMsgDisplay(202, msg);
    return false;
}

function respMsgDisplay(statusCode, message) {
    if (statusCode == 202) {
        $(".mm-error-msg span").empty();
        $(".mm-error-msg span").text("" + message + "");
        $(".mm-error-msg").removeClass("d-none");
        $(".mm-error-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-error-msg").offset().top
        }, 'slow');
        setTimeout(function() {
            $(".mm-error-msg").fadeOut("slow");
        }, 20000);
    } else if (statusCode == 503) {
        $(".mm-error-msg span").empty();
        $(".mm-error-msg span").text("" + message + "");
        $(".mm-error-msg").removeClass("d-none");
        $(".mm-error-msg").fadeIn("slow");
        $('html,body').animate({
            scrollTop: $(".mm-error-msg").offset().top
        }, 'slow');
        setTimeout(function() {
            $(".mm-error-msg").fadeOut("slow");
        }, 20000);
    }
}

