$(document).ready(function() {
    $('.wish-list-create-type').css('display', 'none');
	if($("input[name=copyWishList]:checked").val() == "newwish"){
		$(".form-control.existingWishList").attr('disabled','disabled');
		$("#newWishlistName").removeAttr('disabled');
	}else if($("input[name=copyWishList]:checked").val() == "existwish"){
		$("#newWishlistName").attr('disabled','disabled');
		$(".form-control.existingWishList").removeAttr('disabled');
	}
});

function getWishlistModal() {
    var data = {
        resourcePath: $("#resourcePath").val(),
		pageSize : "0",
        currentPage : "0",
    };
    $.ajax({
        type: "GET",
        url: "/bin/getMercCustomerWishlists",
        ContentType: "application/json",
        data: {
            data: JSON.stringify(data),
        },
		beforeSend: function() {
            $("#loader").removeClass("hidden");
            $('body').addClass("backDisabled");
        },
        success: function(data) {
            if(data.customer != null || data.customer.length > 0){
            if (null != data.customer.wishlists && data.customer.wishlists.length > 0) {
                var wishlists = data.customer.wishlists.reverse();
                $('#add-to-wishlist-modal .existingWishList').empty();
                for (var i = 0; i < wishlists.length; i++) {
                    var wishlistid = wishlists[i].id;
                    var wishlistName = wishlists[i].name;
                    $('#add-to-wishlist-modal .existingWishList').append("<option id = " + wishlistid + " value = " + wishlistName + " >" + wishlistName + "</option>");

                }
            } else {
                $("#add-to-wishlist-modal .existingWishList").empty();
                $("#add-to-wishlist-modal .existingWishList").append("<option value ='empty' >No Wishlist Available</option>");
            }
            }else{
                $("#add-to-wishlist-modal .existingWishList").empty();
                $("#add-to-wishlist-modal .existingWishList").append("<option value ='empty' >No Wishlist Available</option>");
            }
        },
        complete: function() {
            $("#loader").addClass("hidden");
            $('body').removeClass("backDisabled");
        },
        error: function(e) {
            $("#loader").addClass("hidden");
            $('body').removeClass("backDisabled");
            console.log(e);
        }
    });
    $("#add-to-wishlist-modal").modal("show");
}

function WishListCount(){
	var data = {
        resourcePath: $("#resourcePath").val(),
    };
    $.ajax({
        type: "GET",
        url: "/bin/getMercCustomerWishlists",
        ContentType: "application/json",
        data: {
            data: JSON.stringify(data),
        },
        success: function(data) {
            var wishlists = data.responseData.wishlists;
			if (null != wishlists && wishlists.length > 0) {
                $(".wishCount").append(wishlists.length);
            	$(".wishCount").show();
			} else {
                $(".wishCount").append("0");
            	$(".wishCount").show();
            }
        },
        error: function(data) {
            console.log("e");
        }
    });
}

function AddProductToWishL(productArray = "", addingType = "", productQty="", itemStatus, packageQuantity="") {
    $("#add-to-wishlist-modal").modal("hide");
    $(".mm-error-msg span").html("");
    var data = {};
    if (addingType == "addfromcart") {
        data["cartobj"] = productArray;
    } else if (addingType == "singleItem") {
        data["skuid"] = $("#sku-pdp").text();
        data["quantity"] = productQty.toString();
    }
    if ($("#add-to-new-wishlist").is(":checked") && $("#newWishlistName").val() == ""){
        $(".mm-error-msg span")
        .append("Please enter the Wishlist Name.");
        $(".mm-error-msg").removeClass("d-none");
        $(".mm-error-msg").fadeIn("slow");
        setTimeout(function() {
            $(".mm-error-msg").fadeOut("slow");
        }, 3000);
    }else{
    if ($("#newWishlistName").val() !== "" || $(".existingWishList").find(":selected").text() != "Select") {
        data["wishlisttype"] = $("input[name=copyWishList]:checked").val();
        data["resourcePath"] = $("#resourcePath").val();
        if ($("#add-to-existing-wishlist").is(":checked")) {
            data["wishlistname"] = $(".existingWishList")
                .find(":selected")
                .text();
            var id = $(".existingWishList")
                .find(":selected")
                .attr("id");
            data["id"] = id;
        } else if ($("#add-to-new-wishlist").is(":checked")) {
            data["wishlistname"] = $("#newWishlistName").val();
            data["listtype"] = $(
                "input[name=newWishListType]:checked"
            ).val();
        }
            var jsonData = JSON.stringify(data);
            return $.ajax({
                type: "POST",
                url: "/bin/addToMercWishlist",
                ContentType: "application/json",
                data: {
                    data: jsonData,
                    type: addingType,
                },
            });
    }
}
}




function toNumeric(numb) {
    if (numb != undefined && numb != null)
        return parseInt(numb.toString().replace(/[^0-9\.]+/g, ""));
}

$(document).on('click', '#add-to-new-wishlist', function() {
    $('.wish-list-create-type').css('display', 'flex');
    $(".form-control.existingWishList").attr('disabled','disabled');
	$("#newWishlistName").removeAttr('disabled');
});
$(document).on('click', '#add-to-existing-wishlist', function() {
    $('.wish-list-create-type').css('display', 'none');
    $("#newWishlistName").attr('disabled','disabled');
	$(".form-control.existingWishList").removeAttr('disabled');
});